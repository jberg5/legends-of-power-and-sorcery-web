"""Hex grid math using cube coordinates (flat-top orientation).

Internally we use cube coords (q, r, s where q+r+s=0).
For the battlefield display we convert to/from odd-q offset coords.
"""

from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class CubeCoord:
    q: int
    r: int
    s: int

    def __post_init__(self):
        if self.q + self.r + self.s != 0:
            raise ValueError(f"Invalid cube coord: {self.q}+{self.r}+{self.s} != 0")

    def __add__(self, other: CubeCoord) -> CubeCoord:
        return CubeCoord(self.q + other.q, self.r + other.r, self.s + other.s)

    def __sub__(self, other: CubeCoord) -> CubeCoord:
        return CubeCoord(self.q - other.q, self.r - other.r, self.s - other.s)


@dataclass(frozen=True, slots=True)
class OffsetCoord:
    """Odd-q offset coordinates for flat-top hex grid."""

    col: int
    row: int


# The six hex directions in cube coordinates (flat-top)
CUBE_DIRECTIONS = [
    CubeCoord(+1, 0, -1),  # East
    CubeCoord(+1, -1, 0),  # NE
    CubeCoord(0, -1, +1),  # NW
    CubeCoord(-1, 0, +1),  # West
    CubeCoord(-1, +1, 0),  # SW
    CubeCoord(0, +1, -1),  # SE
]


def cube(q: int, r: int) -> CubeCoord:
    """Shorthand: create CubeCoord from q, r (s is derived)."""
    return CubeCoord(q, r, -q - r)


def cube_neighbors(c: CubeCoord) -> list[CubeCoord]:
    return [c + d for d in CUBE_DIRECTIONS]


def cube_distance(a: CubeCoord, b: CubeCoord) -> int:
    diff = a - b
    return max(abs(diff.q), abs(diff.r), abs(diff.s))


def hexes_in_radius(center: CubeCoord, radius: int) -> set[CubeCoord]:
    """Return all hex positions within cube_distance <= radius of center."""
    results: set[CubeCoord] = set()
    for q in range(-radius, radius + 1):
        for r in range(max(-radius, -q - radius), min(radius, -q + radius) + 1):
            s = -q - r
            results.add(CubeCoord(center.q + q, center.r + r, center.s + s))
    return results


def cube_to_offset(c: CubeCoord) -> OffsetCoord:
    """Convert cube -> odd-q offset (flat-top)."""
    col = c.q
    row = c.r + (c.q - (c.q & 1)) // 2
    return OffsetCoord(col, row)


def offset_to_cube(o: OffsetCoord) -> CubeCoord:
    """Convert odd-q offset -> cube (flat-top)."""
    q = o.col
    r = o.row - (o.col - (o.col & 1)) // 2
    s = -q - r
    return CubeCoord(q, r, s)


# Pixel conversion constants
HEX_SIZE = 36  # outer radius (center to vertex)


def set_hex_size(size: int):
    """Override combat hex size (call before creating combat renderer)."""
    global HEX_SIZE
    HEX_SIZE = size


def hex_to_pixel(
    c: CubeCoord,
    origin_x: float = 0.0,
    origin_y: float = 0.0,
    hex_size: float | None = None,
) -> tuple[float, float]:
    """Convert cube coord to pixel center position (flat-top)."""
    size = hex_size if hex_size is not None else HEX_SIZE
    x = size * (3 / 2 * c.q)
    y = size * (math.sqrt(3) / 2 * c.q + math.sqrt(3) * c.r)
    return (x + origin_x, y + origin_y)


def pixel_to_hex(
    x: float,
    y: float,
    origin_x: float = 0.0,
    origin_y: float = 0.0,
    hex_size: float | None = None,
) -> CubeCoord:
    """Convert pixel position to nearest cube coord (flat-top)."""
    size = hex_size if hex_size is not None else HEX_SIZE
    px = (x - origin_x) / size
    py = (y - origin_y) / size

    fq = (2 / 3) * px
    fr = (-1 / 3) * px + (math.sqrt(3) / 3) * py

    return cube_round(fq, fr)


def cube_round(fq: float, fr: float) -> CubeCoord:
    """Round fractional cube coords to nearest hex."""
    fs = -fq - fr
    q = round(fq)
    r = round(fr)
    s = round(fs)

    q_diff = abs(q - fq)
    r_diff = abs(r - fr)
    s_diff = abs(s - fs)

    if q_diff > r_diff and q_diff > s_diff:
        q = -r - s
    elif r_diff > s_diff:
        r = -q - s
    else:
        s = -q - r

    return CubeCoord(q, r, s)


def hex_polygon_corners(
    center_x: float, center_y: float, size: float | None = None
) -> list[tuple[float, float]]:
    """Return the 6 corner points of a flat-top hex centered at (center_x, center_y)."""
    if size is None:
        size = HEX_SIZE
    corners = []
    for i in range(6):
        angle_deg = 60 * i
        angle_rad = math.radians(angle_deg)
        cx = center_x + size * math.cos(angle_rad)
        cy = center_y + size * math.sin(angle_rad)
        corners.append((cx, cy))
    return corners


# Battlefield bounds
BATTLEFIELD_COLS = 15
BATTLEFIELD_ROWS = 11


def is_valid_battlefield_pos(c: CubeCoord) -> bool:
    """Check if a cube coord is within the 15x11 battlefield."""
    o = cube_to_offset(c)
    return 0 <= o.col < BATTLEFIELD_COLS and 0 <= o.row < BATTLEFIELD_ROWS


def all_battlefield_positions() -> list[CubeCoord]:
    """Return all valid cube coords on the battlefield."""
    positions = []
    for col in range(BATTLEFIELD_COLS):
        for row in range(BATTLEFIELD_ROWS):
            positions.append(offset_to_cube(OffsetCoord(col, row)))
    return positions
