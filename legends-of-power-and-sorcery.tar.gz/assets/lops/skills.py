"""HoMM3-style secondary skills: types, levels, and hero skill slots."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto


class SkillId(Enum):
    """All secondary skill identifiers."""

    OFFENSE = auto()
    ARMORER = auto()
    ARCHERY = auto()
    LOGISTICS = auto()
    SCOUTING = auto()
    ESTATES = auto()
    LEADERSHIP = auto()
    LUCK = auto()
    PATHFINDING = auto()
    WISDOM = auto()
    TACTICS = auto()
    BALLISTICS = auto()
    ARTILLERY = auto()
    AIR_MAGIC = auto()
    EARTH_MAGIC = auto()
    FIRE_MAGIC = auto()
    WATER_MAGIC = auto()
    LEARNING = auto()
    MYSTICISM = auto()
    DIPLOMACY = auto()
    SCHOLAR = auto()
    FIRST_AID = auto()
    SORCERY = auto()
    RESISTANCE = auto()
    INTELLIGENCE = auto()
    EAGLE_EYE = auto()


class SkillLevel(Enum):
    """Skill mastery levels."""

    BASIC = 1
    ADVANCED = 2
    EXPERT = 3


@dataclass(frozen=True)
class SkillDef:
    """Immutable definition of a secondary skill."""

    skill_id: SkillId
    name: str
    description: str
    values: tuple[float, float, float]  # (basic, advanced, expert)

    def value_at(self, level: SkillLevel) -> float:
        return self.values[level.value - 1]


@dataclass
class HeroSkill:
    """A skill held by a hero at a specific level."""

    skill_id: SkillId
    level: SkillLevel = SkillLevel.BASIC

    @property
    def definition(self) -> SkillDef:
        from lops.data.skills import SKILL_REGISTRY

        return SKILL_REGISTRY[self.skill_id]

    @property
    def value(self) -> float:
        return self.definition.value_at(self.level)


MAX_HERO_SKILLS = 8
