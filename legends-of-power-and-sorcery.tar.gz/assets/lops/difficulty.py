"""AI difficulty settings."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto


class Difficulty(Enum):
    EASY = auto()
    NORMAL = auto()
    HARD = auto()
    IMPOSSIBLE = auto()


@dataclass(frozen=True)
class DifficultySettings:
    """Tunable parameters that control AI behavior.

    All knobs are purely tactical — no economic cheats or army inflation.
    """

    # Combat: how much stronger the AI wants to be before attacking
    # Higher = more cautious. 2.5 means AI wants 2.5x army strength.
    attack_threshold_monster: float = 1.5
    attack_threshold_hero: float = 1.8

    # Exploration: how aggressively AI moves toward distant targets
    # Higher = explores more. Multiplies the score in _advance_toward_target.
    explore_weight: float = 1.0

    # Max moves per turn (higher = more efficient use of MP)
    max_moves_per_turn: int = 20

    # Whether AI picks XP from treasure chests (vs gold)
    prefer_xp_from_chests: bool = True

    # Gold reservation: fraction of next building cost to reserve (1.0 = full)
    # Lower = spends more freely on recruits, delays buildings
    building_reserve_fraction: float = 1.0

    # Max heroes the AI will try to maintain (hire from tavern)
    max_heroes: int = 1


DIFFICULTY_PRESETS: dict[Difficulty, DifficultySettings] = {
    Difficulty.EASY: DifficultySettings(
        attack_threshold_monster=2.5,
        attack_threshold_hero=3.0,
        explore_weight=0.5,
        max_moves_per_turn=8,
        prefer_xp_from_chests=False,
        building_reserve_fraction=0.5,
        max_heroes=1,
    ),
    Difficulty.NORMAL: DifficultySettings(
        attack_threshold_monster=1.5,
        attack_threshold_hero=1.8,
        explore_weight=1.0,
        max_moves_per_turn=20,
        prefer_xp_from_chests=True,
        building_reserve_fraction=1.0,
        max_heroes=1,
    ),
    Difficulty.HARD: DifficultySettings(
        attack_threshold_monster=1.2,
        attack_threshold_hero=1.4,
        explore_weight=1.5,
        max_moves_per_turn=20,
        prefer_xp_from_chests=True,
        building_reserve_fraction=1.0,
        max_heroes=2,
    ),
    Difficulty.IMPOSSIBLE: DifficultySettings(
        attack_threshold_monster=1.0,
        attack_threshold_hero=1.1,
        explore_weight=2.0,
        max_moves_per_turn=20,
        prefer_xp_from_chests=True,
        building_reserve_fraction=1.0,
        max_heroes=3,
    ),
}


DIFFICULTY_INFO: list[tuple[Difficulty, str, str]] = [
    (Difficulty.EASY, "Easy", "Cautious, slow to explore"),
    (Difficulty.NORMAL, "Normal", "Balanced opponent"),
    (Difficulty.HARD, "Hard", "Aggressive, multi-hero"),
    (Difficulty.IMPOSSIBLE, "Impossible", "Ruthless, 3 heroes"),
]
