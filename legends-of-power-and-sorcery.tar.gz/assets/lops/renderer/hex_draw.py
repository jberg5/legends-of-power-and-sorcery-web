"""Draws the hex grid on the battlefield."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from lops.hex import (
    BATTLEFIELD_COLS,
    BATTLEFIELD_ROWS,
    HEX_SIZE,
    CubeCoord,
    OffsetCoord,
    cube_to_offset,
    hex_polygon_corners,
    hex_to_pixel,
    offset_to_cube,
)

if TYPE_CHECKING:
    from lops.renderer.siege_sprites import SiegeSprites

# Colors
COLOR_GRID_LINE = (60, 80, 60)
COLOR_GRID_FILL = (30, 50, 30)
COLOR_MOVE_HIGHLIGHT = (40, 80, 160, 100)
COLOR_ATTACK_HIGHLIGHT = (180, 40, 40, 100)
COLOR_SELECTED_HIGHLIGHT = (80, 180, 80, 120)
COLOR_HOVER_HIGHLIGHT = (200, 200, 100, 60)
COLOR_SPELL_TARGET_HIGHLIGHT = (120, 60, 180, 100)
COLOR_SPELL_AREA_HIGHLIGHT = (160, 80, 220, 80)


class HexGridRenderer:
    """Renders the 15x11 flat-top hex grid."""

    def __init__(self, surface: pygame.Surface):
        self.surface = surface
        # Reserve right panel for combat log / UI (narrower on small screens)
        sw, sh = surface.get_size()
        self.panel_width = min(240, max(100, sw // 5))
        import math

        grid_w = HEX_SIZE * 1.5 * (BATTLEFIELD_COLS - 1) + 2 * HEX_SIZE
        grid_h = HEX_SIZE * math.sqrt(3) * BATTLEFIELD_ROWS + HEX_SIZE
        battlefield_area_w = sw - self.panel_width
        self.origin_x = (battlefield_area_w - grid_w) / 2 + HEX_SIZE
        self.origin_y = (sh - grid_h) / 2 + HEX_SIZE * math.sqrt(3) / 2

        # Pre-compute pixel positions for all hexes
        self._hex_centers: dict[CubeCoord, tuple[float, float]] = {}
        self._hex_corners: dict[CubeCoord, list[tuple[float, float]]] = {}
        for col in range(BATTLEFIELD_COLS):
            for row in range(BATTLEFIELD_ROWS):
                c = offset_to_cube(OffsetCoord(col, row))
                px, py = hex_to_pixel(c, self.origin_x, self.origin_y)
                self._hex_centers[c] = (px, py)
                self._hex_corners[c] = hex_polygon_corners(px, py)

        # Lazy-loaded siege sprites
        self._siege_sprites: "SiegeSprites | None" = None

    def hex_center(self, c: CubeCoord) -> tuple[float, float]:
        return self._hex_centers.get(c, hex_to_pixel(c, self.origin_x, self.origin_y))

    def _ensure_siege_sprites(self):
        """Lazy-load siege sprites on first use."""
        if self._siege_sprites is None:
            from lops.renderer.siege_sprites import SiegeSprites

            self._siege_sprites = SiegeSprites()
            self._siege_sprites.load()

    def draw_grid(self, use_sprites: bool = False):
        """Draw all hex cells."""
        if use_sprites:
            self._ensure_siege_sprites()
        for c, corners in self._hex_corners.items():
            sprite_drawn = False
            if use_sprites and self._siege_sprites is not None:
                o = cube_to_offset(c)
                variant = (o.col * 7 + o.row * 13) % 4
                tile = self._siege_sprites.get_ground_tile(variant)
                if tile is not None:
                    from lops.renderer.siege_sprites import HEX_HEIGHT, HEX_WIDTH

                    cx, cy = self._hex_centers[c]
                    self.surface.blit(tile, (cx - HEX_WIDTH / 2, cy - HEX_HEIGHT / 2))
                    sprite_drawn = True
            if not sprite_drawn:
                pygame.draw.polygon(self.surface, COLOR_GRID_FILL, corners)
            pygame.draw.polygon(self.surface, COLOR_GRID_LINE, corners, 1)

    def draw_highlights(
        self,
        move_hexes: set[CubeCoord] | None = None,
        attack_hexes: set[CubeCoord] | None = None,
        selected_hex: CubeCoord | None = None,
        hover_hex: CubeCoord | None = None,
        spell_target_hexes: set[CubeCoord] | None = None,
        spell_area_hexes: set[CubeCoord] | None = None,
    ):
        """Draw colored overlays for valid moves, attacks, selection, hover, spells."""
        # Create transparent overlay surface
        overlay = pygame.Surface(self.surface.get_size(), pygame.SRCALPHA)

        if move_hexes:
            for c in move_hexes:
                if c in self._hex_corners:
                    pygame.draw.polygon(
                        overlay, COLOR_MOVE_HIGHLIGHT, self._hex_corners[c]
                    )

        if attack_hexes:
            for c in attack_hexes:
                if c in self._hex_corners:
                    pygame.draw.polygon(
                        overlay, COLOR_ATTACK_HIGHLIGHT, self._hex_corners[c]
                    )

        if spell_area_hexes:
            for c in spell_area_hexes:
                if c in self._hex_corners:
                    pygame.draw.polygon(
                        overlay, COLOR_SPELL_AREA_HIGHLIGHT, self._hex_corners[c]
                    )

        if spell_target_hexes:
            for c in spell_target_hexes:
                if c in self._hex_corners:
                    pygame.draw.polygon(
                        overlay, COLOR_SPELL_TARGET_HIGHLIGHT, self._hex_corners[c]
                    )

        if selected_hex and selected_hex in self._hex_corners:
            pygame.draw.polygon(
                overlay, COLOR_SELECTED_HIGHLIGHT, self._hex_corners[selected_hex]
            )

        if hover_hex and hover_hex in self._hex_corners:
            pygame.draw.polygon(
                overlay, COLOR_HOVER_HIGHLIGHT, self._hex_corners[hover_hex]
            )

        self.surface.blit(overlay, (0, 0))

    def draw_siege(self, siege_info):
        """Draw siege elements: moat, walls, towers, catapult."""
        if siege_info is None:
            return

        self._ensure_siege_sprites()
        sprites = self._siege_sprites

        overlay = pygame.Surface(self.surface.get_size(), pygame.SRCALPHA)

        def _blit_centered(sprite, pos):
            cx, cy = self._hex_centers[pos]
            sw, sh = sprite.get_size()
            overlay.blit(sprite, (cx - sw / 2, cy - sh / 2))

        # Moat
        for pos in siege_info.moat_hexes:
            if pos not in self._hex_corners:
                continue
            moat_tile = sprites.get_moat() if sprites else None
            if moat_tile is not None:
                _blit_centered(moat_tile, pos)
            else:
                pygame.draw.polygon(overlay, (30, 60, 140, 100), self._hex_corners[pos])

        # Walls
        from lops.siege import WallState, WallType

        for wall in siege_info.walls:
            if wall.position not in self._hex_corners:
                continue
            wall_sprite = (
                sprites.get_wall(wall.wall_type, wall.state) if sprites else None
            )
            if wall_sprite is not None:
                _blit_centered(wall_sprite, wall.position)
            else:
                corners = self._hex_corners[wall.position]
                if wall.wall_type == WallType.DRAWBRIDGE:
                    if wall.state == WallState.DESTROYED:
                        color = (80, 60, 30, 60)
                    elif wall.state == WallState.DAMAGED:
                        color = (140, 100, 40, 160)
                    else:
                        color = (160, 120, 50, 180)
                elif wall.state == WallState.DESTROYED:
                    color = (90, 80, 70, 60)
                elif wall.state == WallState.DAMAGED:
                    color = (140, 130, 110, 160)
                else:
                    color = (170, 160, 140, 200)
                pygame.draw.polygon(overlay, color, corners)
                pygame.draw.polygon(overlay, (100, 100, 100, 150), corners, 2)

        # Towers
        for tower in siege_info.towers:
            if tower.position not in self._hex_corners:
                continue
            tower_sprite = sprites.get_tower(tower.destroyed) if sprites else None
            if tower_sprite is not None:
                _blit_centered(tower_sprite, tower.position)
            else:
                corners = self._hex_corners[tower.position]
                if tower.destroyed:
                    color = (90, 80, 70, 80)
                else:
                    color = (160, 140, 100, 200)
                pygame.draw.polygon(overlay, color, corners)
                cx, cy = self._hex_centers[tower.position]
                marker_color = (
                    (200, 50, 50, 200) if not tower.destroyed else (100, 80, 80, 100)
                )
                pygame.draw.circle(overlay, marker_color, (int(cx), int(cy)), 8)

        # Catapult
        if siege_info.has_catapult:
            cat_pos = offset_to_cube(OffsetCoord(1, 9))
            if cat_pos in self._hex_centers:
                cat_sprite = sprites.get_catapult() if sprites else None
                if cat_sprite is not None:
                    _blit_centered(cat_sprite, cat_pos)
                else:
                    cx, cy = self._hex_centers[cat_pos]
                    self._draw_catapult(overlay, int(cx), int(cy))

        self.surface.blit(overlay, (0, 0))

    def _draw_catapult(self, surface: pygame.Surface, cx: int, cy: int):
        """Draw a simple catapult icon at the given pixel position."""
        # Base/frame (brown wooden structure)
        wood = (140, 100, 50, 220)
        dark_wood = (100, 70, 30, 220)
        metal = (160, 160, 170, 220)

        # Wheels (two circles)
        pygame.draw.circle(surface, dark_wood, (cx - 8, cy + 8), 6)
        pygame.draw.circle(surface, dark_wood, (cx + 8, cy + 8), 6)
        pygame.draw.circle(surface, wood, (cx - 8, cy + 8), 4)
        pygame.draw.circle(surface, wood, (cx + 8, cy + 8), 4)

        # Frame/base beam
        pygame.draw.line(surface, wood, (cx - 12, cy + 6), (cx + 12, cy + 6), 3)

        # Upright support
        pygame.draw.line(surface, wood, (cx + 4, cy + 6), (cx + 4, cy - 6), 3)

        # Arm (the throwing lever)
        pygame.draw.line(surface, dark_wood, (cx + 4, cy - 6), (cx - 14, cy - 14), 3)

        # Sling/bucket at end of arm
        pygame.draw.circle(surface, metal, (cx - 14, cy - 14), 4)

        # Counterweight
        pygame.draw.circle(surface, (120, 120, 130, 200), (cx + 10, cy - 2), 5)

        # Label
        font = pygame.font.Font(None, 14)
        label = font.render("Catapult", True, (200, 180, 120))
        label_rect = label.get_rect(center=(cx, cy + 18))
        surface.blit(label, label_rect)
