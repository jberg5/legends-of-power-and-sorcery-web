"""Hero equipment modal: paperdoll slot layout + backpack."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from lops.artifacts import SLOT_NAMES, ArtifactClass, ArtifactSlot
from lops.models import Hero

if TYPE_CHECKING:
    from lops.equipment import HeroEquipment

COLOR_OVERLAY = (0, 0, 0, 180)
COLOR_PANEL = (40, 45, 55)
COLOR_TEXT = (220, 220, 220)
COLOR_GOLD = (240, 200, 50)
COLOR_SLOT_EMPTY = (50, 55, 65)
COLOR_SLOT_FILLED = (60, 70, 90)
COLOR_SLOT_HOVER = (75, 85, 110)
COLOR_SLOT_BORDER = (100, 100, 120)
COLOR_CLOSE = (150, 50, 50)
COLOR_CLOSE_HOVER = (180, 70, 70)
COLOR_BACKPACK_BG = (35, 40, 50)

CLASS_COLORS = {
    ArtifactClass.TREASURE: (220, 220, 220),
    ArtifactClass.MINOR: (80, 200, 80),
    ArtifactClass.MAJOR: (80, 130, 220),
    ArtifactClass.RELIC: (240, 200, 50),
}

# Slot layout: (slot_type, index, row, col) for a paperdoll grid
# Grid is 6 columns wide, each cell 60px
SLOT_LAYOUT = [
    # Row 0: Helmet centered
    (ArtifactSlot.HELMET, 0, 0, 2),
    # Row 1: Necklace, Cape
    (ArtifactSlot.NECKLACE, 0, 1, 1),
    (ArtifactSlot.CAPE, 0, 1, 3),
    # Row 2: Weapon, Armor, Shield
    (ArtifactSlot.WEAPON, 0, 2, 0),
    (ArtifactSlot.ARMOR, 0, 2, 2),
    (ArtifactSlot.SHIELD, 0, 2, 4),
    # Row 3: Ring 1, Ring 2
    (ArtifactSlot.RING, 0, 3, 1),
    (ArtifactSlot.RING, 1, 3, 3),
    # Row 4: Boots
    (ArtifactSlot.BOOTS, 0, 4, 2),
    # Row 5-6: Misc 1-5
    (ArtifactSlot.MISC, 0, 5, 0),
    (ArtifactSlot.MISC, 1, 5, 1),
    (ArtifactSlot.MISC, 2, 5, 2),
    (ArtifactSlot.MISC, 3, 5, 3),
    (ArtifactSlot.MISC, 4, 5, 4),
]


class HeroModal:
    """Modal overlay for managing hero equipment."""

    def __init__(self, surface: pygame.Surface):
        self.surface = surface
        self.font = pygame.font.Font(None, 24)
        self.small_font = pygame.font.Font(None, 20)
        self.tiny_font = pygame.font.Font(None, 16)
        self.title_font = pygame.font.Font(None, 30)
        self.stat_font = pygame.font.Font(None, 18)

        sw, sh = surface.get_size()
        self.panel_w = min(620, sw - 20)
        self.panel_h = min(500, sh - 20)
        self.panel_x = (sw - self.panel_w) // 2
        self.panel_y = (sh - self.panel_h) // 2

        self.close_rect = pygame.Rect(
            self.panel_x + self.panel_w - 80, self.panel_y + 5, 70, 28
        )

        # Computed each frame
        self._slot_rects: dict[tuple[ArtifactSlot, int], pygame.Rect] = {}
        self._backpack_rects: list[pygame.Rect] = []
        self._tooltip_lines: list[str] | None = None
        self._tooltip_pos: tuple[int, int] = (0, 0)
        self._backpack_scroll = 0

    def handle_scroll(self, direction: int):
        self._backpack_scroll -= direction * 30
        self._backpack_scroll = max(0, self._backpack_scroll)

    def draw(self, hero: Hero):
        """Draw the hero equipment modal."""
        mx, my = pygame.mouse.get_pos()
        eq: HeroEquipment | None = hero.equipment  # type: ignore[assignment]
        if eq is None:
            return

        # Dark overlay
        overlay = pygame.Surface(self.surface.get_size(), pygame.SRCALPHA)
        overlay.fill(COLOR_OVERLAY)
        self.surface.blit(overlay, (0, 0))

        # Panel background
        panel_rect = pygame.Rect(self.panel_x, self.panel_y, self.panel_w, self.panel_h)
        pygame.draw.rect(self.surface, COLOR_PANEL, panel_rect, border_radius=6)
        pygame.draw.rect(self.surface, (100, 100, 120), panel_rect, 2, border_radius=6)

        # Title
        title = self.title_font.render(f"{hero.name} — Equipment", True, COLOR_GOLD)
        self.surface.blit(title, (self.panel_x + 15, self.panel_y + 8))

        # Close button
        close_color = (
            COLOR_CLOSE_HOVER if self.close_rect.collidepoint(mx, my) else COLOR_CLOSE
        )
        pygame.draw.rect(self.surface, close_color, self.close_rect, border_radius=4)
        close_text = self.small_font.render("Close", True, (255, 255, 255))
        self.surface.blit(
            close_text, close_text.get_rect(center=self.close_rect.center)
        )

        # --- Equipment slots (left side) ---
        self._slot_rects.clear()
        slots_x = self.panel_x + 15
        slots_y = self.panel_y + 45
        cell_w, cell_h = 56, 56
        gap = 4
        self._tooltip_lines = None

        for slot_type, idx, row, col in SLOT_LAYOUT:
            rx = slots_x + col * (cell_w + gap)
            ry = slots_y + row * (cell_h + gap)
            rect = pygame.Rect(rx, ry, cell_w, cell_h)
            self._slot_rects[(slot_type, idx)] = rect

            key = (slot_type, idx)
            art = eq.equipped.get(key)

            if rect.collidepoint(mx, my):
                bg_color = COLOR_SLOT_HOVER
                if art is not None:
                    self._tooltip_lines = [
                        art.name,
                        art.definition.description,
                        f"Slot: {SLOT_NAMES[slot_type]}",
                        f"Class: {art.definition.artifact_class.name.title()}",
                        "(Click to unequip)",
                    ]
                    self._tooltip_pos = (mx + 12, my - 10)
                else:
                    self._tooltip_lines = [SLOT_NAMES[slot_type]]
                    self._tooltip_pos = (mx + 12, my - 10)
            else:
                bg_color = COLOR_SLOT_FILLED if art else COLOR_SLOT_EMPTY

            pygame.draw.rect(self.surface, bg_color, rect, border_radius=3)
            pygame.draw.rect(self.surface, COLOR_SLOT_BORDER, rect, 1, border_radius=3)

            if art is not None:
                # Draw artifact name (truncated)
                name_color = CLASS_COLORS.get(art.definition.artifact_class, COLOR_TEXT)
                # First line: short name, second line: slot
                words = art.name.split()
                line1 = words[0][:8] if words else "?"
                name_s = self.tiny_font.render(line1, True, name_color)
                self.surface.blit(name_s, (rx + 3, ry + 4))
                # Stat preview
                stat_parts = []
                d = art.definition
                if d.attack:
                    stat_parts.append(f"A{d.attack:+d}")
                if d.defense:
                    stat_parts.append(f"D{d.defense:+d}")
                if d.spell_power:
                    stat_parts.append(f"S{d.spell_power:+d}")
                if d.knowledge:
                    stat_parts.append(f"K{d.knowledge:+d}")
                if d.morale:
                    stat_parts.append(f"M{d.morale:+d}")
                if d.luck:
                    stat_parts.append(f"L{d.luck:+d}")
                if stat_parts:
                    stat_s = self.tiny_font.render(
                        " ".join(stat_parts[:3]), True, (160, 180, 160)
                    )
                    self.surface.blit(stat_s, (rx + 3, ry + 20))
            else:
                # Empty slot label
                label = SLOT_NAMES[slot_type][:5]
                lbl_s = self.tiny_font.render(label, True, (80, 85, 100))
                lbl_rect = lbl_s.get_rect(center=rect.center)
                self.surface.blit(lbl_s, lbl_rect)

        # --- Backpack (right side) ---
        self._backpack_rects.clear()
        bp_x = self.panel_x + 340
        bp_y = self.panel_y + 45
        bp_w = self.panel_w - 355
        bp_h = self.panel_h - 110

        # Header
        bp_header = self.small_font.render(
            f"Backpack ({len(eq.backpack)})", True, COLOR_TEXT
        )
        self.surface.blit(bp_header, (bp_x, bp_y))
        bp_y += 22

        # Backpack list area
        bp_area = pygame.Rect(bp_x, bp_y, bp_w, bp_h)
        pygame.draw.rect(self.surface, COLOR_BACKPACK_BG, bp_area, border_radius=3)
        pygame.draw.rect(self.surface, COLOR_SLOT_BORDER, bp_area, 1, border_radius=3)

        # Clip to backpack area
        old_clip = self.surface.get_clip()
        self.surface.set_clip(bp_area)

        item_h = 36
        max_scroll = max(0, len(eq.backpack) * item_h - bp_h)
        self._backpack_scroll = min(self._backpack_scroll, max_scroll)

        for i, art in enumerate(eq.backpack):
            iy = bp_y + 4 + i * item_h - int(self._backpack_scroll)
            if iy + item_h < bp_y or iy > bp_y + bp_h:
                continue
            item_rect = pygame.Rect(bp_x + 2, iy, bp_w - 4, item_h - 2)
            self._backpack_rects.append(item_rect)

            if item_rect.collidepoint(mx, my):
                pygame.draw.rect(
                    self.surface, COLOR_SLOT_HOVER, item_rect, border_radius=2
                )
                self._tooltip_lines = [
                    art.name,
                    art.definition.description,
                    f"Slot: {SLOT_NAMES[art.slot]}",
                    "(Click to equip)",
                ]
                self._tooltip_pos = (mx + 12, my - 10)
            else:
                pygame.draw.rect(self.surface, (45, 50, 60), item_rect, border_radius=2)

            name_color = CLASS_COLORS.get(art.definition.artifact_class, COLOR_TEXT)
            name_s = self.tiny_font.render(art.name[:28], True, name_color)
            self.surface.blit(name_s, (item_rect.x + 4, item_rect.y + 2))
            desc_s = self.tiny_font.render(
                art.definition.description[:35], True, (140, 140, 140)
            )
            self.surface.blit(desc_s, (item_rect.x + 4, item_rect.y + 16))

        self.surface.set_clip(old_clip)

        # --- Stats bar (bottom) ---
        stats_y = self.panel_y + self.panel_h - 55
        pygame.draw.line(
            self.surface,
            (70, 75, 90),
            (self.panel_x + 10, stats_y - 5),
            (self.panel_x + self.panel_w - 10, stats_y - 5),
        )

        stat_items = [
            ("ATK", hero.attack, hero.effective_attack()),
            ("DEF", hero.defense, hero.effective_defense()),
            ("SPL", hero.spell_power, hero.effective_spell_power()),
            ("KNW", hero.knowledge, hero.effective_knowledge()),
            ("MRL", 0, hero.artifact_morale_bonus()),
            ("LCK", 0, hero.artifact_luck_bonus()),
        ]
        sx = self.panel_x + 15
        for label, base, effective in stat_items:
            lbl_s = self.stat_font.render(f"{label}:", True, (140, 130, 100))
            self.surface.blit(lbl_s, (sx, stats_y))
            bonus = effective - base
            if bonus != 0:
                val_str = f"{base}+{bonus}" if bonus > 0 else f"{base}{bonus}"
                color = (100, 220, 100) if bonus > 0 else (220, 100, 100)
            else:
                val_str = str(base)
                color = COLOR_TEXT
            val_s = self.stat_font.render(val_str, True, color)
            self.surface.blit(val_s, (sx + lbl_s.get_width() + 2, stats_y))
            sx += lbl_s.get_width() + val_s.get_width() + 14

        # Movement bonus
        mv = hero.artifact_movement_bonus()
        if mv > 0:
            mv_s = self.stat_font.render(f"MP:+{mv}", True, (100, 220, 100))
            self.surface.blit(mv_s, (sx, stats_y))
            sx += mv_s.get_width() + 14

        # Scouting bonus
        sc = hero.artifact_scouting_bonus()
        if sc > 0:
            sc_s = self.stat_font.render(f"VIS:+{sc}", True, (100, 220, 100))
            self.surface.blit(sc_s, (sx, stats_y))

        # --- Tooltip ---
        if self._tooltip_lines:
            self._draw_tooltip(self._tooltip_lines, self._tooltip_pos)

    def _draw_tooltip(self, lines: list[str], pos: tuple[int, int]):
        """Draw floating tooltip."""
        pad = 8
        line_h = 16
        rendered = [self.tiny_font.render(l, True, COLOR_TEXT) for l in lines]
        w = max(r.get_width() for r in rendered) + pad * 2
        h = len(rendered) * line_h + pad * 2
        tx, ty = pos
        # Keep on screen
        sw, sh = self.surface.get_size()
        if tx + w > sw:
            tx = sw - w - 4
        if ty + h > sh:
            ty = ty - h - 20

        bg = pygame.Surface((w, h), pygame.SRCALPHA)
        bg.fill((15, 15, 25, 230))
        self.surface.blit(bg, (tx, ty))
        pygame.draw.rect(
            self.surface, (80, 80, 100), (tx, ty, w, h), 1, border_radius=3
        )
        for i, r in enumerate(rendered):
            self.surface.blit(r, (tx + pad, ty + pad + i * line_h))

    def handle_click(self, pos: tuple[int, int], hero: Hero) -> str | None:
        """Handle click. Returns action string or None.

        Actions: -1 (close), 'unequip:SLOT:IDX', 'equip_backpack:IDX'
        """
        if self.close_rect.collidepoint(pos):
            return "-1"

        eq: HeroEquipment | None = hero.equipment  # type: ignore[assignment]
        if eq is None:
            return None

        # Check equipment slots
        for (slot, idx), rect in self._slot_rects.items():
            if rect.collidepoint(pos):
                if (slot, idx) in eq.equipped:
                    eq.unequip(slot, idx)
                    return "unequipped"
                return None

        # Check backpack
        for i, rect in enumerate(self._backpack_rects):
            if rect.collidepoint(pos):
                if i < len(eq.backpack):
                    eq.equip_from_backpack(i)
                    return "equipped"
                return None

        return None
