"""Animation system using generators for non-blocking animations."""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Generator

import pygame

from lops.hex import HEX_SIZE


class AnimationType(Enum):
    MOVE = auto()
    ATTACK_LUNGE = auto()
    DAMAGE_NUMBER = auto()
    FLOAT_TEXT = auto()
    SPELL_BOLT = auto()
    AREA_EXPLOSION = auto()
    CHAIN_BOLT = auto()
    RESURRECT_GLOW = auto()
    BATTLEFIELD_FLASH = auto()
    TELEPORT_EFFECT = auto()
    SCREEN_SHAKE = auto()
    FIRE_SHIELD_BURST = auto()


@dataclass
class Animation:
    """Base animation that tracks a generator-based effect."""

    anim_type: AnimationType
    gen: Generator[object, float, None]
    finished: bool = False
    primed: bool = False
    # Current visual state updated by the generator
    x: float = 0
    y: float = 0
    text: str = ""
    alpha: int = 255
    color: tuple = (255, 255, 255)
    stack: object = None  # CreatureStack being animated
    # Spell bolt data
    bolt_segments: list = field(default_factory=list)
    bolt_progress: float = 0.0
    bolt_glow_alpha: int = 0
    # Area explosion / fire shield burst
    center_x: float = 0
    center_y: float = 0
    radius: float = 0
    max_radius: float = 0
    particles: list = field(default_factory=list)
    is_ring: bool = False
    # Chain bolt
    chain_targets: list = field(default_factory=list)
    chain_segments: list = field(default_factory=list)
    chain_index: int = 0
    # Teleport effect
    effect_phase: int = 0  # 0=disappear, 1=appear
    ring_radius: float = 0
    dest_x: float = 0
    dest_y: float = 0
    # Battlefield flash / screen shake
    flash_alpha: int = 0
    meteors: list = field(default_factory=list)
    dust_particles: list = field(default_factory=list)
    bands: list = field(default_factory=list)
    # Resurrect glow
    sparkles: list = field(default_factory=list)
    halo_radius: float = 0
    column_alpha: int = 0


# Generator result type tags — returned as first element of tuple
_TAG_XYA = 0  # (tag, x, y, alpha)
_TAG_BOLT = 1  # (tag, progress, glow_alpha)
_TAG_EXPLOSION = 2  # (tag, radius, alpha, particles)
_TAG_CHAIN = 3  # (tag, chain_index, bolt_progress, bolt_glow_alpha)
_TAG_RESURRECT = 4  # (tag, sparkles, halo_radius, column_alpha)
_TAG_FLASH = 5  # (tag, flash_alpha, meteors)
_TAG_TELEPORT = 6  # (tag, phase, ring_radius, alpha)
_TAG_SHAKE = 7  # (tag, bands, dust_particles)
_TAG_BURST = 8  # (tag, radius, alpha, particles)


class AnimationManager:
    """Manages all active animations."""

    def __init__(self):
        self.animations: list[Animation] = []
        self.font = None

    def _ensure_font(self):
        if self.font is None:
            self.font = pygame.font.SysFont("Arial", 16, bold=True)

    @property
    def is_animating(self) -> bool:
        return len(self.animations) > 0

    def add_move(
        self,
        stack,
        path_pixels: list[tuple[float, float]],
        speed: float = 400.0,
    ):
        """Add a movement animation along a pixel path."""
        gen = self._move_gen(path_pixels, speed)
        anim = Animation(anim_type=AnimationType.MOVE, gen=gen, stack=stack)
        self.animations.append(anim)

    def add_damage_number(
        self,
        x: float,
        y: float,
        damage: int,
        color: tuple = (255, 50, 50),
    ):
        """Add a floating damage number."""
        self._ensure_font()
        gen = self._float_text_gen(x, y - HEX_SIZE * 0.3, duration=1.2)
        anim = Animation(
            anim_type=AnimationType.DAMAGE_NUMBER,
            gen=gen,
            text=str(damage),
            color=color,
            x=x,
            y=y,
        )
        self.animations.append(anim)

    def add_float_text(
        self,
        x: float,
        y: float,
        text: str,
        color: tuple = (255, 255, 100),
        duration: float = 1.5,
    ):
        """Add floating text (morale, luck, etc)."""
        self._ensure_font()
        gen = self._float_text_gen(x, y - HEX_SIZE * 0.5, duration=duration)
        anim = Animation(
            anim_type=AnimationType.FLOAT_TEXT,
            gen=gen,
            text=text,
            color=color,
            x=x,
            y=y,
        )
        self.animations.append(anim)

    def add_spell_bolt(
        self,
        start_x: float,
        start_y: float,
        end_x: float,
        end_y: float,
        color: tuple = (180, 200, 255),
        duration: float = 0.35,
    ):
        """Add a lightning bolt animation from caster to target."""
        segments = _generate_lightning_segments(start_x, start_y, end_x, end_y)
        gen = self._spell_bolt_gen(duration)
        anim = Animation(
            anim_type=AnimationType.SPELL_BOLT,
            gen=gen,
            color=color,
            bolt_segments=segments,
            bolt_progress=0.0,
            bolt_glow_alpha=255,
        )
        self.animations.append(anim)

    def add_area_explosion(
        self,
        start_x: float,
        start_y: float,
        center_x: float,
        center_y: float,
        color: tuple = (255, 140, 60),
        max_radius: float = 60.0,
        is_ring: bool = False,
        duration: float = 0.8,
    ):
        """Add an area explosion (Fireball, Frost Ring, etc.)."""
        # Generate initial bolt from hero to center
        bolt_segs = _generate_lightning_segments(start_x, start_y, center_x, center_y)
        # Generate particles
        num_particles = random.randint(15, 25)
        particles = []
        for _ in range(num_particles):
            angle = random.uniform(0, 2 * math.pi)
            speed = random.uniform(40, 120)
            particles.append(
                [
                    center_x,
                    center_y,  # x, y
                    math.cos(angle) * speed,  # dx
                    math.sin(angle) * speed,  # dy
                    255,  # alpha
                    random.uniform(2, 5),  # size
                ]
            )
        gen = self._area_explosion_gen(duration)
        anim = Animation(
            anim_type=AnimationType.AREA_EXPLOSION,
            gen=gen,
            color=color,
            center_x=center_x,
            center_y=center_y,
            max_radius=max_radius,
            is_ring=is_ring,
            bolt_segments=bolt_segs,
            particles=particles,
        )
        self.animations.append(anim)

    def add_chain_bolt(
        self,
        start_x: float,
        start_y: float,
        targets: list[tuple[float, float]],
        color: tuple = (180, 200, 255),
        duration_per_bounce: float = 0.3,
    ):
        """Add a chain lightning animation bouncing between targets."""
        if not targets:
            return
        # Build chain: hero -> target1 -> target2 -> ...
        all_points = [(start_x, start_y)] + list(targets)
        chain_segs = []
        for i in range(len(all_points) - 1):
            sx, sy = all_points[i]
            ex, ey = all_points[i + 1]
            chain_segs.append(_generate_lightning_segments(sx, sy, ex, ey))
        total_duration = duration_per_bounce * len(chain_segs)
        gen = self._chain_bolt_gen(len(chain_segs), duration_per_bounce, total_duration)
        anim = Animation(
            anim_type=AnimationType.CHAIN_BOLT,
            gen=gen,
            color=color,
            chain_segments=chain_segs,
            chain_targets=list(targets),
        )
        self.animations.append(anim)

    def add_resurrect_glow(
        self,
        center_x: float,
        center_y: float,
        color: tuple = (255, 215, 80),
        duration: float = 1.0,
    ):
        """Add a resurrection glow effect (sparkles rising, light column, halo)."""
        sparkles = []
        for _ in range(random.randint(8, 12)):
            sparkles.append(
                [
                    center_x + random.uniform(-20, 20),  # x
                    center_y + random.uniform(-5, 10),  # y
                    random.uniform(-15, 15),  # dx
                    random.uniform(-60, -30),  # dy (upward)
                    255,  # alpha
                    random.uniform(2, 4),  # size
                ]
            )
        gen = self._resurrect_glow_gen(duration)
        anim = Animation(
            anim_type=AnimationType.RESURRECT_GLOW,
            gen=gen,
            color=color,
            center_x=center_x,
            center_y=center_y,
            sparkles=sparkles,
        )
        self.animations.append(anim)

    def add_battlefield_flash(
        self,
        surface_size: tuple[int, int],
        color: tuple = (255, 140, 60),
        has_meteors: bool = False,
        duration: float = 1.0,
    ):
        """Add a full-screen flash (Armageddon, Death Ripple, etc.)."""
        meteors = []
        if has_meteors:
            w, h = surface_size
            for _ in range(random.randint(6, 10)):
                # Diagonal streaks falling from top
                sx = random.uniform(0, w)
                sy = random.uniform(-50, 0)
                angle = random.uniform(math.pi * 0.6, math.pi * 0.8)
                speed = random.uniform(300, 500)
                length = random.uniform(40, 80)
                meteors.append(
                    [
                        sx,
                        sy,
                        math.cos(angle) * speed,  # dx
                        math.sin(angle) * speed,  # dy (downward)
                        length,
                        255,  # alpha
                        random.uniform(0, 0.3),  # delay before appearing
                    ]
                )
        gen = self._battlefield_flash_gen(duration)
        anim = Animation(
            anim_type=AnimationType.BATTLEFIELD_FLASH,
            gen=gen,
            color=color,
            meteors=meteors,
        )
        self.animations.append(anim)

    def add_teleport_effect(
        self,
        origin_x: float,
        origin_y: float,
        dest_x: float = 0,
        dest_y: float = 0,
        color: tuple = (180, 200, 255),
        is_summon: bool = False,
        duration: float = 0.7,
    ):
        """Add teleport vanish/appear or summon effect."""
        particles = []
        # Particles for origin (and dest if teleport)
        for _ in range(random.randint(8, 12)):
            angle = random.uniform(0, 2 * math.pi)
            particles.append(
                [angle, 0, 255, random.uniform(2, 4)]
            )  # angle, radius_offset, alpha, size
        gen = self._teleport_effect_gen(is_summon, duration)
        anim = Animation(
            anim_type=AnimationType.TELEPORT_EFFECT,
            gen=gen,
            color=color,
            center_x=origin_x,
            center_y=origin_y,
            dest_x=dest_x if not is_summon else origin_x,
            dest_y=dest_y if not is_summon else origin_y,
            particles=particles,
        )
        self.animations.append(anim)

    def add_screen_shake(
        self,
        surface_size: tuple[int, int],
        wall_positions: list[tuple[float, float]] | None = None,
        color: tuple = (140, 200, 80),
        duration: float = 0.8,
    ):
        """Add earthquake screen shake effect."""
        w, h = surface_size
        # Horizontal bands
        bands = []
        for _ in range(random.randint(4, 7)):
            y = random.uniform(0, h)
            bands.append(
                [0, y, w, random.uniform(3, 8), 0]
            )  # x, y, width, height, alpha
        # Dust particles from bottom
        dust = []
        for _ in range(random.randint(10, 18)):
            dust.append(
                [
                    random.uniform(0, w),  # x
                    h + random.uniform(0, 20),  # y (start below screen)
                    random.uniform(-10, 10),  # dx
                    random.uniform(-40, -15),  # dy (upward)
                    0,  # alpha
                    random.uniform(2, 5),  # size
                ]
            )
        gen = self._screen_shake_gen(wall_positions or [], duration)
        anim = Animation(
            anim_type=AnimationType.SCREEN_SHAKE,
            gen=gen,
            color=color,
            bands=bands,
            dust_particles=dust,
        )
        self.animations.append(anim)

    def add_fire_shield_burst(
        self,
        center_x: float,
        center_y: float,
        color: tuple = (255, 100, 30),
        duration: float = 0.5,
    ):
        """Add a small fire shield burst at the melee attacker."""
        particles = []
        for _ in range(random.randint(8, 12)):
            angle = random.uniform(0, 2 * math.pi)
            speed = random.uniform(30, 80)
            particles.append(
                [
                    center_x,
                    center_y,
                    math.cos(angle) * speed,
                    math.sin(angle) * speed,
                    255,
                    random.uniform(2, 4),
                ]
            )
        gen = self._fire_shield_burst_gen(duration)
        anim = Animation(
            anim_type=AnimationType.FIRE_SHIELD_BURST,
            gen=gen,
            color=color,
            center_x=center_x,
            center_y=center_y,
            particles=particles,
        )
        self.animations.append(anim)

    def update(self, dt: float):
        """Advance all animations by dt seconds."""
        for anim in self.animations:
            if not anim.finished:
                try:
                    if not anim.primed:
                        result = next(anim.gen)
                        anim.primed = True
                    else:
                        result = anim.gen.send(dt)
                    if result:
                        self._apply_gen_result(anim, result)
                except StopIteration:
                    anim.finished = True

        self.animations = [a for a in self.animations if not a.finished]

    def _apply_gen_result(self, anim: Animation, result):
        """Apply generator output to animation state."""
        tag = result[0]
        if tag == _TAG_BOLT:
            _, progress, glow = result
            anim.bolt_progress = progress
            anim.bolt_glow_alpha = int(glow)
        elif tag == _TAG_XYA:
            _, x, y, alpha = result
            anim.x, anim.y, anim.alpha = x, y, alpha
        elif tag == _TAG_EXPLOSION:
            _, radius, alpha, particles = result
            anim.radius = radius
            anim.alpha = int(alpha)
            if particles is not None:
                anim.particles = particles
        elif tag == _TAG_CHAIN:
            _, chain_idx, progress, glow = result
            anim.chain_index = chain_idx
            anim.bolt_progress = progress
            anim.bolt_glow_alpha = int(glow)
        elif tag == _TAG_RESURRECT:
            _, sparkles, halo_r, col_alpha = result
            if sparkles is not None:
                anim.sparkles = sparkles
            anim.halo_radius = halo_r
            anim.column_alpha = int(col_alpha)
        elif tag == _TAG_FLASH:
            _, flash_alpha, meteors = result
            anim.flash_alpha = int(flash_alpha)
            if meteors is not None:
                anim.meteors = meteors
        elif tag == _TAG_TELEPORT:
            _, phase, ring_r, alpha = result
            anim.effect_phase = phase
            anim.ring_radius = ring_r
            anim.alpha = int(alpha)
        elif tag == _TAG_SHAKE:
            _, band_alpha, dust_alpha = result
            anim.flash_alpha = int(band_alpha)  # reuse for band alpha
            anim.alpha = int(dust_alpha)  # reuse for dust alpha
        elif tag == _TAG_BURST:
            _, radius, alpha, particles = result
            anim.radius = radius
            anim.alpha = int(alpha)
            if particles is not None:
                anim.particles = particles

    def draw(self, surface: pygame.Surface):
        """Draw all active animations."""
        self._ensure_font()
        assert self.font is not None
        for anim in self.animations:
            if anim.anim_type in (
                AnimationType.DAMAGE_NUMBER,
                AnimationType.FLOAT_TEXT,
            ):
                if anim.alpha > 0:
                    text_surf = self.font.render(anim.text, True, anim.color)
                    text_surf.set_alpha(int(anim.alpha))
                    rect = text_surf.get_rect(center=(int(anim.x), int(anim.y)))
                    surface.blit(text_surf, rect)
            elif anim.anim_type == AnimationType.SPELL_BOLT:
                self._draw_spell_bolt(surface, anim)
            elif anim.anim_type == AnimationType.AREA_EXPLOSION:
                self._draw_area_explosion(surface, anim)
            elif anim.anim_type == AnimationType.CHAIN_BOLT:
                self._draw_chain_bolt(surface, anim)
            elif anim.anim_type == AnimationType.RESURRECT_GLOW:
                self._draw_resurrect_glow(surface, anim)
            elif anim.anim_type == AnimationType.BATTLEFIELD_FLASH:
                self._draw_battlefield_flash(surface, anim)
            elif anim.anim_type == AnimationType.TELEPORT_EFFECT:
                self._draw_teleport_effect(surface, anim)
            elif anim.anim_type == AnimationType.SCREEN_SHAKE:
                self._draw_screen_shake(surface, anim)
            elif anim.anim_type == AnimationType.FIRE_SHIELD_BURST:
                self._draw_fire_shield_burst(surface, anim)

    def get_stack_offset(self, stack) -> tuple[float, float]:
        """Get the current animation offset for a stack (for move animations)."""
        for anim in self.animations:
            if anim.stack is stack and anim.anim_type == AnimationType.MOVE:
                return (anim.x, anim.y)
        return (0, 0)

    def is_stack_animating(self, stack) -> bool:
        """Check if a stack has an active move animation."""
        return any(
            a.stack is stack and a.anim_type == AnimationType.MOVE and not a.finished
            for a in self.animations
        )

    # ── Generators ──────────────────────────────────────────────────

    @staticmethod
    def _move_gen(path: list[tuple[float, float]], speed: float):
        """Generator that interpolates along a pixel path."""
        if len(path) < 2:
            return

        for i in range(len(path) - 1):
            sx, sy = path[i]
            ex, ey = path[i + 1]
            dx, dy = ex - sx, ey - sy
            dist = (dx**2 + dy**2) ** 0.5
            if dist == 0:
                continue

            duration = dist / speed
            elapsed = 0.0
            while elapsed < duration:
                dt = yield (
                    _TAG_XYA,
                    sx + dx * (elapsed / duration) - path[0][0],
                    sy + dy * (elapsed / duration) - path[0][1],
                    255,
                )
                if dt is None:
                    dt = 0.016
                elapsed += dt

    @staticmethod
    def _float_text_gen(x: float, y: float, duration: float = 1.5):
        """Generator for floating text that rises and fades."""
        elapsed = 0.0
        start_y = y
        while elapsed < duration:
            progress = elapsed / duration
            current_y = start_y - elapsed * 40
            alpha = int(255 * (1 - progress))
            dt = yield (_TAG_XYA, x, current_y, alpha)
            if dt is None:
                dt = 0.016
            elapsed += dt

    @staticmethod
    def _spell_bolt_gen(duration: float = 0.35):
        """Generator for spell bolt: bolt travels fast, then glow fades."""
        elapsed = 0.0
        travel_time = duration * 0.4
        fade_time = duration * 0.6

        while elapsed < duration:
            if elapsed < travel_time:
                progress = min(1.0, elapsed / travel_time)
                glow = 255
            else:
                progress = 1.0
                fade_progress = (elapsed - travel_time) / fade_time
                glow = int(255 * (1.0 - fade_progress))

            dt = yield (_TAG_BOLT, progress, glow)
            if dt is None:
                dt = 0.016
            elapsed += dt

    @staticmethod
    def _area_explosion_gen(duration: float = 0.8):
        """Generator for area explosion: expanding circle + particles."""
        elapsed = 0.0
        # Phase 1 (0-30%): bolt travels (handled by bolt_segments in draw)
        # Phase 2 (30-100%): explosion expands and fades
        bolt_phase = duration * 0.3
        explosion_phase = duration * 0.7

        while elapsed < duration:
            if elapsed < bolt_phase:
                # Bolt traveling phase - pass minimal update
                progress = elapsed / bolt_phase
                alpha = 255
                radius_frac = 0.0
            else:
                exp_elapsed = elapsed - bolt_phase
                exp_progress = min(1.0, exp_elapsed / explosion_phase)
                # Fast expand, then slow
                radius_frac = 1.0 - (1.0 - exp_progress) ** 2
                # Fade out in second half
                if exp_progress > 0.5:
                    alpha = int(255 * (1.0 - (exp_progress - 0.5) * 2))
                else:
                    alpha = 255

            dt = yield (_TAG_EXPLOSION, radius_frac, alpha, None)
            if dt is None:
                dt = 0.016
            elapsed += dt

    @staticmethod
    def _chain_bolt_gen(num_bounces: int, per_bounce: float, total: float):
        """Generator for chain bolt: sequential bounces."""
        elapsed = 0.0

        while elapsed < total:
            bounce_idx = min(int(elapsed / per_bounce), num_bounces - 1)
            bounce_elapsed = elapsed - bounce_idx * per_bounce
            # Each bounce: 40% travel, 60% linger
            travel_time = per_bounce * 0.4
            if bounce_elapsed < travel_time:
                progress = min(1.0, bounce_elapsed / travel_time)
                glow = 255
            else:
                progress = 1.0
                fade_elapsed = bounce_elapsed - travel_time
                fade_time = per_bounce * 0.6
                glow = int(255 * max(0, 1.0 - fade_elapsed / fade_time))

            dt = yield (_TAG_CHAIN, bounce_idx, progress, glow)
            if dt is None:
                dt = 0.016
            elapsed += dt

    @staticmethod
    def _resurrect_glow_gen(duration: float = 1.0):
        """Generator for resurrection glow: sparkles, column, halo."""
        elapsed = 0.0

        while elapsed < duration:
            progress = elapsed / duration
            # Halo expands then fades
            halo_r = progress * HEX_SIZE * 1.2
            # Column: ramps up then down
            if progress < 0.3:
                col_alpha = int(200 * (progress / 0.3))
            elif progress > 0.7:
                col_alpha = int(200 * (1.0 - (progress - 0.7) / 0.3))
            else:
                col_alpha = 200
            dt = yield (_TAG_RESURRECT, None, halo_r, col_alpha)
            if dt is None:
                dt = 0.016
            elapsed += dt

    @staticmethod
    def _battlefield_flash_gen(duration: float = 1.0):
        """Generator for battlefield flash: alpha ramp up then down."""
        elapsed = 0.0

        while elapsed < duration:
            progress = elapsed / duration
            # Alpha: ramp up fast, hold, fade
            if progress < 0.2:
                alpha = int(180 * (progress / 0.2))
            elif progress < 0.5:
                alpha = 180
            else:
                alpha = int(180 * (1.0 - (progress - 0.5) / 0.5))

            dt = yield (_TAG_FLASH, alpha, None)
            if dt is None:
                dt = 0.016
            elapsed += dt

    @staticmethod
    def _teleport_effect_gen(is_summon: bool, duration: float = 0.7):
        """Generator for teleport/summon: shrinking ring -> expanding ring."""
        elapsed = 0.0
        half = duration * 0.5

        while elapsed < duration:
            progress = elapsed / duration
            if is_summon:
                # Summon: just expanding ring at destination
                ring_r = progress * HEX_SIZE * 1.0
                phase = 1
                alpha = int(255 * (1.0 - progress))
            elif elapsed < half:
                # Disappear phase: ring shrinks at origin
                phase_progress = elapsed / half
                ring_r = HEX_SIZE * 0.8 * (1.0 - phase_progress)
                phase = 0
                alpha = int(255 * (1.0 - phase_progress * 0.5))
            else:
                # Appear phase: ring expands at destination
                phase_progress = (elapsed - half) / half
                ring_r = HEX_SIZE * 0.8 * phase_progress
                phase = 1
                alpha = int(255 * (1.0 - phase_progress * 0.5))

            dt = yield (_TAG_TELEPORT, phase, ring_r, alpha)
            if dt is None:
                dt = 0.016
            elapsed += dt

    @staticmethod
    def _screen_shake_gen(wall_positions: list, duration: float = 0.8):
        """Generator for earthquake: bands + dust."""
        elapsed = 0.0

        while elapsed < duration:
            progress = elapsed / duration
            # Band alpha: flicker
            band_alpha = int(
                120 * (1.0 - progress) * (0.5 + 0.5 * math.sin(elapsed * 20))
            )
            # Dust alpha: ramp up then fade
            dust_alpha = int(180 * min(1.0, progress * 3) * max(0, 1.0 - progress))
            dt = yield (_TAG_SHAKE, band_alpha, dust_alpha)
            if dt is None:
                dt = 0.016
            elapsed += dt

    @staticmethod
    def _fire_shield_burst_gen(duration: float = 0.5):
        """Generator for fire shield burst: expanding ring + particles."""
        elapsed = 0.0

        while elapsed < duration:
            progress = elapsed / duration
            radius_frac = 1.0 - (1.0 - progress) ** 2
            if progress > 0.4:
                alpha = int(255 * (1.0 - (progress - 0.4) / 0.6))
            else:
                alpha = 255

            dt = yield (_TAG_BURST, radius_frac, alpha, None)
            if dt is None:
                dt = 0.016
            elapsed += dt

    # ── Draw methods ────────────────────────────────────────────────

    def _draw_spell_bolt(self, surface: pygame.Surface, anim: Animation):
        """Draw a lightning bolt with glow effect."""
        if not anim.bolt_segments or anim.bolt_glow_alpha <= 0:
            return

        segments = anim.bolt_segments
        total = len(segments)
        if total < 2:
            return

        visible_count = max(2, int(total * anim.bolt_progress))
        visible = segments[:visible_count]

        alpha = min(255, anim.bolt_glow_alpha)
        r, g, b = anim.color

        overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)

        # Outer glow
        glow_alpha = max(0, alpha // 3)
        if glow_alpha > 0 and len(visible) >= 2:
            pygame.draw.lines(
                overlay,
                (r, g, b, glow_alpha),
                False,
                [(int(x), int(y)) for x, y in visible],
                7,
            )

        # Middle layer
        mid_alpha = max(0, alpha * 2 // 3)
        if mid_alpha > 0 and len(visible) >= 2:
            pygame.draw.lines(
                overlay,
                (min(255, r + 40), min(255, g + 40), min(255, b + 40), mid_alpha),
                False,
                [(int(x), int(y)) for x, y in visible],
                3,
            )

        # Core
        if alpha > 0 and len(visible) >= 2:
            pygame.draw.lines(
                overlay,
                (255, 255, 255, alpha),
                False,
                [(int(x), int(y)) for x, y in visible],
                1,
            )

        # Impact flash
        if anim.bolt_progress >= 0.9 and alpha > 100:
            tip_x, tip_y = visible[-1]
            flash_radius = int(12 * (alpha / 255))
            pygame.draw.circle(
                overlay,
                (255, 255, 255, min(200, alpha)),
                (int(tip_x), int(tip_y)),
                flash_radius,
            )
            pygame.draw.circle(
                overlay,
                (r, g, b, min(150, alpha)),
                (int(tip_x), int(tip_y)),
                flash_radius + 6,
            )

        surface.blit(overlay, (0, 0))

    def _draw_area_explosion(self, surface: pygame.Surface, anim: Animation):
        """Draw an area explosion: expanding circle/ring + particles."""
        overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        r, g, b = anim.color
        alpha = max(0, min(255, anim.alpha))

        # Draw initial bolt segments (fading as explosion grows)
        if anim.radius < 0.3 and anim.bolt_segments and len(anim.bolt_segments) >= 2:
            bolt_alpha = int(alpha * (1.0 - anim.radius / 0.3))
            if bolt_alpha > 0:
                _draw_bolt_on_overlay(
                    overlay, anim.bolt_segments, anim.color, bolt_alpha
                )

        # Draw explosion circle/ring
        actual_radius = max(1, int(anim.radius * anim.max_radius))
        cx, cy = int(anim.center_x), int(anim.center_y)

        if actual_radius > 0 and alpha > 0:
            if anim.is_ring:
                # Ring outline
                pygame.draw.circle(
                    overlay, (r, g, b, alpha), (cx, cy), actual_radius, 3
                )
                pygame.draw.circle(
                    overlay, (255, 255, 255, alpha // 2), (cx, cy), actual_radius, 1
                )
            else:
                # Filled circle with white core
                pygame.draw.circle(
                    overlay, (r, g, b, alpha // 2), (cx, cy), actual_radius
                )
                core_r = max(1, actual_radius // 3)
                core_alpha = min(255, alpha)
                pygame.draw.circle(
                    overlay, (255, 255, 255, core_alpha), (cx, cy), core_r
                )

        # Draw particles
        if anim.particles and alpha > 0:
            for p in anim.particles:
                px, py = int(p[0]), int(p[1])
                p_alpha = int(p[4] * (alpha / 255))
                p_size = max(1, int(p[5]))
                if p_alpha > 0:
                    pygame.draw.circle(overlay, (r, g, b, p_alpha), (px, py), p_size)

        surface.blit(overlay, (0, 0))

        # Update particle positions
        dt = 0.016
        for p in anim.particles:
            p[0] += p[2] * dt  # x += dx * dt
            p[1] += p[3] * dt  # y += dy * dt
            p[2] *= 0.95  # slow down
            p[3] *= 0.95
            p[4] = max(0, p[4] - 200 * dt)  # fade

    def _draw_chain_bolt(self, surface: pygame.Surface, anim: Animation):
        """Draw chain lightning: sequential bolts with dimming."""
        if not anim.chain_segments:
            return

        overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        r, g, b = anim.color

        for i, segments in enumerate(anim.chain_segments):
            if len(segments) < 2:
                continue
            if i > anim.chain_index:
                break  # haven't reached this bounce yet

            if i == anim.chain_index:
                # Current bounce: partial visibility
                visible_count = max(2, int(len(segments) * anim.bolt_progress))
                visible = segments[:visible_count]
                alpha = min(255, anim.bolt_glow_alpha)
            else:
                # Previous bounces: dimmed
                visible = segments
                dim_factor = max(0.15, 1.0 - (anim.chain_index - i) * 0.3)
                alpha = int(100 * dim_factor)

            if alpha <= 0 or len(visible) < 2:
                continue

            # 3-layer bolt
            glow_a = max(0, alpha // 3)
            if glow_a > 0:
                pygame.draw.lines(
                    overlay,
                    (r, g, b, glow_a),
                    False,
                    [(int(x), int(y)) for x, y in visible],
                    5,
                )
            mid_a = max(0, alpha * 2 // 3)
            if mid_a > 0:
                pygame.draw.lines(
                    overlay,
                    (min(255, r + 40), min(255, g + 40), min(255, b + 40), mid_a),
                    False,
                    [(int(x), int(y)) for x, y in visible],
                    2,
                )
            if alpha > 0:
                pygame.draw.lines(
                    overlay,
                    (255, 255, 255, alpha),
                    False,
                    [(int(x), int(y)) for x, y in visible],
                    1,
                )

            # Impact flash at bounce target
            if i == anim.chain_index and anim.bolt_progress >= 0.9 and alpha > 100:
                tip_x, tip_y = visible[-1]
                flash_r = int(10 * (alpha / 255))
                pygame.draw.circle(
                    overlay,
                    (255, 255, 255, min(200, alpha)),
                    (int(tip_x), int(tip_y)),
                    flash_r,
                )

        surface.blit(overlay, (0, 0))

    def _draw_resurrect_glow(self, surface: pygame.Surface, anim: Animation):
        """Draw resurrection glow: sparkles, light column, halo ring."""
        overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        r, g, b = anim.color
        cx, cy = int(anim.center_x), int(anim.center_y)
        col_alpha = max(0, min(255, anim.column_alpha))

        # Light column (thin vertical rectangle)
        if col_alpha > 0:
            col_w = 8
            col_h = HEX_SIZE * 2
            col_rect = pygame.Rect(cx - col_w // 2, cy - col_h, col_w, col_h)
            # Gradient: brighter at bottom
            for dy in range(int(col_h)):
                line_alpha = int(col_alpha * (dy / col_h))
                pygame.draw.line(
                    overlay,
                    (r, g, b, line_alpha),
                    (col_rect.left, col_rect.top + dy),
                    (col_rect.right, col_rect.top + dy),
                )

        # Halo ring at stack feet
        halo_r = max(1, int(anim.halo_radius))
        if halo_r > 1 and col_alpha > 0:
            halo_alpha = max(0, col_alpha // 2)
            pygame.draw.circle(overlay, (r, g, b, halo_alpha), (cx, cy + 5), halo_r, 2)
            pygame.draw.circle(
                overlay, (255, 255, 255, halo_alpha // 2), (cx, cy + 5), halo_r, 1
            )

        # Sparkle particles
        dt = 0.016
        for s in anim.sparkles:
            sx, sy = int(s[0]), int(s[1])
            s_alpha = int(s[4])
            s_size = max(1, int(s[5]))
            if s_alpha > 0:
                pygame.draw.circle(overlay, (255, 255, 200, s_alpha), (sx, sy), s_size)
                pygame.draw.circle(
                    overlay, (r, g, b, s_alpha // 2), (sx, sy), s_size + 1
                )
            # Update particle
            s[0] += s[2] * dt
            s[1] += s[3] * dt
            s[4] = max(0, s[4] - 180 * dt)

        surface.blit(overlay, (0, 0))

    def _draw_battlefield_flash(self, surface: pygame.Surface, anim: Animation):
        """Draw full-screen flash with optional meteor streaks."""
        alpha = max(0, min(255, anim.flash_alpha))
        if alpha <= 0:
            return

        overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        r, g, b = anim.color

        # Full-screen color wash
        overlay.fill((r, g, b, alpha))

        # Meteor streaks
        dt = 0.016
        for m in anim.meteors:
            mx, my, mdx, mdy, length, m_alpha, delay = m
            if delay > 0:
                m[6] -= dt
                continue
            m_alpha_int = int(m_alpha * (alpha / 180))
            if m_alpha_int > 0:
                # Streak line
                end_x = mx - mdx * 0.1
                end_y = my - mdy * 0.1
                pygame.draw.line(
                    overlay,
                    (255, 200, 100, m_alpha_int),
                    (int(mx), int(my)),
                    (int(end_x), int(end_y)),
                    3,
                )
                pygame.draw.line(
                    overlay,
                    (255, 255, 255, m_alpha_int),
                    (int(mx), int(my)),
                    (int(end_x), int(end_y)),
                    1,
                )
            # Update meteor position
            m[0] += mdx * dt
            m[1] += mdy * dt
            m[5] = max(0, m[5] - 150 * dt)

        surface.blit(overlay, (0, 0))

    def _draw_teleport_effect(self, surface: pygame.Surface, anim: Animation):
        """Draw teleport vanish/appear rings + sparkle particles."""
        overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        r, g, b = anim.color
        alpha = max(0, min(255, anim.alpha))
        ring_r = max(1, int(anim.ring_radius))

        if alpha <= 0:
            surface.blit(overlay, (0, 0))
            return

        # Determine center based on phase
        if anim.effect_phase == 0:
            # Disappear at origin
            cx, cy = int(anim.center_x), int(anim.center_y)
        else:
            # Appear at destination
            cx, cy = int(anim.dest_x), int(anim.dest_y)

        # Ring
        if ring_r > 1:
            pygame.draw.circle(overlay, (r, g, b, alpha), (cx, cy), ring_r, 2)
            pygame.draw.circle(
                overlay, (255, 255, 255, alpha // 2), (cx, cy), ring_r, 1
            )

        # Sparkle particles along the ring
        for p in anim.particles:
            angle, r_off, p_alpha, p_size = p
            px = cx + int(math.cos(angle) * (ring_r + r_off))
            py = cy + int(math.sin(angle) * (ring_r + r_off))
            pa = int(p_alpha * (alpha / 255))
            if pa > 0:
                pygame.draw.circle(
                    overlay, (255, 255, 255, pa), (px, py), max(1, int(p_size))
                )

        surface.blit(overlay, (0, 0))

    def _draw_screen_shake(self, surface: pygame.Surface, anim: Animation):
        """Draw earthquake: horizontal bands + dust particles."""
        overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        r, g, b = anim.color

        # Horizontal semi-transparent bands (flash_alpha used for band alpha)
        ba = max(0, min(255, anim.flash_alpha))
        for band in anim.bands:
            bx, by, bw, bh, _ = band
            if ba > 0:
                pygame.draw.rect(
                    overlay, (r, g, b, ba), (int(bx), int(by), int(bw), int(bh))
                )

        # Dust particles (anim.alpha used for dust alpha target)
        dt = 0.016
        dust_target = max(0, min(255, anim.alpha))
        for d in anim.dust_particles:
            dx_pos, dy_pos = int(d[0]), int(d[1])
            d_alpha = int(min(dust_target, d[4]))
            d_size = max(1, int(d[5]))
            if d_alpha > 0:
                pygame.draw.circle(
                    overlay, (180, 150, 100, d_alpha), (dx_pos, dy_pos), d_size
                )
            d[0] += d[2] * dt
            d[1] += d[3] * dt
            # Ramp up to target alpha
            if d[4] < dust_target:
                d[4] = min(dust_target, d[4] + 200 * dt)
            else:
                d[4] = max(0, d[4] - 100 * dt)

        surface.blit(overlay, (0, 0))

    def _draw_fire_shield_burst(self, surface: pygame.Surface, anim: Animation):
        """Draw fire shield burst: expanding orange ring + flame particles."""
        overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        r, g, b = anim.color
        alpha = max(0, min(255, anim.alpha))
        cx, cy = int(anim.center_x), int(anim.center_y)

        # Expanding ring
        actual_r = max(1, int(anim.radius * HEX_SIZE * 0.6))
        if actual_r > 1 and alpha > 0:
            pygame.draw.circle(overlay, (r, g, b, alpha), (cx, cy), actual_r, 2)
            pygame.draw.circle(
                overlay, (255, 200, 100, alpha // 2), (cx, cy), actual_r, 1
            )

        # Flame particles
        dt = 0.016
        for p in anim.particles:
            px, py = int(p[0]), int(p[1])
            p_alpha = int(p[4] * (alpha / 255))
            p_size = max(1, int(p[5]))
            if p_alpha > 0:
                pygame.draw.circle(overlay, (r, g, b, p_alpha), (px, py), p_size)
            p[0] += p[2] * dt
            p[1] += p[3] * dt + 5 * dt  # slight gravity
            p[2] *= 0.96
            p[3] *= 0.96
            p[4] = max(0, p[4] - 300 * dt)

        surface.blit(overlay, (0, 0))


def _draw_bolt_on_overlay(overlay, segments, color, alpha):
    """Helper: draw a lightning bolt on an existing overlay surface."""
    if len(segments) < 2 or alpha <= 0:
        return
    r, g, b = color
    points = [(int(x), int(y)) for x, y in segments]
    glow_a = max(0, alpha // 3)
    if glow_a > 0:
        pygame.draw.lines(overlay, (r, g, b, glow_a), False, points, 5)
    mid_a = max(0, alpha * 2 // 3)
    if mid_a > 0:
        pygame.draw.lines(
            overlay,
            (min(255, r + 40), min(255, g + 40), min(255, b + 40), mid_a),
            False,
            points,
            2,
        )
    pygame.draw.lines(overlay, (255, 255, 255, min(255, alpha)), False, points, 1)


def _generate_lightning_segments(
    sx: float,
    sy: float,
    ex: float,
    ey: float,
    jitter: float = 12.0,
    subdivisions: int = 5,
) -> list[tuple[float, float]]:
    """Generate jagged lightning bolt segments between two points.

    Uses midpoint displacement to create a realistic lightning look.
    """
    segments = [(sx, sy), (ex, ey)]

    for _ in range(subdivisions):
        new_segments = [segments[0]]
        for i in range(len(segments) - 1):
            x1, y1 = segments[i]
            x2, y2 = segments[i + 1]
            mx = (x1 + x2) / 2
            my = (y1 + y2) / 2
            dx = x2 - x1
            dy = y2 - y1
            length = (dx**2 + dy**2) ** 0.5
            if length > 0:
                px = -dy / length
                py = dx / length
                offset = random.uniform(-jitter, jitter)
                mx += px * offset
                my += py * offset
            new_segments.append((mx, my))
            new_segments.append((x2, y2))
        segments = new_segments
        jitter *= 0.55

    return segments
