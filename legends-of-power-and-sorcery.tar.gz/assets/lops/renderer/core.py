"""GameRenderer: composites all drawing layers."""

from __future__ import annotations

import pygame

from lops.combat import CombatEngine
from lops.hex import CubeCoord, is_valid_battlefield_pos, pixel_to_hex
from lops.models import CreatureStack, Side
from lops.renderer.animation import AnimationManager
from lops.renderer.creatures import CreatureRenderer
from lops.renderer.hero_portraits import HeroPortraitRenderer
from lops.renderer.hex_draw import HexGridRenderer
from lops.renderer.ui import UIRenderer

_DEFAULT_PLAYER_SIDE = Side.ATTACKER

COLOR_BG = (20, 35, 20)


class GameRenderer:
    """Main renderer that composites hex grid, creatures, UI, and animations."""

    def __init__(
        self,
        surface: pygame.Surface,
        engine: CombatEngine,
        player_side: Side = Side.ATTACKER,
    ):
        self.surface = surface
        self.engine = engine
        self.player_side = player_side

        self.hex_renderer = HexGridRenderer(surface)
        self.creature_renderer = CreatureRenderer(
            surface, self.hex_renderer, player_side=player_side
        )
        self.ui_renderer = UIRenderer(surface, engine, player_side=player_side)
        self.hero_portraits = HeroPortraitRenderer(
            surface, self.hex_renderer, player_side=player_side
        )
        self.animations = AnimationManager()
        self.auto_combat = False  # set by main loop when auto-battle active

        # Highlight state (set by input handler)
        self.move_highlights: set[CubeCoord] = set()
        self.attack_highlights: set[CubeCoord] = set()
        self.selected_hex: CubeCoord | None = None
        self.hover_hex: CubeCoord | None = None

        # Spell UI state
        self.show_spellbook: bool = False
        self.spell_target_highlights: set[CubeCoord] = set()
        self.spell_area_highlights: set[CubeCoord] = set()

    @property
    def is_animating(self) -> bool:
        return self.animations.is_animating

    def pixel_to_hex(self, mx: int, my: int) -> CubeCoord | None:
        """Convert screen pixel position to hex coord."""
        c = pixel_to_hex(mx, my, self.hex_renderer.origin_x, self.hex_renderer.origin_y)
        if is_valid_battlefield_pos(c):
            return c
        return None

    def hex_center(self, c: CubeCoord) -> tuple[float, float]:
        return self.hex_renderer.hex_center(c)

    def update(self, dt: float):
        """Update animations."""
        self.animations.update(dt)

        # Update hover hex from mouse
        mx, my = pygame.mouse.get_pos()
        self.hover_hex = self.pixel_to_hex(mx, my)

        # Update hover tooltip
        if self.hover_hex:
            stack = self.engine.battlefield.stack_at(self.hover_hex)
            self.ui_renderer.set_hover_stack(stack)
        else:
            self.ui_renderer.set_hover_stack(None)

    def draw(self):
        """Draw everything."""
        self.surface.fill(COLOR_BG)

        # Layer 1: Hex grid (use sprites for textured ground)
        self.hex_renderer.draw_grid(use_sprites=True)

        # Layer 1.5: Siege elements (walls, moat, towers)
        if self.engine.battlefield.is_siege:
            self.hex_renderer.draw_siege(self.engine.battlefield.siege_info)

        # Layer 1.75: Hero portraits (on horseback, top corners)
        atk_hero = self.engine.get_hero(Side.ATTACKER)
        def_hero = self.engine.get_hero(Side.DEFENDER)
        self.hero_portraits.draw(atk_hero, def_hero)

        # Layer 2: Highlights
        self.hex_renderer.draw_highlights(
            move_hexes=self.move_highlights,
            attack_hexes=self.attack_highlights,
            selected_hex=self.selected_hex,
            hover_hex=self.hover_hex,
            spell_target_hexes=self.spell_target_highlights,
            spell_area_hexes=self.spell_area_highlights,
        )

        # Layer 3: Creature stacks
        current = self.engine.current_stack
        for stack in self.engine.battlefield.alive_stacks:
            is_active = stack is current
            # Skip stacks being move-animated (they'll be drawn by animation)
            if not self.animations.is_stack_animating(stack):
                self.creature_renderer.draw_stack(stack, is_active=is_active)

            if stack.is_defending:
                self.creature_renderer.draw_defending_icon(stack)

        # Layer 4: Animations
        self.animations.draw(self.surface)

        # Layer 5: UI
        self.ui_renderer.draw(auto_combat=self.auto_combat)

        # Layer 6: Spell book overlay
        if self.show_spellbook:
            self.ui_renderer.draw_spellbook()

    def add_damage_animation(self, target: CreatureStack, damage: int):
        """Show floating damage number at target position."""
        if target.position is None:
            return
        cx, cy = self.hex_center(target.position)
        self.animations.add_damage_number(cx, cy, damage)

    def add_float_text(self, stack: CreatureStack, text: str, color=(255, 255, 100)):
        """Show floating text above a stack."""
        if stack.position is None:
            return
        cx, cy = self.hex_center(stack.position)
        self.animations.add_float_text(cx, cy, text, color)

    def add_spell_bolt(
        self, caster_side: Side, target: CreatureStack, color: tuple = (180, 200, 255)
    ):
        """Animate a lightning bolt from the caster's hero to a target stack."""
        from lops.renderer.hero_portraits import _is_real_hero

        hero = self.engine.get_hero(caster_side)
        if not _is_real_hero(hero):
            return
        sx, sy = self.hero_portraits.hero_pixel_position(caster_side)
        if target.position is None:
            return
        ex, ey = self.hex_center(target.position)
        self.animations.add_spell_bolt(sx, sy, ex, ey, color=color)

    def add_spell_animation(
        self,
        spell,
        caster_side: Side,
        target,
        targets: list | None,
        result: dict,
        color: tuple = (180, 200, 255),
    ):
        """Dispatch spell to the appropriate animation type based on SpellId."""
        from lops.hex import HEX_SIZE
        from lops.renderer.hero_portraits import _is_real_hero
        from lops.spells import SpellId

        hero = self.engine.get_hero(caster_side)
        has_hero = _is_real_hero(hero)
        sx, sy = (0.0, 0.0)
        if has_hero:
            sx, sy = self.hero_portraits.hero_pixel_position(caster_side)

        # Spell-to-animation dispatch
        area_explosion_spells = {
            SpellId.FIREBALL,
            SpellId.METEOR_SHOWER,
            SpellId.INFERNO,
            SpellId.FIRE_WALL,
        }
        frost_ring_spells = {SpellId.FROST_RING}
        chain_spells = {SpellId.CHAIN_LIGHTNING}
        resurrect_spells = {SpellId.RESURRECTION, SpellId.ANIMATE_DEAD}
        flash_spells = {
            SpellId.ARMAGEDDON,
            SpellId.DEATH_RIPPLE,
            SpellId.DESTROY_UNDEAD,
        }
        teleport_spells = {SpellId.TELEPORT}
        summon_spells = {
            SpellId.SUMMON_AIR_ELEMENTAL,
            SpellId.SUMMON_EARTH_ELEMENTAL,
            SpellId.SUMMON_FIRE_ELEMENTAL,
            SpellId.SUMMON_WATER_ELEMENTAL,
        }
        earthquake_spells = {SpellId.EARTHQUAKE}

        sid = spell.spell_id

        if sid in area_explosion_spells or sid in frost_ring_spells:
            # Area explosion centered on target
            if target and target.position:
                cx, cy = self.hex_center(target.position)
                max_r = max(1, spell.area_radius) * HEX_SIZE * 1.7
                if has_hero:
                    self.animations.add_area_explosion(
                        sx,
                        sy,
                        cx,
                        cy,
                        color=color,
                        max_radius=max_r,
                        is_ring=(sid in frost_ring_spells),
                    )

        elif sid in chain_spells:
            # Chain bolt bouncing between targets
            all_targets = targets or ([target] if target else [])
            target_pixels = []
            for t in all_targets:
                if t and t.position:
                    target_pixels.append(self.hex_center(t.position))
            if target_pixels and has_hero:
                self.animations.add_chain_bolt(sx, sy, target_pixels, color=color)

        elif sid in resurrect_spells:
            # Resurrection glow at target
            if target and target.position:
                cx, cy = self.hex_center(target.position)
                self.animations.add_resurrect_glow(cx, cy, color=color)

        elif sid in flash_spells:
            # Full-screen flash
            size = self.surface.get_size()
            has_meteors = sid == SpellId.ARMAGEDDON
            self.animations.add_battlefield_flash(
                size, color=color, has_meteors=has_meteors
            )

        elif sid in teleport_spells:
            # Teleport: vanish at origin, appear at destination
            if target and target.position:
                ox, oy = self.hex_center(target.position)
                dest_hex = result.get("destination")
                if dest_hex:
                    dx, dy = self.hex_center(dest_hex)
                    self.animations.add_teleport_effect(ox, oy, dx, dy, color=color)
                else:
                    self.animations.add_teleport_effect(ox, oy, color=color)

        elif sid in summon_spells:
            # Summon: expanding ring at spawn location
            summoned = result.get("summoned")
            if summoned and summoned.position:
                cx, cy = self.hex_center(summoned.position)
                self.animations.add_teleport_effect(cx, cy, color=color, is_summon=True)

        elif sid in earthquake_spells:
            # Screen shake
            size = self.surface.get_size()
            self.animations.add_screen_shake(size, color=color)

        else:
            # Default: spell bolt for all other spells
            all_targets = targets or ([target] if target else [])
            for t in all_targets:
                if t and t.position and has_hero:
                    ex, ey = self.hex_center(t.position)
                    self.animations.add_spell_bolt(sx, sy, ex, ey, color=color)

    def add_fire_shield_burst(self, stack: CreatureStack):
        """Add fire shield burst animation at a stack's position."""
        if stack.position is None:
            return
        cx, cy = self.hex_center(stack.position)
        self.animations.add_fire_shield_burst(cx, cy)

    def clear_highlights(self):
        self.move_highlights.clear()
        self.attack_highlights.clear()
        self.selected_hex = None
        self.spell_target_highlights.clear()
        self.spell_area_highlights.clear()
