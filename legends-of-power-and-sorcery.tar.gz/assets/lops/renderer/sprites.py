"""Sprite loader for creature types.

Loads 72x72 PNG sprites from lops/assets/sprites/ (sourced from
Battle for Wesnoth, licensed under GPL v2+ / CC-BY-SA 4.0).
"""

from __future__ import annotations

import os

import pygame

from lops.data.creatures import CreatureType

_ASSETS_DIR = os.path.join(os.path.dirname(__file__), "..", "assets", "sprites")

# Map creature types to sprite filenames
_SPRITE_FILES: dict[CreatureType, str] = {
    # Castle
    CreatureType.PIKEMAN: "pikeman.png",
    CreatureType.HALBERDIER: "halberdier.png",
    CreatureType.ARCHER: "archer.png",
    CreatureType.MARKSMAN: "marksman.png",
    CreatureType.GRIFFIN: "griffin.png",
    CreatureType.ROYAL_GRIFFIN: "royal_griffin.png",
    CreatureType.SWORDSMAN: "swordsman.png",
    CreatureType.CRUSADER: "crusader.png",
    CreatureType.MONK: "monk.png",
    CreatureType.ZEALOT: "zealot.png",
    CreatureType.CAVALIER: "cavalier.png",
    CreatureType.CHAMPION: "champion.png",
    CreatureType.ANGEL: "angel.png",
    CreatureType.ARCHANGEL: "archangel.png",
    # Necropolis
    CreatureType.SKELETON: "skeleton.png",
    CreatureType.SKELETON_WARRIOR: "skeleton_warrior.png",
    CreatureType.WALKING_DEAD: "walking_dead.png",
    CreatureType.ZOMBIE: "zombie.png",
    CreatureType.WIGHT: "wight.png",
    CreatureType.WRAITH: "wraith.png",
    CreatureType.VAMPIRE: "vampire.png",
    CreatureType.VAMPIRE_LORD: "vampire_lord.png",
    CreatureType.LICH: "lich.png",
    CreatureType.POWER_LICH: "power_lich.png",
    CreatureType.BLACK_KNIGHT: "black_knight.png",
    CreatureType.DREAD_KNIGHT: "dread_knight.png",
    CreatureType.BONE_DRAGON: "bone_dragon.png",
    CreatureType.GHOST_DRAGON: "ghost_dragon.png",
    # Inferno
    CreatureType.IMP: "imp.png",
    CreatureType.FAMILIAR: "familiar.png",
    CreatureType.GOG: "gog.png",
    CreatureType.MAGOG: "magog.png",
    CreatureType.HELL_HOUND: "hell_hound.png",
    CreatureType.CERBERUS: "cerberus.png",
    CreatureType.DEMON: "demon.png",
    CreatureType.HORNED_DEMON: "horned_demon.png",
    CreatureType.PIT_FIEND: "pit_fiend.png",
    CreatureType.PIT_LORD: "pit_lord.png",
    CreatureType.EFREETI: "efreeti.png",
    CreatureType.EFREET_SULTAN: "efreet_sultan.png",
    CreatureType.DEVIL: "devil.png",
    CreatureType.ARCH_DEVIL: "arch_devil.png",
    # Dungeon
    CreatureType.TROGLODYTE: "troglodyte.png",
    CreatureType.INFERNAL_TROGLODYTE: "infernal_troglodyte.png",
    CreatureType.HARPY: "harpy.png",
    CreatureType.HARPY_HAG: "harpy_hag.png",
    CreatureType.BEHOLDER: "beholder.png",
    CreatureType.EVIL_EYE: "evil_eye.png",
    CreatureType.MEDUSA: "medusa.png",
    CreatureType.MEDUSA_QUEEN: "medusa_queen.png",
    CreatureType.MINOTAUR: "minotaur.png",
    CreatureType.MINOTAUR_KING: "minotaur_king.png",
    CreatureType.MANTICORE: "manticore.png",
    CreatureType.SCORPICORE: "scorpicore.png",
    CreatureType.RED_DRAGON: "red_dragon.png",
    CreatureType.BLACK_DRAGON: "black_dragon.png",
    # Rampart
    CreatureType.CENTAUR: "centaur.png",
    CreatureType.CENTAUR_CAPTAIN: "centaur_captain.png",
    CreatureType.DWARF: "dwarf.png",
    CreatureType.BATTLE_DWARF: "battle_dwarf.png",
    CreatureType.WOOD_ELF: "wood_elf.png",
    CreatureType.GRAND_ELF: "grand_elf.png",
    CreatureType.PEGASUS: "pegasus.png",
    CreatureType.SILVER_PEGASUS: "silver_pegasus.png",
    CreatureType.DENDROID_GUARD: "dendroid_guard.png",
    CreatureType.DENDROID_SOLDIER: "dendroid_soldier.png",
    CreatureType.UNICORN: "unicorn.png",
    CreatureType.WAR_UNICORN: "war_unicorn.png",
    CreatureType.GREEN_DRAGON: "green_dragon.png",
    CreatureType.GOLD_DRAGON: "gold_dragon.png",
    # Tower
    CreatureType.GREMLIN: "gremlin.png",
    CreatureType.MASTER_GREMLIN: "master_gremlin.png",
    CreatureType.STONE_GARGOYLE: "stone_gargoyle.png",
    CreatureType.OBSIDIAN_GARGOYLE: "obsidian_gargoyle.png",
    CreatureType.STONE_GOLEM: "stone_golem.png",
    CreatureType.IRON_GOLEM: "iron_golem.png",
    CreatureType.MAGE: "mage.png",
    CreatureType.ARCH_MAGE: "arch_mage.png",
    CreatureType.GENIE: "genie.png",
    CreatureType.MASTER_GENIE: "master_genie.png",
    CreatureType.NAGA: "naga.png",
    CreatureType.NAGA_QUEEN: "naga_queen.png",
    CreatureType.GIANT: "giant.png",
    CreatureType.TITAN: "titan.png",
    # Stronghold
    CreatureType.GOBLIN: "goblin.png",
    CreatureType.HOBGOBLIN: "hobgoblin.png",
    CreatureType.WOLF_RIDER: "wolf_rider.png",
    CreatureType.WOLF_RAIDER: "wolf_raider.png",
    CreatureType.ORC: "orc.png",
    CreatureType.ORC_CHIEFTAIN: "orc_chieftain.png",
    CreatureType.OGRE: "ogre.png",
    CreatureType.OGRE_MAGE: "ogre_mage.png",
    CreatureType.ROC: "roc.png",
    CreatureType.THUNDERBIRD: "thunderbird.png",
    CreatureType.CYCLOPS: "cyclops.png",
    CreatureType.CYCLOPS_KING: "cyclops_king.png",
    CreatureType.BEHEMOTH: "behemoth.png",
    CreatureType.ANCIENT_BEHEMOTH: "ancient_behemoth.png",
    # Fortress
    CreatureType.GNOLL: "gnoll.png",
    CreatureType.GNOLL_MARAUDER: "gnoll_marauder.png",
    CreatureType.LIZARDMAN: "lizardman.png",
    CreatureType.LIZARD_WARRIOR: "lizard_warrior.png",
    CreatureType.SERPENT_FLY: "serpent_fly.png",
    CreatureType.DRAGON_FLY: "dragon_fly.png",
    CreatureType.BASILISK: "basilisk.png",
    CreatureType.GREATER_BASILISK: "greater_basilisk.png",
    CreatureType.GORGON: "gorgon.png",
    CreatureType.MIGHTY_GORGON: "mighty_gorgon.png",
    CreatureType.WYVERN: "wyvern.png",
    CreatureType.WYVERN_MONARCH: "wyvern_monarch.png",
    CreatureType.HYDRA: "hydra.png",
    CreatureType.CHAOS_HYDRA: "chaos_hydra.png",
    # Conflux
    CreatureType.PIXIE: "pixie.png",
    CreatureType.SPRITE: "sprite.png",
    CreatureType.STORM_ELEMENTAL: "storm_elemental.png",
    CreatureType.ICE_ELEMENTAL: "ice_elemental.png",
    CreatureType.ENERGY_ELEMENTAL: "energy_elemental.png",
    CreatureType.MAGMA_ELEMENTAL: "magma_elemental.png",
    CreatureType.PSYCHIC_ELEMENTAL: "psychic_elemental.png",
    CreatureType.MAGIC_ELEMENTAL: "magic_elemental.png",
    CreatureType.FIREBIRD: "firebird.png",
    CreatureType.PHOENIX: "phoenix.png",
    # Neutral / Summoned elementals (also used as Conflux base tiers 2-5)
    CreatureType.AIR_ELEMENTAL: "air_elemental.png",
    CreatureType.WATER_ELEMENTAL: "water_elemental.png",
    CreatureType.FIRE_ELEMENTAL: "fire_elemental.png",
    CreatureType.EARTH_ELEMENTAL: "earth_elemental.png",
}

SPRITE_SIZE = 48  # display size on screen

_sprite_cache: dict[tuple[CreatureType, str], pygame.Surface] = {}


def get_sprite(creature_type: CreatureType, side: str = "neutral") -> pygame.Surface:
    """Get a sprite for the given creature type, scaled to SPRITE_SIZE.

    side: "attacker" tints blue, "defender" tints red, "neutral" is base colors.
    """
    key = (creature_type, side)
    if key in _sprite_cache:
        return _sprite_cache[key]

    filename = _SPRITE_FILES.get(creature_type)
    if filename is None:
        surf = pygame.Surface((SPRITE_SIZE, SPRITE_SIZE), pygame.SRCALPHA)
        surf.fill((128, 128, 128))
        _sprite_cache[key] = surf
        return surf

    path = os.path.join(_ASSETS_DIR, filename)
    try:
        raw = pygame.image.load(path).convert_alpha()
    except (pygame.error, FileNotFoundError):
        surf = pygame.Surface((SPRITE_SIZE, SPRITE_SIZE), pygame.SRCALPHA)
        surf.fill((128, 128, 128))
        _sprite_cache[key] = surf
        return surf

    # Scale to display size
    scaled = pygame.transform.smoothscale(raw, (SPRITE_SIZE, SPRITE_SIZE))

    # Apply team tint
    if side in ("attacker", "player"):
        scaled = _tint(scaled, (40, 60, 180), 0.12)
    elif side in ("defender", "enemy"):
        scaled = _tint(scaled, (180, 40, 40), 0.12)

    _sprite_cache[key] = scaled
    return scaled


def _tint(surf: pygame.Surface, color: tuple, strength: float) -> pygame.Surface:
    """Apply a color tint to a surface (preserving alpha)."""
    tinted = surf.copy()
    overlay = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
    overlay.fill((*color, int(255 * strength)))
    tinted.blit(overlay, (0, 0), special_flags=pygame.BLEND_RGBA_ADD)
    return tinted


def lookup_creature_type(stats_name: str) -> CreatureType | None:
    """Look up CreatureType from a creature stats name string."""
    from lops.data.creatures import CREATURE_REGISTRY

    for ct in CreatureType:
        if CREATURE_REGISTRY[ct].name == stats_name:
            return ct
    return None
