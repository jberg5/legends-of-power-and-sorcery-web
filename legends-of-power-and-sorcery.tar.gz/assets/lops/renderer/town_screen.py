"""Town screen: tabbed Build / Recruit overlay."""

from __future__ import annotations

import pygame

from lops.adventure.adventure_state import PlayerState
from lops.adventure.buildings import BuildingDef, BuildingId
from lops.adventure.resources import Resources
from lops.adventure.town import Town

COLOR_OVERLAY_BG = (20, 20, 30, 230)
COLOR_PANEL_BG = (40, 45, 55)
COLOR_TEXT = (220, 220, 220)
COLOR_GOLD = (240, 200, 50)
COLOR_BUTTON = (50, 90, 50)
COLOR_BUTTON_HOVER = (70, 120, 70)
COLOR_BUTTON_DISABLED = (60, 60, 60)
COLOR_CLOSE_BTN = (150, 50, 50)
COLOR_CLOSE_HOVER = (180, 70, 70)
COLOR_TAB_ACTIVE = (60, 70, 90)
COLOR_TAB_INACTIVE = (40, 45, 55)
COLOR_TAB_HOVER = (55, 65, 80)
COLOR_BUILT = (80, 140, 80)
COLOR_RES_SHORT = (200, 80, 80)

# Resource display colors (compact)
RES_COLORS = {
    "gold": (240, 200, 50),
    "wood": (160, 110, 50),
    "ore": (160, 160, 170),
    "mercury": (200, 80, 200),
    "sulfur": (220, 200, 60),
    "crystal": (80, 170, 230),
    "gems": (60, 210, 110),
}


class TownScreen:
    """Modal tabbed town overlay: Build / Recruit / Garrison tabs."""

    TAB_BUILD = 0
    TAB_RECRUIT = 1
    TAB_GARRISON = 2
    TAB_TAVERN = 3
    TAB_ARTIFACTS = 4
    TAB_MARKETPLACE = 5

    def __init__(self, surface: pygame.Surface):
        self.surface = surface
        from lops.renderer.font_scale import scaled_font_size as _sf

        self.font = pygame.font.Font(None, _sf(24))
        self.title_font = pygame.font.Font(None, _sf(36))
        self.small_font = pygame.font.Font(None, _sf(20))
        self.tiny_font = pygame.font.Font(None, _sf(16))

        sw, sh = surface.get_size()
        self.panel_w = min(800, sw - 40)
        self.panel_h = min(640, sh - 40)
        self.panel_x = (sw - self.panel_w) // 2
        self.panel_y = (sh - self.panel_h) // 2

        self.active_tab = self.TAB_RECRUIT
        self.hero_at_town: bool = False  # set by caller
        self.hero_at_town_army: list | None = (
            None  # set by caller: army of the hero at this town
        )

        # Tab rects — rebuilt dynamically in _rebuild_tab_rects()
        self._tab_y = self.panel_y + 45
        self.tab_rects: list[pygame.Rect] = []
        self._rebuild_tab_rects(5)  # max tabs

        self.close_rect = pygame.Rect(
            self.panel_x + self.panel_w - 80,
            self.panel_y + 10,
            70,
            30,
        )

        self.row_height = 50
        self.build_scroll_px = 0.0  # pixel-based scroll offset
        self._build_scroll_max = 0.0  # max scroll (set during draw)
        self.recruit_scroll_px = 0.0
        self._recruit_scroll_max = 0.0
        self._scrollbar_dragging = False
        self._scrollbar_drag_offset = 0.0  # y offset within thumb when drag started
        self._scrollbar_rect = pygame.Rect(0, 0, 0, 0)  # track rect
        self._scrollbar_thumb_rect = pygame.Rect(0, 0, 0, 0)  # thumb rect
        self.recruit_rects: list[tuple[pygame.Rect, int]] = []
        self.upgrade_rects: list[tuple[pygame.Rect, int]] = []  # (rect, army_slot)
        self.build_rects: list[tuple[pygame.Rect, BuildingId]] = []
        self.hero_army_rects: list[pygame.Rect] = []
        self.garrison_rects: list[pygame.Rect] = []
        self.tavern_rects: list[pygame.Rect] = []  # hire buttons per tavern hero
        self.has_tavern: bool = False  # set by caller
        self.has_merchant: bool = False  # set by caller
        self.merchant_rects: list[pygame.Rect] = []  # buy buttons per merchant artifact
        self.has_marketplace: bool = False  # set by caller
        self.marketplace_count: int = 1  # set by caller

        # Marketplace state
        self._market_sell: str | None = None
        self._market_buy: str | None = None
        self._market_amount: int = 0
        self._market_sell_rects: dict[str, pygame.Rect] = {}
        self._market_buy_rects: dict[str, pygame.Rect] = {}
        self._market_trade_rect = pygame.Rect(0, 0, 0, 0)
        self._market_slider_track = pygame.Rect(0, 0, 0, 0)
        self._market_slider_dragging: bool = False

        # Garrison quantity picker state
        self._garrison_selected: tuple[str, int] | None = (
            None  # ('hero', idx) or ('garrison', idx)
        )
        self._garrison_transfer_count: int = 0
        self._garrison_max_count: int = 0
        self._transfer_btn_rect = pygame.Rect(0, 0, 0, 0)
        self._minus_btn_rect = pygame.Rect(0, 0, 0, 0)
        self._plus_btn_rect = pygame.Rect(0, 0, 0, 0)
        self._minus10_btn_rect = pygame.Rect(0, 0, 0, 0)
        self._plus10_btn_rect = pygame.Rect(0, 0, 0, 0)
        self._all_btn_rect = pygame.Rect(0, 0, 0, 0)

    def _rebuild_tab_rects(self, count: int):
        """Rebuild tab button rects to fit the given number of tabs."""
        tab_w = min(90, (self.panel_w - 20) // max(count, 1) - 5)
        self.tab_rects = [
            pygame.Rect(self.panel_x + 10 + i * (tab_w + 5), self._tab_y, tab_w, 28)
            for i in range(count)
        ]

    def draw(self, town: Town, player: PlayerState):
        sw, sh = self.surface.get_size()

        # Semi-transparent overlay
        overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
        overlay.fill(COLOR_OVERLAY_BG)
        self.surface.blit(overlay, (0, 0))

        # Panel background
        panel_rect = pygame.Rect(self.panel_x, self.panel_y, self.panel_w, self.panel_h)
        pygame.draw.rect(self.surface, COLOR_PANEL_BG, panel_rect, border_radius=8)
        pygame.draw.rect(self.surface, (100, 100, 120), panel_rect, 2, border_radius=8)

        # Title
        title = self.title_font.render(town.name, True, COLOR_TEXT)
        self.surface.blit(title, (self.panel_x + 20, self.panel_y + 12))

        # Resource display in header
        self._draw_resources_header(player)

        # Close button
        mx, my = pygame.mouse.get_pos()
        close_color = (
            COLOR_CLOSE_HOVER
            if self.close_rect.collidepoint(mx, my)
            else COLOR_CLOSE_BTN
        )
        pygame.draw.rect(self.surface, close_color, self.close_rect, border_radius=4)
        close_text = self.font.render("Close", True, (255, 255, 255))
        close_text_rect = close_text.get_rect(center=self.close_rect.center)
        self.surface.blit(close_text, close_text_rect)

        # Tabs — tavern only shown when applicable; garrison always visible
        tab_labels = ["Build", "Recruit", "Garrison"]
        visible_tabs = [self.TAB_BUILD, self.TAB_RECRUIT, self.TAB_GARRISON]
        if self.has_tavern:
            tab_labels.append("Tavern")
            visible_tabs.append(self.TAB_TAVERN)
        if self.has_marketplace:
            tab_labels.append("Market")
            visible_tabs.append(self.TAB_MARKETPLACE)
        if self.has_merchant:
            tab_labels.append("Artifacts")
            visible_tabs.append(self.TAB_ARTIFACTS)

        # Revert to recruit if active tab is hidden
        if self.active_tab == self.TAB_TAVERN and not self.has_tavern:
            self.active_tab = self.TAB_RECRUIT
        if self.active_tab == self.TAB_MARKETPLACE and not self.has_marketplace:
            self.active_tab = self.TAB_RECRUIT
        if self.active_tab == self.TAB_ARTIFACTS and not self.has_merchant:
            self.active_tab = self.TAB_RECRUIT

        # Rebuild tab rects to match visible tab count
        self._rebuild_tab_rects(len(visible_tabs))

        for idx, (tab_id, label) in enumerate(zip(visible_tabs, tab_labels)):
            rect = self.tab_rects[idx]
            if tab_id == self.active_tab:
                color = COLOR_TAB_ACTIVE
            elif rect.collidepoint(mx, my):
                color = COLOR_TAB_HOVER
            else:
                color = COLOR_TAB_INACTIVE
            pygame.draw.rect(self.surface, color, rect, border_radius=4)
            pygame.draw.rect(self.surface, (100, 100, 120), rect, 1, border_radius=4)
            text = self.font.render(label, True, COLOR_TEXT)
            text_rect = text.get_rect(center=rect.center)
            self.surface.blit(text, text_rect)

        # Tab content
        if self.active_tab == self.TAB_BUILD:
            self._draw_build_tab(town, player)
        elif self.active_tab == self.TAB_GARRISON:
            self._draw_garrison_tab(town, player)
        elif self.active_tab == self.TAB_TAVERN:
            self._draw_tavern_tab(town, player)
        elif self.active_tab == self.TAB_ARTIFACTS:
            self._draw_artifacts_tab(town, player)
        elif self.active_tab == self.TAB_MARKETPLACE:
            self._draw_marketplace_tab(town, player)
        else:
            self._draw_recruit_tab(town, player)

    def _draw_resources_header(self, player: PlayerState):
        """Draw compact resource bar at top of panel."""
        res = player.resources
        x = self.panel_x + 200
        y = self.panel_y + 16
        res_items = [
            ("gold", res.gold),
            ("wood", res.wood),
            ("ore", res.ore),
            ("mercury", res.mercury),
            ("sulfur", res.sulfur),
            ("crystal", res.crystal),
            ("gems", res.gems),
        ]
        for name, amount in res_items:
            color = RES_COLORS[name]
            label = name[0].upper()
            lbl = self.tiny_font.render(f"{label}:", True, color)
            self.surface.blit(lbl, (x, y))
            x += lbl.get_width() + 1
            val = self.tiny_font.render(str(amount), True, COLOR_TEXT)
            self.surface.blit(val, (x, y))
            x += val.get_width() + 5

    def _building_benefit(self, bdef: "BuildingDef", town: Town | None = None) -> str:
        """Return a short description of what a building provides."""
        parts = []
        if bdef.daily_gold:
            parts.append(f"+{bdef.daily_gold} gold/day")
        if bdef.growth_bonus:
            pct = int(bdef.growth_bonus * 100)
            parts.append(f"+{pct}% creature growth")
        if bdef.unlocks_creature:
            from lops.data.creatures import CREATURE_REGISTRY

            stats = CREATURE_REGISTRY.get(bdef.unlocks_creature)
            name = stats.name if stats else bdef.unlocks_creature.name
            parts.append(f"Recruits {name}")
        if bdef.upgrades_creature:
            from lops.data.creatures import CREATURE_REGISTRY

            stats = CREATURE_REGISTRY.get(bdef.upgrades_creature)
            name = stats.name if stats else bdef.upgrades_creature.name
            parts.append(f"Upgrades to {name}")
        # Fort enables garrison defense but has no growth_bonus or daily_gold
        if bdef.building_id == BuildingId.FORT:
            parts.append("Enables fortification")
        if bdef.building_id == BuildingId.RESOURCE_SILO and town is not None:
            from lops.adventure.town import FactionId

            silo_map = {
                FactionId.CASTLE: "+1 wood, +1 ore/day",
                FactionId.NECROPOLIS: "+1 wood, +1 ore/day",
                FactionId.INFERNO: "+1 mercury/day",
                FactionId.DUNGEON: "+1 sulfur/day",
                FactionId.RAMPART: "+1 crystal/day",
                FactionId.TOWER: "+1 gems/day",
                FactionId.STRONGHOLD: "+1 wood, +1 ore/day",
                FactionId.FORTRESS: "+1 wood, +1 ore/day",
                FactionId.CONFLUX: "+1 mercury/day",
            }
            parts.append(silo_map.get(town.faction_id, "+1 resource/day"))
        return " | ".join(parts) if parts else ""

    def _get_build_order(self, town: Town) -> list[BuildingId]:
        """Generate build order from the town's faction buildings."""
        bdict = town._get_buildings_dict()
        # Shared infrastructure first
        infra = [
            bid
            for bid in [
                BuildingId.VILLAGE_HALL,
                BuildingId.TAVERN,
                BuildingId.TOWN_HALL,
                BuildingId.CITY_HALL,
                BuildingId.CAPITOL,
                BuildingId.FORT,
                BuildingId.CITADEL,
                BuildingId.CASTLE,
            ]
            if bid in bdict
        ]
        # Mage guilds
        guilds = [
            bid
            for bid in [
                BuildingId.MAGE_GUILD_1,
                BuildingId.MAGE_GUILD_2,
                BuildingId.MAGE_GUILD_3,
                BuildingId.MAGE_GUILD_4,
                BuildingId.MAGE_GUILD_5,
            ]
            if bid in bdict
        ]
        # Misc infrastructure
        misc = [
            bid
            for bid in [
                BuildingId.BLACKSMITH,
                BuildingId.MARKETPLACE,
                BuildingId.RESOURCE_SILO,
                BuildingId.ARTIFACT_MERCHANT,
            ]
            if bid in bdict
        ]
        # Faction dwellings: pair base + upgrade
        dwellings = []
        for bid, bdef in bdict.items():
            if bdef.unlocks_creature is not None:
                dwellings.append(bid)
        # Sort dwellings by their order in the dict (tier order)
        dwelling_pairs = []
        for base_bid in dwellings:
            # Find the upgrade for this base dwelling
            upg_bid = None
            for bid, bdef in bdict.items():
                if (
                    bdef.upgrades_creature is not None
                    and bdef.prerequisites
                    and base_bid in bdef.prerequisites
                ):
                    upg_bid = bid
                    break
            dwelling_pairs.append(base_bid)
            if upg_bid:
                dwelling_pairs.append(upg_bid)
        # Check for Castle-specific infra (Stables)
        stables = [
            bid
            for bid in bdict
            if bid not in set(infra + guilds + misc + dwelling_pairs)
            and bdict[bid].unlocks_creature is None
            and bdict[bid].upgrades_creature is None
        ]
        return infra + guilds + misc + stables + dwelling_pairs

    def _draw_build_tab(self, town: Town, player: PlayerState):
        """Draw the Build tab: scrollable list with two-column layout."""
        mx, my = pygame.mouse.get_pos()
        self.build_rects.clear()

        build_order = self._get_build_order(town)
        bdict = town._get_buildings_dict()

        row_h = 64  # taller rows: name+benefit, cost, prereqs
        scrollbar_w = 12
        content_x = self.panel_x + 10
        content_w = self.panel_w - 20 - scrollbar_w - 4
        content_top = self.panel_y + 82
        content_bottom = self.panel_y + self.panel_h - 10
        visible_h = content_bottom - content_top
        total_h = len(build_order) * row_h

        # Clamp scroll
        self._build_scroll_max = max(0.0, total_h - visible_h)
        self.build_scroll_px = max(
            0.0, min(self.build_scroll_px, self._build_scroll_max)
        )
        scroll = self.build_scroll_px

        # Layout: info on left, button on right
        btn_col_w = 100
        info_w = content_w - btn_col_w - 10

        # Clip region for content
        clip_rect = pygame.Rect(content_x, content_top, content_w, visible_h)
        prev_clip = self.surface.get_clip()
        self.surface.set_clip(clip_rect)

        for i, bid in enumerate(build_order):
            y = content_top + i * row_h - scroll
            if y + row_h < content_top or y > content_bottom:
                continue

            bdef = bdict.get(bid)
            if bdef is None:
                continue
            is_built = bid in town.buildings
            can_build = town.can_build(bid, player.resources)
            has_prereqs = all(p in town.buildings for p in bdef.prerequisites)

            # Row separator
            if i > 0:
                sep_y = int(y)
                if content_top <= sep_y <= content_bottom:
                    pygame.draw.line(
                        self.surface,
                        (60, 65, 75),
                        (content_x, sep_y),
                        (content_x + content_w, sep_y),
                        1,
                    )

            # Line 1: Building name
            name_color = COLOR_BUILT if is_built else COLOR_TEXT
            name_text = self.font.render(bdef.name, True, name_color)
            self.surface.blit(name_text, (content_x + 5, y + 2))

            # Line 2: Benefit description
            benefit = self._building_benefit(bdef, town)
            if benefit:
                benefit_color = (180, 170, 100) if is_built else (150, 150, 120)
                benefit_text = self.small_font.render(benefit, True, benefit_color)
                self.surface.blit(benefit_text, (content_x + 5, y + 22))

            # Line 3: Cost + prerequisites (only for unbuilt)
            if not is_built:
                line3_y = y + 40
                cost_str = self._format_cost(bdef.cost)
                cost_color = COLOR_GOLD if has_prereqs else (120, 110, 80)
                cost_text = self.tiny_font.render(cost_str, True, cost_color)
                self.surface.blit(cost_text, (content_x + 5, line3_y))

                # Missing prerequisites
                if not has_prereqs:
                    missing = [
                        bdict[p].name
                        for p in bdef.prerequisites
                        if p not in town.buildings and p in bdict
                    ]
                    if missing:
                        prereq_str = "Requires: " + ", ".join(missing)
                        prereq_color = (180, 90, 90)
                        prereq_text = self.tiny_font.render(
                            prereq_str, True, prereq_color
                        )
                        # Place after cost with some gap
                        px = content_x + 5 + cost_text.get_width() + 12
                        # If it would overflow, put on its own starting position
                        if px + prereq_text.get_width() > content_x + info_w:
                            px = content_x + 5
                            # Render truncated if still too wide
                            while (
                                prereq_text.get_width() > info_w - 10
                                and len(prereq_str) > 12
                            ):
                                prereq_str = prereq_str[:-2] + "…"
                                prereq_text = self.tiny_font.render(
                                    prereq_str, True, prereq_color
                                )
                        self.surface.blit(prereq_text, (px, line3_y))

            # Build button / status (right column, vertically centered)
            btn_x = content_x + content_w - btn_col_w
            btn_rect = pygame.Rect(btn_x, int(y) + 18, btn_col_w - 6, 28)
            self.build_rects.append((btn_rect, bid))

            if is_built:
                status = self.font.render("Built", True, COLOR_BUILT)
                status_rect = status.get_rect(center=btn_rect.center)
                self.surface.blit(status, status_rect)
            elif can_build:
                btn_color = (
                    COLOR_BUTTON_HOVER
                    if btn_rect.collidepoint(mx, my)
                    else COLOR_BUTTON
                )
                pygame.draw.rect(self.surface, btn_color, btn_rect, border_radius=4)
                btn_text = self.font.render("Build", True, (255, 255, 255))
                btn_text_rect = btn_text.get_rect(center=btn_rect.center)
                self.surface.blit(btn_text, btn_text_rect)
            else:
                pygame.draw.rect(
                    self.surface, COLOR_BUTTON_DISABLED, btn_rect, border_radius=4
                )
                reason = "No funds" if has_prereqs else "Locked"
                btn_text = self.small_font.render(reason, True, (140, 140, 140))
                btn_text_rect = btn_text.get_rect(center=btn_rect.center)
                self.surface.blit(btn_text, btn_text_rect)

        # Restore clip
        self.surface.set_clip(prev_clip)

        # Scrollbar (only if content overflows)
        if self._build_scroll_max > 0:
            self._draw_scrollbar(
                content_x + content_w + 2,
                content_top,
                visible_h,
                total_h,
                self.build_scroll_px,
                self._build_scroll_max,
                scrollbar_w,
                mx,
                my,
            )

    def _draw_recruit_tab(self, town: Town, player: PlayerState):
        """Draw the Recruit tab: scrollable dwellings + army upgrade section."""
        mx, my = pygame.mouse.get_pos()
        self.recruit_rects.clear()
        self.upgrade_rects.clear()

        row_h = self.row_height
        scrollbar_w = 12
        content_x = self.panel_x + 10
        content_w = self.panel_w - 20 - scrollbar_w - 4
        content_top = self.panel_y + 82
        content_bottom = self.panel_y + self.panel_h - 10
        visible_h = content_bottom - content_top

        built_dwellings = [(i, d) for i, d in enumerate(town.dwellings) if d.built]

        # Compute upgradable stacks
        from lops.adventure.buildings import CREATURE_UPGRADES, UPGRADED_RECRUIT_COST
        from lops.data.creatures import CREATURE_REGISTRY

        upgradable = []
        if self.hero_at_town:
            hero_army = self.hero_at_town_army or []
            for slot_idx, stack in enumerate(hero_army):
                if not stack.alive:
                    continue
                for dwelling in town.dwellings:
                    if not dwelling.upgraded:
                        continue
                    base_stats = CREATURE_REGISTRY.get(dwelling.creature_type)
                    if base_stats is None or base_stats.name != stack.stats.name:
                        continue
                    upgraded_type = CREATURE_UPGRADES.get(dwelling.creature_type)
                    if upgraded_type is None:
                        continue
                    upg_cost = UPGRADED_RECRUIT_COST.get(upgraded_type, 0)
                    diff = max(0, upg_cost - dwelling.cost_per_unit)
                    upg_name = CREATURE_REGISTRY[upgraded_type].name
                    upgradable.append((slot_idx, stack, upg_name, diff))
                    break

        # Total content height
        total_h = len(built_dwellings) * row_h
        if upgradable:
            total_h += 32 + len(upgradable) * row_h  # separator + header + rows

        # Clamp scroll
        self._recruit_scroll_max = max(0.0, total_h - visible_h)
        self.recruit_scroll_px = max(
            0.0, min(self.recruit_scroll_px, self._recruit_scroll_max)
        )
        scroll = self.recruit_scroll_px

        # Clip region
        clip_rect = pygame.Rect(content_x, content_top, content_w, visible_h)
        prev_clip = self.surface.get_clip()
        self.surface.set_clip(clip_rect)

        if not built_dwellings:
            text = self.font.render("No dwellings built yet.", True, (140, 140, 140))
            self.surface.blit(text, (content_x + 10, content_top + 20))
            self.surface.set_clip(prev_clip)
            return

        # --- Dwellings ---
        for idx, (dwell_idx, dwelling) in enumerate(built_dwellings):
            y = content_top + idx * row_h - scroll
            if y + row_h < content_top or y > content_bottom:
                continue

            name = self.font.render(dwelling.creature_name, True, COLOR_TEXT)
            self.surface.blit(name, (content_x + 5, y + 5))

            avail = self.small_font.render(
                f"Avail: {dwelling.available}", True, COLOR_TEXT
            )
            self.surface.blit(avail, (content_x + 160, y + 8))

            unit_cost = dwelling.active_cost_per_unit
            cost = self.small_font.render(f"{unit_cost}g ea", True, COLOR_GOLD)
            self.surface.blit(cost, (content_x + 260, y + 8))

            can_recruit = dwelling.available > 0 and player.gold >= unit_cost
            btn_rect = pygame.Rect(content_x + content_w - 120, int(y) + 2, 110, 30)
            if btn_rect.bottom > content_top and btn_rect.top < content_bottom:
                self.recruit_rects.append((btn_rect, dwell_idx))

            if can_recruit:
                btn_color = (
                    COLOR_BUTTON_HOVER
                    if btn_rect.collidepoint(mx, my)
                    else COLOR_BUTTON
                )
            else:
                btn_color = COLOR_BUTTON_DISABLED
            pygame.draw.rect(self.surface, btn_color, btn_rect, border_radius=4)

            max_afford = player.gold // unit_cost if unit_cost > 0 else 0
            recruit_count = min(dwelling.available, max_afford)
            btn_label = f"Recruit {recruit_count}" if can_recruit else "---"
            btn_text = self.small_font.render(btn_label, True, (255, 255, 255))
            self.surface.blit(btn_text, btn_text.get_rect(center=btn_rect.center))

        # --- Army Upgrade section ---
        if upgradable:
            y = content_top + len(built_dwellings) * row_h + 8 - scroll
            if y < content_bottom:
                pygame.draw.line(
                    self.surface,
                    (80, 80, 100),
                    (content_x + 5, int(y)),
                    (content_x + content_w, int(y)),
                )
                y += 4
                header = self.small_font.render("Upgrade Army", True, COLOR_GOLD)
                self.surface.blit(header, (content_x + 5, int(y)))
                y += 20

                for slot_idx, stack, upg_name, cost_diff in upgradable:
                    if y + row_h < content_top or y > content_bottom:
                        y += row_h
                        continue
                    total_cost = cost_diff * stack.count
                    can_afford = player.gold >= total_cost

                    label = f"{stack.stats.name} x{stack.count} → {upg_name}"
                    display_name = label
                    name_surf = self.small_font.render(display_name, True, COLOR_TEXT)
                    max_w = content_w - 150
                    while name_surf.get_width() > max_w and len(display_name) > 8:
                        display_name = display_name[:-2] + "…"
                        name_surf = self.small_font.render(
                            display_name, True, COLOR_TEXT
                        )
                    self.surface.blit(name_surf, (content_x + 5, int(y) + 5))

                    cost_surf = self.small_font.render(
                        f"{total_cost}g", True, COLOR_GOLD
                    )
                    self.surface.blit(
                        cost_surf, (content_x + content_w - 190, int(y) + 5)
                    )

                    btn_rect = pygame.Rect(
                        content_x + content_w - 120, int(y) + 2, 110, 26
                    )
                    if btn_rect.bottom > content_top and btn_rect.top < content_bottom:
                        self.upgrade_rects.append((btn_rect, slot_idx))

                    if can_afford:
                        btn_color = (
                            (100, 60, 160)
                            if btn_rect.collidepoint(mx, my)
                            else (70, 45, 120)
                        )
                    else:
                        btn_color = COLOR_BUTTON_DISABLED
                    pygame.draw.rect(self.surface, btn_color, btn_rect, border_radius=4)

                    btn_label = "Upgrade" if can_afford else "---"
                    btn_text = self.small_font.render(btn_label, True, (255, 255, 255))
                    self.surface.blit(
                        btn_text, btn_text.get_rect(center=btn_rect.center)
                    )

                    y += row_h

        # Restore clip
        self.surface.set_clip(prev_clip)

        # Scrollbar
        if self._recruit_scroll_max > 0:
            self._draw_scrollbar(
                content_x + content_w + 2,
                content_top,
                visible_h,
                total_h,
                self.recruit_scroll_px,
                self._recruit_scroll_max,
                scrollbar_w,
                mx,
                my,
            )

    def _draw_tavern_tab(self, town: Town, player: PlayerState):
        """Draw the Tavern tab: available heroes to hire."""
        mx, my = pygame.mouse.get_pos()
        self.tavern_rects.clear()
        start_y = self.panel_y + 82

        from lops.adventure.adventure_state import MAX_HEROES_PER_PLAYER
        from lops.data.heroes import HERO_HIRE_COST

        if not town.tavern_heroes:
            text = self.font.render("No heroes available.", True, (140, 140, 140))
            self.surface.blit(text, (self.panel_x + 20, start_y + 20))
            return

        can_afford = player.resources.gold >= HERO_HIRE_COST
        at_hero_limit = len(player.alive_heroes()) >= MAX_HEROES_PER_PLAYER

        # Cost header
        cost_hdr = self.small_font.render(
            f"Hire cost: {HERO_HIRE_COST}g  |  Heroes: {len(player.alive_heroes())}/{MAX_HEROES_PER_PLAYER}",
            True,
            COLOR_GOLD,
        )
        self.surface.blit(cost_hdr, (self.panel_x + 15, start_y))
        start_y += 24

        for i, hero_def in enumerate(town.tavern_heroes):
            y = start_y + i * 80

            # Hero name
            name_text = self.font.render(hero_def.name, True, COLOR_TEXT)
            self.surface.blit(name_text, (self.panel_x + 15, y))

            # Skills

            skill_strs = []
            for sid, lvl in hero_def.skills:
                from lops.data.skills import SKILL_REGISTRY

                sdef = SKILL_REGISTRY.get(sid)
                if sdef:
                    lvl_abbr = lvl.name[:3]
                    skill_strs.append(f"{sdef.name} ({lvl_abbr})")
            skills_text = self.small_font.render(
                ", ".join(skill_strs), True, (150, 150, 120)
            )
            self.surface.blit(skills_text, (self.panel_x + 15, y + 24))

            # Stats
            stats_text = self.tiny_font.render(
                f"ATK:{hero_def.attack} DEF:{hero_def.defense} "
                f"SPL:{hero_def.spell_power} KNW:{hero_def.knowledge}",
                True,
                (140, 140, 160),
            )
            self.surface.blit(stats_text, (self.panel_x + 15, y + 42))

            # Hire button
            btn_rect = pygame.Rect(self.panel_x + self.panel_w - 130, y + 10, 110, 30)
            self.tavern_rects.append(btn_rect)

            can_hire = can_afford and not at_hero_limit
            if can_hire:
                btn_color = (
                    COLOR_BUTTON_HOVER
                    if btn_rect.collidepoint(mx, my)
                    else COLOR_BUTTON
                )
                pygame.draw.rect(self.surface, btn_color, btn_rect, border_radius=4)
                btn_text = self.small_font.render(
                    f"Hire ({HERO_HIRE_COST}g)", True, (255, 255, 255)
                )
            else:
                pygame.draw.rect(
                    self.surface, COLOR_BUTTON_DISABLED, btn_rect, border_radius=4
                )
                reason = "Max heroes" if at_hero_limit else "No funds"
                btn_text = self.tiny_font.render(reason, True, (140, 140, 140))
            btn_text_rect = btn_text.get_rect(center=btn_rect.center)
            self.surface.blit(btn_text, btn_text_rect)

            # Separator
            sep_y = y + 68
            pygame.draw.line(
                self.surface,
                (60, 65, 75),
                (self.panel_x + 10, sep_y),
                (self.panel_x + self.panel_w - 10, sep_y),
                1,
            )

    def _draw_artifacts_tab(self, town: Town, player: PlayerState):
        """Draw the Artifacts tab: artifacts available from the merchant."""
        mx, my = pygame.mouse.get_pos()
        self.merchant_rects.clear()
        start_y = self.panel_y + 82

        from lops.artifacts import ArtifactClass
        from lops.data.artifacts import ARTIFACT_COST, ARTIFACT_REGISTRY

        CLASS_COLORS = {
            ArtifactClass.TREASURE: (220, 220, 220),
            ArtifactClass.MINOR: (80, 200, 80),
            ArtifactClass.MAJOR: (80, 130, 220),
            ArtifactClass.RELIC: (240, 200, 50),
        }

        if not town.merchant_artifacts:
            text = self.font.render("No artifacts available.", True, (140, 140, 140))
            self.surface.blit(text, (self.panel_x + 20, start_y + 20))
            return

        hero_here = self.hero_at_town

        for i, art_id in enumerate(town.merchant_artifacts):
            adef = ARTIFACT_REGISTRY.get(art_id)
            if adef is None:
                continue
            cost = ARTIFACT_COST.get(art_id, 5000)
            y = start_y + i * 90

            # Name with class color
            name_color = CLASS_COLORS.get(adef.artifact_class, COLOR_TEXT)
            name_text = self.font.render(adef.name, True, name_color)
            self.surface.blit(name_text, (self.panel_x + 15, y))

            # Slot label
            from lops.artifacts import SLOT_NAMES

            slot_text = self.tiny_font.render(
                f"Slot: {SLOT_NAMES.get(adef.slot, '?')}  |  {adef.artifact_class.name.title()}",
                True,
                (140, 140, 160),
            )
            self.surface.blit(slot_text, (self.panel_x + 15, y + 24))

            # Description
            desc_text = self.small_font.render(adef.description, True, (180, 180, 160))
            self.surface.blit(desc_text, (self.panel_x + 15, y + 40))

            # Buy button
            btn_rect = pygame.Rect(self.panel_x + self.panel_w - 140, y + 10, 120, 30)
            self.merchant_rects.append(btn_rect)

            can_buy = player.resources.gold >= cost and hero_here
            if can_buy:
                btn_color = (
                    COLOR_BUTTON_HOVER
                    if btn_rect.collidepoint(mx, my)
                    else COLOR_BUTTON
                )
                pygame.draw.rect(self.surface, btn_color, btn_rect, border_radius=4)
                btn_text = self.small_font.render(
                    f"Buy ({cost}g)", True, (255, 255, 255)
                )
            else:
                pygame.draw.rect(
                    self.surface, COLOR_BUTTON_DISABLED, btn_rect, border_radius=4
                )
                reason = "No hero here" if not hero_here else "No funds"
                btn_text = self.tiny_font.render(reason, True, (140, 140, 140))
            btn_text_rect = btn_text.get_rect(center=btn_rect.center)
            self.surface.blit(btn_text, btn_text_rect)

            # Separator
            sep_y = y + 78
            pygame.draw.line(
                self.surface,
                (60, 65, 75),
                (self.panel_x + 10, sep_y),
                (self.panel_x + self.panel_w - 10, sep_y),
                1,
            )

    def _draw_marketplace_tab(self, town: Town, player: PlayerState):
        """Draw HoMM3-style Marketplace: two-column resource grids + slider."""
        from lops.adventure.game_director import GameDirector

        mx, my = pygame.mouse.get_pos()
        self._market_sell_rects.clear()
        self._market_buy_rects.clear()

        # Resources: 6 non-gold in a 2x3 grid, gold in a wide row below
        grid_res = [
            ("wood", "Wood"),
            ("mercury", "Mercury"),
            ("ore", "Ore"),
            ("sulfur", "Sulfur"),
            ("crystal", "Crystal"),
            ("gems", "Gems"),
        ]

        sell = self._market_sell
        buy = self._market_buy
        mp = self.marketplace_count
        sell_ratio, buy_ratio = (0, 0)
        if sell and buy and sell != buy:
            sell_ratio, buy_ratio = GameDirector.get_exchange_rate(mp, sell, buy)

        start_y = self.panel_y + 82
        left = self.panel_x + 10
        inner_w = self.panel_w - 20
        col_w = inner_w // 2 - 8  # each column width
        right_col = left + inner_w // 2 + 8

        # Flavor text
        flavor = "Click on the items you wish to trade with and for."
        flavor_text = self.small_font.render(flavor, True, (170, 160, 140))
        self.surface.blit(flavor_text, (left, start_y))

        # --- Column headers ---
        header_y = start_y + 22
        sell_hdr = self.font.render("Kingdom Resources", True, COLOR_GOLD)
        self.surface.blit(sell_hdr, (left, header_y))
        buy_hdr = self.font.render("Available for Trade", True, COLOR_GOLD)
        self.surface.blit(buy_hdr, (right_col, header_y))

        # --- Resource grids ---
        grid_y = header_y + 26
        cell_w = col_w // 2 - 3
        cell_h = 42
        cell_gap = 4

        # Draw a 2x3 grid of non-gold resources + 1 gold row
        def draw_res_cell(
            rname: str, label: str, x: int, y: int, w: int, h: int,
            is_sell_side: bool,
        ):
            """Draw a single resource cell with icon-style layout."""
            rect = pygame.Rect(x, y, w, h)
            if is_sell_side:
                self._market_sell_rects[rname] = rect
                selected = sell == rname
                is_disabled = rname == buy
            else:
                self._market_buy_rects[rname] = rect
                selected = buy == rname
                is_disabled = rname == sell

            hovering = rect.collidepoint(mx, my) and not is_disabled
            if is_disabled:
                bg = (30, 30, 35)
                border = (45, 45, 55)
            elif selected:
                bg = (70, 55, 30) if is_sell_side else (30, 55, 70)
                border = (200, 170, 60) if is_sell_side else (60, 170, 200)
            elif hovering:
                bg = (60, 55, 45) if is_sell_side else (45, 55, 60)
                border = (130, 120, 80) if is_sell_side else (80, 120, 130)
            else:
                bg = (42, 40, 48)
                border = (70, 68, 80)

            pygame.draw.rect(self.surface, bg, rect, border_radius=3)
            pygame.draw.rect(self.surface, border, rect, 1 + int(selected), border_radius=3)

            # Resource color swatch (simulated icon)
            swatch_color = RES_COLORS.get(rname, COLOR_TEXT)
            if is_disabled:
                swatch_color = (60, 60, 60)
            swatch_rect = pygame.Rect(x + 4, y + 6, 14, 14)
            pygame.draw.rect(self.surface, swatch_color, swatch_rect, border_radius=2)
            pygame.draw.rect(self.surface, (0, 0, 0), swatch_rect, 1, border_radius=2)

            # Resource name
            name_color = COLOR_TEXT if not is_disabled else (70, 70, 70)
            name_surf = self.tiny_font.render(label, True, name_color)
            self.surface.blit(name_surf, (x + 22, y + 4))

            # Amount
            amt = getattr(player.resources, rname, 0)
            amt_color = COLOR_TEXT if not is_disabled else (70, 70, 70)
            amt_surf = self.small_font.render(str(amt), True, amt_color)
            self.surface.blit(amt_surf, (x + 22, y + 20))

        # Left column: Kingdom Resources (sell side)
        for i, (rname, label) in enumerate(grid_res):
            row, col = divmod(i, 2)
            cx = left + col * (cell_w + cell_gap)
            cy = grid_y + row * (cell_h + cell_gap)
            draw_res_cell(rname, label, cx, cy, cell_w, cell_h, True)

        # Gold row (sell side) — spans full column width
        gold_y = grid_y + 3 * (cell_h + cell_gap)
        draw_res_cell("gold", "Gold", left, gold_y, col_w, cell_h, True)

        # Right column: Available for Trade (buy side)
        for i, (rname, label) in enumerate(grid_res):
            row, col = divmod(i, 2)
            cx = right_col + col * (cell_w + cell_gap)
            cy = grid_y + row * (cell_h + cell_gap)
            draw_res_cell(rname, label, cx, cy, cell_w, cell_h, False)

        # Gold row (buy side)
        draw_res_cell("gold", "Gold", right_col, gold_y, col_w, cell_h, False)

        # --- Divider ---
        div_x = left + inner_w // 2
        pygame.draw.line(
            self.surface, (70, 68, 80),
            (div_x, grid_y), (div_x, gold_y + cell_h), 1,
        )

        # --- Bottom section: slider + trade info ---
        bottom_y = gold_y + cell_h + 10

        if sell and buy and sell != buy and sell_ratio > 0:
            current_sell = getattr(player.resources, sell, 0)
            max_trades = current_sell // sell_ratio
            max_amount = max_trades * sell_ratio
            self._market_amount = max(0, min(self._market_amount, max_amount))
            if sell_ratio > 0:
                self._market_amount = (self._market_amount // sell_ratio) * sell_ratio

            trades_count = self._market_amount // sell_ratio if sell_ratio > 0 else 0
            receive = trades_count * buy_ratio

            # Trade summary line
            sell_name = sell.capitalize()
            buy_name = buy.capitalize()
            summary = f"{self._market_amount} {sell_name}  \u2192  {receive} {buy_name}"
            summary_color = COLOR_TEXT if self._market_amount > 0 else (120, 120, 120)
            summary_surf = self.font.render(summary, True, summary_color)
            summary_rect = summary_surf.get_rect(
                centerx=self.panel_x + self.panel_w // 2, y=bottom_y
            )
            self.surface.blit(summary_surf, summary_rect)

            # Rate indicator
            rate_text = f"(rate: {sell_ratio}:{buy_ratio})"
            rate_surf = self.tiny_font.render(rate_text, True, (130, 120, 100))
            rate_rect = rate_surf.get_rect(
                centerx=self.panel_x + self.panel_w // 2, y=bottom_y + 22
            )
            self.surface.blit(rate_surf, rate_rect)

            # --- QTY TO TRADE slider ---
            slider_y = bottom_y + 40
            slider_label = self.small_font.render("QTY TO TRADE", True, COLOR_GOLD)
            slider_label_rect = slider_label.get_rect(
                centerx=self.panel_x + self.panel_w // 2, y=slider_y
            )
            self.surface.blit(slider_label, slider_label_rect)

            track_y = slider_y + 20
            track_x = left + 30
            track_w = inner_w - 60
            track_h = 20
            # Hit area is larger than visual track for easier clicking
            hit_pad = 6
            self._market_slider_track = pygame.Rect(
                track_x, track_y - hit_pad, track_w, track_h + hit_pad * 2
            )

            # Visual track (drawn smaller than hit area)
            visual_track = pygame.Rect(track_x, track_y, track_w, track_h)
            pygame.draw.rect(
                self.surface, (25, 25, 30), visual_track, border_radius=5
            )
            pygame.draw.rect(
                self.surface, (80, 75, 65), visual_track, 1, border_radius=5
            )

            # Filled portion
            if max_amount > 0:
                fill_frac = self._market_amount / max_amount
                fill_w = max(0, int((track_w - 4) * fill_frac))
                if fill_w > 0:
                    fill_rect = pygame.Rect(track_x + 2, track_y + 2, fill_w, track_h - 4)
                    pygame.draw.rect(
                        self.surface, (100, 85, 50), fill_rect, border_radius=4
                    )

            # Slider handle
            if max_amount > 0:
                handle_x = track_x + 2 + int(
                    (track_w - 4) * (self._market_amount / max_amount)
                )
            else:
                handle_x = track_x + 2
            handle_w = 14
            handle_h = track_h + 8
            handle_rect = pygame.Rect(
                handle_x - handle_w // 2, track_y - 4, handle_w, handle_h
            )
            handle_color = (180, 160, 100) if handle_rect.collidepoint(mx, my) else (150, 135, 85)
            pygame.draw.rect(self.surface, handle_color, handle_rect, border_radius=4)
            pygame.draw.rect(self.surface, (200, 180, 120), handle_rect, 1, border_radius=4)

            # Trade button
            trade_y = track_y + track_h + 14
            self._market_trade_rect = pygame.Rect(
                left + (inner_w - 140) // 2, trade_y, 140, 30
            )
            can_trade = self._market_amount >= sell_ratio
            if can_trade:
                btn_color = (
                    COLOR_BUTTON_HOVER
                    if self._market_trade_rect.collidepoint(mx, my)
                    else COLOR_BUTTON
                )
                pygame.draw.rect(
                    self.surface, btn_color, self._market_trade_rect, border_radius=4
                )
                trade_surf = self.font.render("Trade", True, (255, 255, 255))
            else:
                pygame.draw.rect(
                    self.surface, COLOR_BUTTON_DISABLED,
                    self._market_trade_rect, border_radius=4,
                )
                trade_surf = self.font.render("Trade", True, (100, 100, 100))
            self.surface.blit(
                trade_surf, trade_surf.get_rect(center=self._market_trade_rect.center)
            )

            # Selected resource name at very bottom
            sel_name = sell_name if sell != "gold" else buy_name
            sel_surf = self.small_font.render(sel_name, True, (170, 160, 140))
            sel_rect = sel_surf.get_rect(
                centerx=self.panel_x + self.panel_w // 2,
                y=trade_y + 34,
            )
            self.surface.blit(sel_surf, sel_rect)
        else:
            # No valid pair selected
            hint = "Click a resource on the left to sell, right to buy."
            hint_surf = self.small_font.render(hint, True, (130, 130, 130))
            hint_rect = hint_surf.get_rect(
                centerx=self.panel_x + self.panel_w // 2, y=bottom_y + 20
            )
            self.surface.blit(hint_surf, hint_rect)
            self._market_trade_rect = pygame.Rect(0, 0, 0, 0)
            self._market_slider_track = pygame.Rect(0, 0, 0, 0)

    def _draw_garrison_tab(self, town: Town, player: PlayerState):
        """Draw the Garrison tab: hero army on left, garrison on right, quantity picker."""
        mx, my = pygame.mouse.get_pos()
        self.hero_army_rects.clear()
        self.garrison_rects.clear()
        start_y = self.panel_y + 82
        col_w = (self.panel_w - 30) // 2
        slot_h = 30
        slot_spacing = 32

        # Validate selection is still valid
        self._validate_garrison_selection(town, player)

        # Header labels
        hero_label = self.font.render("Hero Army", True, COLOR_GOLD)
        self.surface.blit(hero_label, (self.panel_x + 15, start_y))
        garrison_label = self.font.render("Town Garrison", True, COLOR_GOLD)
        self.surface.blit(garrison_label, (self.panel_x + col_w + 20, start_y))

        slot_y = start_y + 24

        # Hero army slots (left column)
        for i in range(7):
            y = slot_y + i * slot_spacing
            rect = pygame.Rect(self.panel_x + 10, y, col_w - 5, slot_h)
            self.hero_army_rects.append(rect)

            selected = self._garrison_selected == ("hero", i)
            hero_army = self.hero_at_town_army or []
            if i < len(hero_army) and hero_army[i].alive:
                stack = hero_army[i]
                hovering = rect.collidepoint(mx, my)
                if selected:
                    bg = (70, 110, 70)
                elif hovering:
                    bg = (60, 80, 60)
                else:
                    bg = (50, 55, 65)
                pygame.draw.rect(self.surface, bg, rect, border_radius=4)
                border = (140, 200, 140) if selected else (90, 90, 110)
                pygame.draw.rect(
                    self.surface, border, rect, 1 + selected, border_radius=4
                )
                name = self.small_font.render(
                    f"{stack.stats.name} x{stack.count}", True, COLOR_TEXT
                )
                self.surface.blit(name, (rect.x + 8, rect.y + 6))
            else:
                pygame.draw.rect(self.surface, (35, 38, 45), rect, border_radius=4)
                pygame.draw.rect(self.surface, (60, 60, 70), rect, 1, border_radius=4)
                empty = self.tiny_font.render("(empty)", True, (80, 80, 80))
                self.surface.blit(empty, (rect.x + 8, rect.y + 8))

        # Garrison slots (right column)
        for i in range(7):
            y = slot_y + i * slot_spacing
            rect = pygame.Rect(self.panel_x + col_w + 15, y, col_w - 5, slot_h)
            self.garrison_rects.append(rect)

            selected = self._garrison_selected == ("garrison", i)
            if i < len(town.garrison) and town.garrison[i].alive:
                stack = town.garrison[i]
                hovering = rect.collidepoint(mx, my)
                if selected:
                    bg = (60, 60, 110)
                elif hovering:
                    bg = (60, 60, 80)
                else:
                    bg = (50, 55, 65)
                pygame.draw.rect(self.surface, bg, rect, border_radius=4)
                border = (140, 140, 220) if selected else (90, 90, 110)
                pygame.draw.rect(
                    self.surface, border, rect, 1 + selected, border_radius=4
                )
                name = self.small_font.render(
                    f"{stack.stats.name} x{stack.count}", True, COLOR_TEXT
                )
                self.surface.blit(name, (rect.x + 8, rect.y + 6))
            else:
                pygame.draw.rect(self.surface, (35, 38, 45), rect, border_radius=4)
                pygame.draw.rect(self.surface, (60, 60, 70), rect, 1, border_radius=4)
                empty = self.tiny_font.render("(empty)", True, (80, 80, 80))
                self.surface.blit(empty, (rect.x + 8, rect.y + 8))

        # Quantity picker (shown when a slot is selected)
        if self._garrison_selected is not None:
            self._draw_quantity_picker(mx, my)

    def _validate_garrison_selection(self, town: Town, player: PlayerState):
        """Clear selection if the selected slot is no longer valid."""
        sel = self._garrison_selected
        if sel is None:
            return
        kind, idx = sel
        if kind == "hero":
            hero_army = self.hero_at_town_army or []
            if idx >= len(hero_army) or not hero_army[idx].alive:
                self._garrison_selected = None
        else:
            if idx >= len(town.garrison) or not town.garrison[idx].alive:
                self._garrison_selected = None

    def _draw_quantity_picker(self, mx: int, my: int):
        """Draw the transfer quantity picker bar at the bottom of the garrison tab."""
        assert self._garrison_selected is not None
        kind, idx = self._garrison_selected
        if kind == "hero":
            direction_label = "-> Garrison"
            accent = (150, 200, 150)
        else:
            direction_label = "-> Hero"
            accent = (150, 150, 220)

        bar_y = self.panel_y + self.panel_h - 55
        bar_x = self.panel_x + 10
        bar_w = self.panel_w - 20

        # Background bar
        bar_rect = pygame.Rect(bar_x, bar_y, bar_w, 44)
        pygame.draw.rect(self.surface, (55, 58, 68), bar_rect, border_radius=6)
        pygame.draw.rect(self.surface, (90, 90, 110), bar_rect, 1, border_radius=6)

        # Direction label
        dir_text = self.small_font.render(direction_label, True, accent)
        self.surface.blit(dir_text, (bar_x + 8, bar_y + 4))

        # Buttons: -10, -, count, +, +10, All, [Transfer]
        btn_y = bar_y + 20
        btn_h = 20
        cx = bar_x + 8

        # -10 button
        self._minus10_btn_rect = pygame.Rect(cx, btn_y, 28, btn_h)
        self._draw_picker_btn(self._minus10_btn_rect, "-10", mx, my)
        cx += 32

        # - button
        self._minus_btn_rect = pygame.Rect(cx, btn_y, 22, btn_h)
        self._draw_picker_btn(self._minus_btn_rect, "-", mx, my)
        cx += 26

        # Count display
        count_text = self.font.render(
            str(self._garrison_transfer_count), True, COLOR_GOLD
        )
        count_rect = count_text.get_rect(midleft=(cx + 4, btn_y + btn_h // 2))
        self.surface.blit(count_text, count_rect)
        cx += max(count_rect.width + 12, 36)

        # + button
        self._plus_btn_rect = pygame.Rect(cx, btn_y, 22, btn_h)
        self._draw_picker_btn(self._plus_btn_rect, "+", mx, my)
        cx += 26

        # +10 button
        self._plus10_btn_rect = pygame.Rect(cx, btn_y, 28, btn_h)
        self._draw_picker_btn(self._plus10_btn_rect, "+10", mx, my)
        cx += 32

        # All button
        self._all_btn_rect = pygame.Rect(cx, btn_y, 28, btn_h)
        self._draw_picker_btn(self._all_btn_rect, "All", mx, my)
        cx += 36

        # Transfer button
        self._transfer_btn_rect = pygame.Rect(
            bar_x + bar_w - 80, btn_y - 2, 72, btn_h + 4
        )
        can_transfer = self._garrison_transfer_count > 0
        if can_transfer:
            btn_color = (
                COLOR_BUTTON_HOVER
                if self._transfer_btn_rect.collidepoint(mx, my)
                else COLOR_BUTTON
            )
        else:
            btn_color = COLOR_BUTTON_DISABLED
        pygame.draw.rect(
            self.surface, btn_color, self._transfer_btn_rect, border_radius=4
        )
        t_text = self.small_font.render("Transfer", True, (255, 255, 255))
        t_rect = t_text.get_rect(center=self._transfer_btn_rect.center)
        self.surface.blit(t_text, t_rect)

    def _draw_picker_btn(self, rect: pygame.Rect, label: str, mx: int, my: int):
        """Draw a small quantity picker button."""
        hovering = rect.collidepoint(mx, my)
        bg = (80, 85, 100) if hovering else (65, 68, 80)
        pygame.draw.rect(self.surface, bg, rect, border_radius=3)
        text = self.tiny_font.render(label, True, COLOR_TEXT)
        text_rect = text.get_rect(center=rect.center)
        self.surface.blit(text, text_rect)

    def _handle_picker_click(
        self, pos: tuple[int, int], town: Town, player: PlayerState
    ) -> str | None:
        """Handle clicks on the quantity picker buttons. Returns transfer command or None."""
        if self._minus10_btn_rect.collidepoint(pos):
            self._garrison_transfer_count = max(1, self._garrison_transfer_count - 10)
            return None
        if self._minus_btn_rect.collidepoint(pos):
            self._garrison_transfer_count = max(1, self._garrison_transfer_count - 1)
            return None
        if self._plus_btn_rect.collidepoint(pos):
            self._garrison_transfer_count = min(
                self._garrison_max_count, self._garrison_transfer_count + 1
            )
            return None
        if self._plus10_btn_rect.collidepoint(pos):
            self._garrison_transfer_count = min(
                self._garrison_max_count, self._garrison_transfer_count + 10
            )
            return None
        if self._all_btn_rect.collidepoint(pos):
            self._garrison_transfer_count = self._garrison_max_count
            return None
        if (
            self._transfer_btn_rect.collidepoint(pos)
            and self._garrison_transfer_count > 0
            and self._garrison_selected is not None
        ):
            kind, idx = self._garrison_selected
            count = self._garrison_transfer_count
            self._garrison_selected = None
            if kind == "hero":
                return f"garrison_to:{idx}:{count}"
            else:
                return f"garrison_from:{idx}:{count}"
        return None

    def _format_cost(self, cost: Resources) -> str:
        """Format resource cost as compact string."""
        parts = []
        if cost.gold:
            parts.append(f"{cost.gold} gold")
        if cost.wood:
            parts.append(f"{cost.wood} wood")
        if cost.ore:
            parts.append(f"{cost.ore} ore")
        if cost.mercury:
            parts.append(f"{cost.mercury} merc")
        if cost.sulfur:
            parts.append(f"{cost.sulfur} sulf")
        if cost.crystal:
            parts.append(f"{cost.crystal} crys")
        if cost.gems:
            parts.append(f"{cost.gems} gems")
        return ", ".join(parts) if parts else "Free"

    def _draw_scrollbar(
        self,
        sb_x: int,
        track_top: int,
        visible_h: int,
        total_h: float,
        scroll_px: float,
        scroll_max: float,
        bar_w: int,
        mx: int,
        my: int,
    ):
        """Draw a classic scrollbar track + draggable thumb."""
        track_rect = pygame.Rect(sb_x, track_top, bar_w, visible_h)
        self._scrollbar_rect = track_rect

        # Track background
        pygame.draw.rect(self.surface, (30, 33, 40), track_rect)
        pygame.draw.rect(self.surface, (70, 70, 85), track_rect, 1)

        # Thumb size proportional to visible/total ratio
        thumb_h = max(20, int(visible_h * (visible_h / total_h)))
        scroll_range = visible_h - thumb_h
        if scroll_max > 0:
            thumb_y = track_top + int(scroll_range * scroll_px / scroll_max)
        else:
            thumb_y = track_top

        thumb_rect = pygame.Rect(sb_x + 1, thumb_y, bar_w - 2, thumb_h)
        self._scrollbar_thumb_rect = thumb_rect

        # Thumb color: highlight on hover/drag
        if self._scrollbar_dragging:
            thumb_color = (140, 140, 160)
        elif thumb_rect.collidepoint(mx, my):
            thumb_color = (110, 110, 130)
        else:
            thumb_color = (80, 82, 95)

        pygame.draw.rect(self.surface, thumb_color, thumb_rect, border_radius=3)

        # Grip lines on thumb (3 horizontal lines in center)
        grip_cx = thumb_rect.centerx
        grip_cy = thumb_rect.centery
        for dy in (-3, 0, 3):
            gy = grip_cy + dy
            if thumb_rect.top + 4 <= gy <= thumb_rect.bottom - 4:
                pygame.draw.line(
                    self.surface,
                    (55, 55, 65),
                    (thumb_rect.left + 3, gy),
                    (thumb_rect.right - 3, gy),
                    1,
                )

    def handle_scroll(self, direction: int):
        """Handle mouse wheel scroll. direction: positive=up, negative=down."""
        if self.active_tab == self.TAB_BUILD:
            self.build_scroll_px -= direction * self.row_height * 0.6
            # Clamping happens in _draw_build_tab
        elif self.active_tab == self.TAB_RECRUIT:
            self.recruit_scroll_px -= direction * self.row_height * 0.6
            # Clamping happens in _draw_recruit_tab

    def handle_mouse_down(self, pos: tuple[int, int]) -> bool:
        """Handle mouse button down for scrollbar drag. Returns True if consumed."""
        if self.active_tab != self.TAB_BUILD or self._build_scroll_max <= 0:
            return False
        if self._scrollbar_thumb_rect.collidepoint(pos):
            self._scrollbar_dragging = True
            self._scrollbar_drag_offset = pos[1] - self._scrollbar_thumb_rect.top
            return True
        if self._scrollbar_rect.collidepoint(pos):
            # Click on track — jump to position
            track_top = self._scrollbar_rect.top
            thumb_h = self._scrollbar_thumb_rect.height
            scroll_range = self._scrollbar_rect.height - thumb_h
            if scroll_range > 0:
                ratio = max(
                    0.0, min(1.0, (pos[1] - track_top - thumb_h / 2) / scroll_range)
                )
                self.build_scroll_px = ratio * self._build_scroll_max
            return True
        return False

    def handle_mouse_up(self):
        """Handle mouse button release — stop scrollbar drag."""
        self._scrollbar_dragging = False

    def handle_mouse_motion(self, pos: tuple[int, int]):
        """Handle mouse motion — update scrollbar drag."""
        if not self._scrollbar_dragging:
            return
        track_top = self._scrollbar_rect.top
        thumb_h = self._scrollbar_thumb_rect.height
        scroll_range = self._scrollbar_rect.height - thumb_h
        if scroll_range > 0:
            thumb_top = pos[1] - self._scrollbar_drag_offset
            ratio = max(0.0, min(1.0, (thumb_top - track_top) / scroll_range))
            self.build_scroll_px = ratio * self._build_scroll_max

    def handle_click(
        self, pos: tuple[int, int], town: Town, player: PlayerState
    ) -> str | int | BuildingId | None:
        """Handle click in town screen.

        Returns:
            -1: close
            int >= 0: dwelling index to recruit from (Recruit tab)
            BuildingId: building to construct (Build tab)
            'garrison_to:N': transfer hero army slot N to garrison
            'garrison_from:N': transfer garrison slot N to hero
            None: nothing clicked
        """
        if self.close_rect.collidepoint(pos):
            return -1

        # Tab clicks — map visible tab index to tab id
        visible_tabs = [self.TAB_BUILD, self.TAB_RECRUIT, self.TAB_GARRISON]
        if self.has_tavern:
            visible_tabs.append(self.TAB_TAVERN)
        if self.has_marketplace:
            visible_tabs.append(self.TAB_MARKETPLACE)
        if self.has_merchant:
            visible_tabs.append(self.TAB_ARTIFACTS)
        for idx, tab_id in enumerate(visible_tabs):
            if idx < len(self.tab_rects) and self.tab_rects[idx].collidepoint(pos):
                self.active_tab = tab_id
                return None

        if self.active_tab == self.TAB_BUILD:
            for rect, bid in self.build_rects:
                if rect.collidepoint(pos):
                    if town.can_build(bid, player.resources):
                        return bid
            return None

        elif self.active_tab == self.TAB_GARRISON:
            # If a slot is selected, check quantity picker buttons first
            if self._garrison_selected is not None:
                picker_result = self._handle_picker_click(pos, town, player)
                if picker_result is not None:
                    return picker_result

            # Hero army slot click -> select/deselect
            hero_army = self.hero_at_town_army or []
            for i, rect in enumerate(self.hero_army_rects):
                if rect.collidepoint(pos) and i < len(hero_army) and hero_army[i].alive:
                    if self._garrison_selected == ("hero", i):
                        self._garrison_selected = None  # deselect
                    else:
                        self._garrison_selected = ("hero", i)
                        self._garrison_max_count = hero_army[i].count
                        self._garrison_transfer_count = self._garrison_max_count
                    return None
            # Garrison slot click -> select/deselect
            for i, rect in enumerate(self.garrison_rects):
                if (
                    rect.collidepoint(pos)
                    and i < len(town.garrison)
                    and town.garrison[i].alive
                ):
                    if self._garrison_selected == ("garrison", i):
                        self._garrison_selected = None  # deselect
                    else:
                        self._garrison_selected = ("garrison", i)
                        self._garrison_max_count = town.garrison[i].count
                        self._garrison_transfer_count = self._garrison_max_count
                    return None
            return None

        elif self.active_tab == self.TAB_TAVERN:
            from lops.adventure.adventure_state import MAX_HEROES_PER_PLAYER
            from lops.data.heroes import HERO_HIRE_COST

            for i, rect in enumerate(self.tavern_rects):
                if rect.collidepoint(pos):
                    can_afford = player.resources.gold >= HERO_HIRE_COST
                    at_limit = len(player.alive_heroes()) >= MAX_HEROES_PER_PLAYER
                    if can_afford and not at_limit and i < len(town.tavern_heroes):
                        return f"hire_hero:{i}"
            return None

        elif self.active_tab == self.TAB_ARTIFACTS:
            from lops.data.artifacts import ARTIFACT_COST

            for i, rect in enumerate(self.merchant_rects):
                if rect.collidepoint(pos):
                    if i < len(town.merchant_artifacts):
                        art_id = town.merchant_artifacts[i]
                        cost = ARTIFACT_COST.get(art_id, 5000)
                        if player.resources.gold >= cost and self.hero_at_town:
                            return f"buy_artifact:{i}"
            return None

        elif self.active_tab == self.TAB_MARKETPLACE:
            return self._handle_marketplace_click(pos, player)

        else:  # TAB_RECRUIT
            # Check upgrade buttons first
            for rect, army_slot in self.upgrade_rects:
                if rect.collidepoint(pos):
                    return f"upgrade:{army_slot}"
            for rect, dwell_idx in self.recruit_rects:
                if rect.collidepoint(pos):
                    dwelling = town.dwellings[dwell_idx]
                    if (
                        dwelling.built
                        and dwelling.available > 0
                        and player.gold >= dwelling.active_cost_per_unit
                    ):
                        return dwell_idx
            return None

    def _handle_marketplace_click(
        self, pos: tuple[int, int], player: PlayerState
    ) -> str | None:
        """Handle clicks on the marketplace tab. Returns trade string or None."""
        from lops.adventure.game_director import GameDirector

        # Sell resource buttons (left column)
        for rname, rect in self._market_sell_rects.items():
            if rect.collidepoint(pos) and rname != self._market_buy:
                self._market_sell = rname
                self._market_amount = 0
                return None

        # Buy resource buttons (right column)
        for rname, rect in self._market_buy_rects.items():
            if rect.collidepoint(pos) and rname != self._market_sell:
                self._market_buy = rname
                self._market_amount = 0
                return None

        sell = self._market_sell
        buy = self._market_buy
        if not sell or not buy or sell == buy:
            return None

        sell_ratio, buy_ratio = GameDirector.get_exchange_rate(
            self.marketplace_count, sell, buy
        )
        if sell_ratio <= 0:
            return None

        current_sell = getattr(player.resources, sell, 0)
        max_amount = (current_sell // sell_ratio) * sell_ratio

        # Slider click — set amount based on click position
        if self._market_slider_track.collidepoint(pos):
            self._market_slider_dragging = True
            self._market_slider_set_from_x(pos[0], sell_ratio, max_amount)
            return None

        # Trade button
        if self._market_trade_rect.collidepoint(pos):
            if self._market_amount >= sell_ratio and current_sell >= self._market_amount:
                return f"trade:{sell}:{buy}:{self._market_amount}"

        return None

    def _market_slider_set_from_x(
        self, x: int, sell_ratio: int, max_amount: int
    ):
        """Set marketplace trade amount from a slider x position."""
        track = self._market_slider_track
        if track.width <= 4 or max_amount <= 0:
            return
        frac = max(0.0, min(1.0, (x - track.x - 2) / (track.width - 4)))
        raw = int(frac * max_amount)
        # Snap to multiples of sell_ratio
        snapped = (raw // sell_ratio) * sell_ratio
        self._market_amount = max(0, min(max_amount, snapped))

    def handle_marketplace_mouse_down(self, pos: tuple[int, int], player: PlayerState) -> bool:
        """Handle mouse-down for marketplace slider drag. Returns True if consumed."""
        if self.active_tab != self.TAB_MARKETPLACE:
            return False
        if self._market_slider_track.collidepoint(pos):
            self._market_slider_dragging = True
            sell = self._market_sell
            buy = self._market_buy
            if sell and buy and sell != buy:
                from lops.adventure.game_director import GameDirector

                sell_ratio, _ = GameDirector.get_exchange_rate(
                    self.marketplace_count, sell, buy
                )
                current_sell = getattr(player.resources, sell, 0)
                max_amount = (current_sell // sell_ratio) * sell_ratio
                self._market_slider_set_from_x(pos[0], sell_ratio, max_amount)
            return True
        return False

    def handle_marketplace_mouse_motion(self, pos: tuple[int, int], player: PlayerState):
        """Handle mouse motion for marketplace slider drag."""
        if not self._market_slider_dragging:
            return
        sell = self._market_sell
        buy = self._market_buy
        if not sell or not buy or sell == buy:
            return
        from lops.adventure.game_director import GameDirector

        sell_ratio, _ = GameDirector.get_exchange_rate(
            self.marketplace_count, sell, buy
        )
        current_sell = getattr(player.resources, sell, 0)
        max_amount = (current_sell // sell_ratio) * sell_ratio
        self._market_slider_set_from_x(pos[0], sell_ratio, max_amount)

    def handle_marketplace_mouse_up(self):
        """Handle mouse-up for marketplace slider drag."""
        self._market_slider_dragging = False
