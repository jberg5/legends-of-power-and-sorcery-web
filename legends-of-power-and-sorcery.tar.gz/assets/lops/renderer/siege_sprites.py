"""Siege battlefield sprite loader and procedural generator."""

from __future__ import annotations

import math
import os
import random
from collections.abc import Callable

import pygame

from lops.hex import HEX_SIZE, hex_polygon_corners
from lops.siege import WallState, WallType

ASSETS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets")
SIEGE_DIR = os.path.join(ASSETS_DIR, "siege")
TERRAIN_DIR = os.path.join(ASSETS_DIR, "terrain")

# Combat hex bounding box (flat-top, outer radius = HEX_SIZE = 36)
HEX_WIDTH = int(HEX_SIZE * 2)  # 72
HEX_HEIGHT = int(HEX_SIZE * math.sqrt(3))  # ~62


def _load_image(path: str) -> pygame.Surface | None:
    if os.path.exists(path):
        return pygame.image.load(path).convert_alpha()
    return None


def _make_hex_mask() -> pygame.Surface:
    """Create a hex-shaped alpha mask for combat-sized hexes."""
    mask = pygame.Surface((HEX_WIDTH, HEX_HEIGHT), pygame.SRCALPHA)
    cx, cy = HEX_WIDTH / 2, HEX_HEIGHT / 2
    corners = hex_polygon_corners(cx, cy, HEX_SIZE)
    pygame.draw.polygon(mask, (255, 255, 255, 255), corners)
    return mask


_hex_mask_cache: pygame.Surface | None = None


def _get_hex_mask() -> pygame.Surface:
    global _hex_mask_cache
    if _hex_mask_cache is None:
        _hex_mask_cache = _make_hex_mask()
    return _hex_mask_cache


def _clip_to_hex(source: pygame.Surface) -> pygame.Surface:
    """Scale source image and clip to combat hex shape."""
    scaled = pygame.transform.smoothscale(source, (HEX_WIDTH, HEX_HEIGHT))
    mask = _get_hex_mask()
    result = pygame.Surface((HEX_WIDTH, HEX_HEIGHT), pygame.SRCALPHA)
    result.blit(scaled, (0, 0))
    result.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    return result


def _clip_surface_to_hex(surf: pygame.Surface) -> pygame.Surface:
    """Clip an already-sized surface to hex shape (no scaling)."""
    w, h = surf.get_size()
    if w != HEX_WIDTH or h != HEX_HEIGHT:
        surf = pygame.transform.smoothscale(surf, (HEX_WIDTH, HEX_HEIGHT))
    mask = _get_hex_mask()
    result = pygame.Surface((HEX_WIDTH, HEX_HEIGHT), pygame.SRCALPHA)
    result.blit(surf, (0, 0))
    result.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    return result


# ---------------------------------------------------------------------------
# Procedural texture helpers
# ---------------------------------------------------------------------------


def _noise_surface_fast(
    w: int,
    h: int,
    base_color: tuple,
    variance: int = 15,
    alpha: int = 255,
    seed: int = 42,
) -> pygame.Surface:
    """Noise via 4x4 block fills for a textured look."""
    surf = pygame.Surface((w, h), pygame.SRCALPHA)
    rng = random.Random(seed)
    block = 4
    for y in range(0, h, block):
        for x in range(0, w, block):
            r = max(0, min(255, base_color[0] + rng.randint(-variance, variance)))
            g = max(0, min(255, base_color[1] + rng.randint(-variance, variance)))
            b = max(0, min(255, base_color[2] + rng.randint(-variance, variance)))
            pygame.draw.rect(
                surf, (r, g, b, alpha), (x, y, min(block, w - x), min(block, h - y))
            )
    return surf


def _draw_cracks(
    surf: pygame.Surface,
    count: int = 4,
    seed: int = 99,
    color: tuple = (30, 25, 15, 220),
    width: int = 2,
):
    """Draw random crack lines on a surface."""
    rng = random.Random(seed)
    w, h = surf.get_size()
    for _ in range(count):
        x1 = rng.randint(w // 5, 4 * w // 5)
        y1 = rng.randint(h // 5, 4 * h // 5)
        pts = [(x1, y1)]
        for _ in range(rng.randint(4, 8)):
            dx = rng.randint(-10, 10)
            dy = rng.randint(-10, 10)
            nx = max(2, min(w - 2, pts[-1][0] + dx))
            ny = max(2, min(h - 2, pts[-1][1] + dy))
            pts.append((nx, ny))
        if len(pts) >= 2:
            pygame.draw.lines(surf, color, False, pts, width)


def _draw_hex_border(surf: pygame.Surface, color: tuple, width: int = 2):
    """Draw a hex-shaped border on the surface."""
    cx, cy = surf.get_width() / 2, surf.get_height() / 2
    corners = hex_polygon_corners(cx, cy, HEX_SIZE - 1)
    pygame.draw.polygon(surf, color, corners, width)


# ---------------------------------------------------------------------------
# Procedural generators — all produce HEX_WIDTH x HEX_HEIGHT surfaces
# ---------------------------------------------------------------------------


def _generate_stone_wall() -> pygame.Surface:
    """Intact destructible stone wall."""
    surf = _noise_surface_fast(
        HEX_WIDTH, HEX_HEIGHT, (170, 165, 150), variance=12, alpha=240, seed=7
    )
    w, h = HEX_WIDTH, HEX_HEIGHT
    # Mortar / stone block lines
    rng = random.Random(7)
    block_h = max(6, h // 5)
    for i, y in enumerate(range(2, h - 2, block_h)):
        pygame.draw.line(surf, (120, 115, 100, 200), (0, y), (w, y), 1)
        # Staggered vertical joints
        offset = (block_h // 2) if i % 2 else 0
        for x in range(offset, w, w // 3):
            jx = x + rng.randint(-2, 2)
            pygame.draw.line(
                surf, (120, 115, 100, 200), (jx, y), (jx, min(y + block_h, h)), 1
            )
    # Hex clip + border
    result = _clip_surface_to_hex(surf)
    _draw_hex_border(result, (130, 125, 110, 220), 2)
    return result


def _generate_damaged_wall() -> pygame.Surface:
    """Damaged destructible wall — cracked stone."""
    surf = _noise_surface_fast(
        HEX_WIDTH, HEX_HEIGHT, (155, 140, 120), variance=15, alpha=240, seed=13
    )
    w, h = HEX_WIDTH, HEX_HEIGHT
    # Faded mortar lines
    block_h = max(6, h // 5)
    for y in range(2, h - 2, block_h):
        pygame.draw.line(surf, (110, 100, 80, 160), (0, y), (w, y), 1)
    # Heavy cracks
    _draw_cracks(surf, count=7, seed=13, color=(50, 30, 10, 240), width=2)
    _draw_cracks(surf, count=4, seed=77, color=(80, 50, 20, 180), width=1)
    # Reddish-brown damage tint
    tint = pygame.Surface((w, h), pygame.SRCALPHA)
    tint.fill((100, 40, 10, 40))
    surf.blit(tint, (0, 0))
    result = _clip_surface_to_hex(surf)
    _draw_hex_border(result, (100, 80, 60, 200), 2)
    return result


def _generate_rubble() -> pygame.Surface:
    """Destroyed wall — scattered rubble on ground."""
    surf = pygame.Surface((HEX_WIDTH, HEX_HEIGHT), pygame.SRCALPHA)
    rng = random.Random(21)
    # Dust/dirt base
    cx, cy = HEX_WIDTH // 2, HEX_HEIGHT // 2
    pygame.draw.circle(surf, (120, 110, 90, 50), (cx, cy), 24)
    # Rubble pieces — varied sizes and shades
    for _ in range(30):
        rx = rng.randint(8, HEX_WIDTH - 12)
        ry = rng.randint(HEX_HEIGHT // 4, HEX_HEIGHT - 8)
        rw = rng.randint(3, 10)
        rh = rng.randint(2, 7)
        grey = rng.randint(80, 170)
        alpha = rng.randint(100, 180)
        pygame.draw.rect(surf, (grey, grey - 15, grey - 30, alpha), (rx, ry, rw, rh))
    return _clip_surface_to_hex(surf)


def _generate_wood_gate() -> pygame.Surface:
    """Intact drawbridge / wooden gate — warm brown, clearly distinct from stone."""
    surf = _noise_surface_fast(
        HEX_WIDTH, HEX_HEIGHT, (155, 110, 50), variance=12, alpha=240, seed=31
    )
    w, h = HEX_WIDTH, HEX_HEIGHT
    # Horizontal plank lines
    plank_h = max(5, h // 7)
    for y in range(0, h, plank_h):
        pygame.draw.line(surf, (110, 75, 25, 200), (0, y), (w, y), 2)
    # Vertical bracing
    for x in (w // 3, 2 * w // 3):
        pygame.draw.line(surf, (100, 65, 20, 220), (x, 0), (x, h), 3)
    # Iron bands across
    for y in (h // 4, h // 2, 3 * h // 4):
        pygame.draw.line(surf, (100, 100, 110, 200), (4, y), (w - 4, y), 3)
    # Iron studs
    rng = random.Random(33)
    for y in range(h // 6, h, h // 4):
        for x in range(w // 5, w, w // 4):
            pygame.draw.circle(
                surf,
                (90, 90, 100, 200),
                (x + rng.randint(-2, 2), y + rng.randint(-2, 2)),
                3,
            )
    result = _clip_surface_to_hex(surf)
    _draw_hex_border(result, (90, 65, 25, 220), 3)
    return result


def _generate_damaged_gate() -> pygame.Surface:
    """Damaged drawbridge — splintered wood with visible cracks."""
    surf = _noise_surface_fast(
        HEX_WIDTH, HEX_HEIGHT, (135, 90, 35), variance=18, alpha=230, seed=37
    )
    w, h = HEX_WIDTH, HEX_HEIGHT
    # Broken planks
    plank_h = max(5, h // 7)
    for y in range(0, h, plank_h):
        pygame.draw.line(surf, (90, 60, 15, 180), (0, y), (w, y), 2)
    # Splinters / heavy cracks
    _draw_cracks(surf, count=8, seed=37, color=(60, 30, 5, 240), width=3)
    _draw_cracks(surf, count=5, seed=71, color=(80, 50, 15, 200), width=2)
    # Bent iron bands
    for y in (h // 3, 2 * h // 3):
        pts = [(4, y), (w // 3, y - 3), (2 * w // 3, y + 4), (w - 4, y - 2)]
        pygame.draw.lines(surf, (80, 80, 90, 160), False, pts, 2)
    result = _clip_surface_to_hex(surf)
    _draw_hex_border(result, (80, 55, 20, 180), 2)
    return result


def _generate_destroyed_gate() -> pygame.Surface:
    """Destroyed gate — open passage with scattered wood debris."""
    surf = pygame.Surface((HEX_WIDTH, HEX_HEIGHT), pygame.SRCALPHA)
    rng = random.Random(44)
    cx, cy = HEX_WIDTH // 2, HEX_HEIGHT // 2
    # Dirt smudge
    pygame.draw.circle(surf, (100, 80, 50, 40), (cx, cy), 22)
    # Scattered wood splinters
    for _ in range(20):
        rx = rng.randint(6, HEX_WIDTH - 10)
        ry = rng.randint(HEX_HEIGHT // 4, HEX_HEIGHT - 6)
        rw = rng.randint(4, 14)
        rh = rng.randint(2, 5)
        brown = rng.randint(70, 140)
        alpha = rng.randint(80, 160)
        pygame.draw.rect(surf, (brown, brown - 25, brown - 45, alpha), (rx, ry, rw, rh))
    return _clip_surface_to_hex(surf)


def _generate_heavy_stone() -> pygame.Surface:
    """Indestructible wall — dark, heavy fortified stone. Visually distinct."""
    surf = _noise_surface_fast(
        HEX_WIDTH, HEX_HEIGHT, (95, 90, 80), variance=8, alpha=250, seed=3
    )
    w, h = HEX_WIDTH, HEX_HEIGHT
    # Thick mortar grid — large blocks
    block_h = max(8, h // 3)
    block_w = max(10, w // 2)
    for i, y in enumerate(range(0, h, block_h)):
        pygame.draw.line(surf, (60, 55, 45, 220), (0, y), (w, y), 3)
        offset = block_w // 2 if i % 2 else 0
        for x in range(offset, w, block_w):
            pygame.draw.line(
                surf, (60, 55, 45, 220), (x, y), (x, min(y + block_h, h)), 3
            )
    result = _clip_surface_to_hex(surf)
    # Heavy dark border
    _draw_hex_border(result, (50, 45, 35, 240), 3)
    return result


def _generate_tower(destroyed: bool = False) -> pygame.Surface:
    """Tower — stone structure with crenellation, arrow slit, and colored banner."""
    surf = pygame.Surface((HEX_WIDTH, HEX_HEIGHT), pygame.SRCALPHA)
    w, h = HEX_WIDTH, HEX_HEIGHT
    cx, cy = w // 2, h // 2

    if destroyed:
        # Broken base
        base = _noise_surface_fast(w, h, (90, 85, 75), variance=10, alpha=180, seed=55)
        _draw_cracks(base, count=6, seed=55, color=(50, 40, 30, 200), width=2)
        surf.blit(base, (0, 0))
        # Rubble chunks
        rng = random.Random(66)
        for _ in range(12):
            rx = rng.randint(8, w - 12)
            ry = rng.randint(h // 4, h - 6)
            grey = rng.randint(80, 130)
            pygame.draw.rect(
                surf,
                (grey, grey - 10, grey - 20, 140),
                (rx, ry, rng.randint(4, 9), rng.randint(3, 7)),
            )
        result = _clip_surface_to_hex(surf)
        _draw_hex_border(result, (70, 60, 50, 150), 2)
        return result

    # Tower body — lighter stone to stand out from walls
    body = _noise_surface_fast(w, h, (165, 155, 135), variance=10, alpha=245, seed=8)
    surf.blit(body, (0, 0))

    # Crenellation (battlements) at top
    cren_w = max(4, w // 8)
    cren_h = 7
    for i in range(w // cren_w):
        x = i * cren_w
        if i % 2 == 0:
            pygame.draw.rect(surf, (140, 130, 110, 250), (x, 0, cren_w, cren_h))
        else:
            pygame.draw.rect(surf, (50, 45, 35, 200), (x, 0, cren_w, cren_h))

    # Arrow slit (cross shape)
    pygame.draw.rect(surf, (25, 20, 15, 230), (cx - 2, cy - 10, 5, 20))
    pygame.draw.rect(surf, (25, 20, 15, 230), (cx - 7, cy - 2, 15, 5))

    # Red banner/flag to make towers obvious
    flag_pts = [(cx + 12, cy - 8), (cx + 24, cy - 4), (cx + 12, cy)]
    pygame.draw.polygon(surf, (180, 30, 30, 220), flag_pts)
    pygame.draw.line(surf, (60, 50, 40, 240), (cx + 12, cy - 12), (cx + 12, cy + 4), 2)

    result = _clip_surface_to_hex(surf)
    _draw_hex_border(result, (110, 100, 80, 230), 3)
    return result


def _generate_catapult() -> pygame.Surface:
    """Catapult — larger, more detailed wooden siege engine."""
    surf = pygame.Surface((HEX_WIDTH, HEX_HEIGHT), pygame.SRCALPHA)
    cx, cy = HEX_WIDTH // 2, HEX_HEIGHT // 2

    wood = (150, 110, 55, 245)
    dark_wood = (110, 78, 32, 245)
    metal = (155, 155, 165, 245)
    rope = (130, 120, 80, 230)

    # Platform / base frame
    pygame.draw.rect(surf, dark_wood, (cx - 22, cy + 4, 44, 8))
    pygame.draw.rect(surf, wood, (cx - 20, cy + 5, 40, 6))

    # Wheels — bigger, with detail
    for wx in (cx - 14, cx + 14):
        pygame.draw.circle(surf, (60, 45, 20, 240), (wx, cy + 14), 10)
        pygame.draw.circle(surf, dark_wood, (wx, cy + 14), 9)
        pygame.draw.circle(surf, wood, (wx, cy + 14), 7)
        # Spokes
        for angle in range(0, 360, 45):
            rad = math.radians(angle)
            ex = wx + int(6 * math.cos(rad))
            ey = cy + 14 + int(6 * math.sin(rad))
            pygame.draw.line(surf, dark_wood, (wx, cy + 14), (ex, ey), 1)
        # Hub
        pygame.draw.circle(surf, metal, (wx, cy + 14), 2)

    # A-frame upright
    pygame.draw.line(surf, dark_wood, (cx + 6, cy + 4), (cx + 2, cy - 12), 4)
    pygame.draw.line(surf, dark_wood, (cx - 4, cy + 4), (cx + 2, cy - 12), 3)
    # Cross brace
    pygame.draw.line(surf, wood, (cx - 2, cy - 2), (cx + 6, cy - 2), 2)

    # Throwing arm (the big lever)
    pygame.draw.line(surf, dark_wood, (cx + 2, cy - 12), (cx - 22, cy - 24), 4)

    # Rope/sling from arm end
    pygame.draw.line(surf, rope, (cx - 22, cy - 24), (cx - 26, cy - 18), 2)
    pygame.draw.line(surf, rope, (cx - 22, cy - 24), (cx - 18, cy - 18), 2)

    # Sling/bucket
    pygame.draw.ellipse(surf, metal, (cx - 28, cy - 20, 12, 6))
    # Projectile (stone)
    pygame.draw.circle(surf, (120, 115, 100, 220), (cx - 22, cy - 22), 4)

    # Counterweight (heavy block)
    pygame.draw.rect(surf, (100, 100, 110, 230), (cx + 6, cy - 8, 14, 12))
    pygame.draw.rect(surf, metal, (cx + 7, cy - 7, 12, 10))

    # Label
    font = pygame.font.Font(None, 16)
    label = font.render("Catapult", True, (220, 200, 140))
    label_rect = label.get_rect(center=(cx, cy + 27))
    surf.blit(label, label_rect)

    return surf


def _generate_moat() -> pygame.Surface:
    """Generate a hex-shaped water moat tile with visible blue color."""
    surf = _noise_surface_fast(
        HEX_WIDTH, HEX_HEIGHT, (30, 70, 150), variance=15, alpha=190, seed=51
    )
    w, h = HEX_WIDTH, HEX_HEIGHT
    # Water shimmer highlights
    rng = random.Random(52)
    for _ in range(12):
        sx = rng.randint(4, w - 8)
        sy = rng.randint(4, h - 8)
        sw = rng.randint(8, 20)
        pygame.draw.line(surf, (80, 130, 200, 100), (sx, sy), (sx + sw, sy), 1)
    return _clip_surface_to_hex(surf)


# ---------------------------------------------------------------------------
# SiegeSprites class
# ---------------------------------------------------------------------------

# Wall sprite key: (WallType, WallState) -> generator function
_WALL_GENERATORS: dict[tuple[WallType, WallState], Callable[[], pygame.Surface]] = {
    (WallType.INDESTRUCTIBLE, WallState.INTACT): _generate_heavy_stone,
    (WallType.INDESTRUCTIBLE, WallState.DAMAGED): _generate_heavy_stone,
    (WallType.INDESTRUCTIBLE, WallState.DESTROYED): _generate_heavy_stone,
    (WallType.DESTRUCTIBLE, WallState.INTACT): _generate_stone_wall,
    (WallType.DESTRUCTIBLE, WallState.DAMAGED): _generate_damaged_wall,
    (WallType.DESTRUCTIBLE, WallState.DESTROYED): _generate_rubble,
    (WallType.DRAWBRIDGE, WallState.INTACT): _generate_wood_gate,
    (WallType.DRAWBRIDGE, WallState.DAMAGED): _generate_damaged_gate,
    (WallType.DRAWBRIDGE, WallState.DESTROYED): _generate_destroyed_gate,
}


class SiegeSprites:
    """Loads and caches siege battlefield sprites."""

    def __init__(self):
        self._ground_tiles: list[pygame.Surface] = []
        self._wall_sprites: dict[tuple[WallType, WallState], pygame.Surface] = {}
        self._tower_sprites: dict[bool, pygame.Surface] = {}
        self._catapult_sprite: pygame.Surface | None = None
        self._moat_sprite: pygame.Surface | None = None
        self._loaded = False

    def load(self):
        """Load all siege sprites. Call after pygame.init()."""
        if self._loaded:
            return

        self._load_ground_tiles()
        self._load_wall_sprites()
        self._load_tower_sprites()
        self._load_catapult()
        self._load_moat()

        self._loaded = True

    # -- Ground tiles --

    def _load_ground_tiles(self):
        """Load grass tiles scaled to combat hex size."""
        for name in ("green.png", "green2.png", "green3.png", "green4.png"):
            img = _load_image(os.path.join(TERRAIN_DIR, name))
            if img:
                self._ground_tiles.append(_clip_to_hex(img))

    def get_ground_tile(self, variant: int = 0) -> pygame.Surface | None:
        if not self._ground_tiles:
            return None
        return self._ground_tiles[variant % len(self._ground_tiles)]

    # -- Wall sprites --

    def _load_wall_sprites(self):
        """Try loading wall PNGs; fall back to procedural generation."""
        file_map: dict[tuple[WallType, WallState], str] = {
            (WallType.DESTRUCTIBLE, WallState.INTACT): "wall-intact.png",
            (WallType.DESTRUCTIBLE, WallState.DAMAGED): "wall-damaged.png",
            (WallType.DESTRUCTIBLE, WallState.DESTROYED): "wall-destroyed.png",
            (WallType.DRAWBRIDGE, WallState.INTACT): "gate-intact.png",
            (WallType.DRAWBRIDGE, WallState.DAMAGED): "gate-damaged.png",
            (WallType.DRAWBRIDGE, WallState.DESTROYED): "gate-destroyed.png",
            (WallType.INDESTRUCTIBLE, WallState.INTACT): "wall-heavy.png",
        }

        for key, gen_fn in _WALL_GENERATORS.items():
            filename = file_map.get(key)
            loaded = False
            if filename:
                img = _load_image(os.path.join(SIEGE_DIR, filename))
                if img:
                    self._wall_sprites[key] = _clip_to_hex(img)
                    loaded = True
            if not loaded:
                self._wall_sprites[key] = gen_fn()

    def get_wall(
        self, wall_type: WallType, wall_state: WallState
    ) -> pygame.Surface | None:
        return self._wall_sprites.get((wall_type, wall_state))

    # -- Tower sprites --

    def _load_tower_sprites(self):
        """Load or generate tower sprites."""
        for destroyed in (False, True):
            suffix = "destroyed" if destroyed else "intact"
            img = _load_image(os.path.join(SIEGE_DIR, f"tower-{suffix}.png"))
            if img:
                self._tower_sprites[destroyed] = _clip_to_hex(img)
            else:
                self._tower_sprites[destroyed] = _generate_tower(destroyed=destroyed)

    def get_tower(self, destroyed: bool = False) -> pygame.Surface | None:
        return self._tower_sprites.get(destroyed)

    # -- Catapult --

    def _load_catapult(self):
        """Load or generate catapult sprite."""
        img = _load_image(os.path.join(SIEGE_DIR, "catapult.png"))
        if img:
            self._catapult_sprite = pygame.transform.smoothscale(
                img, (HEX_WIDTH, HEX_HEIGHT)
            )
        else:
            self._catapult_sprite = _generate_catapult()

    def get_catapult(self) -> pygame.Surface | None:
        return self._catapult_sprite

    # -- Moat --

    def _load_moat(self):
        """Load water tile or generate a moat hex with per-pixel alpha."""
        img = _load_image(os.path.join(TERRAIN_DIR, "water.png"))
        if img:
            clipped = _clip_to_hex(img)
            # Apply per-pixel alpha reduction for overlay blending
            alpha_surf = pygame.Surface((HEX_WIDTH, HEX_HEIGHT), pygame.SRCALPHA)
            alpha_surf.fill((255, 255, 255, 180))
            clipped.blit(alpha_surf, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
            self._moat_sprite = clipped
        else:
            self._moat_sprite = _generate_moat()

    def get_moat(self) -> pygame.Surface | None:
        return self._moat_sprite

    @property
    def loaded(self) -> bool:
        return self._loaded
