"""Draws hero portraits on horseback in the battlefield corners.

In HoMM3, heroes sit on horseback at the top-left (attacker) and
top-right (defender) corners of the battlefield. They can't be attacked —
they're purely visual.
"""

from __future__ import annotations

import pygame

from lops.models import Hero, Side

# Portrait colors
_HORSE_BODY = (100, 70, 45)
_HORSE_DARK = (70, 50, 30)
_SADDLE = (140, 30, 30)
_ARMOR_PLAYER = (60, 80, 160)
_ARMOR_ENEMY = (160, 50, 50)
_SKIN = (220, 180, 140)
_CAPE_PLAYER = (40, 60, 180)
_CAPE_ENEMY = (180, 40, 40)
_BANNER_BG = (20, 20, 40, 200)
_MANA_BAR_BG = (30, 30, 60)
_MANA_BAR_FILL = (60, 80, 200)


def _draw_horse_and_rider(
    surface: pygame.Surface,
    cx: float,
    cy: float,
    facing_right: bool,
    armor_color: tuple,
    cape_color: tuple,
    scale: float = 1.0,
):
    """Draw a procedural hero on horseback."""
    s = scale
    flip = 1 if facing_right else -1

    # Horse body (ellipse)
    horse_rect = pygame.Rect(
        int(cx - 28 * s), int(cy - 4 * s), int(56 * s), int(28 * s)
    )
    pygame.draw.ellipse(surface, _HORSE_BODY, horse_rect)

    # Horse belly highlight
    belly_rect = pygame.Rect(
        int(cx - 20 * s), int(cy + 2 * s), int(40 * s), int(16 * s)
    )
    pygame.draw.ellipse(surface, (120, 90, 60), belly_rect)

    # Horse legs (4 lines)
    leg_positions = [(-18, 16), (-8, 18), (8, 18), (18, 16)]
    for lx, ly in leg_positions:
        start = (int(cx + lx * s), int(cy + ly * s))
        end = (int(cx + lx * s), int(cy + (ly + 16) * s))
        pygame.draw.line(surface, _HORSE_DARK, start, end, max(1, int(3 * s)))
        # Hoof
        pygame.draw.circle(surface, (60, 45, 25), end, max(1, int(2 * s)))

    # Horse neck (angled up toward head)
    neck_pts = [
        (int(cx + 22 * s * flip), int(cy - 2 * s)),
        (int(cx + 30 * s * flip), int(cy - 20 * s)),
        (int(cx + 26 * s * flip), int(cy - 22 * s)),
        (int(cx + 18 * s * flip), int(cy - 4 * s)),
    ]
    pygame.draw.polygon(surface, _HORSE_BODY, neck_pts)

    # Horse head
    head_cx = int(cx + 32 * s * flip)
    head_cy = int(cy - 24 * s)
    head_rect = pygame.Rect(
        head_cx - int(8 * s), head_cy - int(6 * s), int(16 * s), int(12 * s)
    )
    pygame.draw.ellipse(surface, _HORSE_BODY, head_rect)

    # Horse ear
    ear_pts = [
        (head_cx + int(2 * s * flip), head_cy - int(6 * s)),
        (head_cx + int(5 * s * flip), head_cy - int(12 * s)),
        (head_cx + int(7 * s * flip), head_cy - int(6 * s)),
    ]
    pygame.draw.polygon(surface, _HORSE_DARK, ear_pts)

    # Horse eye
    eye_x = head_cx + int(4 * s * flip)
    eye_y = head_cy - int(1 * s)
    pygame.draw.circle(surface, (20, 20, 20), (eye_x, eye_y), max(1, int(2 * s)))

    # Mane (along neck)
    for i in range(5):
        mx = int(cx + (20 + i * 2) * s * flip)
        my = int(cy - (4 + i * 4) * s)
        mane_end = (mx - int(4 * s * flip), my - int(3 * s))
        pygame.draw.line(surface, _HORSE_DARK, (mx, my), mane_end, max(1, int(2 * s)))

    # Tail
    tail_start = (int(cx - 26 * s * flip), int(cy + 2 * s))
    tail_mid = (int(cx - 34 * s * flip), int(cy + 10 * s))
    tail_end = (int(cx - 38 * s * flip), int(cy + 20 * s))
    pygame.draw.lines(
        surface,
        _HORSE_DARK,
        False,
        [tail_start, tail_mid, tail_end],
        max(1, int(3 * s)),
    )

    # Saddle
    saddle_rect = pygame.Rect(
        int(cx - 10 * s), int(cy - 10 * s), int(20 * s), int(12 * s)
    )
    pygame.draw.ellipse(surface, _SADDLE, saddle_rect)

    # --- Rider ---

    # Cape (billowing behind)
    cape_pts = [
        (int(cx - 4 * s * flip), int(cy - 16 * s)),
        (int(cx - 18 * s * flip), int(cy - 8 * s)),
        (int(cx - 22 * s * flip), int(cy + 4 * s)),
        (int(cx - 14 * s * flip), int(cy - 2 * s)),
        (int(cx - 6 * s * flip), int(cy - 10 * s)),
    ]
    pygame.draw.polygon(surface, cape_color, cape_pts)

    # Torso (armored)
    torso_rect = pygame.Rect(
        int(cx - 8 * s), int(cy - 24 * s), int(16 * s), int(18 * s)
    )
    pygame.draw.ellipse(surface, armor_color, torso_rect)

    # Arms — one holding reins, one holding staff/sword
    # Rein arm
    arm_start = (int(cx + 4 * s * flip), int(cy - 18 * s))
    arm_end = (int(cx + 16 * s * flip), int(cy - 12 * s))
    pygame.draw.line(surface, armor_color, arm_start, arm_end, max(1, int(4 * s)))
    # Hand
    pygame.draw.circle(surface, _SKIN, arm_end, max(1, int(3 * s)))

    # Staff arm (behind)
    staff_arm_start = (int(cx - 4 * s * flip), int(cy - 18 * s))
    staff_arm_end = (int(cx - 10 * s * flip), int(cy - 28 * s))
    pygame.draw.line(
        surface, armor_color, staff_arm_start, staff_arm_end, max(1, int(4 * s))
    )
    # Staff
    staff_top = (int(cx - 12 * s * flip), int(cy - 44 * s))
    pygame.draw.line(
        surface, (140, 120, 80), staff_arm_end, staff_top, max(1, int(2 * s))
    )
    # Staff orb
    pygame.draw.circle(surface, (200, 220, 255), staff_top, max(2, int(4 * s)))
    pygame.draw.circle(surface, (255, 255, 255), staff_top, max(1, int(2 * s)))

    # Head
    head_rx = int(cx)
    head_ry = int(cy - 30 * s)
    pygame.draw.circle(surface, _SKIN, (head_rx, head_ry), max(3, int(7 * s)))

    # Helmet
    helmet_rect = pygame.Rect(
        head_rx - int(8 * s), head_ry - int(9 * s), int(16 * s), int(10 * s)
    )
    pygame.draw.ellipse(surface, armor_color, helmet_rect)

    # Helmet visor line
    visor_y = head_ry - int(2 * s)
    pygame.draw.line(
        surface,
        (30, 30, 30),
        (head_rx - int(6 * s), visor_y),
        (head_rx + int(6 * s), visor_y),
        max(1, int(2 * s)),
    )

    # Helmet plume
    plume_pts = [
        (head_rx, head_ry - int(9 * s)),
        (head_rx - int(8 * s * flip), head_ry - int(16 * s)),
        (head_rx - int(4 * s * flip), head_ry - int(10 * s)),
    ]
    pygame.draw.polygon(surface, cape_color, plume_pts)


_PLACEHOLDER_NAMES = frozenset({"Monster", "Garrison"})


def _is_real_hero(hero: Hero | None) -> bool:
    """Return True if the hero is a real named hero, not a placeholder."""
    if hero is None:
        return False
    return hero.name not in _PLACEHOLDER_NAMES


class HeroPortraitRenderer:
    """Draws hero portraits on horseback at the corners of the battlefield."""

    def __init__(
        self, surface: pygame.Surface, hex_renderer, player_side: Side = Side.ATTACKER
    ):
        self.surface = surface
        self.hex_renderer = hex_renderer
        self.player_side = player_side
        self.font = pygame.font.SysFont("Arial", 13, bold=True)
        self.small_font = pygame.font.SysFont("Arial", 11)

    def attacker_position(self) -> tuple[float, float]:
        """Position of the attacker hero portrait (top-left)."""
        ox = self.hex_renderer.origin_x
        oy = self.hex_renderer.origin_y
        return (ox - 20, oy + 10)

    def defender_position(self) -> tuple[float, float]:
        """Position of the defender hero portrait (top-right)."""
        sw = self.surface.get_width()
        panel_w = self.hex_renderer.panel_width
        ox = self.hex_renderer.origin_x
        oy = self.hex_renderer.origin_y

        # Right side: near the last column
        from lops.hex import BATTLEFIELD_COLS, HEX_SIZE

        grid_right = ox + HEX_SIZE * 1.5 * (BATTLEFIELD_COLS - 1) + HEX_SIZE
        return (grid_right + 20, oy + 10)

    def draw(self, atk_hero: Hero, def_hero: Hero):
        """Draw both hero portraits. Skip placeholder heroes (Monster/Garrison)."""
        # Attacker (top-left, facing right)
        if _is_real_hero(atk_hero):
            ax, ay = self.attacker_position()
            atk_is_player = self.player_side == Side.ATTACKER
            atk_armor = _ARMOR_PLAYER if atk_is_player else _ARMOR_ENEMY
            atk_cape = _CAPE_PLAYER if atk_is_player else _CAPE_ENEMY
            _draw_horse_and_rider(
                self.surface,
                ax,
                ay,
                facing_right=True,
                armor_color=atk_armor,
                cape_color=atk_cape,
                scale=0.85,
            )

        # Defender (top-right, facing left)
        if not _is_real_hero(def_hero):
            return
        dx, dy = self.defender_position()
        def_is_player = self.player_side == Side.DEFENDER
        def_armor = _ARMOR_PLAYER if def_is_player else _ARMOR_ENEMY
        def_cape = _CAPE_PLAYER if def_is_player else _CAPE_ENEMY
        _draw_horse_and_rider(
            self.surface,
            dx,
            dy,
            facing_right=False,
            armor_color=def_armor,
            cape_color=def_cape,
            scale=0.85,
        )

    def hero_pixel_position(self, side: Side) -> tuple[float, float]:
        """Get the pixel position of the hero's staff orb (spell origin point)."""
        if side == Side.ATTACKER:
            ax, ay = self.attacker_position()
            s = 0.85
            flip = 1
            return (ax - 12 * s * flip, ay - 44 * s)
        else:
            dx, dy = self.defender_position()
            s = 0.85
            flip = -1
            return (dx - 12 * s * flip, dy - 44 * s)
