"""Global font scale factor for mobile responsiveness."""

# Set via set_font_scale() before creating renderers.
FONT_SCALE: float = 1.0


def set_font_scale(scale: float):
    global FONT_SCALE
    FONT_SCALE = scale


def scaled_font_size(base_size: int) -> int:
    """Return a font size scaled for the current platform."""
    return max(10, int(base_size * FONT_SCALE))
