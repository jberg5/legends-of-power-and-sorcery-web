"""Adventure map renderer: camera, terrain drawing, map objects, heroes."""

from __future__ import annotations

import math

import pygame

from lops.adventure.world_map import WorldMap
from lops.data.terrain import TERRAIN_COLOR
from lops.hex import (
    CubeCoord,
    hex_polygon_corners,
    hex_to_pixel,
    pixel_to_hex,
)

# Adventure map hex size (smaller than battlefield hexes)
# Set via set_adv_hex_size() before creating renderer for mobile zoom.
ADV_HEX_SIZE = 28


def set_adv_hex_size(size: int):
    """Override hex size before renderer init (e.g., for mobile zoom)."""
    global ADV_HEX_SIZE
    ADV_HEX_SIZE = size

# Keep/village sprite cache for towns
_town_sprite_cache: dict[object, pygame.Surface | None] = {}

# Colors
COLOR_ADV_BG = (20, 30, 45)
COLOR_HEX_BORDER = (0, 0, 0, 60)
COLOR_HERO_PLAYER = (50, 120, 220)
COLOR_HERO_AI = (200, 50, 50)
COLOR_MOVE_RANGE = (50, 130, 220, 70)
COLOR_MOVE_PATH = (255, 255, 100, 140)
COLOR_MONSTER = (180, 40, 180)
COLOR_GOLD = (220, 190, 40)
COLOR_TOWN_PLAYER = (50, 140, 220)
COLOR_TOWN_AI = (200, 60, 60)
COLOR_TOWN_NEUTRAL = (150, 150, 150)
COLOR_TEXT = (220, 220, 220)


class Camera:
    """World-space camera for scrolling the adventure map."""

    def __init__(
        self,
        screen_w: int,
        screen_h: int,
        hud_height: int = 40,
        viewport_w: int | None = None,
    ):
        self.screen_w = screen_w
        self.screen_h = screen_h
        self.hud_height = hud_height
        # viewport_w limits how much horizontal space the map uses
        self.viewport_w = viewport_w if viewport_w is not None else screen_w
        # Camera position is the world-space pixel at the top-left of the view
        self.x = 0.0
        self.y = 0.0
        # World bounds (set after map is loaded)
        self.world_w = 0.0
        self.world_h = 0.0

    def set_world_bounds(self, cols: int, rows: int):
        """Compute world pixel dimensions from map size."""
        self.world_w = ADV_HEX_SIZE * 1.5 * (cols - 1) + 2 * ADV_HEX_SIZE + ADV_HEX_SIZE
        self.world_h = ADV_HEX_SIZE * math.sqrt(3) * rows + ADV_HEX_SIZE * 2

    def clamp(self):
        """Keep camera within world bounds."""
        view_h = self.screen_h - self.hud_height
        max_x = max(0, self.world_w - self.viewport_w)
        max_y = max(0, self.world_h - view_h)
        self.x = max(0, min(self.x, max_x))
        self.y = max(0, min(self.y, max_y))

    def scroll(self, dx: float, dy: float):
        self.x += dx
        self.y += dy
        self.clamp()

    def center_on_world(self, wx: float, wy: float):
        """Center camera on a world pixel position."""
        view_h = self.screen_h - self.hud_height
        self.x = wx - self.viewport_w / 2
        self.y = wy - view_h / 2
        self.clamp()

    def world_to_screen(self, wx: float, wy: float) -> tuple[float, float]:
        return (wx - self.x, wy - self.y + self.hud_height)

    def screen_to_world(self, sx: float, sy: float) -> tuple[float, float]:
        return (sx + self.x, sy - self.hud_height + self.y)


class AdventureRenderer:
    """Renders the adventure map with terrain, objects, and heroes."""

    def __init__(
        self,
        surface: pygame.Surface,
        world_map: WorldMap,
        viewport_w: int | None = None,
        layered_map=None,
    ):
        self.surface = surface
        self.world_map = world_map
        self.layered_map = layered_map  # LayeredMap or None
        self.current_layer: int = 0
        sw, sh = surface.get_size()
        self.viewport_w = viewport_w if viewport_w is not None else sw
        self.camera = Camera(sw, sh, viewport_w=self.viewport_w)
        self.camera.set_world_bounds(world_map.cols, world_map.rows)

        # Origin offset so hex (0,0) isn't at pixel (0,0) — add margin
        self.origin_x = ADV_HEX_SIZE * 1.5
        self.origin_y = ADV_HEX_SIZE * math.sqrt(3)

        # Pre-compute hex corners and centers in world space
        self._hex_centers: dict[CubeCoord, tuple[float, float]] = {}
        self._hex_corners: dict[CubeCoord, list[tuple[float, float]]] = {}
        for pos in world_map.all_positions():
            px, py = hex_to_pixel(
                pos, self.origin_x, self.origin_y, hex_size=ADV_HEX_SIZE
            )
            self._hex_centers[pos] = (px, py)
            self._hex_corners[pos] = hex_polygon_corners(px, py, ADV_HEX_SIZE)

        # Terrain sprites
        from lops.renderer.terrain_sprites import TerrainSprites

        self._terrain_sprites = TerrainSprites()
        self._terrain_sprites.load()

        # Pre-compute a stable variant index per hex for visual variety
        self._hex_variant: dict[CubeCoord, int] = {}
        for pos in world_map.all_positions():
            # Simple hash from coordinates for deterministic variation
            self._hex_variant[pos] = abs(hash(pos)) % 7

        # Fog of war star field — pre-generate star positions per hex
        import random as _rng_mod

        _star_rng = _rng_mod.Random(42)
        self._fog_stars: dict[CubeCoord, list[tuple[float, float, float, float]]] = {}
        for pos in world_map.all_positions():
            cx, cy = self._hex_centers[pos]
            n_stars = _star_rng.randint(2, 5)
            stars = []
            for _ in range(n_stars):
                # Random offset within hex bounds
                ox = _star_rng.uniform(-ADV_HEX_SIZE * 0.7, ADV_HEX_SIZE * 0.7)
                oy = _star_rng.uniform(-ADV_HEX_SIZE * 0.6, ADV_HEX_SIZE * 0.6)
                phase = _star_rng.uniform(0, 6.283)  # random twinkle phase
                speed = _star_rng.uniform(0.8, 2.5)  # twinkle speed
                stars.append((ox, oy, phase, speed))
            self._fog_stars[pos] = stars
        self._fog_time: float = 0.0

        # Highlight state
        self.move_range: set[CubeCoord] = set()
        self.move_path: list[CubeCoord] = []
        self.hover_hex: CubeCoord | None = None

        # Scroll state
        self._scroll_keys = {
            pygame.K_w: False,
            pygame.K_a: False,
            pygame.K_s: False,
            pygame.K_d: False,
            pygame.K_UP: False,
            pygame.K_DOWN: False,
            pygame.K_LEFT: False,
            pygame.K_RIGHT: False,
        }
        self._scroll_speed = 400.0

    @property
    def _active_map(self) -> WorldMap:
        """Get the map for the current display layer."""
        if self.layered_map is not None:
            return self.layered_map.get_map(self.current_layer)
        return self.world_map

    def hex_world_center(self, pos: CubeCoord) -> tuple[float, float]:
        return self._hex_centers.get(
            pos,
            hex_to_pixel(pos, self.origin_x, self.origin_y, hex_size=ADV_HEX_SIZE),
        )

    def screen_to_hex(self, sx: int, sy: int) -> CubeCoord | None:
        # Ignore clicks in the sidebar area
        if sx >= self.viewport_w:
            return None
        wx, wy = self.camera.screen_to_world(sx, sy)
        c = pixel_to_hex(wx, wy, self.origin_x, self.origin_y, hex_size=ADV_HEX_SIZE)
        if self._active_map.in_bounds(c):
            return c
        return None

    def center_on_hex(self, pos: CubeCoord | None):
        if pos is None:
            return
        wx, wy = self.hex_world_center(pos)
        self.camera.center_on_world(wx, wy)

    def handle_scroll_key(self, key: int, pressed: bool):
        if key in self._scroll_keys:
            self._scroll_keys[key] = pressed

    def update(self, dt: float):
        self._fog_time += dt
        # Apply scroll from held keys
        dx = dy = 0.0
        if self._scroll_keys[pygame.K_a] or self._scroll_keys[pygame.K_LEFT]:
            dx -= self._scroll_speed * dt
        if self._scroll_keys[pygame.K_d] or self._scroll_keys[pygame.K_RIGHT]:
            dx += self._scroll_speed * dt
        if self._scroll_keys[pygame.K_w] or self._scroll_keys[pygame.K_UP]:
            dy -= self._scroll_speed * dt
        if self._scroll_keys[pygame.K_s] or self._scroll_keys[pygame.K_DOWN]:
            dy += self._scroll_speed * dt
        if dx or dy:
            self.camera.scroll(dx, dy)

        # Update hover hex (only within map viewport)
        mx, my = pygame.mouse.get_pos()
        if mx < self.viewport_w:
            self.hover_hex = self.screen_to_hex(mx, my)
        else:
            self.hover_hex = None

    def draw(
        self,
        adventure_state,
        revealed: set | None = None,
        visible: set | None = None,
        anim_state=None,
        current_layer: int = 0,
    ):
        """Draw the full adventure map."""
        self.current_layer = current_layer
        self._revealed = revealed
        self._visible = visible
        self._adventure_state = adventure_state
        self._anim_state = anim_state
        # Clip drawing to viewport area
        old_clip = self.surface.get_clip()
        self.surface.set_clip(
            pygame.Rect(0, 0, self.viewport_w, self.surface.get_height())
        )
        # Darker background for underground
        bg = (10, 8, 15) if current_layer == 1 else COLOR_ADV_BG
        self.surface.fill(bg)
        self._draw_terrain()
        self._draw_highlights()
        self._draw_map_objects(adventure_state)
        self._draw_heroes(adventure_state)
        self._draw_fog_overlay()
        self._draw_hover_tooltip(adventure_state)
        self.surface.set_clip(old_clip)
        self._revealed = None
        self._visible = None
        self._adventure_state = None
        self._anim_state = None

    def _draw_terrain(self):
        """Draw visible terrain hexes with sprites."""
        cam = self.camera
        sprites = self._terrain_sprites
        margin = ADV_HEX_SIZE * 3  # extra margin for overlays that extend above hex

        # Two passes: base tiles first, then overlays (so trees/mountains draw on top)
        overlay_queue = []

        for pos, corners_world in self._hex_corners.items():
            cx, cy = self._hex_centers[pos]
            sx, sy = cam.world_to_screen(cx, cy)

            # Cull off-screen hexes (use viewport_w for horizontal)
            if sx < -margin or sx > cam.viewport_w + margin:
                continue
            if sy < cam.hud_height - margin or sy > cam.screen_h + margin:
                continue

            tile = self._active_map.get_tile(pos)
            if tile is None:
                continue

            variant = self._hex_variant.get(pos, 0)

            # Draw base tile sprite (or fallback to solid color)
            base = sprites.get_base_tile(tile.terrain, variant)
            if base:
                blit_x = sx - base.get_width() / 2
                blit_y = sy - base.get_height() / 2
                self.surface.blit(base, (blit_x, blit_y))
            else:
                # Fallback: solid color fill
                screen_corners = [
                    cam.world_to_screen(wx, wy) for wx, wy in corners_world
                ]
                color = TERRAIN_COLOR.get(tile.terrain, (100, 100, 100))
                pygame.draw.polygon(self.surface, color, screen_corners)

            # Queue overlays for second pass
            if sprites.has_overlay(tile.terrain):
                overlay_queue.append((pos, sx, sy, tile.terrain, variant))

        # Draw thin hex borders
        for pos, corners_world in self._hex_corners.items():
            cx, cy = self._hex_centers[pos]
            sx, sy = cam.world_to_screen(cx, cy)
            if sx < -margin or sx > cam.viewport_w + margin:
                continue
            if sy < cam.hud_height - margin or sy > cam.screen_h + margin:
                continue
            screen_corners = [cam.world_to_screen(wx, wy) for wx, wy in corners_world]
            pygame.draw.polygon(self.surface, (0, 0, 0, 40), screen_corners, 1)

        # Second pass: overlays (forest, mountain) drawn on top
        for pos, sx, sy, terrain, variant in overlay_queue:
            overlay = sprites.get_overlay(terrain, variant)
            if overlay:
                blit_x = sx - overlay.get_width() / 2
                blit_y = sy - overlay.get_height() + ADV_HEX_SIZE * 0.4
                self.surface.blit(overlay, (blit_x, blit_y))

    def _draw_highlights(self):
        """Draw movement range and path highlights."""
        if not self.move_range and not self.move_path:
            return

        overlay = pygame.Surface(self.surface.get_size(), pygame.SRCALPHA)
        cam = self.camera

        for pos in self.move_range:
            if pos in self._hex_corners:
                corners = [
                    (cam.world_to_screen(wx, wy)) for wx, wy in self._hex_corners[pos]
                ]
                pygame.draw.polygon(overlay, COLOR_MOVE_RANGE, corners)

        for pos in self.move_path:
            if pos in self._hex_corners:
                corners = [
                    (cam.world_to_screen(wx, wy)) for wx, wy in self._hex_corners[pos]
                ]
                pygame.draw.polygon(overlay, COLOR_MOVE_PATH, corners)

        if self.hover_hex and self.hover_hex in self._hex_corners:
            corners = [
                (cam.world_to_screen(wx, wy))
                for wx, wy in self._hex_corners[self.hover_hex]
            ]
            pygame.draw.polygon(overlay, (255, 255, 255, 40), corners)

        self.surface.blit(overlay, (0, 0))

    def _draw_map_objects(self, adventure_state):
        """Draw monsters, resources, mines, and town markers."""
        cam = self.camera
        revealed = self._revealed
        visible = self._visible

        from lops.adventure.map_objects import (
            ArtifactPickup,
            Campfire,
            CreatureBank,
            CreatureDwelling,
            HillFort,
            MagicWell,
            Mine,
            PandorasBox,
            ResourcePickup,
            StatBooster,
            SubterraneanGate,
            TownSite,
            TreasureChest,
            WanderingMonster,
        )

        for obj in adventure_state.map_objects:
            if not obj.alive:
                continue
            # Filter by layer
            obj_layer = getattr(obj, "layer", 0)
            if obj_layer != self.current_layer:
                continue
            pos = obj.position
            if pos not in self._hex_centers:
                continue

            # Fog of war: skip objects on unexplored (never-seen) hexes
            if revealed is not None and pos not in revealed:
                continue

            wx, wy = self._hex_centers[pos]
            sx, sy = cam.world_to_screen(wx, wy)

            if isinstance(obj, WanderingMonster):
                self._draw_monster_sprite(sx, sy, obj)
            elif isinstance(obj, ResourcePickup):
                self._draw_gold_sprite(sx, sy, obj.gold)
            elif isinstance(obj, ArtifactPickup):
                self._draw_artifact_pickup(sx, sy, obj)
            elif isinstance(obj, TreasureChest):
                self._draw_treasure_chest(sx, sy)
            elif isinstance(obj, Mine):
                self._draw_mine(sx, sy, obj)
            elif isinstance(obj, TownSite):
                self._draw_town_sprite(sx, sy, obj.owner)
            elif isinstance(obj, Campfire):
                self._draw_campfire(sx, sy)
            elif isinstance(obj, StatBooster):
                self._draw_stat_booster(sx, sy, obj)
                if self._is_visited(obj):
                    self._draw_visited_badge(sx, sy)
            elif isinstance(obj, MagicWell):
                self._draw_magic_well(sx, sy)
                if self._is_visited(obj):
                    self._draw_visited_badge(sx, sy)
            elif isinstance(obj, PandorasBox):
                self._draw_pandoras_box(sx, sy)
            elif isinstance(obj, CreatureBank):
                self._draw_creature_bank(sx, sy, obj)
            elif isinstance(obj, CreatureDwelling):
                self._draw_creature_dwelling(sx, sy, obj)
            elif isinstance(obj, HillFort):
                self._draw_hill_fort(sx, sy)
            elif isinstance(obj, SubterraneanGate):
                self._draw_subterranean_gate(sx, sy)

    def _is_visited(self, obj) -> bool:
        """Check if current human hero has visited this object."""
        state = self._adventure_state
        if state is None:
            return False
        human = state.players[0] if state.players else None
        if human is None:
            return False
        hs = human.active_hero_state
        if hs is None:
            return False
        from lops.adventure.map_objects import MagicWell, StatBooster

        if isinstance(obj, StatBooster):
            return hs.hero_id in obj.visited_by
        elif isinstance(obj, MagicWell):
            return not obj.can_visit(hs.hero_id, state.day)
        return False

    def _draw_visited_badge(self, sx: float, sy: float):
        """Draw a small checkmark badge to indicate a visited location."""
        r = int(ADV_HEX_SIZE * 0.25)
        bx, by = int(sx + ADV_HEX_SIZE * 0.35), int(sy - ADV_HEX_SIZE * 0.35)
        pygame.draw.circle(self.surface, (20, 20, 20), (bx, by), r + 1)
        pygame.draw.circle(self.surface, (60, 140, 60), (bx, by), r)
        # Small checkmark
        s = r * 0.6
        pygame.draw.lines(
            self.surface, (255, 255, 255), False,
            [(bx - s, by), (bx - s * 0.2, by + s * 0.6), (bx + s, by - s * 0.5)],
            max(1, r // 3),
        )

    def _draw_subterranean_gate(self, sx: float, sy: float):
        """Draw a portal/gate icon for subterranean gates."""
        # Swirling portal effect
        r = int(ADV_HEX_SIZE * 0.45)
        center = (int(sx), int(sy))
        # Dark outer ring
        pygame.draw.circle(self.surface, (30, 10, 50), center, r + 2)
        # Purple portal
        pygame.draw.circle(self.surface, (100, 40, 140), center, r)
        # Inner glow
        pygame.draw.circle(self.surface, (160, 80, 200), center, r - 3)
        # Bright center
        pygame.draw.circle(self.surface, (200, 150, 255), center, r - 6)
        # Arrow indicator
        font = pygame.font.Font(None, 18)
        label = "▼" if self.current_layer == 0 else "▲"
        text = font.render(label, True, (255, 255, 255))
        self.surface.blit(text, (sx - text.get_width() / 2, sy - text.get_height() / 2))

    def _draw_gold_sprite(self, sx: float, sy: float, gold_amount: int):
        """Draw gold pile using coin sprites, sized by amount."""
        # Pick sprite tier based on gold amount
        if gold_amount >= 700:
            filename = "gold-coins-large.png"
        elif gold_amount >= 400:
            filename = "gold-coins-medium.png"
        else:
            filename = "gold-coins-small.png"

        cache_key = ("gold", filename)
        if cache_key not in _town_sprite_cache:
            import os

            assets_dir = os.path.join(
                os.path.dirname(os.path.dirname(__file__)), "assets", "terrain"
            )
            path = os.path.join(assets_dir, filename)
            if os.path.exists(path):
                img = pygame.image.load(path).convert_alpha()
                target_size = int(ADV_HEX_SIZE * 1.2)
                w, h = img.get_size()
                scale = target_size / max(w, h)
                img = pygame.transform.smoothscale(
                    img, (int(w * scale), int(h * scale))
                )
                _town_sprite_cache[cache_key] = img
            else:
                _town_sprite_cache[cache_key] = None

        sprite = _town_sprite_cache[cache_key]
        if sprite:
            blit_x = sx - sprite.get_width() / 2
            blit_y = sy - sprite.get_height() / 2
            self.surface.blit(sprite, (blit_x, blit_y))
        else:
            # Fallback
            pygame.draw.circle(
                self.surface, COLOR_GOLD, (int(sx), int(sy)), int(ADV_HEX_SIZE * 0.3)
            )

    def _draw_artifact_pickup(self, sx: float, sy: float, obj):
        """Draw an artifact pickup as a colored diamond gem."""
        from lops.artifacts import ArtifactClass

        CLASS_COLORS = {
            ArtifactClass.TREASURE: (220, 220, 220),
            ArtifactClass.MINOR: (80, 200, 80),
            ArtifactClass.MAJOR: (80, 130, 220),
            ArtifactClass.RELIC: (240, 200, 50),
        }
        adef = obj.definition if hasattr(obj, "definition") else None
        if adef is None:
            from lops.data.artifacts import ARTIFACT_REGISTRY

            adef = ARTIFACT_REGISTRY.get(obj.artifact_id)
        color = (
            CLASS_COLORS.get(adef.artifact_class, (220, 220, 220))
            if adef
            else (220, 220, 220)
        )
        size = ADV_HEX_SIZE * 0.35
        points = [(sx, sy - size), (sx + size, sy), (sx, sy + size), (sx - size, sy)]
        pygame.draw.polygon(self.surface, color, points)
        pygame.draw.polygon(self.surface, (255, 255, 255), points, 2)

    def _draw_monster_sprite(self, sx: float, sy: float, monster):
        """Draw a wandering monster using its creature sprite."""
        from lops.renderer.sprites import lookup_creature_type

        sprite = None
        if monster.army:
            first_stack = monster.army[0]
            ct = lookup_creature_type(first_stack.stats.name)
            if ct is not None:
                sprite = self._get_map_monster_sprite(ct)

        if sprite:
            blit_x = sx - sprite.get_width() / 2
            blit_y = sy - sprite.get_height() / 2
            self.surface.blit(sprite, (blit_x, blit_y))
        else:
            # Fallback: purple diamond
            size = ADV_HEX_SIZE * 0.4
            points = [
                (sx, sy - size),
                (sx + size, sy),
                (sx, sy + size),
                (sx - size, sy),
            ]
            pygame.draw.polygon(self.surface, COLOR_MONSTER, points)

        # Draw stack count badge
        if monster.army:
            count = sum(s.count for s in monster.army if s.alive)
            font = pygame.font.Font(None, 16)
            text = font.render(str(count), True, (255, 255, 255))
            badge_x = int(sx + ADV_HEX_SIZE * 0.2)
            badge_y = int(sy + ADV_HEX_SIZE * 0.15)
            # Badge background
            badge_rect = text.get_rect(center=(badge_x, badge_y))
            bg_rect = badge_rect.inflate(6, 2)
            pygame.draw.rect(self.surface, (60, 20, 60), bg_rect, border_radius=3)
            self.surface.blit(text, badge_rect)

    def _get_map_monster_sprite(self, creature_type) -> pygame.Surface:
        """Get a scaled-down creature sprite for the adventure map."""
        from lops.renderer.sprites import get_sprite

        cache_key = ("map_monster", creature_type)
        if cache_key not in _town_sprite_cache:
            full_sprite = get_sprite(creature_type, "neutral")
            map_size = int(ADV_HEX_SIZE * 1.4)
            scaled = pygame.transform.smoothscale(full_sprite, (map_size, map_size))
            _town_sprite_cache[cache_key] = scaled
        result = _town_sprite_cache[cache_key]
        assert result is not None
        return result

    def _draw_town_sprite(self, sx: float, sy: float, owner: int | None):
        """Draw a town using the keep sprite, tinted by owner."""
        import os

        key = f"town_{owner}"
        if key not in _town_sprite_cache:
            assets_dir = os.path.join(
                os.path.dirname(os.path.dirname(__file__)), "assets", "terrain"
            )
            keep_path = os.path.join(assets_dir, "keep.png")
            if os.path.exists(keep_path):
                img = pygame.image.load(keep_path).convert_alpha()
                target_h = int(ADV_HEX_SIZE * 1.8)
                scale = target_h / img.get_height()
                img = pygame.transform.smoothscale(
                    img, (int(img.get_width() * scale), target_h)
                )
                # Apply team color tint
                if owner == 0:
                    tint_color = (50, 100, 200, 50)
                elif owner == 1:
                    tint_color = (200, 50, 50, 50)
                else:
                    tint_color = (200, 200, 200, 30)
                tint = pygame.Surface(img.get_size(), pygame.SRCALPHA)
                tint.fill(tint_color)
                img.blit(tint, (0, 0))
                _town_sprite_cache[key] = img
            else:
                _town_sprite_cache[key] = None

        sprite = _town_sprite_cache[key]
        if sprite:
            blit_x = sx - sprite.get_width() / 2
            blit_y = sy - sprite.get_height() + ADV_HEX_SIZE * 0.3
            self.surface.blit(sprite, (blit_x, blit_y))
        else:
            # Fallback colored square
            if owner == 0:
                color = COLOR_TOWN_PLAYER
            elif owner is not None:
                color = COLOR_TOWN_AI
            else:
                color = COLOR_TOWN_NEUTRAL
            size = ADV_HEX_SIZE * 0.5
            rect = pygame.Rect(sx - size, sy - size, size * 2, size * 2)
            pygame.draw.rect(self.surface, color, rect)
            pygame.draw.rect(self.surface, (255, 255, 255), rect, 2)

    def _draw_treasure_chest(self, sx: float, sy: float):
        """Draw a treasure chest as a brown box with gold trim."""
        s = int(ADV_HEX_SIZE * 0.45)
        # Body
        body_rect = pygame.Rect(int(sx - s), int(sy - s * 0.7), s * 2, int(s * 1.4))
        pygame.draw.rect(self.surface, (120, 80, 30), body_rect, border_radius=2)
        # Lid (top darker band)
        lid_rect = pygame.Rect(body_rect.x, body_rect.y, body_rect.w, body_rect.h // 3)
        pygame.draw.rect(self.surface, (90, 60, 20), lid_rect, border_radius=2)
        # Gold trim border
        pygame.draw.rect(self.surface, (220, 190, 40), body_rect, 2, border_radius=2)
        # Lock (small gold square)
        lock_size = max(3, s // 3)
        lock_rect = pygame.Rect(
            int(sx - lock_size // 2),
            body_rect.y + body_rect.h // 3 - lock_size // 2,
            lock_size,
            lock_size,
        )
        pygame.draw.rect(self.surface, (220, 190, 40), lock_rect)

    def _draw_mine(self, sx: float, sy: float, mine):
        """Draw a mine using resource-type sprite with owner flag."""
        from lops.adventure.resources import ResourceType

        MINE_SPRITE_FILES = {
            ResourceType.GOLD: "mine-gold.png",
            ResourceType.WOOD: "mine-wood.png",
            ResourceType.ORE: "mine-ore.png",
            ResourceType.MERCURY: "mine-mercury.png",
            ResourceType.SULFUR: "mine-sulfur.png",
            ResourceType.CRYSTAL: "mine-crystal.png",
            ResourceType.GEMS: "mine-gems.png",
        }

        filename = MINE_SPRITE_FILES.get(mine.resource_type)
        sprite = self._get_mine_sprite(filename) if filename else None

        if sprite:
            blit_x = sx - sprite.get_width() / 2
            blit_y = sy - sprite.get_height() / 2
            self.surface.blit(sprite, (blit_x, blit_y))
        else:
            # Fallback: colored circle with letter
            MINE_COLORS = {
                ResourceType.GOLD: (220, 190, 40),
                ResourceType.WOOD: (120, 80, 30),
                ResourceType.ORE: (140, 140, 150),
                ResourceType.MERCURY: (180, 50, 180),
                ResourceType.SULFUR: (200, 180, 40),
                ResourceType.CRYSTAL: (80, 160, 220),
                ResourceType.GEMS: (60, 200, 100),
            }
            color = MINE_COLORS.get(mine.resource_type, (150, 150, 150))
            r = int(ADV_HEX_SIZE * 0.35)
            pygame.draw.circle(self.surface, color, (int(sx), int(sy)), r)
            pygame.draw.circle(self.surface, (255, 255, 255), (int(sx), int(sy)), r, 2)

        # Owner flag (small colored dot in corner)
        if mine.owner is not None:
            flag_color = COLOR_HERO_PLAYER if mine.owner == 0 else COLOR_HERO_AI
            r = int(ADV_HEX_SIZE * 0.35)
            fx = int(sx + r * 0.7)
            fy = int(sy - r * 0.7)
            pygame.draw.circle(self.surface, flag_color, (fx, fy), 5)
            pygame.draw.circle(self.surface, (255, 255, 255), (fx, fy), 5, 1)

    def _get_mine_sprite(self, filename: str) -> pygame.Surface | None:
        """Load and cache a mine sprite."""
        cache_key = ("mine", filename)
        if cache_key not in _town_sprite_cache:
            import os

            assets_dir = os.path.join(
                os.path.dirname(os.path.dirname(__file__)), "assets", "mines"
            )
            path = os.path.join(assets_dir, filename)
            if os.path.exists(path):
                img = pygame.image.load(path).convert_alpha()
                target_size = int(ADV_HEX_SIZE * 1.3)
                w, h = img.get_size()
                scale = target_size / max(w, h)
                img = pygame.transform.smoothscale(
                    img, (int(w * scale), int(h * scale))
                )
                _town_sprite_cache[cache_key] = img
            else:
                _town_sprite_cache[cache_key] = None
        return _town_sprite_cache[cache_key]

    # ── New map object draw methods (sprite-based) ────────────────

    # Booster type -> sprite filename
    _BOOSTER_SPRITES = {
        "learning_stone": "standing-stone.png",
        "gazebo": "gazebo.png",
        "mercenary_camp": "mercenary-camp.png",
        "marletto_tower": "tower.png",
        "garden_of_revelation": "rune-stone.png",
        "colosseum_of_the_magi": "altar.png",
        "arena": "arena.png",
        "library": "library.png",
    }

    def _get_object_sprite(
        self, filename: str, scale: float = 1.3
    ) -> pygame.Surface | None:
        """Load and cache a map object sprite from lops/assets/objects/."""
        cache_key = ("obj", filename, scale)
        if cache_key not in _town_sprite_cache:
            import os

            assets_dir = os.path.join(
                os.path.dirname(os.path.dirname(__file__)), "assets", "objects"
            )
            path = os.path.join(assets_dir, filename)
            if os.path.exists(path):
                img = pygame.image.load(path).convert_alpha()
                target_size = int(ADV_HEX_SIZE * scale)
                w, h = img.get_size()
                s = target_size / max(w, h)
                img = pygame.transform.smoothscale(img, (int(w * s), int(h * s)))
                _town_sprite_cache[cache_key] = img
            else:
                _town_sprite_cache[cache_key] = None
        return _town_sprite_cache[cache_key]

    def _blit_object_sprite(
        self, sx: float, sy: float, filename: str, scale: float = 1.3
    ):
        """Load and blit a centered object sprite. Returns True if drawn."""
        sprite = self._get_object_sprite(filename, scale)
        if sprite is not None:
            rect = sprite.get_rect(center=(int(sx), int(sy)))
            self.surface.blit(sprite, rect)
            return True
        return False

    def _draw_campfire(self, sx: float, sy: float):
        if not self._blit_object_sprite(sx, sy, "campfire.png", 1.4):
            # Fallback: procedural flame
            r = int(ADV_HEX_SIZE * 0.3)
            pts = [
                (int(sx), int(sy - r)),
                (int(sx - r * 0.6), int(sy + r * 0.3)),
                (int(sx + r * 0.6), int(sy + r * 0.3)),
            ]
            pygame.draw.polygon(self.surface, (255, 140, 40), pts)

    def _draw_stat_booster(self, sx: float, sy: float, obj):
        filename = self._BOOSTER_SPRITES.get(obj.booster_type)
        if filename and self._blit_object_sprite(sx, sy, filename, 1.3):
            return
        # Fallback: colored rectangle
        color = (150, 150, 150)
        r = int(ADV_HEX_SIZE * 0.35)
        rect = pygame.Rect(int(sx - r), int(sy - r // 2), r * 2, int(r * 1.2))
        pygame.draw.rect(self.surface, color, rect, border_radius=3)
        pygame.draw.rect(self.surface, (255, 255, 255), rect, 1, border_radius=3)

    def _draw_magic_well(self, sx: float, sy: float):
        if not self._blit_object_sprite(sx, sy, "magic-well.png", 1.3):
            r = int(ADV_HEX_SIZE * 0.35)
            pygame.draw.circle(self.surface, (40, 80, 160), (int(sx), int(sy)), r)
            pygame.draw.circle(self.surface, (80, 140, 220), (int(sx), int(sy)), r, 2)

    def _draw_pandoras_box(self, sx: float, sy: float):
        if not self._blit_object_sprite(sx, sy, "pandoras-box.png", 1.2):
            r = int(ADV_HEX_SIZE * 0.35)
            box = pygame.Rect(int(sx - r), int(sy - r * 0.6), r * 2, int(r * 1.2))
            pygame.draw.rect(self.surface, (60, 30, 80), box, border_radius=3)
            pygame.draw.rect(self.surface, (220, 180, 50), box, 2, border_radius=3)

    def _draw_creature_bank(self, sx: float, sy: float, obj):
        if not self._blit_object_sprite(sx, sy, "creature-bank.png", 1.4):
            r = int(ADV_HEX_SIZE * 0.4)
            body = pygame.Rect(int(sx - r), int(sy - r * 0.5), r * 2, int(r * 1.2))
            pygame.draw.rect(self.surface, (80, 70, 50), body, border_radius=4)
            pygame.draw.rect(self.surface, (180, 160, 100), body, 2, border_radius=4)

    def _draw_creature_dwelling(self, sx: float, sy: float, obj):
        if not self._blit_object_sprite(sx, sy, "creature-dwelling.png", 1.3):
            r = int(ADV_HEX_SIZE * 0.35)
            body = pygame.Rect(int(sx - r), int(sy - r // 3), r * 2, int(r * 1.0))
            pygame.draw.rect(self.surface, (100, 80, 50), body, border_radius=3)
        # Available count badge (drawn over sprite)
        if obj.available > 0:
            r = int(ADV_HEX_SIZE * 0.35)
            font = pygame.font.Font(None, 14)
            txt = font.render(str(obj.available), True, (255, 255, 255))
            bg = pygame.Rect(
                int(sx + r - 8), int(sy + r * 0.4), txt.get_width() + 4, 14
            )
            pygame.draw.rect(self.surface, (40, 80, 40), bg, border_radius=2)
            self.surface.blit(txt, (bg.x + 2, bg.y + 1))
        # Owner flag (drawn over sprite)
        if obj.owner is not None:
            r = int(ADV_HEX_SIZE * 0.35)
            flag_color = (80, 120, 220) if obj.owner == 0 else (220, 80, 80)
            pygame.draw.circle(
                self.surface, flag_color, (int(sx - r + 4), int(sy - r + 4)), 4
            )

    def _draw_hill_fort(self, sx: float, sy: float):
        if not self._blit_object_sprite(sx, sy, "hill-fort.png", 1.4):
            r = int(ADV_HEX_SIZE * 0.4)
            base = pygame.Rect(int(sx - r), int(sy - r * 0.3), r * 2, int(r * 1.0))
            pygame.draw.rect(self.surface, (120, 120, 130), base, border_radius=2)
            pygame.draw.rect(self.surface, (180, 180, 190), base, 2, border_radius=2)

    def _draw_heroes(self, adventure_state):
        """Draw hero tokens on the map using horse sprites."""
        cam = self.camera
        font = pygame.font.Font(None, 16)
        visible = self._visible
        anim = self._anim_state

        for player in adventure_state.players:
            if player.defeated:
                continue

            # Determine which hero is selected (for human player highlight)
            active_hs = player.active_hero_state

            for hs in player.alive_heroes():
                # Only draw heroes on the current layer
                if hs.layer != self.current_layer:
                    continue
                # Check if this hero is currently being animated
                if (
                    anim is not None
                    and anim.is_animating
                    and anim.active is not None
                    and anim.active.hero_state is hs
                ):
                    # AI heroes only visible if their current hex is revealed
                    if self._revealed is not None and player.is_ai:
                        cur_step = anim.active.current_step
                        cur_hex = anim.active.hex_path[cur_step]
                        if cur_hex not in self._revealed:
                            continue
                    wx, wy = anim.active.current_world_pos
                    sx, sy = cam.world_to_screen(wx, wy)
                else:
                    pos = hs.position
                    if pos is None or pos not in self._hex_centers:
                        continue
                    # AI heroes visible if in any revealed hex
                    if (
                        self._revealed is not None
                        and player.is_ai
                        and pos not in self._revealed
                    ):
                        continue
                    wx, wy = self._hex_centers[pos]
                    sx, sy = cam.world_to_screen(wx, wy)

                # Try to draw horse sprite
                sprite_file = "hero-player.png" if not player.is_ai else "hero-ai.png"
                sprite = self._get_hero_sprite(sprite_file)
                color = COLOR_HERO_PLAYER if not player.is_ai else COLOR_HERO_AI

                # Selected hero (human player) gets a gold ring highlight
                is_selected = not player.is_ai and hs is active_hs
                ring_color = COLOR_GOLD if is_selected else color

                if sprite:
                    blit_x = sx - sprite.get_width() / 2
                    blit_y = sy - sprite.get_height() / 2
                    self.surface.blit(sprite, (blit_x, blit_y))
                    # Ring outline (gold for selected, team color for others)
                    ring_width = 3 if is_selected else 2
                    pygame.draw.circle(
                        self.surface,
                        ring_color,
                        (int(sx), int(sy)),
                        int(ADV_HEX_SIZE * 0.5),
                        ring_width,
                    )
                else:
                    # Fallback: colored circle with initial
                    pygame.draw.circle(
                        self.surface,
                        color,
                        (int(sx), int(sy)),
                        int(ADV_HEX_SIZE * 0.45),
                    )
                    ring_width = 3 if is_selected else 2
                    pygame.draw.circle(
                        self.surface,
                        ring_color,
                        (int(sx), int(sy)),
                        int(ADV_HEX_SIZE * 0.45),
                        ring_width,
                    )

                # Draw hero name label below
                name_text = font.render(hs.hero.name, True, (255, 255, 255))
                name_rect = name_text.get_rect(
                    center=(int(sx), int(sy + ADV_HEX_SIZE * 0.55))
                )
                # Background for readability
                bg_rect = name_rect.inflate(6, 2)
                pygame.draw.rect(self.surface, (0, 0, 0, 160), bg_rect, border_radius=2)
                self.surface.blit(name_text, name_rect)

    def _get_hero_sprite(self, filename: str) -> pygame.Surface | None:
        """Load and cache a hero sprite."""
        cache_key = ("hero", filename)
        if cache_key not in _town_sprite_cache:
            import os

            assets_dir = os.path.join(
                os.path.dirname(os.path.dirname(__file__)), "assets", "heroes"
            )
            path = os.path.join(assets_dir, filename)
            if os.path.exists(path):
                img = pygame.image.load(path).convert_alpha()
                target_size = int(ADV_HEX_SIZE * 1.6)
                w, h = img.get_size()
                scale = target_size / max(w, h)
                img = pygame.transform.smoothscale(
                    img, (int(w * scale), int(h * scale))
                )
                _town_sprite_cache[cache_key] = img
            else:
                _town_sprite_cache[cache_key] = None
        return _town_sprite_cache[cache_key]

    def _draw_fog_overlay(self):
        """Draw fog of war: dark sky with twinkling stars on unexplored hexes."""
        import math as _m

        revealed = self._revealed
        visible = self._visible
        if revealed is None and visible is None:
            return

        cam = self.camera
        margin = ADV_HEX_SIZE * 2
        overlay = pygame.Surface(
            (self.viewport_w, self.surface.get_height()), pygame.SRCALPHA
        )
        t = self._fog_time

        for pos, corners_world in self._hex_corners.items():
            cx, cy = self._hex_centers[pos]
            sx, sy = cam.world_to_screen(cx, cy)
            if sx < -margin or sx > cam.viewport_w + margin:
                continue
            if sy < cam.hud_height - margin or sy > cam.screen_h + margin:
                continue

            if revealed is not None and pos not in revealed:
                screen_corners = [
                    cam.world_to_screen(wx, wy) for wx, wy in corners_world
                ]
                # Dark night sky base
                pygame.draw.polygon(overlay, (6, 8, 18, 255), screen_corners)

                # Twinkling stars
                stars = self._fog_stars.get(pos)
                if stars:
                    for ox, oy, phase, speed in stars:
                        star_sx, star_sy = cam.world_to_screen(cx + ox, cy + oy)
                        # Skip if off-screen
                        if star_sx < 0 or star_sx >= self.viewport_w:
                            continue
                        if star_sy < 0 or star_sy >= cam.screen_h:
                            continue
                        # Twinkle: sinusoidal brightness with phase offset
                        brightness = 0.5 + 0.5 * _m.sin(t * speed + phase)
                        # Occasional bright flash
                        flash = _m.sin(t * speed * 0.3 + phase * 2.7)
                        if flash > 0.95:
                            brightness = 1.0
                        alpha = int(40 + 180 * brightness)
                        # Warm white to cool blue-white color
                        warmth = 0.5 + 0.5 * _m.sin(phase)  # fixed per star
                        r = int(180 + 75 * warmth * brightness)
                        g = int(180 + 65 * brightness)
                        b = int(200 + 55 * brightness)
                        overlay.set_at(
                            (int(star_sx), int(star_sy)), (r, g, b, alpha)
                        )
                        # Brighter stars get a small glow pixel
                        if brightness > 0.7:
                            glow_a = int(alpha * 0.3)
                            for gdx, gdy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                                gx = int(star_sx) + gdx
                                gy = int(star_sy) + gdy
                                if 0 <= gx < self.viewport_w and 0 <= gy < cam.screen_h:
                                    overlay.set_at(
                                        (gx, gy), (r, g, b, glow_a)
                                    )

        self.surface.blit(overlay, (0, 0))

    def _draw_hover_tooltip(self, adventure_state):
        """Draw army preview tooltip when hovering over heroes, monsters, or towns."""
        if self.hover_hex is None:
            return

        from lops.adventure.map_objects import TownSite, WanderingMonster
        from lops.quantity_words import quantity_word

        hover = self.hover_hex
        revealed = self._revealed
        visible = self._visible

        # Don't show tooltips for unexplored hexes
        if revealed is not None and hover not in revealed:
            return

        lines: list[tuple[str, tuple[int, int, int]]] = []
        title = ""
        title_color = COLOR_TEXT

        # Check for hero at this hex (iterate all heroes of all players)
        for player in adventure_state.players:
            if player.defeated:
                continue
            # AI heroes visible if in revealed hexes
            if revealed is not None and player.is_ai and hover not in revealed:
                continue
            for hs in player.alive_heroes():
                if hs.position != hover or hs.layer != self.current_layer:
                    continue
                title = hs.hero.name
                title_color = COLOR_HERO_PLAYER if not player.is_ai else COLOR_HERO_AI
                for stack in hs.army:
                    if stack.alive:
                        lines.append(
                            (
                                f"{quantity_word(stack.count)} {stack.stats.name}",
                                (200, 200, 200),
                            )
                        )
                break
            if lines:
                break

        # Check for map object at this hex (current layer only)
        if not lines:
            obj = adventure_state.find_object_at(hover, layer=self.current_layer)
            if obj is None:
                return

            if isinstance(obj, WanderingMonster):
                if visible is not None and hover not in visible:
                    return
                title = obj.name
                title_color = COLOR_MONSTER
                for stack in obj.army:
                    if stack.alive:
                        lines.append(
                            (
                                f"{quantity_word(stack.count)} {stack.stats.name}",
                                (200, 200, 200),
                            )
                        )

            elif isinstance(obj, TownSite):
                title = obj.name
                if obj.owner == 0:
                    title_color = COLOR_TOWN_PLAYER
                elif obj.owner is not None:
                    title_color = COLOR_TOWN_AI
                else:
                    title_color = COLOR_TOWN_NEUTRAL
                from lops.adventure.town import Town as _Town

                _town: _Town | None = obj.town  # type: ignore[assignment]
                if _town and _town.garrison:
                    for stack in _town.garrison:
                        if stack.alive:
                            lines.append(
                                (
                                    f"{quantity_word(stack.count)} {stack.stats.name}",
                                    (200, 200, 200),
                                )
                            )
                    # Also show if a hero is at the town
                    for player in adventure_state.players:
                        if player.defeated:
                            continue
                        for hs in player.alive_heroes():
                            if hs.position == hover:
                                if (
                                    visible is None
                                    or hover in visible
                                    or not player.is_ai
                                ):
                                    lines.append(
                                        (
                                            f"+ {hs.hero.name}'s army",
                                            (180, 180, 120),
                                        )
                                    )
                elif obj.owner is not None:
                    lines.append(("(no garrison)", (120, 120, 120)))
            elif hasattr(obj, "artifact_id") and not hasattr(obj, "bank_type_index"):
                # ArtifactPickup
                from lops.data.artifacts import ARTIFACT_REGISTRY

                adef = ARTIFACT_REGISTRY.get(obj.artifact_id)
                if adef:
                    title = adef.name
                    from lops.artifacts import ArtifactClass

                    CLASS_COLORS = {
                        ArtifactClass.TREASURE: (220, 220, 220),
                        ArtifactClass.MINOR: (80, 200, 80),
                        ArtifactClass.MAJOR: (80, 130, 220),
                        ArtifactClass.RELIC: (240, 200, 50),
                    }
                    title_color = CLASS_COLORS.get(adef.artifact_class, COLOR_TEXT)
                    lines.append((adef.description, (200, 200, 200)))
            elif hasattr(obj, "booster_type"):
                # Check if current hero has visited
                visited = False
                hs = adventure_state.current_player.active_hero_state
                if hs and hs.hero_id in obj.visited_by:
                    visited = True
                suffix = " (visited)" if visited else ""
                title = obj.name + suffix
                title_color = (120, 120, 100) if visited else (200, 200, 140)
                desc_map = {
                    "learning_stone": "+1000 XP",
                    "gazebo": "+1000 XP",
                    "mercenary_camp": "+1 Attack",
                    "marletto_tower": "+1 Defense",
                    "garden_of_revelation": "+1 Knowledge",
                    "colosseum_of_the_magi": "+1 Spell Power",
                    "arena": "+2 Attack or Defense",
                    "library": "+2 All Stats (Lv 10)",
                }
                lines.append((desc_map.get(obj.booster_type, ""), (200, 200, 200)))
            elif hasattr(obj, "bank_type_index"):

                title = obj.name
                title_color = (200, 180, 120)
                if visible is None or hover in visible:
                    for ct, count in obj.bank_def["guards"]:
                        from lops.data.creatures import CREATURE_REGISTRY

                        stats = CREATURE_REGISTRY.get(ct)
                        if stats:
                            lines.append(
                                (
                                    f"{quantity_word(count)} {stats.name}",
                                    (200, 200, 200),
                                )
                            )
            elif hasattr(obj, "growth_per_week"):

                title = obj.name
                title_color = (180, 140, 80)
                lines.append((f"Available: {obj.available}", (200, 200, 200)))
            elif hasattr(obj, "guards") and hasattr(obj, "gold_reward"):
                title = "Pandora's Box"
                title_color = (180, 120, 200)
                if obj.is_guarded and (visible is None or hover in visible):
                    lines.append(("Guarded!", (220, 80, 80)))
            elif hasattr(obj, "can_visit"):
                visited_well = False
                hs = adventure_state.current_player.active_hero_state
                if hs and not obj.can_visit(hs.hero_id, adventure_state.day):
                    visited_well = True
                suffix = " (visited this week)" if visited_well else ""
                title = "Magic Well" + suffix
                title_color = (80, 110, 160) if visited_well else (100, 160, 255)
                lines.append(("Restores mana", (200, 200, 200)))
            elif isinstance(obj, type) or hasattr(obj, "name"):
                # Campfire, HillFort, etc.
                title = getattr(obj, "name", "")
                title_color = (200, 200, 200)
            else:
                return  # no tooltip for mines/resources

        if not title:
            return

        # Render tooltip near the mouse cursor
        mx, my = pygame.mouse.get_pos()
        font = pygame.font.Font(None, 18)
        title_font = pygame.font.Font(None, 20)

        # Build rendered lines
        rendered_title = title_font.render(title, True, title_color)
        rendered_lines = [font.render(text, True, color) for text, color in lines]

        # Calculate tooltip dimensions
        pad_x, pad_y = 10, 6
        line_h = 16
        tooltip_w = rendered_title.get_width()
        for rl in rendered_lines:
            tooltip_w = max(tooltip_w, rl.get_width())
        tooltip_w += pad_x * 2
        tooltip_h = (
            rendered_title.get_height() + pad_y + len(rendered_lines) * line_h + pad_y
        )

        # Position: offset from cursor, keep on screen
        tx = mx + 16
        ty = my - tooltip_h - 4
        if tx + tooltip_w > self.viewport_w:
            tx = mx - tooltip_w - 8
        if ty < 40:
            ty = my + 20

        # Draw background
        bg_rect = pygame.Rect(tx, ty, tooltip_w, tooltip_h)
        bg_surf = pygame.Surface((tooltip_w, tooltip_h), pygame.SRCALPHA)
        bg_surf.fill((15, 15, 25, 220))
        self.surface.blit(bg_surf, (tx, ty))
        pygame.draw.rect(self.surface, (80, 80, 100), bg_rect, 1, border_radius=3)

        # Draw title
        self.surface.blit(rendered_title, (tx + pad_x, ty + pad_y))
        # Draw army lines
        y = ty + pad_y + rendered_title.get_height() + 2
        for rl in rendered_lines:
            self.surface.blit(rl, (tx + pad_x, y))
            y += line_h

    def clear_highlights(self):
        self.move_range.clear()
        self.move_path.clear()
