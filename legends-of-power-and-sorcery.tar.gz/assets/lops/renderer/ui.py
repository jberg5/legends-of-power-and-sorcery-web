"""HUD: turn info, tooltips, action panel, combat log."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pygame

from lops.combat import CombatEngine
from lops.damage import calculate_damage_range
from lops.models import CreatureStack, Side

if TYPE_CHECKING:
    from lops.spells import Spell

COLOR_PANEL_BG = (20, 20, 30, 220)
COLOR_TEXT = (220, 220, 220)
COLOR_HIGHLIGHT = (255, 255, 100)
COLOR_PLAYER_TEXT = (100, 160, 255)
COLOR_ENEMY_TEXT = (255, 100, 100)
COLOR_LOG_BG = (15, 15, 25, 200)


class UIRenderer:
    """Renders HUD elements: turn info, tooltips, combat log, action hints."""

    def __init__(
        self,
        surface: pygame.Surface,
        engine: CombatEngine,
        player_side: Side = Side.ATTACKER,
    ):
        self.surface = surface
        self.engine = engine
        self.player_side = player_side
        self.font = pygame.font.SysFont("Arial", 14)
        self.title_font = pygame.font.SysFont("Arial", 16, bold=True)
        self.small_font = pygame.font.SysFont("Arial", 12)
        self.log_scroll = 0
        self._hover_stack: CreatureStack | None = None
        # Spellbook layout tracking
        self._spell_rects: list[tuple[pygame.Rect, Spell]] = []

    def set_hover_stack(self, stack: CreatureStack | None):
        self._hover_stack = stack

    def draw(self, auto_combat: bool = False):
        self._draw_turn_indicator()
        self._draw_hero_banners()
        self._draw_mana_bars()
        self._draw_action_hints(auto_combat=auto_combat)
        self._draw_combat_log()
        if self._hover_stack:
            self._draw_tooltip(self._hover_stack)
        if self.engine.is_over():
            self._draw_victory_screen()

    def _draw_turn_indicator(self):
        """Show whose turn it is at the top of the screen."""
        sw = self.surface.get_width()
        panel = pygame.Surface((sw, 36), pygame.SRCALPHA)
        panel.fill((20, 20, 30, 180))
        self.surface.blit(panel, (0, 0))

        stack = self.engine.current_stack
        if stack and not self.engine.is_over():
            is_player = stack.side == self.player_side
            side_color = COLOR_PLAYER_TEXT if is_player else COLOR_ENEMY_TEXT
            side_name = "Your" if is_player else "Enemy"
            text = f"Round {self.engine.round_number} | {side_name} turn: {stack.stats.name} ({stack.count})"
            if stack.is_waiting:
                text += " [WAITING]"

            rendered = self.title_font.render(text, True, side_color)
            self.surface.blit(rendered, (10, 8))

            # Speed/ATK/DEF info
            info = f"SPD:{stack.effective_speed}  ATK:{stack.effective_attack}  DEF:{stack.effective_defense}"
            if stack.stats.is_ranged:
                info += f"  Shots:{stack.shots_left}"
            info_surf = self.small_font.render(info, True, COLOR_TEXT)
            self.surface.blit(info_surf, (sw - info_surf.get_width() - 10, 12))

    def _draw_hero_banners(self):
        """Draw hero name banners for attacker (left) and defender (right)."""
        sh = self.surface.get_height()
        sw = self.surface.get_width()
        panel_w = 230  # combat log panel width
        battlefield_w = sw - panel_w

        atk_hero = self.engine.get_hero(Side.ATTACKER)
        def_hero = self.engine.get_hero(Side.DEFENDER)

        atk_is_player = self.player_side == Side.ATTACKER
        def_is_player = self.player_side == Side.DEFENDER

        # Attacker banner (bottom-left)
        atk_label = "You" if atk_is_player else "Enemy"
        atk_text = f"{atk_hero.name} ({atk_label})"
        atk_color = COLOR_PLAYER_TEXT if atk_is_player else COLOR_ENEMY_TEXT
        atk_surf = self.font.render(atk_text, True, atk_color)
        atk_bg = pygame.Surface((atk_surf.get_width() + 16, 22), pygame.SRCALPHA)
        atk_bg.fill((20, 20, 40, 180))
        self.surface.blit(atk_bg, (8, sh - 55))
        self.surface.blit(atk_surf, (16, sh - 52))

        # Defender banner (bottom-right, left of combat log)
        def_label = "You" if def_is_player else "Enemy"
        def_text = f"{def_hero.name} ({def_label})"
        def_color = COLOR_PLAYER_TEXT if def_is_player else COLOR_ENEMY_TEXT
        def_surf = self.font.render(def_text, True, def_color)
        def_bg = pygame.Surface((def_surf.get_width() + 16, 22), pygame.SRCALPHA)
        def_bg.fill((20, 20, 40, 180))
        dx = battlefield_w - def_surf.get_width() - 24
        self.surface.blit(def_bg, (dx, sh - 55))
        self.surface.blit(def_surf, (dx + 8, sh - 52))

    def _draw_action_hints(self, auto_combat: bool = False):
        """Show available keyboard shortcuts at the bottom."""
        if self.engine.is_over():
            return

        if auto_combat:
            hint_text = "AUTO BATTLE  |  A: Take Control"
            rendered = self.small_font.render(hint_text, True, (255, 200, 60))
            sh = self.surface.get_height()
            panel = pygame.Surface((rendered.get_width() + 20, 24), pygame.SRCALPHA)
            panel.fill((60, 40, 10, 180))
            self.surface.blit(panel, (5, sh - 29))
            self.surface.blit(rendered, (15, sh - 26))
            return

        stack = self.engine.current_stack
        if not stack or stack.side != self.player_side:
            return

        hints = ["W: Wait", "D: Defend"]
        hero = self.engine.get_hero(stack.side)
        if hero.spells and not hero.has_cast_this_round:
            hints.append("S: Spellbook")
        hints.append("A: Auto")

        hint_text = "  |  ".join(hints)
        rendered = self.small_font.render(hint_text, True, (160, 160, 160))

        sh = self.surface.get_height()
        panel = pygame.Surface((rendered.get_width() + 20, 24), pygame.SRCALPHA)
        panel.fill((20, 20, 30, 160))
        self.surface.blit(panel, (5, sh - 29))
        self.surface.blit(rendered, (15, sh - 26))

    def _draw_combat_log(self):
        """Draw the combat log in the right-side panel (off the battlefield)."""
        sw, sh = self.surface.get_size()
        panel_w = 230
        log_x = sw - panel_w - 5
        log_y = 42
        log_h = sh - log_y - 35  # fill most of the right panel

        panel = pygame.Surface((panel_w, log_h), pygame.SRCALPHA)
        panel.fill(COLOR_LOG_BG)
        self.surface.blit(panel, (log_x, log_y))

        # Title
        title = self.small_font.render("Combat Log", True, COLOR_HIGHLIGHT)
        self.surface.blit(title, (log_x + 5, log_y + 3))

        # Log entries (show as many as fit, wrap long lines)
        max_char = panel_w // 7  # approx chars that fit in panel width
        y = log_y + 20
        max_y = log_y + log_h - 5

        # Collect wrapped lines from recent log entries (newest at end)
        wrapped_lines: list[tuple[str, tuple]] = []
        for entry in self.engine.combat_log:
            color = COLOR_HIGHLIGHT if entry.startswith("---") else COLOR_TEXT
            if len(entry) <= max_char:
                wrapped_lines.append((entry, color))
            else:
                # Wrap at word boundaries
                words = entry.split()
                line = ""
                for word in words:
                    if line and len(line) + 1 + len(word) > max_char:
                        wrapped_lines.append((line, color))
                        line = "  " + word  # indent continuation
                    else:
                        line = line + " " + word if line else word
                if line:
                    wrapped_lines.append((line, color))

        # Show as many as fit from the end
        visible_count = (max_y - y) // 14
        visible = wrapped_lines[-visible_count:] if visible_count > 0 else []
        for line_text, color in visible:
            text = self.small_font.render(line_text, True, color)
            self.surface.blit(text, (log_x + 5, y))
            y += 14

    def _draw_tooltip(self, stack: CreatureStack):
        """Draw creature info tooltip near the mouse."""
        mx, my = pygame.mouse.get_pos()
        sw, sh = self.surface.get_size()

        lines = [
            f"{stack.stats.name} x{stack.count}",
            f"ATK: {stack.effective_attack}  DEF: {stack.effective_defense}",
            f"DMG: {stack.effective_min_damage}-{stack.effective_max_damage}",
            f"HP: {stack.current_hp}/{stack.stats.hp}  SPD: {stack.effective_speed}",
        ]
        if stack.stats.is_ranged:
            lines.append(f"Ranged (shots: {stack.shots_left})")
        if stack.stats.is_flying:
            lines.append("Flying")
        if stack.stats.double_strike:
            lines.append("Double Strike")
        if stack.stats.unlimited_retaliation:
            lines.append("Unlimited Retaliation")

        # Show damage preview against current stack
        current = self.engine.current_stack
        if current and current.side != stack.side and current.alive:
            hero = self.engine.get_hero(current.side)
            def_hero = self.engine.get_hero(stack.side)
            min_d, max_d = calculate_damage_range(current, stack, hero, def_hero)
            lines.append(f"Est. damage: {min_d}-{max_d}")

        # Calculate tooltip size
        tt_w = max(self.font.size(l)[0] for l in lines) + 16
        tt_h = len(lines) * 18 + 10

        # Position tooltip
        tx = mx + 15
        ty = my - tt_h - 5
        if tx + tt_w > sw:
            tx = mx - tt_w - 15
        if ty < 0:
            ty = my + 20

        panel = pygame.Surface((tt_w, tt_h), pygame.SRCALPHA)
        panel.fill((10, 10, 20, 230))
        self.surface.blit(panel, (tx, ty))

        y = ty + 5
        for i, line in enumerate(lines):
            color = COLOR_HIGHLIGHT if i == 0 else COLOR_TEXT
            text = self.font.render(line, True, color)
            self.surface.blit(text, (tx + 8, y))
            y += 18

    def _draw_mana_bars(self):
        """Draw mana bars under hero banners."""
        sh = self.surface.get_height()
        sw = self.surface.get_width()
        panel_w = 230
        battlefield_w = sw - panel_w

        for side, x_pos in [(Side.ATTACKER, 8), (Side.DEFENDER, battlefield_w - 150)]:
            hero = self.engine.get_hero(side)
            if not hero or hero.effective_knowledge() == 0:
                continue
            max_mana = hero.effective_knowledge() * 10
            if max_mana <= 0:
                continue
            bar_w = 100
            bar_h = 8
            y = sh - 33
            # Background
            pygame.draw.rect(self.surface, (30, 30, 60), (x_pos, y, bar_w, bar_h))
            # Fill
            fill_w = int(bar_w * hero.mana / max_mana) if max_mana > 0 else 0
            pygame.draw.rect(self.surface, (60, 80, 200), (x_pos, y, fill_w, bar_h))
            # Text
            mana_text = self.small_font.render(
                f"MP: {hero.mana}/{max_mana}", True, (150, 170, 255)
            )
            self.surface.blit(mana_text, (x_pos + bar_w + 4, y - 2))

    def spellbook_scroll(self, direction: int):
        """Scroll the spellbook up/down. direction: -1 = up, +1 = down."""
        self._spellbook_scroll = getattr(self, "_spellbook_scroll", 0)
        self._spellbook_scroll = max(0, self._spellbook_scroll + direction * 3)

    def draw_spellbook(self):
        """Draw spell book overlay panel with hover descriptions and scrolling."""
        from lops.data.spells import SPELL_REGISTRY
        from lops.spells import MagicSchool, get_mana_cost, spell_detail_lines

        hero = self.engine.get_hero(self.player_side)
        if not hero or not hero.spells:
            return

        sw, sh = self.surface.get_size()
        scroll_offset = getattr(self, "_spellbook_scroll", 0)

        # Panel dimensions — list on left, detail on right
        list_w = 310
        detail_w = 210
        panel_w = list_w + detail_w
        panel_h = 500  # fixed height with scroll
        px = (sw - panel_w) // 2
        py = (sh - panel_h) // 2

        # Background
        overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 120))
        self.surface.blit(overlay, (0, 0))

        panel = pygame.Surface((panel_w, panel_h), pygame.SRCALPHA)
        panel.fill((20, 20, 40, 240))
        pygame.draw.rect(panel, (80, 80, 120), (0, 0, panel_w, panel_h), 2)
        # Divider between list and detail
        pygame.draw.line(panel, (60, 60, 90), (list_w, 30), (list_w, panel_h - 26), 1)
        self.surface.blit(panel, (px, py))

        # Title
        title = self.title_font.render("Spell Book", True, (220, 220, 255))
        self.surface.blit(title, (px + (list_w - title.get_width()) // 2, py + 8))

        # Column headers
        header_y = py + 35
        headers = self.small_font.render(
            "Spell                School   Lv  Cost", True, (160, 160, 180)
        )
        self.surface.blit(headers, (px + 10, header_y))

        # School colors
        school_colors = {
            MagicSchool.AIR: (180, 220, 255),
            MagicSchool.EARTH: (160, 200, 120),
            MagicSchool.FIRE: (255, 140, 100),
            MagicSchool.WATER: (100, 160, 255),
        }

        # Group spells by level, sorted
        spells_by_level: dict[int, list] = {}
        for spell_id in hero.spells:
            spell = SPELL_REGISTRY.get(spell_id)
            if spell:
                spells_by_level.setdefault(spell.level, []).append(spell)

        # Build flat list of rows: (type, data)  type = 'header' or 'spell'
        rows: list[tuple[str, int | Spell]] = []
        for level in sorted(spells_by_level.keys()):
            rows.append(("header", level))
            for spell in sorted(spells_by_level[level], key=lambda s: s.name):
                rows.append(("spell", spell))

        # Clamp scroll
        row_h = 24
        header_h = 20
        content_area_top = header_y + 18
        content_area_bottom = py + panel_h - 28
        visible_h = content_area_bottom - content_area_top
        total_content_h = sum(header_h if r[0] == "header" else row_h for r in rows)
        max_scroll = max(0, total_content_h - visible_h)
        scroll_offset = min(scroll_offset, max_scroll)
        self._spellbook_scroll = scroll_offset

        # Clip region for spell list
        clip_rect = pygame.Rect(px, content_area_top, list_w, visible_h)

        mx, my = pygame.mouse.get_pos()
        hovered_spell = None

        self._spell_rects = []
        y = content_area_top - scroll_offset
        for row_type, data in rows:
            if row_type == "header":
                h = header_h
                if y + h > content_area_top and y < content_area_bottom:
                    # Level header
                    hdr_text = f"--- Level {data} ---"
                    hdr_surf = self.small_font.render(hdr_text, True, (200, 200, 140))
                    self.surface.blit(hdr_surf, (px + 10, y + 2), area=None)
                y += h
                continue

            assert not isinstance(data, int)
            spell = data
            h = row_h
            # Only render/interact if visible
            if y + h > content_area_top and y < content_area_bottom:
                mana_cost = get_mana_cost(hero, spell)
                can_cast = hero.mana >= mana_cost and not hero.has_cast_this_round

                # Row background on hover
                row_rect = pygame.Rect(px + 4, y, list_w - 8, h)
                if row_rect.collidepoint(mx, my) and clip_rect.collidepoint(mx, my):
                    hover_bg = pygame.Surface((list_w - 8, h), pygame.SRCALPHA)
                    hover_bg.fill((60, 60, 100, 100))
                    self.surface.blit(hover_bg, (px + 4, y))
                    hovered_spell = spell

                # Spell name
                color = (
                    school_colors.get(spell.school, COLOR_TEXT)
                    if can_cast
                    else (80, 80, 80)
                )
                name_surf = self.font.render(spell.name, True, color)
                self.surface.blit(name_surf, (px + 10, y + 3))

                # School
                school_text = spell.school.name.capitalize()
                school_surf = self.small_font.render(school_text, True, color)
                self.surface.blit(school_surf, (px + 160, y + 5))

                # Level
                level_surf = self.small_font.render(str(spell.level), True, color)
                self.surface.blit(level_surf, (px + 225, y + 5))

                # Cost
                cost_color = (100, 150, 255) if can_cast else (80, 80, 80)
                cost_surf = self.small_font.render(str(mana_cost), True, cost_color)
                self.surface.blit(cost_surf, (px + 260, y + 5))

                self._spell_rects.append((row_rect, spell))
            y += h

        # Scroll indicators
        if scroll_offset > 0:
            arrow = self.small_font.render("^ scroll up ^", True, (150, 150, 180))
            self.surface.blit(arrow, (px + 10, content_area_top - 1))
        if scroll_offset < max_scroll:
            arrow = self.small_font.render("v scroll down v", True, (150, 150, 180))
            self.surface.blit(arrow, (px + 10, content_area_bottom + 1))

        # --- Detail panel (right side) ---
        detail_x = px + list_w + 8
        detail_y = py + 10
        if hovered_spell:
            # Spell name as header
            sc = school_colors.get(hovered_spell.school, COLOR_TEXT)
            name_s = self.title_font.render(hovered_spell.name, True, sc)
            self.surface.blit(name_s, (detail_x, detail_y))
            detail_y += 22

            # Detail lines (description + computed values)
            lines = spell_detail_lines(hovered_spell, hero)
            for line in lines:
                # Word-wrap long lines
                words = line.split()
                wrapped = ""
                for word in words:
                    test = wrapped + (" " if wrapped else "") + word
                    if self.small_font.size(test)[0] > detail_w - 12:
                        if wrapped:
                            surf = self.small_font.render(
                                wrapped, True, (190, 190, 210)
                            )
                            self.surface.blit(surf, (detail_x, detail_y))
                            detail_y += 15
                        wrapped = word
                    else:
                        wrapped = test
                if wrapped:
                    surf = self.small_font.render(wrapped, True, (190, 190, 210))
                    self.surface.blit(surf, (detail_x, detail_y))
                    detail_y += 15
                detail_y += 2  # small gap between lines
        else:
            hint = self.small_font.render("Hover a spell", True, (100, 100, 120))
            self.surface.blit(hint, (detail_x, detail_y + 20))
            hint2 = self.small_font.render("for details", True, (100, 100, 120))
            self.surface.blit(hint2, (detail_x, detail_y + 36))

        # Instructions
        inst = self.small_font.render(
            "Click to cast  |  ESC to close  |  Scroll: mouse wheel",
            True,
            (120, 120, 140),
        )
        self.surface.blit(
            inst, (px + (panel_w - inst.get_width()) // 2, py + panel_h - 22)
        )

    def spellbook_click(self, pos: tuple[int, int]):
        """Check if a spell was clicked in the spellbook. Returns Spell or None."""
        from lops.spells import get_mana_cost

        hero = self.engine.get_hero(self.player_side)
        if not hero:
            return None
        for rect, spell in self._spell_rects:
            if rect.collidepoint(pos):
                mana_cost = get_mana_cost(hero, spell)
                if hero.mana >= mana_cost and not hero.has_cast_this_round:
                    return spell
        return None

    def _draw_victory_screen(self):
        """Draw victory/defeat overlay."""
        sw, sh = self.surface.get_size()
        overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 150))
        self.surface.blit(overlay, (0, 0))

        if self.engine.winner == self.player_side:
            text = "VICTORY!"
            color = (100, 255, 100)
        else:
            text = "DEFEAT!"
            color = (255, 100, 100)

        title = pygame.font.SysFont("Arial", 48, bold=True).render(text, True, color)
        tr = title.get_rect(center=(sw // 2, sh // 2 - 30))
        self.surface.blit(title, tr)

        # Combat stats
        stats_lines = [
            f"Rounds: {self.engine.round_number}",
            f"Attacker stacks remaining: {len(self.engine.battlefield.attacker.alive_stacks)}",
            f"Defender stacks remaining: {len(self.engine.battlefield.defender.alive_stacks)}",
        ]
        y = sh // 2 + 20
        for line in stats_lines:
            line_surf = self.font.render(line, True, COLOR_TEXT)
            tr = line_surf.get_rect(center=(sw // 2, y))
            self.surface.blit(line_surf, tr)
            y += 22
