"""Welcome screen: faction and map size selection before starting a new game."""

from __future__ import annotations

from dataclasses import dataclass

import pygame

from lops.adventure.town import FactionId
from lops.difficulty import DIFFICULTY_INFO, Difficulty

# Faction display info: (faction_id, name, description, color, tier7_creature)
FACTION_INFO = [
    (FactionId.CASTLE, "Castle", "Knights & Angels", (50, 120, 220), "Angel"),
    (
        FactionId.NECROPOLIS,
        "Necropolis",
        "Undead & Dragons",
        (100, 60, 140),
        "Bone Dragon",
    ),
    (FactionId.INFERNO, "Inferno", "Demons & Devils", (200, 50, 30), "Devil"),
    (FactionId.DUNGEON, "Dungeon", "Dark Elves & Dragons", (80, 50, 120), "Red Dragon"),
    (FactionId.RAMPART, "Rampart", "Elves & Dragons", (60, 160, 60), "Gold Dragon"),
    (FactionId.TOWER, "Tower", "Wizards & Titans", (100, 150, 210), "Titan"),
    (FactionId.STRONGHOLD, "Stronghold", "Barbarians & Beasts", (180, 100, 40), "Ancient Behemoth"),
    (FactionId.FORTRESS, "Fortress", "Beastmen & Hydras", (120, 140, 80), "Chaos Hydra"),
    (FactionId.CONFLUX, "Conflux", "Elementals & Phoenix", (160, 100, 200), "Phoenix"),
]


@dataclass
class MapSize:
    """Map size preset."""

    key: str
    label: str
    cols: int
    rows: int
    description: str


MAP_SIZES = [
    MapSize("test", "Test", 36, 24, "36x24 — quick games"),
    MapSize("small", "Small", 52, 36, "52x36 — short campaign"),
    MapSize("medium", "Medium", 72, 48, "72x48 — standard game"),
    MapSize("large", "Large", 108, 72, "108x72 — epic campaign"),
]


@dataclass
class GameSetup:
    """Result of welcome screen selections."""

    faction: FactionId
    map_size: MapSize
    difficulty: Difficulty = Difficulty.NORMAL


class WelcomeScreen:
    """Faction and map size selection screen."""

    def __init__(self, surface: pygame.Surface, is_mobile: bool = False):
        self.surface = surface
        self.is_mobile = is_mobile
        # Scale fonts for mobile
        s = 1.3 if is_mobile else 1.0
        self.title_font = pygame.font.Font(None, int(56 * s))
        self.subtitle_font = pygame.font.Font(None, int(28 * s))
        self.faction_font = pygame.font.Font(None, int(32 * s))
        self.desc_font = pygame.font.Font(None, int(22 * s))
        self.hint_font = pygame.font.Font(None, int(20 * s))
        self.size_font = pygame.font.Font(None, int(26 * s))

        self._scroll_y: int = 0  # vertical scroll offset for mobile

        self.selected_faction: FactionId | None = None
        self.selected_map_size: MapSize | None = None
        self.selected_difficulty: Difficulty = Difficulty.NORMAL
        self._faction_rects: list[tuple[pygame.Rect, FactionId]] = []
        self._size_rects: list[tuple[pygame.Rect, MapSize]] = []
        self._diff_rects: list[tuple[pygame.Rect, Difficulty]] = []

    def handle_scroll(self, dy: int):
        """Handle scroll wheel or touch scroll."""
        self._scroll_y = max(0, self._scroll_y - dy * 30)

    def handle_click(self, pos: tuple[int, int]) -> GameSetup | None:
        """Handle a click. Returns GameSetup when both selections are made."""
        # Adjust for scroll on mobile
        pos = (pos[0], pos[1] + self._scroll_y)
        # Faction buttons
        for rect, faction_id in self._faction_rects:
            if rect.collidepoint(pos):
                self.selected_faction = faction_id
                return None

        # Map size buttons
        for rect, map_size in self._size_rects:
            if rect.collidepoint(pos):
                self.selected_map_size = map_size
                return None

        # Difficulty buttons
        for rect, diff in self._diff_rects:
            if rect.collidepoint(pos):
                self.selected_difficulty = diff
                return None

        # Start button
        if (
            self.selected_faction is not None
            and self.selected_map_size is not None
            and hasattr(self, "_start_rect")
            and self._start_rect.collidepoint(pos)
        ):
            return GameSetup(self.selected_faction, self.selected_map_size, self.selected_difficulty)

        return None

    def draw(self):
        sw, sh = self.surface.get_size()
        self.surface.fill((15, 12, 10))
        mx, my = pygame.mouse.get_pos()
        # Apply scroll offset for mobile
        scroll_y = self._scroll_y if self.is_mobile else 0
        my += scroll_y

        # Title
        title_y = 20 if self.is_mobile else 30
        title = self.title_font.render(
            "Legends of Power and Sorcery", True, (240, 200, 50)
        )
        self.surface.blit(title, title.get_rect(centerx=sw // 2, y=title_y - scroll_y))

        # --- Faction selection ---
        subtitle = self.subtitle_font.render(
            "Choose your faction", True, (200, 190, 170)
        )
        sub_y = (55 if self.is_mobile else 85) - scroll_y
        self.surface.blit(subtitle, subtitle.get_rect(centerx=sw // 2, y=sub_y))

        self._faction_rects.clear()
        if self.is_mobile:
            cols = max(2, sw // 220)
            btn_w = min(200, (sw - (cols + 1) * 8) // cols)
            btn_h = 70
            gap = 8
        else:
            cols = 5
            btn_w, btn_h = 230, 90
            gap = 12
        # Split factions into rows of `cols`
        rows_data = []
        for i in range(0, len(FACTION_INFO), cols):
            rows_data.append(FACTION_INFO[i : i + cols])
        btn_y = (80 if self.is_mobile else 115) - scroll_y

        for row_idx, row_factions in enumerate(rows_data):
            row_total_w = len(row_factions) * btn_w + (len(row_factions) - 1) * gap
            row_start_x = (sw - row_total_w) // 2
            for col_idx, (faction_id, name, desc, color, tier7) in enumerate(row_factions):
                x = row_start_x + col_idx * (btn_w + gap)
                y = btn_y + row_idx * (btn_h + gap)
                rect = pygame.Rect(x, y, btn_w, btn_h)
                self._faction_rects.append((rect, faction_id))

                is_selected = self.selected_faction == faction_id
                hover = rect.collidepoint(mx, my)
                bg = (
                    tuple(min(255, c + 25) for c in color)
                    if (hover or is_selected)
                    else color
                )

                pygame.draw.rect(self.surface, (30, 25, 22), rect, border_radius=8)
                band = pygame.Rect(rect.x + 2, rect.y + 2, rect.w - 4, 34)
                pygame.draw.rect(self.surface, bg, band, border_radius=6)

                border_color = (
                    (255, 220, 100)
                    if is_selected
                    else (180, 160, 100)
                    if hover
                    else (80, 70, 50)
                )
                border_w = 3 if is_selected else 2
                pygame.draw.rect(
                    self.surface, border_color, rect, border_w, border_radius=8
                )

                name_surf = self.faction_font.render(name, True, (255, 255, 255))
                if self.is_mobile:
                    # Compact: just name, centered
                    self.surface.blit(
                        name_surf, name_surf.get_rect(center=rect.center)
                    )
                else:
                    self.surface.blit(
                        name_surf, name_surf.get_rect(centerx=rect.centerx, y=rect.y + 8)
                    )
                    desc_surf = self.desc_font.render(desc, True, (200, 190, 170))
                    self.surface.blit(
                        desc_surf, desc_surf.get_rect(centerx=rect.centerx, y=rect.y + 42)
                    )
                    t7_surf = self.desc_font.render(
                        f"Champion: {tier7}", True, (180, 170, 140)
                    )
                    self.surface.blit(
                        t7_surf, t7_surf.get_rect(centerx=rect.centerx, y=rect.y + 66)
                    )

        # --- Map size selection ---
        size_label = self.subtitle_font.render("Choose map size", True, (200, 190, 170))
        num_rows = len(rows_data)
        size_label_y = btn_y + num_rows * btn_h + (num_rows - 1) * gap + 20
        self.surface.blit(
            size_label, size_label.get_rect(centerx=sw // 2, y=size_label_y)
        )

        self._size_rects.clear()
        size_btn_w, size_btn_h = 240, 60
        total_size_w = len(MAP_SIZES) * size_btn_w + (len(MAP_SIZES) - 1) * 16
        size_start_x = (sw - total_size_w) // 2
        size_btn_y = size_label_y + 35

        for i, ms in enumerate(MAP_SIZES):
            x = size_start_x + i * (size_btn_w + 16)
            rect = pygame.Rect(x, size_btn_y, size_btn_w, size_btn_h)
            self._size_rects.append((rect, ms))

            is_selected = (
                self.selected_map_size is not None
                and self.selected_map_size.key == ms.key
            )
            hover = rect.collidepoint(mx, my)

            bg = (55, 50, 42) if (hover or is_selected) else (35, 30, 25)
            pygame.draw.rect(self.surface, bg, rect, border_radius=6)
            border_color = (
                (255, 220, 100)
                if is_selected
                else (150, 140, 100)
                if hover
                else (70, 60, 45)
            )
            border_w = 3 if is_selected else 1
            pygame.draw.rect(
                self.surface, border_color, rect, border_w, border_radius=6
            )

            label = self.size_font.render(ms.label, True, (255, 255, 255))
            self.surface.blit(label, label.get_rect(centerx=rect.centerx, y=rect.y + 8))

            desc_surf = self.hint_font.render(ms.description, True, (160, 150, 130))
            self.surface.blit(
                desc_surf, desc_surf.get_rect(centerx=rect.centerx, y=rect.y + 35)
            )

        # --- Difficulty selection ---
        diff_label = self.subtitle_font.render("Difficulty", True, (200, 190, 170))
        diff_label_y = size_btn_y + size_btn_h + 20
        self.surface.blit(
            diff_label, diff_label.get_rect(centerx=sw // 2, y=diff_label_y)
        )

        self._diff_rects.clear()
        diff_btn_w, diff_btn_h = 240, 50
        total_diff_w = len(DIFFICULTY_INFO) * diff_btn_w + (len(DIFFICULTY_INFO) - 1) * 16
        diff_start_x = (sw - total_diff_w) // 2
        diff_btn_y = diff_label_y + 30

        diff_colors = {
            Difficulty.EASY: (50, 120, 60),
            Difficulty.NORMAL: (60, 80, 120),
            Difficulty.HARD: (140, 80, 30),
            Difficulty.IMPOSSIBLE: (140, 30, 30),
        }

        for i, (diff, label, desc) in enumerate(DIFFICULTY_INFO):
            x = diff_start_x + i * (diff_btn_w + 16)
            rect = pygame.Rect(x, diff_btn_y, diff_btn_w, diff_btn_h)
            self._diff_rects.append((rect, diff))

            is_selected = self.selected_difficulty == diff
            hover = rect.collidepoint(mx, my)

            base_color = diff_colors.get(diff, (50, 50, 50))
            bg = (
                tuple(min(255, c + 20) for c in base_color)
                if (hover or is_selected)
                else base_color
            )
            pygame.draw.rect(self.surface, bg, rect, border_radius=6)
            border_color = (
                (255, 220, 100) if is_selected
                else (150, 140, 100) if hover
                else (70, 60, 45)
            )
            border_w = 3 if is_selected else 1
            pygame.draw.rect(
                self.surface, border_color, rect, border_w, border_radius=6
            )

            lbl = self.size_font.render(label, True, (255, 255, 255))
            self.surface.blit(lbl, lbl.get_rect(centerx=rect.centerx, y=rect.y + 6))

            desc_surf = self.hint_font.render(desc, True, (180, 170, 150))
            self.surface.blit(
                desc_surf, desc_surf.get_rect(centerx=rect.centerx, y=rect.y + 30)
            )

        # --- Start button (only when both selected) ---
        start_y = diff_btn_y + diff_btn_h + 25
        if self.selected_faction is not None and self.selected_map_size is not None:
            self._start_rect = pygame.Rect(sw // 2 - 100, start_y, 200, 44)
            hover = self._start_rect.collidepoint(mx, my)
            btn_color = (80, 140, 60) if hover else (60, 110, 45)
            pygame.draw.rect(self.surface, btn_color, self._start_rect, border_radius=6)
            pygame.draw.rect(
                self.surface, (160, 200, 100), self._start_rect, 2, border_radius=6
            )
            start_text = self.faction_font.render("Start Game", True, (255, 255, 255))
            self.surface.blit(
                start_text, start_text.get_rect(center=self._start_rect.center)
            )
        else:
            self._start_rect = pygame.Rect(0, 0, 0, 0)  # no clickable area

        # Hint
        hint = self.hint_font.render(
            "AI opponent will use a random different faction", True, (120, 110, 90)
        )
        self.surface.blit(hint, hint.get_rect(centerx=sw // 2, y=start_y + 55))
