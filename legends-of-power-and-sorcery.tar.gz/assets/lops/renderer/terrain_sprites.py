"""Terrain sprite loader and caching for adventure map."""

from __future__ import annotations

import math
import os

import pygame

from lops.adventure.world_map import Terrain
from lops.hex import hex_polygon_corners
from lops.renderer.adventure_renderer import ADV_HEX_SIZE

ASSETS_DIR = os.path.join(
    os.path.dirname(os.path.dirname(__file__)), "assets", "terrain"
)

# Target size for hex sprites: bounding box of a flat-top hex
HEX_WIDTH = int(ADV_HEX_SIZE * 2)  # 56
HEX_HEIGHT = int(ADV_HEX_SIZE * math.sqrt(3))  # ~48


def _load_image(filename: str) -> pygame.Surface | None:
    path = os.path.join(ASSETS_DIR, filename)
    if os.path.exists(path):
        return pygame.image.load(path).convert_alpha()
    return None


def _make_hex_mask() -> pygame.Surface:
    """Create a hex-shaped alpha mask surface for clipping base tiles."""
    mask = pygame.Surface((HEX_WIDTH, HEX_HEIGHT), pygame.SRCALPHA)
    # Get corners for a hex centered in the surface
    cx, cy = HEX_WIDTH / 2, HEX_HEIGHT / 2
    corners = hex_polygon_corners(cx, cy, ADV_HEX_SIZE)
    pygame.draw.polygon(mask, (255, 255, 255, 255), corners)
    return mask


def _clip_to_hex(source: pygame.Surface) -> pygame.Surface:
    """Scale a source image and clip it to a hex polygon shape."""
    # Scale source to cover the hex bounding box
    scaled = pygame.transform.smoothscale(source, (HEX_WIDTH, HEX_HEIGHT))
    # Apply hex mask
    mask = _make_hex_mask()
    result = pygame.Surface((HEX_WIDTH, HEX_HEIGHT), pygame.SRCALPHA)
    result.blit(scaled, (0, 0))
    # Multiply alpha with mask: keep only hex-shaped region
    result.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    return result


def _scale_overlay(source: pygame.Surface, target_height: int) -> pygame.Surface:
    """Scale an overlay sprite proportionally to fit target height."""
    w, h = source.get_size()
    scale = target_height / h
    new_w = int(w * scale)
    new_h = int(h * scale)
    return pygame.transform.smoothscale(source, (new_w, new_h))


class TerrainSprites:
    """Loads and caches terrain sprites for the adventure map."""

    def __init__(self):
        self._base_tiles: dict[Terrain, list[pygame.Surface]] = {}
        self._overlay_tiles: dict[Terrain, list[pygame.Surface]] = {}
        self._loaded = False

    def load(self):
        """Load all terrain sprites. Call after pygame.init()."""
        if self._loaded:
            return

        # --- Base tiles (clipped to hex shape) ---
        grass_variants = []
        for name in ("green.png", "green2.png", "green3.png", "green4.png"):
            img = _load_image(name)
            if img:
                grass_variants.append(_clip_to_hex(img))
        self._base_tiles[Terrain.GRASS] = grass_variants

        road_variants = []
        for name in ("road.png", "road2.png", "road3.png"):
            img = _load_image(name)
            if img:
                road_variants.append(_clip_to_hex(img))
        self._base_tiles[Terrain.ROAD] = road_variants

        water_variants = []
        img = _load_image("water.png")
        if img:
            water_variants.append(_clip_to_hex(img))
        self._base_tiles[Terrain.WATER] = water_variants

        # Dirt: tint a grass tile brownish
        if grass_variants:
            dirt = grass_variants[0].copy()
            tint = pygame.Surface(dirt.get_size(), pygame.SRCALPHA)
            tint.fill((80, 60, 20, 80))
            dirt.blit(tint, (0, 0))
            self._base_tiles[Terrain.DIRT] = [dirt]
        else:
            self._base_tiles[Terrain.DIRT] = []

        # Mountain base: use a grey-tinted grass
        if grass_variants:
            mt_base = grass_variants[0].copy()
            tint = pygame.Surface(mt_base.get_size(), pygame.SRCALPHA)
            tint.fill((60, 50, 40, 100))
            mt_base.blit(tint, (0, 0))
            self._base_tiles[Terrain.MOUNTAIN] = [mt_base]
        else:
            self._base_tiles[Terrain.MOUNTAIN] = []

        # Forest base: use grass
        self._base_tiles[Terrain.FOREST] = grass_variants[:1] if grass_variants else []

        # --- Underground terrain (procedurally generated) ---
        self._base_tiles[Terrain.CAVE_FLOOR] = self._generate_cave_floor_tiles()
        self._base_tiles[Terrain.CAVE_WALL] = self._generate_cave_wall_tiles()
        self._base_tiles[Terrain.LAVA] = self._generate_lava_tiles()
        self._base_tiles[Terrain.SUBTERRANEAN_ROAD] = self._generate_sub_road_tiles()

        # --- Overlay sprites (drawn on top of base) ---
        overlay_height = int(HEX_HEIGHT * 1.4)  # overlays are taller than hex

        forest_overlays = []
        for name in (
            "forest-deciduous.png",
            "forest-deciduous2.png",
            "forest-mixed.png",
            "forest-mixed2.png",
        ):
            img = _load_image(name)
            if img:
                forest_overlays.append(_scale_overlay(img, overlay_height))
        self._overlay_tiles[Terrain.FOREST] = forest_overlays

        mountain_overlays = []
        for name in ("mountain.png", "mountain2.png", "mountain3.png"):
            img = _load_image(name)
            if img:
                mountain_overlays.append(_scale_overlay(img, int(HEX_HEIGHT * 1.6)))
        self._overlay_tiles[Terrain.MOUNTAIN] = mountain_overlays

        self._loaded = True

    # --- Procedural underground tile generators ---

    def _generate_cave_floor_tiles(self) -> list[pygame.Surface]:
        """Generate rocky cave floor hex tiles with cracks and texture."""
        import random as _rng

        rng = _rng.Random(100)
        mask = _make_hex_mask()
        tiles = []
        for v in range(3):
            surf = pygame.Surface((HEX_WIDTH, HEX_HEIGHT), pygame.SRCALPHA)
            # Base: dark brown-grey stone
            base_r, base_g, base_b = 62 + v * 4, 52 + v * 3, 42 + v * 2
            surf.fill((base_r, base_g, base_b, 255))
            # Scattered stone texture dots
            for _ in range(40):
                x = rng.randint(2, HEX_WIDTH - 3)
                y = rng.randint(2, HEX_HEIGHT - 3)
                shade = rng.randint(-15, 15)
                c = (
                    max(0, min(255, base_r + shade)),
                    max(0, min(255, base_g + shade)),
                    max(0, min(255, base_b + shade)),
                    255,
                )
                sz = rng.randint(1, 3)
                pygame.draw.circle(surf, c, (x, y), sz)
            # A few darker cracks
            for _ in range(rng.randint(1, 3)):
                x1 = rng.randint(8, HEX_WIDTH - 8)
                y1 = rng.randint(8, HEX_HEIGHT - 8)
                x2 = x1 + rng.randint(-12, 12)
                y2 = y1 + rng.randint(-10, 10)
                crack_c = (base_r - 20, base_g - 18, base_b - 15, 180)
                pygame.draw.line(surf, crack_c, (x1, y1), (x2, y2), 1)
            # Hex clip
            surf.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
            tiles.append(surf)
        return tiles

    def _generate_cave_wall_tiles(self) -> list[pygame.Surface]:
        """Generate dark impassable cave wall hex tiles."""
        import random as _rng

        rng = _rng.Random(200)
        mask = _make_hex_mask()
        tiles = []
        for v in range(2):
            surf = pygame.Surface((HEX_WIDTH, HEX_HEIGHT), pygame.SRCALPHA)
            # Very dark base
            base = 22 + v * 5
            surf.fill((base, base - 3, base - 5, 255))
            # Rocky bumps
            for _ in range(25):
                x = rng.randint(2, HEX_WIDTH - 3)
                y = rng.randint(2, HEX_HEIGHT - 3)
                shade = rng.randint(-8, 8)
                c = (
                    max(0, base + shade + 10),
                    max(0, base + shade + 5),
                    max(0, base + shade),
                    255,
                )
                pygame.draw.circle(surf, c, (x, y), rng.randint(2, 5))
            # Dark edge shading
            edge_tint = pygame.Surface((HEX_WIDTH, HEX_HEIGHT), pygame.SRCALPHA)
            edge_tint.fill((0, 0, 0, 40))
            surf.blit(edge_tint, (0, 0))
            surf.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
            tiles.append(surf)
        return tiles

    def _generate_lava_tiles(self) -> list[pygame.Surface]:
        """Generate glowing lava hex tiles."""
        import random as _rng

        rng = _rng.Random(300)
        mask = _make_hex_mask()
        tiles = []
        for v in range(2):
            surf = pygame.Surface((HEX_WIDTH, HEX_HEIGHT), pygame.SRCALPHA)
            # Dark red-orange base
            surf.fill((140 + v * 10, 30, 10, 255))
            # Brighter molten veins
            for _ in range(6):
                x1 = rng.randint(4, HEX_WIDTH - 4)
                y1 = rng.randint(4, HEX_HEIGHT - 4)
                x2 = x1 + rng.randint(-15, 15)
                y2 = y1 + rng.randint(-12, 12)
                pygame.draw.line(
                    surf, (220, 120 + rng.randint(0, 40), 20, 200),
                    (x1, y1), (x2, y2), rng.randint(1, 3),
                )
            # Hot spots
            for _ in range(4):
                x = rng.randint(8, HEX_WIDTH - 8)
                y = rng.randint(8, HEX_HEIGHT - 8)
                pygame.draw.circle(
                    surf, (255, 180, 40, 120), (x, y), rng.randint(3, 6),
                )
            surf.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
            tiles.append(surf)
        return tiles

    def _generate_sub_road_tiles(self) -> list[pygame.Surface]:
        """Generate subterranean road hex tiles — paved stone path."""
        import random as _rng

        rng = _rng.Random(400)
        mask = _make_hex_mask()
        tiles = []
        for v in range(2):
            surf = pygame.Surface((HEX_WIDTH, HEX_HEIGHT), pygame.SRCALPHA)
            # Grey-tan stone base
            base_r, base_g, base_b = 95 + v * 5, 85 + v * 4, 70 + v * 3
            surf.fill((base_r, base_g, base_b, 255))
            # Paving stone lines
            for y in range(4, HEX_HEIGHT - 4, 8):
                offset = (v * 4 + y) % 12
                pygame.draw.line(
                    surf, (base_r - 15, base_g - 12, base_b - 10, 160),
                    (offset, y), (HEX_WIDTH - offset, y), 1,
                )
            for x in range(6, HEX_WIDTH - 6, 10):
                y_off = rng.randint(0, 4)
                pygame.draw.line(
                    surf, (base_r - 12, base_g - 10, base_b - 8, 140),
                    (x, y_off), (x + rng.randint(-3, 3), HEX_HEIGHT - y_off), 1,
                )
            # Lighter center stripe
            stripe = pygame.Surface((HEX_WIDTH, HEX_HEIGHT), pygame.SRCALPHA)
            pygame.draw.rect(
                stripe, (base_r + 15, base_g + 12, base_b + 10, 50),
                (HEX_WIDTH // 4, 0, HEX_WIDTH // 2, HEX_HEIGHT),
            )
            surf.blit(stripe, (0, 0))
            surf.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
            tiles.append(surf)
        return tiles

    def get_base_tile(
        self, terrain: Terrain, variant: int = 0
    ) -> pygame.Surface | None:
        """Get a hex-clipped base tile for a terrain type."""
        tiles = self._base_tiles.get(terrain, [])
        if not tiles:
            return None
        return tiles[variant % len(tiles)]

    def get_overlay(self, terrain: Terrain, variant: int = 0) -> pygame.Surface | None:
        """Get an overlay sprite for terrain (forest, mountain, etc.)."""
        overlays = self._overlay_tiles.get(terrain, [])
        if not overlays:
            return None
        return overlays[variant % len(overlays)]

    def has_overlay(self, terrain: Terrain) -> bool:
        return terrain in self._overlay_tiles and len(self._overlay_tiles[terrain]) > 0

    @property
    def loaded(self) -> bool:
        return self._loaded
