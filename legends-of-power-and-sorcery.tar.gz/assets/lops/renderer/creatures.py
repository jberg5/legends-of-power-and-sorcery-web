"""Draws creature stacks on the battlefield using pixel art sprites."""

from __future__ import annotations

import pygame

from lops.hex import HEX_SIZE
from lops.models import CreatureStack, Side
from lops.renderer.sprites import get_sprite, lookup_creature_type

COLOR_HP_BG = (40, 40, 40)
COLOR_HP_FILL = (50, 200, 50)
COLOR_HP_LOW = (200, 200, 0)
COLOR_HP_CRITICAL = (200, 50, 50)
COLOR_TEXT = (255, 255, 255)
COLOR_TEXT_SHADOW = (0, 0, 0)
COLOR_COUNT_BG = (20, 20, 20, 200)

SPRITE_SIZE = 48


class CreatureRenderer:
    """Renders creature stacks using pixel art sprites."""

    def __init__(
        self, surface: pygame.Surface, hex_renderer, player_side: Side = Side.ATTACKER
    ):
        self.surface = surface
        self.hex_renderer = hex_renderer
        self.player_side = player_side
        self.font = pygame.font.SysFont("Arial", 14, bold=True)
        self.small_font = pygame.font.SysFont("Arial", 11)

    def draw_stack(
        self,
        stack: CreatureStack,
        is_active: bool = False,
        offset: tuple[float, float] = (0, 0),
    ):
        """Draw a single creature stack at its position."""
        if not stack.alive or stack.position is None:
            return

        cx, cy = self.hex_renderer.hex_center(stack.position)
        cx += offset[0]
        cy += offset[1]

        half = SPRITE_SIZE // 2

        # Active indicator ring (drawn behind sprite)
        if is_active:
            pygame.draw.circle(
                self.surface, (255, 255, 100), (int(cx), int(cy)), half + 4, 2
            )

        # Player=blue, enemy=red background circle (subtle, behind sprite)
        is_player = stack.side == self.player_side
        if is_player:
            bg_color = (40, 60, 140, 100)
        else:
            bg_color = (140, 30, 30, 100)
        bg_surf = pygame.Surface((SPRITE_SIZE + 4, SPRITE_SIZE + 4), pygame.SRCALPHA)
        pygame.draw.circle(
            bg_surf,
            bg_color,
            (SPRITE_SIZE // 2 + 2, SPRITE_SIZE // 2 + 2),
            SPRITE_SIZE // 2 + 2,
        )
        self.surface.blit(bg_surf, (int(cx - half - 2), int(cy - half - 2)))

        # Draw the sprite — tint by player/enemy, not attacker/defender
        tint_str = "player" if is_player else "enemy"
        ct = lookup_creature_type(stack.stats.name)
        if ct is not None:
            sprite = get_sprite(ct, tint_str)
            self.surface.blit(sprite, (int(cx - half), int(cy - half)))
        else:
            # Fallback: colored circle with initial
            radius = int(HEX_SIZE * 0.55)
            color = (70, 130, 230) if is_player else (220, 60, 60)
            pygame.draw.circle(self.surface, color, (int(cx), int(cy)), radius)
            initial = stack.stats.name[0]
            text = self.font.render(initial, True, COLOR_TEXT)
            tr = text.get_rect(center=(int(cx), int(cy)))
            self.surface.blit(text, tr)

        # Stack count (bottom right of sprite)
        count_str = str(stack.count)
        count_text = self.small_font.render(count_str, True, COLOR_TEXT)
        cr = count_text.get_rect()
        cr.bottomright = (int(cx + half), int(cy + half + 2))

        bg_rect = cr.inflate(6, 2)
        bg_s = pygame.Surface(bg_rect.size, pygame.SRCALPHA)
        bg_s.fill(COLOR_COUNT_BG)
        self.surface.blit(bg_s, bg_rect)
        self.surface.blit(count_text, cr)

        # HP bar
        self._draw_hp_bar(stack, cx, cy, half)

    def _draw_hp_bar(self, stack: CreatureStack, cx: float, cy: float, half: int):
        """Draw HP bar below the creature sprite."""
        bar_w = SPRITE_SIZE
        bar_h = 4
        bar_x = cx - half
        bar_y = cy + half + 5

        pygame.draw.rect(
            self.surface, COLOR_HP_BG, (int(bar_x), int(bar_y), bar_w, bar_h)
        )

        hp_ratio = stack.current_hp / stack.stats.hp
        fill_w = int(bar_w * hp_ratio)

        if hp_ratio > 0.5:
            fill_color = COLOR_HP_FILL
        elif hp_ratio > 0.25:
            fill_color = COLOR_HP_LOW
        else:
            fill_color = COLOR_HP_CRITICAL

        if fill_w > 0:
            pygame.draw.rect(
                self.surface, fill_color, (int(bar_x), int(bar_y), fill_w, bar_h)
            )

    def draw_defending_icon(self, stack: CreatureStack):
        """Draw a shield icon for defending stacks."""
        if not stack.is_defending or stack.position is None:
            return
        cx, cy = self.hex_renderer.hex_center(stack.position)
        shield_text = self.small_font.render("D", True, (200, 200, 255))
        sr = shield_text.get_rect(midtop=(int(cx), int(cy) - int(HEX_SIZE * 0.7)))
        self.surface.blit(shield_text, sr)
