"""Right sidebar panel: minimap, hero/town inventory, selected hero army display."""

from __future__ import annotations

import math

import pygame

from lops.adventure.adventure_state import AdventureState
from lops.adventure.map_objects import Mine, TownSite
from lops.adventure.world_map import Terrain, WorldMap
from lops.hex import (
    CubeCoord,
    OffsetCoord,
    cube_to_offset,
    offset_to_cube,
)
from lops.renderer.sprites import get_sprite, lookup_creature_type

# Colors
COLOR_SIDEBAR_BG = (25, 20, 18)
COLOR_SIDEBAR_BORDER = (80, 65, 45)
COLOR_SECTION_BG = (35, 30, 25)
COLOR_SECTION_BORDER = (90, 75, 55)
COLOR_TEXT = (220, 215, 200)
COLOR_TEXT_DIM = (140, 135, 120)
COLOR_GOLD_TEXT = (240, 200, 50)
COLOR_PLAYER_BLUE = (50, 120, 220)
COLOR_ENEMY_RED = (200, 50, 50)
COLOR_MINIMAP_UNEXPLORED = (15, 12, 10)
COLOR_MINIMAP_FOG = (30, 25, 20)
COLOR_MINIMAP_HERO = (255, 255, 100)
COLOR_MINIMAP_ENEMY_HERO = (255, 80, 80)
COLOR_MINIMAP_TOWN = (255, 255, 255)
COLOR_MINIMAP_MINE = (180, 160, 100)
COLOR_MINIMAP_CAMERA = (255, 255, 255)
COLOR_SLOT_BG = (40, 35, 30)
COLOR_SLOT_BORDER = (70, 60, 45)
COLOR_MP_BAR_BG = (40, 35, 30)
COLOR_MP_BAR_FILL = (60, 180, 80)
COLOR_STAT_LABEL = (160, 140, 100)

# Ornate border colors
COLOR_BORDER_OUTER = (60, 50, 30)
COLOR_BORDER_INNER = (130, 110, 65)
COLOR_HEADER_BG_DARK = (45, 38, 28)
COLOR_HEADER_BG_LIGHT = (65, 55, 38)

# Minimap terrain colors (simplified)
MINIMAP_TERRAIN = {
    Terrain.GRASS: (60, 100, 40),
    Terrain.FOREST: (30, 70, 25),
    Terrain.DIRT: (120, 100, 60),
    Terrain.MOUNTAIN: (90, 80, 70),
    Terrain.WATER: (30, 60, 130),
    Terrain.ROAD: (130, 115, 80),
    Terrain.CAVE_FLOOR: (55, 45, 35),
    Terrain.CAVE_WALL: (25, 20, 15),
    Terrain.LAVA: (130, 30, 15),
    Terrain.SUBTERRANEAN_ROAD: (100, 90, 65),
}


class SidebarPanel:
    """Right sidebar with minimap, hero/town inventory, and selected hero display."""

    SIDEBAR_W = 256
    MINIMAP_H = 180
    INVENTORY_H = 200
    # Bottom section takes remaining space

    def __init__(
        self, surface: pygame.Surface, x: int, width: int, world_map: WorldMap,
        layered_map=None,
    ):
        self.surface = surface
        self.x = x
        self.w = width
        self.h = surface.get_height()
        self.world_map = world_map
        self.layered_map = layered_map
        self.minimap_layer: int = 0

        self.font = pygame.font.Font(None, 20)
        self.small_font = pygame.font.Font(None, 16)
        self.bold_font = pygame.font.Font(None, 22)
        self.stat_font = pygame.font.Font(None, 18)
        self.compass_font = pygame.font.Font(None, 14)

        # Minimap surface (pre-rendered terrain, updated when fog changes)
        self._minimap_rect = pygame.Rect(x + 4, 4, width - 8, self.MINIMAP_H - 8)
        self._minimap_surface: pygame.Surface | None = None
        self._minimap_revealed_count = -1  # track changes

        # Compute minimap scale
        self._mm_cols = world_map.cols
        self._mm_rows = world_map.rows
        # Each hex as a small rect in the minimap
        self._mm_hex_w = (self._minimap_rect.w - 4) / self._mm_cols
        self._mm_hex_h = (self._minimap_rect.h - 4) / self._mm_rows

        # Section rects
        self._inventory_rect = pygame.Rect(x, self.MINIMAP_H, width, self.INVENTORY_H)
        self._hero_panel_y = self.MINIMAP_H + self.INVENTORY_H
        self._hero_panel_rect = pygame.Rect(
            x, self._hero_panel_y, width, self.h - self._hero_panel_y
        )

        # Click targets (updated each frame)
        self._hero_buttons: list[tuple[pygame.Rect, int]] = []  # (rect, hero_index)
        self._town_buttons: list[tuple[pygame.Rect, object]] = []  # (rect, town_site)

        # Inventory scroll state
        self._inv_scroll_px = 0.0
        self._inv_scroll_max = 0.0
        self._inv_content_h = 0  # total content height (computed each frame)

        # Hero panel scroll state
        self._hero_scroll_px = 0.0
        self._hero_scroll_max = 0.0

    def handle_scroll(self, direction: int):
        """Handle mouse wheel scroll over sidebar sections."""
        mx, my = pygame.mouse.get_pos()
        if my >= self._hero_panel_y:
            # Scroll hero panel
            self._hero_scroll_px -= direction * 30
            self._hero_scroll_px = max(
                0.0, min(self._hero_scroll_px, self._hero_scroll_max)
            )
        else:
            # Scroll inventory
            self._inv_scroll_px -= direction * 30
            self._inv_scroll_px = max(
                0.0, min(self._inv_scroll_px, self._inv_scroll_max)
            )

    def handle_click(
        self, pos: tuple[int, int], adventure_state: AdventureState
    ) -> str | None:
        """Handle a click in the sidebar. Returns action or None.

        Actions: 'minimap_click', 'hero_select:N', 'town_click:N'
        """
        mx, my = pos

        # Layer toggle button click
        if (
            hasattr(self, "_layer_toggle_rect")
            and self._layer_toggle_rect.collidepoint(mx, my)
        ):
            self.minimap_layer = 1 - self.minimap_layer
            return "layer_toggle"

        # Minimap click -> return world position to center on
        if self._minimap_rect.collidepoint(mx, my):
            return "minimap_click"

        # Hero buttons
        for rect, hero_index in self._hero_buttons:
            if rect.collidepoint(mx, my):
                return f"hero_select:{hero_index}"

        # Town buttons
        for rect, town_site in self._town_buttons:
            if rect.collidepoint(mx, my):
                return f"town_click:{id(town_site)}"

        return None

    def minimap_to_world_hex(self, pos: tuple[int, int]) -> CubeCoord | None:
        """Convert a screen click position on the minimap to a world hex."""
        mx, my = pos
        if not self._minimap_rect.collidepoint(mx, my):
            return None
        local_x = mx - self._minimap_rect.x - 2
        local_y = my - self._minimap_rect.y - 2
        col = int(local_x / self._mm_hex_w)
        row = int(local_y / self._mm_hex_h)
        col = max(0, min(col, self._mm_cols - 1))
        row = max(0, min(row, self._mm_rows - 1))
        return offset_to_cube(OffsetCoord(col, row))

    def _draw_ornate_border(self, rect: pygame.Rect):
        """Draw a double-line ornate border with corner accents."""
        # Outer border
        pygame.draw.rect(self.surface, COLOR_BORDER_OUTER, rect, 2)
        # Inner border (inset by 2px)
        inner = rect.inflate(-4, -4)
        pygame.draw.rect(self.surface, COLOR_BORDER_INNER, inner, 1)
        # Corner accent lines (4px diagonal strokes)
        corners = [
            (rect.topleft, (1, 1)),
            (rect.topright, (-1, 1)),
            (rect.bottomleft, (1, -1)),
            (rect.bottomright, (-1, -1)),
        ]
        for (cx, cy), (dx, dy) in corners:
            pygame.draw.line(
                self.surface,
                COLOR_BORDER_INNER,
                (cx, cy),
                (cx + dx * 6, cy + dy * 6),
                1,
            )

    def _draw_section_header(self, rect: pygame.Rect, label: str):
        """Draw a gradient-shaded section header bar."""
        header_h = 18
        header_rect = pygame.Rect(rect.x + 3, rect.y + 3, rect.w - 6, header_h)
        # Gradient-like shading (2 bands)
        top_half = pygame.Rect(
            header_rect.x, header_rect.y, header_rect.w, header_h // 2
        )
        bot_half = pygame.Rect(
            header_rect.x,
            header_rect.y + header_h // 2,
            header_rect.w,
            header_h - header_h // 2,
        )
        pygame.draw.rect(self.surface, COLOR_HEADER_BG_LIGHT, top_half)
        pygame.draw.rect(self.surface, COLOR_HEADER_BG_DARK, bot_half)
        # Label centered
        lbl = self.small_font.render(label, True, COLOR_GOLD_TEXT)
        lbl_rect = lbl.get_rect(center=header_rect.center)
        self.surface.blit(lbl, lbl_rect)
        return header_rect.bottom + 2

    def draw(
        self,
        adventure_state: AdventureState,
        revealed: set[CubeCoord] | None = None,
        visible: set[CubeCoord] | None = None,
        camera=None,
        minimap_revealed: set[CubeCoord] | None = None,
    ):
        """Draw the full sidebar.

        minimap_revealed: revealed hexes for the minimap layer (may differ
        from revealed if minimap shows a different layer than the hero's).
        """
        # Background
        pygame.draw.rect(self.surface, COLOR_SIDEBAR_BG, (self.x, 0, self.w, self.h))
        # Left border line
        pygame.draw.line(
            self.surface, COLOR_SIDEBAR_BORDER, (self.x, 0), (self.x, self.h), 2
        )

        mm_revealed = minimap_revealed if minimap_revealed is not None else revealed
        self._draw_minimap(adventure_state, mm_revealed, visible, camera)
        self._draw_inventory(adventure_state)
        self._draw_hero_panel(adventure_state)

    def _draw_minimap(
        self,
        state: AdventureState,
        revealed: set[CubeCoord] | None,
        visible: set[CubeCoord] | None,
        camera,
    ):
        """Draw the minimap section."""
        rect = self._minimap_rect

        # Section background
        pygame.draw.rect(self.surface, COLOR_SECTION_BG, rect)
        # Ornate border
        self._draw_ornate_border(rect)

        # Draw terrain pixels
        hw = self._mm_hex_w
        hh = self._mm_hex_h

        for col in range(self._mm_cols):
            for row in range(self._mm_rows):
                pos = offset_to_cube(OffsetCoord(col, row))
                px = rect.x + 2 + col * hw
                py = rect.y + 2 + row * hh

                # Fog of war
                if revealed is not None and pos not in revealed:
                    color = COLOR_MINIMAP_UNEXPLORED
                else:
                    mm_map = self.world_map
                    if self.layered_map is not None:
                        mm_map = self.layered_map.get_map(self.minimap_layer)
                    tile = mm_map.get_tile(pos)
                    if tile:
                        color = MINIMAP_TERRAIN.get(tile.terrain, (50, 50, 50))
                    else:
                        color = (20, 20, 20)

                pygame.draw.rect(
                    self.surface,
                    color,
                    (int(px), int(py), max(2, int(hw)), max(2, int(hh))),
                )

        # Draw map objects on minimap (only if revealed)
        for obj in state.map_objects:
            if not obj.alive:
                continue
            obj_layer = getattr(obj, "layer", 0)
            if obj_layer != self.minimap_layer:
                continue
            oc = cube_to_offset(obj.position)
            if revealed is not None and obj.position not in revealed:
                continue
            ox = rect.x + 2 + oc.col * hw + hw / 2
            oy = rect.y + 2 + oc.row * hh + hh / 2

            if isinstance(obj, TownSite):
                if obj.owner == 0:
                    color = COLOR_PLAYER_BLUE
                elif obj.owner is not None:
                    color = COLOR_ENEMY_RED
                else:
                    color = (150, 150, 150)  # neutral/unclaimed
                sz = max(3, int(hw * 0.8))
                pygame.draw.rect(
                    self.surface, color, (int(ox - sz / 2), int(oy - sz / 2), sz, sz)
                )
            elif isinstance(obj, Mine):
                if obj.owner is None:
                    mine_color = (130, 130, 130)  # gray for unclaimed
                elif obj.owner == 0:
                    mine_color = COLOR_PLAYER_BLUE
                else:
                    mine_color = COLOR_ENEMY_RED
                pygame.draw.circle(
                    self.surface, mine_color, (int(ox), int(oy)), max(1, int(hw * 0.4))
                )

        # Draw hero positions (one dot per alive hero)
        for player in state.players:
            if player.defeated:
                continue
            for hs in player.alive_heroes():
                if hs.layer != self.minimap_layer:
                    continue
                hero_pos: CubeCoord | None = hs.position
                if hero_pos is None:
                    continue
                if revealed is not None and player.is_ai and hero_pos not in revealed:
                    continue
                oc = cube_to_offset(hero_pos)
                hx = rect.x + 2 + oc.col * hw + hw / 2
                hy = rect.y + 2 + oc.row * hh + hh / 2
                color = (
                    COLOR_MINIMAP_HERO if not player.is_ai else COLOR_MINIMAP_ENEMY_HERO
                )
                pygame.draw.circle(
                    self.surface, color, (int(hx), int(hy)), max(2, int(hw * 0.6))
                )

        # Draw camera viewport rectangle
        if camera is not None:
            # Convert camera world bounds to minimap coords
            cam_col_start = camera.x / (28 * 1.5)  # ADV_HEX_SIZE * 1.5
            cam_row_start = camera.y / (28 * math.sqrt(3))
            cam_col_end = (camera.x + camera.viewport_w) / (28 * 1.5)
            cam_row_end = (camera.y + camera.screen_h - camera.hud_height) / (
                28 * math.sqrt(3)
            )

            cx1 = rect.x + 2 + cam_col_start * hw
            cy1 = rect.y + 2 + cam_row_start * hh
            cx2 = rect.x + 2 + cam_col_end * hw
            cy2 = rect.y + 2 + cam_row_end * hh

            cam_rect = pygame.Rect(int(cx1), int(cy1), int(cx2 - cx1), int(cy2 - cy1))
            cam_rect.clamp_ip(rect)
            pygame.draw.rect(self.surface, COLOR_MINIMAP_CAMERA, cam_rect, 1)

        # Compass rose labels
        self._draw_compass_rose(rect)

        # Layer toggle button (only if underground exists)
        if self.layered_map is not None:
            btn_w, btn_h = 50, 16
            btn_x = rect.right - btn_w - 4
            btn_y = rect.bottom - btn_h - 4
            self._layer_toggle_rect = pygame.Rect(btn_x, btn_y, btn_w, btn_h)
            btn_color = (60, 40, 80) if self.minimap_layer == 1 else (50, 60, 80)
            pygame.draw.rect(self.surface, btn_color, self._layer_toggle_rect, border_radius=3)
            pygame.draw.rect(self.surface, (120, 100, 80), self._layer_toggle_rect, 1, border_radius=3)
            label = "UG" if self.minimap_layer == 0 else "Srf"
            text = self.small_font.render(label, True, (200, 200, 200))
            self.surface.blit(text, (btn_x + (btn_w - text.get_width()) // 2,
                                     btn_y + (btn_h - text.get_height()) // 2))

    def _draw_compass_rose(self, rect: pygame.Rect):
        """Draw N/S/E/W labels at the edges of the minimap."""
        labels = [
            ("N", rect.centerx, rect.y + 6),
            ("S", rect.centerx, rect.bottom - 10),
            ("W", rect.x + 8, rect.centery),
            ("E", rect.right - 12, rect.centery),
        ]
        for letter, lx, ly in labels:
            txt = self.compass_font.render(letter, True, (200, 190, 160))
            txt_rect = txt.get_rect(center=(lx, ly))
            # Semi-transparent background
            bg = pygame.Surface((txt_rect.w + 4, txt_rect.h + 2), pygame.SRCALPHA)
            bg.fill((0, 0, 0, 120))
            self.surface.blit(bg, (txt_rect.x - 2, txt_rect.y - 1))
            self.surface.blit(txt, txt_rect)

    def _draw_inventory(self, state: AdventureState):
        """Draw scrollable hero/town inventory section."""
        rect = self._inventory_rect
        pygame.draw.rect(self.surface, COLOR_SECTION_BG, rect)
        self._draw_ornate_border(rect)

        self._hero_buttons.clear()
        self._town_buttons.clear()

        pad = 6
        scrollbar_w = 8
        content_w = rect.w - pad * 2 - scrollbar_w - 2

        # Measure total content height (without drawing)
        content_h = 20  # Heroes header
        human_player = None
        for player in state.players:
            if not player.is_ai and not player.defeated:
                human_player = player
                break
        num_heroes = len(human_player.all_alive_heroes()) if human_player else 0
        content_h += num_heroes * 50
        content_h += 8 + 20  # gap + Towns header
        num_towns = sum(
            1
            for obj in state.map_objects
            if isinstance(obj, TownSite) and obj.alive and obj.owner == 0
        )
        content_h += num_towns * 42

        visible_h = rect.h - 4  # small inset
        self._inv_scroll_max = max(0.0, content_h - visible_h)
        self._inv_scroll_px = max(0.0, min(self._inv_scroll_px, self._inv_scroll_max))
        scroll = self._inv_scroll_px
        self._inv_content_h = content_h

        # Clip to inventory rect
        clip_rect = pygame.Rect(rect.x + 2, rect.y + 2, rect.w - 4, visible_h)
        prev_clip = self.surface.get_clip()
        self.surface.set_clip(clip_rect)

        # Draw content with scroll offset
        y = rect.y + 2 - int(scroll)

        # Heroes header
        header_rect = pygame.Rect(rect.x, y, rect.w, 20)
        y = self._draw_section_header(header_rect, "Heroes")

        # Hero buttons
        if human_player is not None:
            from lops.adventure.adventure_state import DEFAULT_MOVEMENT_POINTS

            alive_heroes = human_player.all_alive_heroes()
            for hero_idx, hs in enumerate(alive_heroes):
                btn_rect = pygame.Rect(rect.x + pad, y, content_w, 44)
                # Only register click targets if visible
                if btn_rect.bottom > rect.y and btn_rect.top < rect.y + rect.h:
                    self._hero_buttons.append((btn_rect, hero_idx))

                is_selected = hero_idx == human_player.selected_hero_idx
                pygame.draw.rect(self.surface, COLOR_SLOT_BG, btn_rect)
                border_color = COLOR_GOLD_TEXT if is_selected else COLOR_PLAYER_BLUE
                pygame.draw.rect(self.surface, border_color, btn_rect, 2)

                # Portrait
                portrait_rect = pygame.Rect(btn_rect.x + 4, btn_rect.y + 4, 36, 36)
                top_c = (20, 30, 50)
                bot_c = (40, 90, 180)
                for row_i in range(portrait_rect.h):
                    t = row_i / max(portrait_rect.h - 1, 1)
                    rc = int(top_c[0] + (bot_c[0] - top_c[0]) * t)
                    gc = int(top_c[1] + (bot_c[1] - top_c[1]) * t)
                    bc = int(top_c[2] + (bot_c[2] - top_c[2]) * t)
                    pygame.draw.line(
                        self.surface,
                        (rc, gc, bc),
                        (portrait_rect.x, portrait_rect.y + row_i),
                        (portrait_rect.right - 1, portrait_rect.y + row_i),
                    )
                portrait_border = COLOR_GOLD_TEXT if is_selected else (180, 180, 190)
                pygame.draw.rect(self.surface, portrait_border, portrait_rect, 2)
                initial = self.bold_font.render(hs.hero.name[0], True, (255, 255, 255))
                ir = initial.get_rect(center=portrait_rect.center)
                self.surface.blit(initial, ir)

                # Name + MP
                name_text = self.font.render(hs.hero.name, True, COLOR_TEXT)
                self.surface.blit(name_text, (btn_rect.x + 46, btn_rect.y + 4))
                mp_text = self.small_font.render(
                    f"MP: {hs.movement_points}", True, COLOR_TEXT_DIM
                )
                self.surface.blit(mp_text, (btn_rect.x + 46, btn_rect.y + 22))

                # MP bar
                bar_x = btn_rect.x + 46 + mp_text.get_width() + 6
                bar_w = btn_rect.right - bar_x - pad
                if bar_w > 10:
                    bar_rect_mp = pygame.Rect(bar_x, btn_rect.y + 25, bar_w, 8)
                    pygame.draw.rect(self.surface, COLOR_MP_BAR_BG, bar_rect_mp)
                    fill_pct = min(1.0, hs.movement_points / DEFAULT_MOVEMENT_POINTS)
                    fill_rect = pygame.Rect(
                        bar_x, btn_rect.y + 25, int(bar_w * fill_pct), 8
                    )
                    pygame.draw.rect(self.surface, COLOR_MP_BAR_FILL, fill_rect)
                    pygame.draw.rect(self.surface, COLOR_SLOT_BORDER, bar_rect_mp, 1)

                y += 50

        y += 8
        # Towns header
        town_header_rect = pygame.Rect(rect.x, y - 2, rect.w, 20)
        y = self._draw_section_header(town_header_rect, "Towns")

        # Town buttons
        for obj in state.map_objects:
            if not isinstance(obj, TownSite):
                continue
            if not obj.alive or obj.owner != 0:
                continue
            btn_rect = pygame.Rect(rect.x + pad, y, content_w, 36)
            if btn_rect.bottom > rect.y and btn_rect.top < rect.y + rect.h:
                self._town_buttons.append((btn_rect, obj))

            pygame.draw.rect(self.surface, COLOR_SLOT_BG, btn_rect)
            pygame.draw.rect(self.surface, COLOR_PLAYER_BLUE, btn_rect, 1)

            # Town icon
            cx = btn_rect.x + 18
            cy = btn_rect.y + 18
            pygame.draw.rect(self.surface, (160, 140, 100), (cx - 8, cy - 6, 16, 12))
            pygame.draw.rect(self.surface, (130, 110, 80), (cx - 10, cy - 10, 6, 8))
            pygame.draw.rect(self.surface, (130, 110, 80), (cx + 4, cy - 10, 6, 8))

            name_text = self.font.render(obj.name, True, COLOR_TEXT)
            self.surface.blit(name_text, (btn_rect.x + 36, btn_rect.y + 9))

            y += 42

        # Restore clip
        self.surface.set_clip(prev_clip)

        # Scrollbar (only if content overflows)
        if self._inv_scroll_max > 0:
            sb_x = rect.right - scrollbar_w - 2
            sb_y = rect.y + 2
            sb_h = visible_h

            # Track
            pygame.draw.rect(
                self.surface, (30, 28, 24), (sb_x, sb_y, scrollbar_w, sb_h)
            )
            # Thumb
            thumb_h = max(16, int(sb_h * (visible_h / content_h)))
            scroll_range = sb_h - thumb_h
            if self._inv_scroll_max > 0:
                thumb_y = sb_y + int(
                    scroll_range * self._inv_scroll_px / self._inv_scroll_max
                )
            else:
                thumb_y = sb_y
            thumb_rect = pygame.Rect(sb_x, thumb_y, scrollbar_w, thumb_h)
            mx, my = pygame.mouse.get_pos()
            thumb_color = (
                (100, 95, 80) if thumb_rect.collidepoint(mx, my) else (70, 65, 50)
            )
            pygame.draw.rect(self.surface, thumb_color, thumb_rect, border_radius=3)

    def _draw_hero_panel(self, state: AdventureState):
        """Draw selected hero stats and army with scrolling support."""
        rect = self._hero_panel_rect
        pygame.draw.rect(self.surface, COLOR_SECTION_BG, rect)
        self._draw_ornate_border(rect)

        # Get current human player
        player = None
        for p in state.players:
            if not p.is_ai and not p.defeated:
                player = p
                break
        if player is None:
            return

        pad = 6

        # Render hero panel content to a temporary surface for clipping
        content_h = self._hero_panel_content_height(player)
        panel_h = rect.h - 4  # inner area
        self._hero_scroll_max = max(0.0, content_h - panel_h)
        self._hero_scroll_px = max(
            0.0, min(self._hero_scroll_px, self._hero_scroll_max)
        )

        # Clip to panel area
        clip_rect = pygame.Rect(rect.x + 2, rect.y + 2, rect.w - 4, panel_h)
        old_clip = self.surface.get_clip()
        self.surface.set_clip(clip_rect)

        y = rect.y + 6 - int(self._hero_scroll_px)

        # Hero name + level
        hero = player.hero
        name_lv = f"{hero.name}  Lv {hero.level}"
        name = self.bold_font.render(name_lv, True, COLOR_GOLD_TEXT)
        self.surface.blit(name, (rect.x + pad, y))
        y += 24

        # XP progress bar
        from lops.experience import xp_for_level

        current_xp = hero.experience
        current_threshold = xp_for_level(hero.level)
        next_threshold = xp_for_level(hero.level + 1)
        xp_range = next_threshold - current_threshold
        xp_progress = current_xp - current_threshold
        xp_pct = min(1.0, xp_progress / xp_range) if xp_range > 0 else 0.0

        xp_bar_rect = pygame.Rect(rect.x + pad, y, rect.w - pad * 2, 6)
        pygame.draw.rect(self.surface, COLOR_MP_BAR_BG, xp_bar_rect)
        fill_w = int(xp_bar_rect.w * xp_pct)
        if fill_w > 0:
            pygame.draw.rect(
                self.surface, (180, 140, 255), (xp_bar_rect.x, xp_bar_rect.y, fill_w, 6)
            )
        pygame.draw.rect(self.surface, COLOR_SLOT_BORDER, xp_bar_rect, 1)

        xp_label = self.small_font.render(
            f"XP: {current_xp}/{next_threshold}", True, COLOR_TEXT_DIM
        )
        self.surface.blit(xp_label, (rect.x + pad, y + 7))
        y += 22

        # Stats in 2x2 grid (show effective = base + artifact bonus)
        stats = [
            ("ATK", hero.attack, hero.effective_attack()),
            ("DEF", hero.defense, hero.effective_defense()),
            ("SPL", hero.spell_power, hero.effective_spell_power()),
            ("KNW", hero.knowledge, hero.effective_knowledge()),
        ]
        col_w = (rect.w - pad * 2) // 2
        for i, (label, base, effective) in enumerate(stats):
            sx = rect.x + pad + (i % 2) * col_w
            sy = y + (i // 2) * 18
            lbl = self.stat_font.render(f"{label}:", True, COLOR_STAT_LABEL)
            self.surface.blit(lbl, (sx, sy))
            bonus = effective - base
            if bonus != 0:
                val_str = f"{base}+{bonus}" if bonus > 0 else f"{base}{bonus}"
                color = (100, 220, 100) if bonus > 0 else (220, 100, 100)
                val_s = self.stat_font.render(val_str, True, color)
            else:
                val_s = self.stat_font.render(str(base), True, COLOR_TEXT)
            self.surface.blit(val_s, (sx + lbl.get_width() + 3, sy))

        y += 40

        # Skills (compact list)
        if player.hero.skills:
            from lops.skills import SkillLevel

            _SKILL_COLORS = {
                SkillLevel.BASIC: (160, 160, 160),
                SkillLevel.ADVANCED: (100, 170, 255),
                SkillLevel.EXPERT: (255, 215, 0),
            }
            for skill in player.hero.skills:
                lvl_abbr = skill.level.name[:3]
                color = _SKILL_COLORS.get(skill.level, COLOR_TEXT_DIM)
                text = self.small_font.render(
                    f"{skill.definition.name} ({lvl_abbr})", True, color
                )
                self.surface.blit(text, (rect.x + pad, y))
                y += 15
            y += 2

        # Separator
        pygame.draw.line(
            self.surface, COLOR_SECTION_BORDER, (rect.x + pad, y), (rect.right - pad, y)
        )
        y += 4

        # Army section header
        army_header_rect = pygame.Rect(rect.x, y, rect.w, 20)
        y = self._draw_section_header(army_header_rect, "Army")

        # Army slots (7 max, display in column)
        slot_h = 36
        for i in range(7):
            slot_rect = pygame.Rect(rect.x + pad, y, rect.w - pad * 2, slot_h)
            pygame.draw.rect(self.surface, COLOR_SLOT_BG, slot_rect)
            pygame.draw.rect(self.surface, COLOR_SLOT_BORDER, slot_rect, 1)

            if i < len(player.army) and player.army[i].alive:
                stack = player.army[i]

                # Creature sprite (28x28 on the left)
                sprite_size = 28
                sprite_x = slot_rect.x + 2
                sprite_y = slot_rect.y + 2
                ct = lookup_creature_type(stack.stats.name)
                if ct is not None:
                    sprite = get_sprite(ct, "neutral")
                    scaled_sprite = pygame.transform.smoothscale(
                        sprite, (sprite_size, sprite_size)
                    )
                    self.surface.blit(scaled_sprite, (sprite_x, sprite_y))
                else:
                    # Fallback: gray square
                    pygame.draw.rect(
                        self.surface,
                        (80, 70, 60),
                        (sprite_x, sprite_y, sprite_size, sprite_size),
                    )

                # Creature name (to the right of sprite)
                text_x = sprite_x + sprite_size + 4
                name_s = self.small_font.render(stack.stats.name, True, COLOR_TEXT)
                self.surface.blit(name_s, (text_x, slot_rect.y + 3))

                # Count (right-aligned, gold)
                count_s = self.small_font.render(
                    str(stack.count), True, COLOR_GOLD_TEXT
                )
                self.surface.blit(
                    count_s,
                    (slot_rect.right - count_s.get_width() - 4, slot_rect.y + 3),
                )

                # HP bar below name
                bar_y = slot_rect.y + 18
                bar_x = text_x
                bar_w = slot_rect.right - bar_x - 4
                pygame.draw.rect(
                    self.surface, COLOR_MP_BAR_BG, (bar_x, bar_y, bar_w, 4)
                )
                hp_pct = (
                    stack.current_hp / stack.stats.hp if stack.stats.hp > 0 else 1.0
                )
                fill_w = int(bar_w * hp_pct)
                bar_color = (
                    (60, 180, 80)
                    if hp_pct > 0.5
                    else (200, 160, 40)
                    if hp_pct > 0.25
                    else (200, 50, 50)
                )
                pygame.draw.rect(self.surface, bar_color, (bar_x, bar_y, fill_w, 4))

                # Stack size badge (bottom-right of sprite)
                badge_s = self.small_font.render(
                    str(stack.count), True, COLOR_GOLD_TEXT
                )
                badge_x = sprite_x + sprite_size - badge_s.get_width() - 1
                badge_y = sprite_y + sprite_size - badge_s.get_height()
                badge_bg = pygame.Surface(
                    (badge_s.get_width() + 2, badge_s.get_height()), pygame.SRCALPHA
                )
                badge_bg.fill((0, 0, 0, 160))
                self.surface.blit(badge_bg, (badge_x - 1, badge_y))
                self.surface.blit(badge_s, (badge_x, badge_y))

            y += slot_h + 2

        y += 6
        # Movement points bar at bottom
        mp_label = self.small_font.render("Movement", True, COLOR_TEXT_DIM)
        self.surface.blit(mp_label, (rect.x + pad, y))
        y += 14
        bar_rect = pygame.Rect(rect.x + pad, y, rect.w - pad * 2, 10)
        pygame.draw.rect(self.surface, COLOR_MP_BAR_BG, bar_rect)
        from lops.adventure.adventure_state import DEFAULT_MOVEMENT_POINTS

        fill_pct = min(1.0, player.movement_points / DEFAULT_MOVEMENT_POINTS)
        fill_rect = pygame.Rect(bar_rect.x, bar_rect.y, int(bar_rect.w * fill_pct), 10)
        pygame.draw.rect(self.surface, COLOR_MP_BAR_FILL, fill_rect)
        pygame.draw.rect(self.surface, COLOR_SLOT_BORDER, bar_rect, 1)
        mp_val = self.small_font.render(
            f"{player.movement_points} / {DEFAULT_MOVEMENT_POINTS}", True, COLOR_TEXT
        )
        self.surface.blit(mp_val, (bar_rect.x, y + 12))

        # Restore clip
        self.surface.set_clip(old_clip)

        # Scroll indicator (thin bar on right edge if scrollable)
        if self._hero_scroll_max > 0:
            sb_x = rect.right - 6
            sb_y = rect.y + 4
            sb_h = panel_h - 4
            pygame.draw.rect(self.surface, (40, 35, 30), (sb_x, sb_y, 4, sb_h))
            thumb_h = max(16, int(sb_h * panel_h / content_h))
            scroll_range = sb_h - thumb_h
            if self._hero_scroll_max > 0:
                thumb_y = sb_y + int(
                    scroll_range * self._hero_scroll_px / self._hero_scroll_max
                )
            else:
                thumb_y = sb_y
            pygame.draw.rect(
                self.surface, (80, 75, 60), (sb_x, thumb_y, 4, thumb_h), border_radius=2
            )

    def _hero_panel_content_height(self, player) -> int:
        """Compute the total content height of the hero panel."""
        h = 6  # top padding
        h += 24  # hero name + level
        h += 22  # XP bar
        h += 40  # stats
        if player.hero.skills:
            h += len(player.hero.skills) * 15 + 2
        h += 4 + 20  # separator + army header
        h += 7 * (36 + 2)  # army slots
        h += 6 + 14 + 10 + 14  # movement bar area
        return h
