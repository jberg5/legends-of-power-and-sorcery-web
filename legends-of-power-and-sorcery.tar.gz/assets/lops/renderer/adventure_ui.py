"""Adventure mode HUD: day, resources, MP, end-turn button, status messages."""

from __future__ import annotations

import pygame

from lops.adventure.adventure_state import AdventureState

COLOR_HUD_BG = (30, 30, 40)
COLOR_HUD_TEXT = (220, 220, 220)
COLOR_BUTTON = (60, 80, 120)
COLOR_BUTTON_HOVER = (80, 100, 150)
COLOR_BUTTON_TEXT = (255, 255, 255)
COLOR_VICTORY_BG = (0, 0, 0, 180)

# Bottom bar colors
COLOR_BOTTOM_BAR_BG = (25, 22, 18)
COLOR_BOTTOM_BAR_BORDER = (80, 65, 45)

# Resource display colors
RES_COLORS = {
    "gold": (240, 200, 50),
    "wood": (160, 110, 50),
    "ore": (160, 160, 170),
    "mercury": (200, 80, 200),
    "sulfur": (220, 200, 60),
    "crystal": (80, 170, 230),
    "gems": (60, 210, 110),
}


def _build_resource_icons(size: int = 16) -> dict[str, pygame.Surface]:
    """Procedurally draw recognizable mini-icons for each resource type."""
    icons: dict[str, pygame.Surface] = {}
    s = size

    def _surf() -> pygame.Surface:
        return pygame.Surface((s, s), pygame.SRCALPHA)

    # --- Gold: stack of coins ---
    surf = _surf()
    coin_color = (230, 195, 50)
    coin_hi = (255, 230, 100)
    coin_shadow = (170, 140, 20)
    for dy in (8, 5, 2):
        # Coin ellipse (approx with rects + rounded)
        pygame.draw.ellipse(surf, coin_shadow, (2, dy + 1, 12, 6))
        pygame.draw.ellipse(surf, coin_color, (2, dy, 12, 6))
        pygame.draw.ellipse(surf, coin_hi, (4, dy, 6, 3))
    icons["gold"] = surf

    # --- Wood: two stacked logs ---
    surf = _surf()
    bark = (130, 85, 35)
    bark_hi = (170, 120, 55)
    cut_face = (210, 180, 120)
    ring = (180, 150, 90)
    # Bottom log
    pygame.draw.rect(surf, bark, (1, 8, 12, 6), border_radius=2)
    pygame.draw.rect(surf, bark_hi, (1, 8, 12, 3), border_radius=1)
    pygame.draw.ellipse(surf, cut_face, (10, 7, 6, 8))
    pygame.draw.ellipse(surf, ring, (11, 9, 4, 4), 1)
    # Top log
    pygame.draw.rect(surf, bark, (3, 2, 11, 6), border_radius=2)
    pygame.draw.rect(surf, bark_hi, (3, 2, 11, 3), border_radius=1)
    pygame.draw.ellipse(surf, cut_face, (11, 1, 5, 8))
    pygame.draw.ellipse(surf, ring, (12, 3, 3, 4), 1)
    icons["wood"] = surf

    # --- Ore: grey rock chunks ---
    surf = _surf()
    rock = (140, 140, 150)
    rock_hi = (180, 180, 195)
    rock_dk = (90, 90, 100)
    # Large rock
    pts = [(3, 14), (1, 8), (5, 5), (11, 4), (14, 7), (13, 14)]
    pygame.draw.polygon(surf, rock, pts)
    pygame.draw.polygon(surf, rock_dk, pts, 1)
    # Highlight facet
    pygame.draw.polygon(surf, rock_hi, [(5, 5), (11, 4), (10, 8), (4, 9)])
    # Small rock
    pts2 = [(9, 14), (10, 10), (15, 9), (15, 14)]
    pygame.draw.polygon(surf, rock, pts2)
    pygame.draw.polygon(surf, rock_hi, [(10, 10), (15, 9), (14, 12)])
    icons["ore"] = surf

    # --- Mercury: flask/pot ---
    surf = _surf()
    flask_body = (180, 60, 180)
    flask_hi = (220, 120, 220)
    flask_dk = (120, 30, 120)
    glass = (200, 180, 210)
    # Neck
    pygame.draw.rect(surf, glass, (6, 1, 4, 4))
    pygame.draw.rect(surf, (230, 220, 240), (7, 1, 2, 2))
    # Body (pot shape)
    pygame.draw.ellipse(surf, flask_dk, (2, 6, 12, 10))
    pygame.draw.ellipse(surf, flask_body, (2, 5, 12, 10))
    pygame.draw.ellipse(surf, flask_hi, (4, 6, 5, 4))
    # Neck connects to body
    pygame.draw.rect(surf, glass, (5, 4, 6, 3))
    icons["mercury"] = surf

    # --- Sulfur: yellow pile with glow ---
    surf = _surf()
    pile_base = (190, 180, 40)
    pile_hi = (240, 230, 80)
    pile_dk = (140, 130, 20)
    # Mound shape
    pts = [(1, 15), (3, 9), (6, 5), (10, 4), (13, 6), (15, 10), (15, 15)]
    pygame.draw.polygon(surf, pile_base, pts)
    pygame.draw.polygon(surf, pile_dk, pts, 1)
    # Highlight
    pygame.draw.polygon(surf, pile_hi, [(5, 9), (7, 5), (11, 5), (12, 8)])
    # Granular texture dots
    for dx, dy in ((4, 12), (8, 10), (11, 12), (6, 8), (10, 7)):
        surf.set_at((dx, dy), pile_hi)
    icons["sulfur"] = surf

    # --- Crystal: blue faceted crystal ---
    surf = _surf()
    crys = (60, 140, 220)
    crys_hi = (130, 200, 255)
    crys_dk = (30, 80, 150)
    # Main crystal body
    pts = [(5, 15), (2, 8), (5, 1), (8, 0), (11, 1), (14, 8), (11, 15)]
    pygame.draw.polygon(surf, crys, pts)
    # Dark facet (right)
    pygame.draw.polygon(surf, crys_dk, [(8, 0), (11, 1), (14, 8), (8, 10)])
    # Highlight facet (left)
    pygame.draw.polygon(surf, crys_hi, [(5, 1), (8, 0), (8, 6), (3, 6)])
    # Edge lines
    pygame.draw.polygon(surf, (40, 100, 180), pts, 1)
    # Gleam
    surf.set_at((5, 3), (200, 240, 255))
    surf.set_at((6, 2), (200, 240, 255))
    icons["crystal"] = surf

    # --- Gems: green cut gemstone ---
    surf = _surf()
    gem = (40, 190, 90)
    gem_hi = (100, 240, 150)
    gem_dk = (20, 120, 50)
    # Octagonal gem shape
    pts = [(4, 14), (1, 9), (1, 6), (4, 2), (11, 2), (14, 6), (14, 9), (11, 14)]
    pygame.draw.polygon(surf, gem, pts)
    # Top facet (lighter)
    pygame.draw.polygon(surf, gem_hi, [(4, 2), (11, 2), (10, 6), (5, 6)])
    # Bottom facet (darker)
    pygame.draw.polygon(surf, gem_dk, [(5, 10), (10, 10), (11, 14), (4, 14)])
    # Outline
    pygame.draw.polygon(surf, (15, 90, 40), pts, 1)
    # Center line
    pygame.draw.line(surf, (30, 150, 70), (5, 6), (10, 6), 1)
    pygame.draw.line(surf, (30, 150, 70), (5, 10), (10, 10), 1)
    # Gleam
    surf.set_at((5, 4), (180, 255, 200))
    surf.set_at((6, 3), (180, 255, 200))
    icons["gems"] = surf

    return icons


class AdventureUI:
    """HUD overlay for adventure mode."""

    HUD_HEIGHT = 40
    BOTTOM_BAR_HEIGHT = 32

    def __init__(self, surface: pygame.Surface, viewport_w: int | None = None,
                 is_mobile: bool = False):
        self.surface = surface
        self.is_mobile = is_mobile
        from lops.renderer.font_scale import scaled_font_size as _sf

        self.font = pygame.font.Font(None, _sf(24))
        self.small_font = pygame.font.Font(None, _sf(18))
        self.large_font = pygame.font.Font(None, _sf(48))
        self.res_font = pygame.font.Font(None, _sf(17))
        self._res_icons = _build_resource_icons(16)

        self.viewport_w = viewport_w if viewport_w is not None else surface.get_width()
        # End turn button
        self.end_turn_rect = pygame.Rect(self.viewport_w - 130, 5, 120, 30)

        # Mobile action buttons
        self._mobile_buttons: list[tuple[pygame.Rect, str, str]] = []  # (rect, action, label)

        # Status message
        self.status_message: str = ""
        self.status_timer: float = 0

        # Treasure chest dialog
        self.chest_dialog_active: bool = False
        self._chest_gold: int = 0
        self._chest_xp: int = 0
        self._chest_is_artifact: bool = False
        self._chest_artifact_name: str = ""
        self._gold_btn_rect = pygame.Rect(0, 0, 0, 0)
        self._xp_btn_rect = pygame.Rect(0, 0, 0, 0)

        # Arena dialog
        self.arena_dialog_active: bool = False
        self._arena_atk_rect = pygame.Rect(0, 0, 0, 0)
        self._arena_def_rect = pygame.Rect(0, 0, 0, 0)

        # Dwelling dialog
        self.dwelling_dialog_active: bool = False
        self._dwelling_recruit_rect = pygame.Rect(0, 0, 0, 0)
        self._dwelling_cancel_rect = pygame.Rect(0, 0, 0, 0)

        # Hill fort dialog
        self.hill_fort_dialog_active: bool = False
        self._hill_fort_close_rect = pygame.Rect(0, 0, 0, 0)
        self._hill_fort_slot_rects: list[
            tuple[pygame.Rect, int]
        ] = []  # (rect, army_slot_index)

    def set_status(self, msg: str, duration: float = 2.0):
        self.status_message = msg
        self.status_timer = duration

    def update(self, dt: float):
        if self.status_timer > 0:
            self.status_timer -= dt
            if self.status_timer <= 0:
                self.status_message = ""

    def handle_mobile_button_click(self, pos: tuple[int, int]) -> str | None:
        """Check if pos hits a mobile action button. Returns action or None."""
        if not self.is_mobile:
            return None
        for rect, action, _label in self._mobile_buttons:
            if rect.collidepoint(pos):
                return action
        # Also check the (larger) end turn button
        if self.end_turn_rect.collidepoint(pos):
            return "end_turn"
        return None

    def draw(self, adventure_state: AdventureState, anim_state=None):
        self._draw_hud_bar(adventure_state, anim_state=anim_state)
        self._draw_bottom_bar(adventure_state)
        if self.is_mobile:
            self._draw_mobile_buttons()
        self._draw_status_message()
        self._draw_chest_dialog()
        self._draw_arena_dialog()
        self._draw_dwelling_dialog(adventure_state)
        self._draw_hill_fort_dialog(adventure_state)
        if adventure_state.game_over:
            self._draw_victory_screen(adventure_state)

    def _draw_hud_bar(self, state: AdventureState, anim_state=None):
        """Simplified top HUD: hero name + MP + speed indicator + End Turn button."""
        # Background bar - only spans the map viewport
        pygame.draw.rect(
            self.surface, COLOR_HUD_BG, (0, 0, self.viewport_w, self.HUD_HEIGHT)
        )

        player = state.current_player
        y = 10

        # Hero name
        hero_text = self.font.render(player.hero.name, True, (240, 200, 50))
        self.surface.blit(hero_text, (10, y))

        # Movement points
        mp_text = self.small_font.render(
            f"MP: {player.movement_points}", True, COLOR_HUD_TEXT
        )
        self.surface.blit(mp_text, (hero_text.get_width() + 24, y + 3))

        # Speed indicator
        if anim_state is not None:
            from lops.adventure.movement_anim import SPEED_LABELS

            label = SPEED_LABELS.get(anim_state.speed, "1x")
            speed_text = self.small_font.render(
                f"Speed: {label}  [V]", True, (160, 180, 220)
            )
            speed_x = hero_text.get_width() + mp_text.get_width() + 48
            self.surface.blit(speed_text, (speed_x, y + 3))

        # Layer indicator
        hs = player.active_hero_state
        if hs and hs.layer == 1:
            layer_text = self.small_font.render("Underground", True, (180, 100, 220))
            lx = hero_text.get_width() + mp_text.get_width() + 180
            self.surface.blit(layer_text, (lx, y + 3))

        # End turn button (desktop only — mobile uses action buttons)
        if not self.is_mobile:
            mx, my = pygame.mouse.get_pos()
            btn_color = (
                COLOR_BUTTON_HOVER
                if self.end_turn_rect.collidepoint(mx, my)
                else COLOR_BUTTON
            )
            pygame.draw.rect(self.surface, btn_color, self.end_turn_rect, border_radius=4)
            btn_text = self.font.render("End Turn", True, COLOR_BUTTON_TEXT)
            btn_rect = btn_text.get_rect(center=self.end_turn_rect.center)
            self.surface.blit(btn_text, btn_rect)

    def _draw_mobile_buttons(self):
        """Draw touch-friendly action buttons along the right edge for mobile."""
        self._mobile_buttons.clear()
        btn_w, btn_h = 64, 52
        gap = 10
        x = self.viewport_w - btn_w - 6
        start_y = self.HUD_HEIGHT + 12

        buttons = [
            ("end_turn", "End\nTurn"),
            ("speed", "Speed"),
            ("hero", "Hero"),
        ]

        btn_font = pygame.font.Font(None, 20)

        for i, (action, label) in enumerate(buttons):
            y = start_y + i * (btn_h + gap)
            rect = pygame.Rect(x, y, btn_w, btn_h)
            self._mobile_buttons.append((rect, action, label))

            bg = (40, 50, 75, 180)
            pygame.draw.rect(self.surface, bg, rect, border_radius=8)
            pygame.draw.rect(self.surface, (100, 110, 140), rect, 1, border_radius=8)

            # Render multi-line labels
            lines = label.split("\n")
            total_h = len(lines) * 16
            ly = rect.centery - total_h // 2
            for line in lines:
                text = btn_font.render(line, True, (220, 220, 220))
                self.surface.blit(text, text.get_rect(centerx=rect.centerx, centery=ly + 8))
                ly += 16

    def _draw_bottom_bar(self, state: AdventureState):
        """Draw HoMM3-style bottom resource bar."""
        screen_h = self.surface.get_height()
        bar_y = screen_h - self.BOTTOM_BAR_HEIGHT

        # Background
        pygame.draw.rect(
            self.surface,
            COLOR_BOTTOM_BAR_BG,
            (0, bar_y, self.viewport_w, self.BOTTOM_BAR_HEIGHT),
        )
        # Top border line
        pygame.draw.line(
            self.surface,
            COLOR_BOTTOM_BAR_BORDER,
            (0, bar_y),
            (self.viewport_w, bar_y),
            1,
        )

        player = state.current_player
        res = player.resources

        res_items = [
            ("gold", res.gold),
            ("wood", res.wood),
            ("ore", res.ore),
            ("mercury", res.mercury),
            ("sulfur", res.sulfur),
            ("crystal", res.crystal),
            ("gems", res.gems),
        ]

        # Resources evenly spaced across the left portion of the bar
        # Reserve right side for day/week
        res_area_w = self.viewport_w - 200
        spacing = res_area_w // len(res_items)
        icon_size = 16

        for i, (name, amount) in enumerate(res_items):
            x = 8 + i * spacing
            cy = bar_y + self.BOTTOM_BAR_HEIGHT // 2

            # Procedural resource icon
            icon = self._res_icons.get(name)
            if icon:
                self.surface.blit(icon, (x, cy - icon_size // 2))

            # Value
            val_surf = self.res_font.render(str(amount), True, COLOR_HUD_TEXT)
            self.surface.blit(
                val_surf, (x + icon_size + 3, cy - val_surf.get_height() // 2)
            )

        # Day / Week (right-aligned, like HoMM3)
        day_text = self.res_font.render(
            f"Day {state.day}, Week {state.week}", True, (200, 190, 160)
        )
        dx = self.viewport_w - day_text.get_width() - 10
        dy = bar_y + (self.BOTTOM_BAR_HEIGHT - day_text.get_height()) // 2
        self.surface.blit(day_text, (dx, dy))

    def _draw_status_message(self):
        if not self.status_message:
            return
        text = self.font.render(self.status_message, True, (255, 255, 100))
        sw = self.surface.get_width()
        rect = text.get_rect(center=(sw // 2, self.HUD_HEIGHT + 20))
        # Background
        bg_rect = rect.inflate(20, 10)
        pygame.draw.rect(self.surface, (0, 0, 0, 180), bg_rect, border_radius=4)
        self.surface.blit(text, rect)

    def _draw_victory_screen(self, state: AdventureState):
        sw, sh = self.surface.get_size()
        overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
        overlay.fill(COLOR_VICTORY_BG)
        self.surface.blit(overlay, (0, 0))

        if state.winner_id is not None:
            winner = state.players[state.winner_id]
            text = f"{winner.hero.name} is victorious!"
        else:
            text = "Game Over!"

        title = self.large_font.render(text, True, (255, 215, 0))
        title_rect = title.get_rect(center=(sw // 2, sh // 2 - 20))
        self.surface.blit(title, title_rect)

        sub = self.font.render("Press ESC to quit", True, COLOR_HUD_TEXT)
        sub_rect = sub.get_rect(center=(sw // 2, sh // 2 + 30))
        self.surface.blit(sub, sub_rect)

    def show_chest_dialog(
        self, gold: int, xp: int, is_artifact: bool = False, artifact_name: str = ""
    ):
        """Show the treasure chest choice dialog."""
        self.chest_dialog_active = True
        self._chest_gold = gold
        self._chest_xp = xp
        self._chest_is_artifact = is_artifact
        self._chest_artifact_name = artifact_name

    def handle_chest_click(self, pos: tuple[int, int]) -> str | None:
        """Handle click on chest dialog. Returns 'gold', 'xp', or None."""
        if not self.chest_dialog_active:
            return None
        if self._chest_is_artifact:
            # Artifact chest: any click dismisses
            self.chest_dialog_active = False
            return "xp"  # artifact is auto-equipped
        if self._gold_btn_rect.collidepoint(pos):
            self.chest_dialog_active = False
            return "gold"
        if self._xp_btn_rect.collidepoint(pos):
            self.chest_dialog_active = False
            return "xp"
        return None

    def _draw_chest_dialog(self):
        """Draw the treasure chest choice overlay."""
        if not self.chest_dialog_active:
            return
        sw, sh = self.viewport_w, self.surface.get_height()
        # Dim overlay
        overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 140))
        self.surface.blit(overlay, (0, 0))

        # Dialog box
        dw, dh = 340, 140
        dx = (sw - dw) // 2
        dy = (sh - dh) // 2
        dialog_rect = pygame.Rect(dx, dy, dw, dh)
        pygame.draw.rect(self.surface, (40, 35, 30), dialog_rect, border_radius=6)
        pygame.draw.rect(self.surface, (220, 190, 40), dialog_rect, 2, border_radius=6)

        if self._chest_is_artifact:
            # Artifact chest
            title = self.font.render("Treasure Chest", True, (240, 200, 50))
            self.surface.blit(title, title.get_rect(centerx=dx + dw // 2, y=dy + 12))
            msg = self.font.render(
                f"Found: {self._chest_artifact_name}!", True, (220, 220, 220)
            )
            self.surface.blit(msg, msg.get_rect(centerx=dx + dw // 2, y=dy + 45))
            hint = self.small_font.render("Click to continue", True, (160, 150, 130))
            self.surface.blit(hint, hint.get_rect(centerx=dx + dw // 2, y=dy + 90))
        else:
            # Gold vs XP choice
            title = self.font.render("Treasure Chest", True, (240, 200, 50))
            self.surface.blit(title, title.get_rect(centerx=dx + dw // 2, y=dy + 12))
            subtitle = self.small_font.render(
                "Choose your reward:", True, (200, 190, 170)
            )
            self.surface.blit(
                subtitle, subtitle.get_rect(centerx=dx + dw // 2, y=dy + 38)
            )

            btn_w, btn_h = 130, 40
            btn_y = dy + dh - btn_h - 20
            self._gold_btn_rect = pygame.Rect(dx + 25, btn_y, btn_w, btn_h)
            self._xp_btn_rect = pygame.Rect(dx + dw - btn_w - 25, btn_y, btn_w, btn_h)

            mx, my = pygame.mouse.get_pos()
            for btn_rect, label, color in [
                (self._gold_btn_rect, f"Gold: {self._chest_gold}", (180, 150, 30)),
                (self._xp_btn_rect, f"XP: {self._chest_xp}", (40, 120, 180)),
            ]:
                hover = btn_rect.collidepoint(mx, my)
                bg = tuple(min(255, c + 30) for c in color) if hover else color
                pygame.draw.rect(self.surface, bg, btn_rect, border_radius=4)
                pygame.draw.rect(
                    self.surface, (220, 220, 220), btn_rect, 1, border_radius=4
                )
                txt = self.font.render(label, True, (255, 255, 255))
                self.surface.blit(txt, txt.get_rect(center=btn_rect.center))

    def is_end_turn_clicked(self, pos: tuple[int, int]) -> bool:
        return self.end_turn_rect.collidepoint(pos)

    # ── Arena dialog ────────────────────────────────────────────────

    def show_arena_dialog(self):
        self.arena_dialog_active = True

    def handle_arena_click(self, pos: tuple[int, int]) -> str | None:
        if not self.arena_dialog_active:
            return None
        if self._arena_atk_rect.collidepoint(pos):
            self.arena_dialog_active = False
            return "attack"
        if self._arena_def_rect.collidepoint(pos):
            self.arena_dialog_active = False
            return "defense"
        return None

    def _draw_arena_dialog(self):
        if not self.arena_dialog_active:
            return
        sw, sh = self.viewport_w, self.surface.get_height()
        overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 140))
        self.surface.blit(overlay, (0, 0))

        dw, dh = 340, 140
        dx, dy = (sw - dw) // 2, (sh - dh) // 2
        pygame.draw.rect(self.surface, (40, 35, 30), (dx, dy, dw, dh), border_radius=6)
        pygame.draw.rect(
            self.surface, (200, 160, 60), (dx, dy, dw, dh), 2, border_radius=6
        )

        title = self.font.render("Arena", True, (200, 160, 60))
        self.surface.blit(title, title.get_rect(centerx=dx + dw // 2, y=dy + 12))
        sub = self.small_font.render("Choose your training:", True, (200, 190, 170))
        self.surface.blit(sub, sub.get_rect(centerx=dx + dw // 2, y=dy + 38))

        btn_w, btn_h = 130, 40
        btn_y = dy + dh - btn_h - 20
        self._arena_atk_rect = pygame.Rect(dx + 25, btn_y, btn_w, btn_h)
        self._arena_def_rect = pygame.Rect(dx + dw - btn_w - 25, btn_y, btn_w, btn_h)

        mx, my = pygame.mouse.get_pos()
        for rect, label, color in [
            (self._arena_atk_rect, "Attack +2", (180, 60, 60)),
            (self._arena_def_rect, "Defense +2", (60, 120, 180)),
        ]:
            hover = rect.collidepoint(mx, my)
            bg = tuple(min(255, c + 30) for c in color) if hover else color
            pygame.draw.rect(self.surface, bg, rect, border_radius=4)
            pygame.draw.rect(self.surface, (220, 220, 220), rect, 1, border_radius=4)
            txt = self.font.render(label, True, (255, 255, 255))
            self.surface.blit(txt, txt.get_rect(center=rect.center))

    # ── Dwelling recruitment dialog ─────────────────────────────────

    def show_dwelling_dialog(self):
        self.dwelling_dialog_active = True

    def handle_dwelling_click(self, pos: tuple[int, int]) -> str | None:
        if not self.dwelling_dialog_active:
            return None
        if self._dwelling_recruit_rect.collidepoint(pos):
            self.dwelling_dialog_active = False
            return "recruit"
        if self._dwelling_cancel_rect.collidepoint(pos):
            self.dwelling_dialog_active = False
            return "cancel"
        return None

    def _draw_dwelling_dialog(self, adventure_state):
        if not self.dwelling_dialog_active:
            return
        player = adventure_state.current_player
        from lops.adventure.map_objects import CreatureDwelling

        hs = player.active_hero_state
        _layer = hs.layer if hs else 0
        obj = adventure_state.find_object_at(player.position, layer=_layer)
        if not isinstance(obj, CreatureDwelling):
            self.dwelling_dialog_active = False
            return

        sw, sh = self.viewport_w, self.surface.get_height()
        overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 140))
        self.surface.blit(overlay, (0, 0))

        dw, dh = 360, 160
        dx, dy = (sw - dw) // 2, (sh - dh) // 2
        pygame.draw.rect(self.surface, (40, 35, 30), (dx, dy, dw, dh), border_radius=6)
        pygame.draw.rect(
            self.surface, (180, 140, 80), (dx, dy, dw, dh), 2, border_radius=6
        )

        title = self.font.render(obj.name, True, (180, 140, 80))
        self.surface.blit(title, title.get_rect(centerx=dx + dw // 2, y=dy + 12))
        info = self.small_font.render(
            f"Available: {obj.available}  |  Cost: {obj.cost_per_unit}g each",
            True,
            (200, 200, 200),
        )
        self.surface.blit(info, info.get_rect(centerx=dx + dw // 2, y=dy + 42))
        total = obj.available * obj.cost_per_unit
        affordable = min(
            obj.available, player.resources.gold // max(1, obj.cost_per_unit)
        )

        # Check if army has room (matching stack or empty slot)
        from lops.data.creatures import CREATURE_REGISTRY

        army_full = False
        hs = player.active_hero_state
        if hs is not None and affordable > 0:
            creature_stats = CREATURE_REGISTRY.get(obj.creature_type)
            creature_name = creature_stats.name if creature_stats else ""
            has_matching = any(
                s.stats.name == creature_name and s.alive for s in hs.army
            )
            has_empty_slot = len(hs.army) < 7
            army_full = not has_matching and not has_empty_slot

        if army_full:
            cost_text = self.small_font.render(
                "Army is full! No room for these creatures.",
                True,
                (200, 100, 100),
            )
        else:
            cost_text = self.small_font.render(
                f"Recruit {affordable} for {affordable * obj.cost_per_unit}g",
                True,
                (220, 220, 180),
            )
        self.surface.blit(
            cost_text, cost_text.get_rect(centerx=dx + dw // 2, y=dy + 65)
        )

        btn_w, btn_h = 120, 36
        btn_y = dy + dh - btn_h - 18
        self._dwelling_recruit_rect = pygame.Rect(dx + 30, btn_y, btn_w, btn_h)
        self._dwelling_cancel_rect = pygame.Rect(
            dx + dw - btn_w - 30, btn_y, btn_w, btn_h
        )

        mx, my = pygame.mouse.get_pos()
        can_recruit = affordable > 0 and not army_full
        for rect, label, color, enabled in [
            (self._dwelling_recruit_rect, "Recruit All", (40, 120, 60), can_recruit),
            (self._dwelling_cancel_rect, "Cancel", (120, 60, 60), True),
        ]:
            if enabled:
                hover = rect.collidepoint(mx, my)
                bg = tuple(min(255, c + 30) for c in color) if hover else color
            else:
                bg = (60, 60, 60)
            pygame.draw.rect(self.surface, bg, rect, border_radius=4)
            pygame.draw.rect(self.surface, (200, 200, 200), rect, 1, border_radius=4)
            txt = self.font.render(
                label, True, (255, 255, 255) if enabled else (120, 120, 120)
            )
            self.surface.blit(txt, txt.get_rect(center=rect.center))

    # ── Hill Fort dialog ────────────────────────────────────────────

    def show_hill_fort_dialog(self):
        self.hill_fort_dialog_active = True

    def handle_hill_fort_click(self, pos: tuple[int, int]):
        """Returns slot index (int) to upgrade, 'close', or None."""
        if not self.hill_fort_dialog_active:
            return None
        if self._hill_fort_close_rect.collidepoint(pos):
            self.hill_fort_dialog_active = False
            return "close"
        for rect, army_slot in self._hill_fort_slot_rects:
            if rect.collidepoint(pos):
                return army_slot
        return None

    def _draw_hill_fort_dialog(self, adventure_state):
        if not self.hill_fort_dialog_active:
            return
        player = adventure_state.current_player
        hs = player.active_hero_state
        if hs is None:
            self.hill_fort_dialog_active = False
            return

        from lops.adventure.buildings import CREATURE_UPGRADES, UPGRADED_RECRUIT_COST
        from lops.data.creatures import CREATURE_REGISTRY

        sw, sh = self.viewport_w, self.surface.get_height()
        overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 140))
        self.surface.blit(overlay, (0, 0))

        dw, dh = 400, 300
        dx, dy = (sw - dw) // 2, (sh - dh) // 2
        pygame.draw.rect(self.surface, (40, 35, 30), (dx, dy, dw, dh), border_radius=6)
        pygame.draw.rect(
            self.surface, (180, 180, 190), (dx, dy, dw, dh), 2, border_radius=6
        )

        title = self.font.render("Hill Fort - Upgrade Creatures", True, (180, 180, 190))
        self.surface.blit(title, title.get_rect(centerx=dx + dw // 2, y=dy + 10))

        self._hill_fort_slot_rects.clear()
        slot_y = dy + 40
        mx, my = pygame.mouse.get_pos()

        for i, stack in enumerate(hs.army):
            if not stack.alive:
                continue
            # Find if upgradable
            base_ct = None
            for ct, stats in CREATURE_REGISTRY.items():
                if stats.name == stack.stats.name:
                    base_ct = ct
                    break
            upgraded_ct = CREATURE_UPGRADES.get(base_ct) if base_ct else None
            if (
                upgraded_ct is None
                or CREATURE_REGISTRY[upgraded_ct].name == stack.stats.name
            ):
                # Already upgraded or no upgrade path
                txt = self.small_font.render(
                    f"{stack.stats.name} x{stack.count} (no upgrade)",
                    True,
                    (120, 120, 120),
                )
                self.surface.blit(txt, (dx + 15, slot_y))
                slot_y += 28
                continue

            upg_stats = CREATURE_REGISTRY[upgraded_ct]
            upg_cost = UPGRADED_RECRUIT_COST.get(upgraded_ct, 0)
            # Rough base cost estimate
            base_cost = 0
            from lops.adventure.town import FACTION_DWELLINGS

            for fid, dwellings in FACTION_DWELLINGS.items():
                for ct_type, _growth, cost in dwellings:
                    if ct_type == base_ct:
                        base_cost = cost
                        break
            diff = max(0, upg_cost - base_cost)
            total = diff * stack.count
            can_afford = player.resources.gold >= total

            rect = pygame.Rect(dx + 10, slot_y, dw - 20, 26)
            self._hill_fort_slot_rects.append((rect, i))
            hover = rect.collidepoint(mx, my) and can_afford
            bg = (60, 80, 60) if hover else (50, 50, 55)
            pygame.draw.rect(self.surface, bg, rect, border_radius=3)

            label = f"{stack.stats.name} x{stack.count} -> {upg_stats.name} ({total}g)"
            color = (220, 220, 220) if can_afford else (120, 100, 100)
            txt = self.small_font.render(label, True, color)
            self.surface.blit(txt, (rect.x + 8, rect.y + 5))
            slot_y += 30

        # Close button
        self._hill_fort_close_rect = pygame.Rect(
            dx + dw // 2 - 50, dy + dh - 40, 100, 30
        )
        hover = self._hill_fort_close_rect.collidepoint(mx, my)
        bg = (100, 70, 70) if hover else (80, 50, 50)
        pygame.draw.rect(self.surface, bg, self._hill_fort_close_rect, border_radius=4)
        pygame.draw.rect(
            self.surface,
            (200, 200, 200),
            self._hill_fort_close_rect,
            1,
            border_radius=4,
        )
        txt = self.font.render("Close", True, (255, 255, 255))
        self.surface.blit(txt, txt.get_rect(center=self._hill_fort_close_rect.center))
