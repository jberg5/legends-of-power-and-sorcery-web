"""Touch-based adventure input for mobile.

Wraps the desktop AdventureInputHandler, adding:
- Touch drag to pan the camera
- Tap threshold to distinguish pans from taps
- Sidebar overlay click routing
- No keyboard shortcuts (action bar buttons handled by MobileAdventureUI)
"""

from __future__ import annotations

import pygame

from lops.adventure.game_director import GameDirector, GameMode
from lops.adventure.map_objects import TownSite
from lops.adventure.movement_anim import AdventureAnimState
from lops.hex import CubeCoord
from lops.input.adventure_input import AdventureInputHandler
from lops.renderer.adventure_renderer import AdventureRenderer


class MobileAdventureInput:
    """Touch-based adventure map input."""

    DRAG_THRESHOLD = 12  # pixels before a touch becomes a drag

    def __init__(
        self,
        director: GameDirector,
        renderer: AdventureRenderer,
        ui,  # MobileAdventureUI
        *,
        anim_state: AdventureAnimState | None = None,
    ):
        self.director = director
        self.renderer = renderer
        self.ui = ui
        self.anim_state = anim_state

        # Sidebar reference (set by game_loop after creation)
        self.sidebar = None

        # Inner handler for game logic (click-to-move, dialog handling, etc.)
        self._inner = AdventureInputHandler(
            director, renderer, ui, anim_state=anim_state
        )

        # Touch drag state
        self._touch_start: tuple[int, int] | None = None
        self._camera_start: tuple[float, float] | None = None
        self._is_dragging = False

    # -- Delegate attributes used by game_loop --
    @property
    def _move_range(self):
        return self._inner._move_range

    def refresh_move_range(self):
        self._inner.refresh_move_range()

    def _select_hero(self, player, hero_idx: int):
        self._inner._select_hero(player, hero_idx)

    def handle_event(self, event: pygame.event.Event) -> str | None:
        """Process touch events. Returns action string or None."""
        state = self.director._state

        # Let mobile UI handle its own button taps first
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            result = self.ui.handle_tap(event.pos)
            if result is not None:
                return self._dispatch_ui_result(result, event.pos)

        # Victory screen: check for "New Game?" button
        if state.game_over:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if self.ui.is_new_game_clicked(event.pos):
                    return "new_game"
            return None

        # Dialog intercepts — delegate to inner handler
        if (self.ui.chest_dialog_active or self.ui.arena_dialog_active
                or self.ui.dwelling_dialog_active or self.ui.hill_fort_dialog_active):
            return self._inner.handle_event(event)

        # When sidebar overlay is visible, block map interaction
        if self.ui.sidebar_visible:
            return None

        # Touch down: start potential drag
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self._touch_start = event.pos
            cam = self.renderer.camera
            self._camera_start = (cam.x, cam.y)
            self._is_dragging = False
            return None

        # Touch move: pan camera if dragging
        if event.type == pygame.MOUSEMOTION and self._touch_start is not None:
            dx = event.pos[0] - self._touch_start[0]
            dy = event.pos[1] - self._touch_start[1]
            dist = (dx * dx + dy * dy) ** 0.5
            if dist > self.DRAG_THRESHOLD:
                self._is_dragging = True
            if self._is_dragging and self._camera_start is not None:
                cam = self.renderer.camera
                cam.x = self._camera_start[0] - dx
                cam.y = self._camera_start[1] - dy
                cam.clamp()
            return None

        # Touch up: if not dragging, treat as tap (click)
        if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            was_dragging = self._is_dragging
            start_pos = self._touch_start
            self._touch_start = None
            self._camera_start = None
            self._is_dragging = False

            if was_dragging or start_pos is None:
                return None  # was a pan, not a tap

            # Synthesize a click event for the inner handler
            click_event = pygame.event.Event(
                pygame.MOUSEBUTTONDOWN,
                pos=start_pos,
                button=1,
            )
            return self._inner.handle_event(click_event)

        # Mouse wheel for scrolling (desktop fallback in emulator)
        if event.type == pygame.MOUSEWHEEL:
            if self.ui.sidebar_visible and self.sidebar is not None:
                self.sidebar.handle_scroll(event.y)
                return None
            return self._inner.handle_event(event)

        return None

    def update(self):
        self._inner.update()

    def _dispatch_ui_result(self, result: str, pos: tuple[int, int]) -> str | None:
        """Handle results from mobile UI button taps."""
        if result == "end_turn":
            self._inner._end_turn()
            return "end_turn"
        elif result == "hero_modal":
            self.director.open_hero_modal()
            return "hero_modal"
        elif result == "set_speed":
            if self.anim_state is not None and hasattr(self.ui, "_pending_speed"):
                self.anim_state.speed = self.ui._pending_speed
            return None
        elif result == "sidebar_click":
            return self._handle_sidebar_click(pos)
        elif result in (
            "settings_opened", "settings_closed", "settings_consumed",
            "sidebar_opened", "sidebar_closed",
        ):
            return None
        return None

    def _handle_sidebar_click(self, pos: tuple[int, int]) -> str | None:
        """Route a click on the sidebar overlay to the sidebar panel."""
        if self.sidebar is None:
            return None

        sidebar_result = self.sidebar.handle_click(
            pos, self.director.adventure_state
        )
        if sidebar_result is None:
            return None

        if sidebar_result == "layer_toggle":
            pass  # handled internally by sidebar
        elif sidebar_result == "minimap_click":
            hex_pos = self.sidebar.minimap_to_world_hex(pos)
            if hex_pos is not None:
                self.renderer.center_on_hex(hex_pos)
            self.ui.sidebar_visible = False  # dismiss after minimap click
        elif sidebar_result.startswith("hero_select:"):
            hero_idx = int(sidebar_result.split(":")[1])
            human = self.director.adventure_state.players[0]
            self._inner._select_hero(human, hero_idx)
            self.ui.sidebar_visible = False  # dismiss after hero select
        elif sidebar_result.startswith("town_click:"):
            tid = int(sidebar_result.split(":")[1])
            for obj in self.director.adventure_state.map_objects:
                if isinstance(obj, TownSite) and id(obj) == tid:
                    self.renderer.center_on_hex(obj.position)
                    self.director.open_town_screen(obj)
                    self.ui.sidebar_visible = False
                    break

        return None
