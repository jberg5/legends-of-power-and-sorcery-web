"""Touch-based combat input for mobile.

Wraps the desktop InputHandler, adding on-screen buttons for:
- Spellbook (big button)
- Wait
- Defend
No keyboard shortcuts needed.
"""

from __future__ import annotations

import pygame

from lops.combat import CombatEngine
from lops.input.handler import InputHandler
from lops.models import Side
from lops.renderer.core import GameRenderer


# Button layout constants
BTN_HEIGHT = 42
BTN_GAP = 8
BTN_COLOR = (55, 65, 90)
BTN_COLOR_HOVER = (75, 90, 125)
BTN_COLOR_ACTIVE = (80, 120, 80)
BTN_TEXT_COLOR = (220, 220, 220)


class MobileCombatInput:
    """Touch-friendly combat input with on-screen buttons."""

    def __init__(
        self,
        engine: CombatEngine,
        renderer: GameRenderer,
        *,
        player_side: Side = Side.ATTACKER,
    ):
        self._inner = InputHandler(engine, renderer, player_side=player_side)
        self.engine = engine
        self.renderer = renderer

        self._btn_font = pygame.font.Font(None, 24)
        self._btn_rects: dict[str, pygame.Rect] = {}

    # -- Delegate attributes used by game_loop --
    @property
    def auto_combat(self):
        return self._inner.auto_combat

    @auto_combat.setter
    def auto_combat(self, val):
        self._inner.auto_combat = val

    @property
    def player_side(self):
        return self._inner.player_side

    def handle_event(self, event: pygame.event.Event):
        """Handle touch events with button overlay."""
        if self.engine.is_over():
            return
        if self.renderer.is_animating:
            return

        # Check button taps
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for btn_id, rect in self._btn_rects.items():
                if rect.collidepoint(event.pos):
                    self._handle_button(btn_id)
                    return

        # Delegate to inner handler for hex taps, spellbook clicks, etc.
        self._inner.handle_event(event)

    def _handle_button(self, btn_id: str):
        """Handle a button tap."""
        if btn_id == "spellbook":
            self._inner._toggle_spellbook()
        elif btn_id == "wait":
            stack = self.engine.current_stack
            if stack and self._inner.selection.is_player_turn:
                self._inner._execute_wait(stack)
        elif btn_id == "defend":
            stack = self.engine.current_stack
            if stack and self._inner.selection.is_player_turn:
                self._inner._execute_defend(stack)
        elif btn_id == "auto":
            self._inner.auto_combat = not self._inner.auto_combat

    def update(self):
        self._inner.update()

    def draw_buttons(self):
        """Draw mobile combat buttons. Called after combat renderer draws."""
        surface = self.renderer.surface
        sw, sh = surface.get_size()
        mx, my = pygame.mouse.get_pos()

        # Determine which buttons to show
        has_spells = False
        hero = self.engine.get_hero(self._inner.player_side)
        if hero and hero.spells:
            has_spells = True

        buttons = []
        if has_spells:
            buttons.append(("spellbook", "Spellbook"))
        buttons.append(("wait", "Wait"))
        buttons.append(("defend", "Defend"))
        buttons.append(("auto", "Auto" if not self._inner.auto_combat else "Auto ON"))

        btn_w = 100
        total_w = len(buttons) * btn_w + (len(buttons) - 1) * BTN_GAP
        start_x = (sw - total_w) // 2
        btn_y = sh - BTN_HEIGHT - 8

        self._btn_rects.clear()

        for i, (btn_id, label) in enumerate(buttons):
            x = start_x + i * (btn_w + BTN_GAP)
            rect = pygame.Rect(x, btn_y, btn_w, BTN_HEIGHT)
            self._btn_rects[btn_id] = rect

            hover = rect.collidepoint(mx, my)
            is_active = (
                (btn_id == "spellbook" and self.renderer.show_spellbook)
                or (btn_id == "auto" and self._inner.auto_combat)
            )

            if is_active:
                bg = BTN_COLOR_ACTIVE
            elif hover:
                bg = BTN_COLOR_HOVER
            else:
                bg = BTN_COLOR

            pygame.draw.rect(surface, bg, rect, border_radius=6)
            pygame.draw.rect(surface, (100, 100, 110), rect, 1, border_radius=6)

            txt = self._btn_font.render(label, True, BTN_TEXT_COLOR)
            surface.blit(txt, txt.get_rect(center=rect.center))
