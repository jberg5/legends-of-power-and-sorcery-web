"""Mobile-specific input handlers."""
