"""CombatEngine: turn order, action execution, round management."""

from __future__ import annotations

import random
from enum import Enum, auto
from typing import Any

from lops.actions import ActionType, CombatAction
from lops.damage import calculate_damage, calculate_tower_damage, roll_luck, roll_morale
from lops.hex import cube_distance
from lops.models import Battlefield, CreatureStack, Hero, Side
from lops.pathfinding import (
    crosses_wall,
    find_path,
    get_attack_positions,
    movement_range,
)


class CombatPhase(Enum):
    NOT_STARTED = auto()
    ACTIVE_TURN = auto()
    WAITING_PHASE = auto()
    ROUND_END = auto()
    COMBAT_OVER = auto()


class CombatEngine:
    """Manages the flow of tactical combat between two armies."""

    def __init__(self, battlefield: Battlefield):
        self.battlefield = battlefield
        self.phase = CombatPhase.NOT_STARTED
        self.round_number = 0
        self.turn_queue: list[CreatureStack] = []
        self.wait_queue: list[CreatureStack] = []
        self.current_stack: CreatureStack | None = None
        self.combat_log: list[str] = []
        self.winner: Side | None = None

        # Callbacks for renderer/UI
        self.on_action: list = []  # called with (CombatAction, result_dict)

    def start_combat(self):
        self.combat_log.append("Combat begins!")
        self.round_number = 0
        self._start_new_round()

    def is_over(self) -> bool:
        return self.phase == CombatPhase.COMBAT_OVER

    def current_side(self) -> Side | None:
        if self.current_stack:
            return self.current_stack.side
        return None

    def get_hero(self, side: Side) -> Hero:
        return self.battlefield.get_army(side).hero

    def _start_new_round(self):
        self.round_number += 1
        self.combat_log.append(f"--- Round {self.round_number} ---")

        # Reset hero cast flags
        for side in (Side.ATTACKER, Side.DEFENDER):
            hero = self.get_hero(side)
            if hero:
                hero.has_cast_this_round = False

        # Decrement buff durations and remove expired buffs
        for stack in self.battlefield.alive_stacks:
            remaining = []
            for buff in stack.active_buffs:
                buff.remaining_rounds -= 1
                if buff.remaining_rounds > 0:
                    remaining.append(buff)
                else:
                    self.combat_log.append(f"{buff.name} expires on {stack.stats.name}")
            stack.active_buffs = remaining

        # Reset all stacks for new round
        for stack in self.battlefield.alive_stacks:
            stack.reset_round()

        # Siege: fire towers then catapult before turn queue
        if self.battlefield.is_siege:
            self._fire_arrow_towers()
            self._fire_catapult()
            # Check if combat is over after siege fire
            if self.battlefield.attacker.defeated or self.battlefield.defender.defeated:
                self._advance_turn()
                return

        # Build turn order: sort by speed descending
        # Ties: attacker goes first, then by slot index
        alive = self.battlefield.alive_stacks
        self.turn_queue = sorted(
            alive,
            key=lambda s: (-s.effective_speed, s.side != Side.ATTACKER, s.slot_index),
        )
        self.wait_queue = []
        self.phase = CombatPhase.ACTIVE_TURN
        self._advance_turn()

    def _advance_turn(self):
        """Move to the next stack in the turn queue."""
        # Check for combat over
        if self.battlefield.attacker.defeated:
            self.phase = CombatPhase.COMBAT_OVER
            self.winner = Side.DEFENDER
            self.combat_log.append("Defender wins!")
            self.current_stack = None
            return
        if self.battlefield.defender.defeated:
            self.phase = CombatPhase.COMBAT_OVER
            self.winner = Side.ATTACKER
            self.combat_log.append("Attacker wins!")
            self.current_stack = None
            return

        # Try to get next from turn queue
        while self.turn_queue:
            stack = self.turn_queue.pop(0)
            if stack.alive and not stack.has_moved and not stack.has_attacked:
                # Check for Blind: skip turn and remove blind buff
                blind_buffs = [b for b in stack.active_buffs if b.is_blinded]
                if blind_buffs:
                    for b in blind_buffs:
                        stack.active_buffs.remove(b)
                    stack.has_moved = True
                    stack.has_attacked = True
                    self.combat_log.append(
                        f"{stack.stats.name} is blinded and cannot act!"
                    )
                    continue
                self.current_stack = stack
                self.phase = CombatPhase.ACTIVE_TURN
                return

        # Normal turns exhausted, process wait queue
        if self.wait_queue:
            self.phase = CombatPhase.WAITING_PHASE
            # Wait queue processed in reverse speed order (slowest first)
            self.wait_queue.sort(
                key=lambda s: (
                    s.effective_speed,
                    s.side != Side.ATTACKER,
                    s.slot_index,
                ),
            )
            while self.wait_queue:
                stack = self.wait_queue.pop(0)
                if stack.alive:
                    stack.is_waiting = False
                    self.current_stack = stack
                    return

        # Round is over
        self._start_new_round()

    def get_valid_moves(self, stack: CreatureStack | None = None) -> dict:
        """Get all valid hexes the current stack can move to, with costs."""
        stack = stack or self.current_stack
        if not stack or not stack.alive:
            return {}
        return movement_range(stack, self.battlefield)

    def get_valid_attacks(
        self, stack: CreatureStack | None = None
    ) -> list[CreatureStack]:
        """Get all enemy stacks the current stack can attack."""
        stack = stack or self.current_stack
        if not stack or not stack.alive:
            return []

        enemy_army = self.battlefield.get_enemy_army(stack.side)
        targets = []

        if (
            stack.stats.is_ranged
            and stack.shots_left > 0
            and not stack.is_ranged_disabled
        ):
            # Ranged: can shoot any alive enemy (unless Forgetfulness debuff)
            targets = [s for s in enemy_army.alive_stacks]
        else:
            # Melee: can attack enemies adjacent or reachable
            for enemy in enemy_army.alive_stacks:
                attack_positions = get_attack_positions(stack, enemy, self.battlefield)
                if attack_positions:
                    targets.append(enemy)

        return targets

    def get_melee_positions(self, target: CreatureStack) -> list:
        """Get hexes adjacent to target that the current stack can reach."""
        if not self.current_stack:
            return []
        return get_attack_positions(self.current_stack, target, self.battlefield)

    def execute_action(self, action: CombatAction) -> dict[str, Any]:
        """Execute a combat action and return the result."""
        result: dict[str, Any] = {}

        if action.action_type == ActionType.MOVE:
            result = self._execute_move(action)
        elif action.action_type == ActionType.MELEE_ATTACK:
            result = self._execute_melee(action)
        elif action.action_type == ActionType.RANGED_ATTACK:
            result = self._execute_ranged(action)
        elif action.action_type == ActionType.WAIT:
            result = self._execute_wait(action)
        elif action.action_type == ActionType.DEFEND:
            result = self._execute_defend(action)
        elif action.action_type == ActionType.CAST_SPELL:
            result = self._execute_spell(action)

        # Notify callbacks
        for callback in self.on_action:
            callback(action, result)

        # Check for morale bonus (extra turn) after attacking
        if action.action_type in (ActionType.MELEE_ATTACK, ActionType.RANGED_ATTACK):
            hero = self.get_hero(action.actor.side)
            if action.actor.alive and roll_morale(action.actor, hero):
                # Check victory before granting extra turn
                if (
                    self.battlefield.attacker.defeated
                    or self.battlefield.defender.defeated
                ):
                    self._advance_turn()
                    return result
                action.actor.had_morale_bonus = True
                action.actor.has_moved = False
                action.actor.has_attacked = False
                result["morale_bonus"] = True
                self.combat_log.append(
                    f"{action.actor.stats.name} has high morale! Extra turn!"
                )
                return result

        self._advance_turn()
        return result

    def _execute_move(self, action: CombatAction) -> dict[str, Any]:
        actor = action.actor
        dest = action.destination
        assert actor.position is not None
        assert dest is not None

        # Build path for animation
        path = find_path(
            actor.position,
            dest,
            self.battlefield,
            actor.stats.is_flying,
            side=actor.side,
        )

        actor.position = dest
        actor.has_moved = True
        action.path = path

        # Moat: ground units entering moat lose their turn
        siege = self.battlefield.siege_info
        if self.battlefield.is_siege and not actor.stats.is_flying and siege is not None:
            if dest in siege.moat_hexes:
                actor.in_moat = True
                actor.has_attacked = True  # can't attack after entering moat
                self.combat_log.append(f"{actor.stats.name} enters the moat!")
                return {"path": path, "moat": True}

        self.combat_log.append(f"{actor.stats.name} moves")
        return {"path": path}

    def _execute_melee(self, action: CombatAction) -> dict[str, Any]:
        actor = action.actor
        target = action.target
        dest = action.destination
        assert target is not None

        result: dict[str, Any] = {}

        # Move to attack position if needed
        if dest and dest != actor.position:
            assert actor.position is not None
            path = find_path(
                actor.position,
                dest,
                self.battlefield,
                actor.stats.is_flying,
                side=actor.side,
            )
            actor.position = dest
            action.path = path
            result["path"] = path

        # Calculate and apply damage
        atk_hero = self.get_hero(actor.side)
        def_hero = self.get_hero(target.side)

        # Jousting bonus: +5% damage per hex traveled
        if action.path and actor.position is not None and target.position is not None:
            distance = cube_distance(actor.position, target.position)
        else:
            distance = 1

        damage = calculate_damage(actor, target, atk_hero, def_hero, distance=distance)

        # Lucky strike: double damage
        lucky = roll_luck(actor, atk_hero)
        if lucky:
            damage *= 2

        killed = target.take_damage(damage)

        actor.has_moved = True
        actor.has_attacked = True

        if lucky:
            self.combat_log.append(f"{actor.stats.name} gets lucky! Double damage!")
        self.combat_log.append(
            f"{actor.stats.name} ({actor.count}) attacks {target.stats.name} "
            f"for {damage} damage (killed {killed})"
        )
        result.update(
            {"damage": damage, "killed": killed, "target": target, "lucky": lucky}
        )

        # Double strike
        if actor.stats.double_strike and target.alive:
            damage2 = calculate_damage(actor, target, atk_hero, def_hero)
            killed2 = target.take_damage(damage2)
            self.combat_log.append(
                f"{actor.stats.name} strikes again for {damage2} damage (killed {killed2})"
            )
            result["damage2"] = damage2
            result["killed2"] = killed2

        # Fire Shield reflect: attacker takes percentage of dealt damage back
        for buff in target.active_buffs:
            if buff.fire_shield_reflect > 0:
                reflect_damage = max(1, int(damage * buff.fire_shield_reflect))
                reflect_killed = actor.take_damage(reflect_damage)
                self.combat_log.append(
                    f"Fire Shield reflects {reflect_damage} damage back at {actor.stats.name} "
                    f"(killed {reflect_killed})"
                )
                result["fire_shield_damage"] = reflect_damage
                result["fire_shield_killed"] = reflect_killed

        # Retaliation
        if target.alive and not target.has_retaliated:
            ret_damage = calculate_damage(target, actor, def_hero, atk_hero)
            ret_killed = actor.take_damage(ret_damage)
            # Counterstrike: extra retaliations
            max_retaliations = 1 + target.total_extra_retaliations
            if not target.stats.unlimited_retaliation:
                # Track retaliation count via has_retaliated + extra_retaliations
                target._retaliation_count += 1
                if target._retaliation_count >= max_retaliations:
                    target.has_retaliated = True

            self.combat_log.append(
                f"{target.stats.name} ({target.count}) retaliates "
                f"for {ret_damage} damage (killed {ret_killed})"
            )
            result["retaliation_damage"] = ret_damage
            result["retaliation_killed"] = ret_killed

        return result

    def _execute_ranged(self, action: CombatAction) -> dict[str, Any]:
        actor = action.actor
        target = action.target
        assert target is not None

        atk_hero = self.get_hero(actor.side)
        def_hero = self.get_hero(target.side)

        # Wall penalty: halve ranged damage when shooting across walls
        wp = False
        if self.battlefield.is_siege and actor.position and target.position:
            wp = crosses_wall(actor.position, target.position)

        damage = calculate_damage(
            actor, target, atk_hero, def_hero, is_ranged=True, wall_penalty=wp
        )

        # Lucky strike: double damage
        lucky = roll_luck(actor, atk_hero)
        if lucky:
            damage *= 2

        killed = target.take_damage(damage)

        actor.has_attacked = True
        actor.has_moved = True  # can't move after shooting
        actor.shots_left -= 1

        if lucky:
            self.combat_log.append(f"{actor.stats.name} gets lucky! Double damage!")
        self.combat_log.append(
            f"{actor.stats.name} ({actor.count}) shoots {target.stats.name} "
            f"for {damage} damage (killed {killed})"
        )

        # Double strike for ranged (e.g., Marksman)
        result: dict[str, Any] = {
            "damage": damage,
            "killed": killed,
            "target": target,
            "is_ranged": True,
            "lucky": lucky,
        }

        if actor.stats.double_strike and target.alive and actor.shots_left > 0:
            damage2 = calculate_damage(
                actor, target, atk_hero, def_hero, is_ranged=True, wall_penalty=wp
            )
            killed2 = target.take_damage(damage2)
            actor.shots_left -= 1
            self.combat_log.append(
                f"{actor.stats.name} shoots again for {damage2} damage (killed {killed2})"
            )
            result["damage2"] = damage2
            result["killed2"] = killed2

        return result

    def _execute_wait(self, action: CombatAction) -> dict[str, Any]:
        actor = action.actor
        actor.is_waiting = True
        self.wait_queue.append(actor)
        self.combat_log.append(f"{actor.stats.name} waits")
        return {}

    def _execute_defend(self, action: CombatAction) -> dict[str, Any]:
        actor = action.actor
        actor.is_defending = True
        actor.has_moved = True
        actor.has_attacked = True
        self.combat_log.append(f"{actor.stats.name} defends")
        return {}

    def _execute_spell(self, action: CombatAction) -> dict[str, Any]:
        from lops.spells import (
            Spell,
            SpellEffect,
            SpellTarget,
            calculate_spell_damage,
            create_buff_from_template,
            get_mana_cost,
            get_spell_targets,
        )

        actor = action.actor
        spell = action.spell
        target = action.target
        hero = self.get_hero(actor.side)

        if not isinstance(spell, Spell):
            return {}

        # Adventure spells can't be cast in combat
        if spell.effect == SpellEffect.ADVENTURE:
            self.combat_log.append(
                f"{spell.name} can only be cast on the adventure map!"
            )
            return {}

        mana_cost = get_mana_cost(hero, spell)
        if hero.mana < mana_cost:
            self.combat_log.append("Not enough mana!")
            return {}

        if hero.has_cast_this_round:
            self.combat_log.append("Already cast a spell this round!")
            return {}

        # Check spell immunity on single-target spells
        if (
            target
            and hasattr(target, "spell_immunity_level")
            and target.spell_immunity_level >= spell.level
        ):
            if spell.target_type in (
                SpellTarget.SINGLE_ENEMY,
                SpellTarget.SINGLE_FRIENDLY,
            ):
                self.combat_log.append(
                    f"{target.stats.name} is immune to {spell.name}!"
                )
                hero.mana -= mana_cost
                hero.has_cast_this_round = True
                return {"spell": spell, "mana_cost": mana_cost, "immune": True}

        hero.mana -= mana_cost
        hero.has_cast_this_round = True
        result = {"spell": spell, "mana_cost": mana_cost}

        targets = get_spell_targets(spell, hero, target, self.battlefield)

        # Filter out immune targets
        if (
            spell.effect == SpellEffect.DAMAGE
            or spell.effect == SpellEffect.CHAIN_DAMAGE
        ):
            targets = [t for t in targets if t.spell_immunity_level < spell.level]

        if spell.effect == SpellEffect.DAMAGE:
            damage = calculate_spell_damage(spell, hero)
            total_killed = 0
            for t in targets:
                actual_dmg = damage
                # Apply spell damage reduction from Protection buffs
                for buff in t.active_buffs:
                    if buff.spell_damage_reduction > 0:
                        actual_dmg = int(
                            actual_dmg * (1.0 - buff.spell_damage_reduction)
                        )
                killed = t.take_damage(actual_dmg)
                total_killed += killed
                self.combat_log.append(
                    f"{hero.name} casts {spell.name} on {t.stats.name} "
                    f"for {actual_dmg} damage (killed {killed})"
                )
            result.update(
                {"damage": damage, "killed": total_killed, "targets": targets}
            )

        elif spell.effect == SpellEffect.CHAIN_DAMAGE:
            result.update(self._execute_chain_damage(spell, hero, target, actor.side))

        elif spell.effect in (SpellEffect.BUFF, SpellEffect.DEBUFF):
            buff = create_buff_from_template(spell, hero)
            applied_targets = []
            for t in targets:
                if (
                    spell.effect == SpellEffect.DEBUFF
                    and t.spell_immunity_level >= spell.level
                ):
                    self.combat_log.append(f"{t.stats.name} is immune to {spell.name}!")
                    continue
                # Remove existing buff of same spell
                t.active_buffs = [
                    b for b in t.active_buffs if b.spell_id != spell.spell_id
                ]
                t.active_buffs.append(create_buff_from_template(spell, hero))
                applied_targets.append(t)
                self.combat_log.append(
                    f"{hero.name} casts {spell.name} on {t.stats.name}"
                )
            result["buff"] = buff
            result["targets"] = applied_targets

        elif spell.effect == SpellEffect.HEAL:
            heal_amount = calculate_spell_damage(spell, hero)  # same formula
            for t in targets:
                healed = self._apply_heal(t, heal_amount)
                # Remove negative buffs (debuffs)
                t.active_buffs = [
                    b
                    for b in t.active_buffs
                    if b.attack_mod >= 0
                    and b.speed_mod >= 0
                    and not b.deal_min_damage
                    and not b.is_blinded
                ]
                self.combat_log.append(
                    f"{hero.name} casts {spell.name} on {t.stats.name} "
                    f"(healed {healed} HP)"
                )
            result["healed"] = heal_amount
            result["targets"] = targets

        elif spell.effect == SpellEffect.DISPEL:
            for t in targets:
                t.active_buffs.clear()
                self.combat_log.append(
                    f"{hero.name} casts {spell.name} on {t.stats.name} "
                    f"(all effects removed)"
                )
            result["targets"] = targets

        elif spell.effect == SpellEffect.RESURRECT:
            result.update(self._execute_resurrect(spell, hero, target, actor.side))

        elif spell.effect == SpellEffect.TELEPORT:
            result.update(self._execute_teleport(action, hero))

        elif spell.effect == SpellEffect.SUMMON:
            result.update(self._execute_summon(spell, hero, actor.side))

        elif spell.effect == SpellEffect.EARTHQUAKE:
            result.update(self._execute_earthquake(spell, hero))

        return result

    def _execute_chain_damage(self, spell: Any, hero: Hero, initial_target: CreatureStack | None, caster_side: Side) -> dict[str, Any]:
        """Chain Lightning: hit target, then bounce to 3 nearest, -50% each bounce."""
        from lops.hex import cube_distance
        from lops.spells import calculate_spell_damage

        base_damage = calculate_spell_damage(spell, hero)
        hit_stacks: list[CreatureStack] = []
        total_killed = 0
        current_damage = base_damage
        current_target = initial_target
        hit_set: set[int] = set()

        for bounce in range(4):  # up to 4 hits
            if current_target is None or not current_target.alive:
                break
            if id(current_target) in hit_set:
                break
            hit_set.add(id(current_target))

            # Apply spell damage reduction
            actual_dmg = current_damage
            for buff in current_target.active_buffs:
                if buff.spell_damage_reduction > 0:
                    actual_dmg = int(actual_dmg * (1.0 - buff.spell_damage_reduction))

            killed = current_target.take_damage(actual_dmg)
            total_killed += killed
            hit_stacks.append(current_target)
            self.combat_log.append(
                f"{hero.name}'s {spell.name} hits {current_target.stats.name} "
                f"for {actual_dmg} damage (killed {killed})"
            )

            # Find next nearest target (any side)
            current_damage = current_damage // 2
            if current_damage <= 0:
                break
            candidates = [
                s
                for s in self.battlefield.alive_stacks
                if id(s) not in hit_set
                and s.spell_immunity_level < spell.level
                and s.position is not None
            ]
            if not candidates:
                break
            # Capture position to avoid late-binding issue in the sort key
            ref_pos = current_target.position
            assert ref_pos is not None
            current_target = min(
                candidates,
                key=lambda s: cube_distance(s.position, ref_pos),  # type: ignore[arg-type]
            )

        return {"damage": base_damage, "killed": total_killed, "targets": hit_stacks}

    def _execute_resurrect(self, spell: Any, hero: Hero, target: CreatureStack | None, caster_side: Side) -> dict[str, Any]:
        """Resurrect/Animate Dead: restore killed creatures to a stack."""
        from lops.spells import calculate_spell_damage

        hp_to_restore = calculate_spell_damage(spell, hero)
        army = self.battlefield.get_army(caster_side)

        if target is None:
            return {}

        # Find the target stack (must be on caster's side)
        if target.side != caster_side:
            self.combat_log.append("Can only resurrect friendly creatures!")
            return {}

        # Calculate how many creatures to revive
        max_hp = target.stats.hp
        creatures_to_revive = hp_to_restore // max_hp

        if creatures_to_revive <= 0:
            self.combat_log.append(
                f"Not enough power to resurrect {target.stats.name}!"
            )
            return {}

        # Count original stack size from slot (we need to track original count)
        # For simplicity, just add creatures back up to some reasonable limit
        old_count = target.count
        target.count += creatures_to_revive
        if not target.alive:
            # Revive dead stack
            target.count = creatures_to_revive
            target.current_hp = max_hp

        actual_revived = target.count - old_count
        self.combat_log.append(
            f"{hero.name} casts {spell.name} on {target.stats.name} "
            f"(revived {actual_revived} creatures)"
        )
        return {"revived": actual_revived, "targets": [target]}

    def _execute_teleport(self, action: CombatAction, hero: Hero) -> dict[str, Any]:
        """Teleport: move friendly stack to target hex."""
        target_stack = action.target
        dest = action.destination

        if target_stack is None:
            return {}

        if target_stack.side != action.actor.side:
            self.combat_log.append("Can only teleport friendly creatures!")
            return {}

        if dest is None:
            return {}

        # Check destination is passable
        if not self.battlefield.is_passable(dest, target_stack.side):
            self.combat_log.append("Destination is blocked!")
            return {}

        old_pos = target_stack.position
        target_stack.position = dest
        self.combat_log.append(f"{hero.name} teleports {target_stack.stats.name}")
        return {"teleported": target_stack, "from": old_pos, "to": dest}

    def _execute_summon(self, spell: Any, hero: Hero, caster_side: Side) -> dict[str, Any]:
        """Summon Elemental: create an elemental stack on the battlefield."""
        from lops.data.creatures import CREATURE_REGISTRY, CreatureType
        from lops.spells import SpellId

        # Map spell to creature type
        elemental_map = {
            SpellId.SUMMON_AIR_ELEMENTAL: CreatureType.AIR_ELEMENTAL,
            SpellId.SUMMON_EARTH_ELEMENTAL: CreatureType.EARTH_ELEMENTAL,
            SpellId.SUMMON_FIRE_ELEMENTAL: CreatureType.FIRE_ELEMENTAL,
            SpellId.SUMMON_WATER_ELEMENTAL: CreatureType.WATER_ELEMENTAL,
        }

        creature_type = elemental_map.get(spell.spell_id)
        if creature_type is None or creature_type not in CREATURE_REGISTRY:
            self.combat_log.append("Summon failed - unknown elemental type!")
            return {}

        stats = CREATURE_REGISTRY[creature_type]
        sp = hero.effective_spell_power() if hero else 1
        count = max(1, sp)

        # Find a free hex near the caster's side
        from lops.hex import BATTLEFIELD_ROWS, OffsetCoord, offset_to_cube

        start_col = 1 if caster_side == Side.ATTACKER else 13
        position = None
        for col_offset in range(15):
            col = (
                start_col + col_offset
                if caster_side == Side.ATTACKER
                else start_col - col_offset
            )
            if col < 0 or col > 14:
                continue
            for row in range(BATTLEFIELD_ROWS):
                pos = offset_to_cube(OffsetCoord(col, row))
                if self.battlefield.is_passable(pos, caster_side):
                    position = pos
                    break
            if position:
                break

        if position is None:
            self.combat_log.append("No space to summon!")
            return {}

        new_stack = CreatureStack(
            stats=stats,
            count=count,
            current_hp=stats.hp,
            position=position,
            side=caster_side,
        )
        new_stack.shots_left = stats.shots

        army = self.battlefield.get_army(caster_side)
        new_stack.slot_index = len(army.stacks)
        army.stacks.append(new_stack)

        self.combat_log.append(f"{hero.name} summons {count} {stats.name}!")
        return {"summoned": new_stack, "targets": [new_stack]}

    def _execute_earthquake(self, spell: Any, hero: Hero) -> dict[str, Any]:
        """Earthquake: damage all walls in siege combat."""
        from lops.spells import calculate_spell_damage

        siege = self.battlefield.siege_info
        if siege is None:
            self.combat_log.append("Earthquake can only be cast during siege!")
            return {}

        damage = calculate_spell_damage(spell, hero)
        walls_hit = 0

        for wall in siege.destructible_walls():
            wall.take_damage(damage)
            walls_hit += 1

        self.combat_log.append(
            f"{hero.name} casts Earthquake! {walls_hit} wall segments damaged!"
        )
        return {"walls_hit": walls_hit}

    def _apply_heal(self, stack: CreatureStack, amount: int) -> int:
        """Heal a stack by amount HP. Cannot exceed original total HP. Returns HP healed."""
        if not stack.alive:
            return 0
        old_hp = stack.current_hp
        max_hp = stack.stats.hp
        # Heal the top creature first
        healed = min(amount, max_hp - stack.current_hp)
        stack.current_hp += healed
        return healed

    def _fire_arrow_towers(self):
        """Siege: each active tower fires at the strongest attacker stack."""
        siege = self.battlefield.siege_info
        if siege is None:
            return
        attacker_stacks = self.battlefield.attacker.alive_stacks
        if not attacker_stacks:
            return
        # Total defender creature count for tower damage scaling
        defender_count = sum(s.count for s in self.battlefield.defender.alive_stacks)
        for tower in siege.active_towers():
            if not attacker_stacks:
                break
            # Target strongest (highest total HP)
            target = max(attacker_stacks, key=lambda s: s.total_hp)
            damage = calculate_tower_damage(defender_count, tower.is_central)
            killed = target.take_damage(damage)
            tower_type = "Central tower" if tower.is_central else "Arrow tower"
            self.combat_log.append(
                f"{tower_type} fires at {target.stats.name} "
                f"for {damage} damage (killed {killed})"
            )
            # Notify callbacks
            action = CombatAction(
                actor=target,
                action_type=ActionType.DEFEND,
            )
            result = {
                "damage": damage,
                "killed": killed,
                "target": target,
                "tower_fire": True,
            }
            for callback in self.on_action:
                callback(action, result)
            # Refresh alive list
            attacker_stacks = self.battlefield.attacker.alive_stacks

    def _fire_catapult(self):
        """Siege: catapult fires at destructible walls. Ballistics improves it."""
        siege = self.battlefield.siege_info
        if siege is None or not siege.has_catapult:
            return

        from lops.skills import SkillId

        atk_hero = self.get_hero(Side.ATTACKER)
        ballistics_level = atk_hero.skill_level(SkillId.BALLISTICS) if atk_hero else 0

        # Ballistics determines shots, targeting, and damage
        shots = 2 if ballistics_level >= 2 else 1
        targeted = ballistics_level >= 1
        damage_per_hit = 2 if ballistics_level >= 3 else 1

        from lops.hex import cube_to_offset

        for _ in range(shots):
            targets = siege.destructible_walls()
            if not targets:
                break
            if targeted:
                wall = min(targets, key=lambda w: w.current_hp)
            else:
                wall = random.choice(targets)
            wall.take_damage(damage_per_hit)
            row = cube_to_offset(wall.position).row
            state_str = wall.state.name.lower()
            self.combat_log.append(
                f"Catapult hits wall (row {row})! {state_str} {wall.current_hp}/{wall.max_hp} HP"
            )

    def run_headless(self, max_rounds: int = 100) -> Side | None:
        """Run combat to completion without any UI, returning the winner.

        Useful for testing and AI simulations.
        """
        from lops.ai.opponent import AIOpponent

        ai_attacker = AIOpponent(self, side=Side.ATTACKER)
        ai_defender = AIOpponent(self, side=Side.DEFENDER)

        if self.phase == CombatPhase.NOT_STARTED:
            self.start_combat()

        while not self.is_over() and self.round_number <= max_rounds:
            if self.current_side() == Side.ATTACKER:
                ai_attacker.take_turn()
            else:
                ai_defender.take_turn()

        return self.winner
