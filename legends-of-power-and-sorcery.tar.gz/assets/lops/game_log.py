"""Game action log: records all player and AI actions to a file for debugging."""

from __future__ import annotations

import time
from pathlib import Path


class GameLog:
    """Append-only log of game actions. Written to a file in real-time."""

    def __init__(self, path: str | Path | None = None):
        if path is None:
            path = Path("game_log.txt")
        self._path = Path(path)
        self._file = None
        try:
            self._file = open(self._path, "w", encoding="utf-8")
        except OSError:
            pass  # WASM / read-only filesystem — log to nowhere
        self._turn = 0
        self._day = 1
        self._start_time = time.monotonic()
        self._write(f"=== Game Log started at {time.strftime('%Y-%m-%d %H:%M:%S')} ===")

    def _write(self, msg: str):
        if self._file is None:
            return
        elapsed = time.monotonic() - self._start_time
        line = f"[{elapsed:7.1f}s] {msg}"
        self._file.write(line + "\n")
        self._file.flush()

    def _player_tag(self, player) -> str:
        if player is None:
            return "[???]"
        kind = "AI" if player.is_ai else "Human"
        # Find any alive hero name, not just the active one
        hero_name = "no-hero"
        try:
            for hs in player.all_alive_heroes():
                hero_name = hs.hero.name
                break
        except Exception:
            if player.hero:
                hero_name = player.hero.name
        return f"[P{player.player_id} {kind} {hero_name}]"

    # --- Game lifecycle ---

    def log_setup(self, seed, player_faction, ai_faction, cols, rows):
        self._write(
            f"SETUP: seed={seed} player={player_faction.name} "
            f"ai={ai_faction.name} map={cols}x{rows}"
        )

    def log_end_turn(self, player, day: int, week: int):
        self._turn += 1
        self._day = day
        self._write(
            f"END_TURN: {self._player_tag(player)} → day={day} week={week} "
            f"(turn #{self._turn})"
        )

    def log_new_day(self, day: int, week: int):
        self._write(f"--- Day {day}, Week {week} ---")

    # --- Movement ---

    def log_move(self, player, destination, event: str | None):
        from lops.hex import cube_to_offset

        oc = cube_to_offset(destination)
        self._write(
            f"MOVE: {self._player_tag(player)} → ({oc.col},{oc.row})"
            f"{f' event={event}' if event else ''}"
        )

    # --- Combat ---

    def log_combat_start(self, attacker, defender_desc: str, is_siege: bool = False):
        kind = "SIEGE" if is_siege else "COMBAT"
        self._write(f"{kind}_START: {self._player_tag(attacker)} vs {defender_desc}")

    def log_combat_end(
        self,
        winner_side,
        attacker,
        defender_desc: str,
        xp_gained: int = 0,
        level_ups: list | None = None,
    ):
        self._write(
            f"COMBAT_END: winner={winner_side.name} "
            f"attacker={self._player_tag(attacker)} vs {defender_desc}"
            f"{f' xp={xp_gained}' if xp_gained else ''}"
            f"{f' level_ups={len(level_ups)}' if level_ups else ''}"
        )

    def log_combat_action(self, stack_name: str, side: str, action_desc: str):
        self._write(f"  COMBAT_ACTION: [{side}] {stack_name}: {action_desc}")

    def on_combat_action_callback(self, action, result):
        """Callback for CombatEngine.on_action — logs each combat action."""
        actor = action.actor
        side = actor.side.name
        name = f"{actor.stats.name} x{actor.count}"
        action_type = action.action_type.name

        if action_type in ("MELEE_ATTACK", "RANGED_ATTACK"):
            target = result.get("target") or action.target
            tgt_name = target.stats.name if target else "?"
            dmg = result.get("damage", 0)
            killed = result.get("killed", 0)
            desc = f"{action_type} → {tgt_name}: {dmg} dmg, {killed} killed"
            if result.get("lucky"):
                desc += " (LUCKY)"
            if result.get("damage2"):
                desc += f" + double strike {result['damage2']} dmg, {result.get('killed2', 0)} killed"
            if result.get("retaliation_damage"):
                desc += f" | retaliation {result['retaliation_damage']} dmg, {result.get('retaliation_killed', 0)} killed"
            if result.get("morale_bonus"):
                desc += " → MORALE BONUS (extra turn)"
            self.log_combat_action(name, side, desc)
        elif action_type == "CAST_SPELL":
            spell = (
                getattr(action.spell, "name", str(action.spell))
                if action.spell
                else "?"
            )
            targets = result.get("targets", [])
            tgt_names = ", ".join(t.stats.name for t in targets) if targets else "?"
            desc = f"CAST {spell} → {tgt_names}"
            if result.get("damage"):
                desc += f" ({result['damage']} dmg)"
            self.log_combat_action(name, side, desc)
        elif action_type == "WAIT":
            self.log_combat_action(name, side, "WAIT")
        elif action_type == "DEFEND":
            self.log_combat_action(name, side, "DEFEND")
        elif action_type == "MOVE":
            self.log_combat_action(name, side, "MOVE")

    # --- Town ---

    def log_recruit(self, player, creature_name: str, count: int, cost: int):
        self._write(
            f"RECRUIT: {self._player_tag(player)} {creature_name} x{count} for {cost}g"
        )

    def log_build(self, player, building_name: str, cost: int):
        self._write(f"BUILD: {self._player_tag(player)} {building_name} for {cost}g")

    def log_upgrade_creature(
        self, player, old_name: str, new_name: str, count: int, cost: int
    ):
        self._write(
            f"UPGRADE: {self._player_tag(player)} {old_name} x{count} → "
            f"{new_name} for {cost}g"
        )

    def log_hire_hero(self, player, hero_name: str):
        self._write(f"HIRE_HERO: {self._player_tag(player)} hired {hero_name}")

    def log_buy_artifact(self, player, artifact_name: str, cost: int):
        self._write(
            f"BUY_ARTIFACT: {self._player_tag(player)} {artifact_name} for {cost}g"
        )

    def log_garrison_transfer(
        self, player, creature_name: str, count: int, direction: str
    ):
        self._write(
            f"GARRISON: {self._player_tag(player)} {direction} {creature_name} x{count}"
        )

    # --- Map events ---

    def log_treasure_chest(self, player, choice: str, amount: int):
        self._write(f"CHEST: {self._player_tag(player)} chose {choice} ({amount})")

    def log_capture_town(self, player, town_name: str):
        self._write(f"CAPTURE_TOWN: {self._player_tag(player)} captured {town_name}")

    def log_pickup(self, player, what: str):
        self._write(f"PICKUP: {self._player_tag(player)} {what}")

    def log_mine_captured(self, player, mine_name: str):
        self._write(f"MINE: {self._player_tag(player)} captured {mine_name}")

    # --- AI decisions ---

    def log_ai_decision(self, player, decision: str):
        self._write(f"AI: {self._player_tag(player)} {decision}")

    # --- Player defeat / victory ---

    def log_defeat(self, player):
        self._write(f"DEFEAT: {self._player_tag(player)} eliminated")

    def log_victory(self, player):
        self._write(f"VICTORY: {self._player_tag(player)} wins!")

    # --- Level up ---

    def log_level_up(self, player, level: int, stat: str, skill: str | None):
        skill_str = f", learned {skill}" if skill else ""
        self._write(
            f"LEVEL_UP: {self._player_tag(player)} → level {level}, "
            f"+1 {stat}{skill_str}"
        )

    # --- Generic ---

    def log(self, msg: str):
        self._write(msg)

    def close(self):
        self._write("=== Game Log ended ===")
        if self._file is not None:
            self._file.close()
