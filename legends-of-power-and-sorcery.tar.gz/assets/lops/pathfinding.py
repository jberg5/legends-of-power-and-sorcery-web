"""BFS movement range and A* shortest path on hex grid."""

from __future__ import annotations

import heapq
from collections import deque

from lops.hex import (
    CubeCoord,
    cube_distance,
    cube_neighbors,
    cube_to_offset,
    is_valid_battlefield_pos,
)
from lops.models import Battlefield, CreatureStack
from lops.siege import WALL_COL


def movement_range(
    stack: CreatureStack,
    battlefield: Battlefield,
) -> dict[CubeCoord, int]:
    """BFS to find all reachable hexes within movement speed.

    Returns dict mapping reachable position -> cost to reach it.
    Flying units ignore obstacles (but not other stacks as destinations).
    """
    if stack.position is None:
        return {}

    speed = stack.effective_speed
    is_flying = stack.stats.is_flying

    visited: dict[CubeCoord, int] = {stack.position: 0}
    queue: deque[tuple[CubeCoord, int]] = deque([(stack.position, 0)])

    # Siege info for moat/wall checks
    siege = battlefield.siege_info if battlefield.is_siege else None
    moat_hexes = siege.moat_hexes if siege else set()

    while queue:
        pos, cost = queue.popleft()
        if cost >= speed:
            continue

        # Moat stops ground movement (can enter but not continue)
        if not is_flying and pos in moat_hexes and pos != stack.position:
            continue

        for neighbor in cube_neighbors(pos):
            if not is_valid_battlefield_pos(neighbor):
                continue
            if neighbor in visited:
                continue

            new_cost = cost + 1

            # Check passability
            if is_flying:
                # Flying units can pass over obstacles and other stacks,
                # but can't land on them
                occupant = battlefield.stack_at(neighbor)
                if occupant is not None:
                    continue  # can't land on another stack
                if neighbor in battlefield.obstacles:
                    continue  # can't land on obstacle
                # Flying can traverse intact wall hexes but not land on them
                if siege and siege.is_wall_blocking(neighbor, stack.side):
                    continue
            else:
                if not battlefield.is_passable(neighbor, stack.side):
                    continue

            visited[neighbor] = new_cost
            queue.append((neighbor, new_cost))

    # Remove starting position from results
    visited.pop(stack.position, None)
    return visited


def find_path(
    start: CubeCoord,
    goal: CubeCoord,
    battlefield: Battlefield,
    is_flying: bool = False,
    side=None,
) -> list[CubeCoord] | None:
    """A* pathfinding from start to goal.

    Returns list of positions from start to goal (inclusive), or None if no path.
    """
    if start == goal:
        return [start]

    siege = battlefield.siege_info if battlefield.is_siege else None

    open_set: list[tuple[int, int, CubeCoord]] = []
    counter = 0
    heapq.heappush(open_set, (0, counter, start))
    came_from: dict[CubeCoord, CubeCoord] = {}
    g_score: dict[CubeCoord, int] = {start: 0}

    while open_set:
        _, _, current = heapq.heappop(open_set)

        if current == goal:
            # Reconstruct path
            path = [current]
            while current in came_from:
                current = came_from[current]
                path.append(current)
            path.reverse()
            return path

        for neighbor in cube_neighbors(current):
            if not is_valid_battlefield_pos(neighbor):
                continue

            # Goal is always reachable (we might be pathing to an adjacent hex)
            if neighbor != goal:
                if is_flying:
                    if neighbor in battlefield.obstacles:
                        continue
                    occupant = battlefield.stack_at(neighbor)
                    if occupant is not None:
                        continue
                    # Flying can't land on blocking walls
                    if siege and siege.is_wall_blocking(neighbor, side):
                        continue
                else:
                    if not battlefield.is_passable(neighbor, side):
                        continue

            tentative_g = g_score[current] + 1
            if tentative_g < g_score.get(neighbor, float("inf")):
                came_from[neighbor] = current
                g_score[neighbor] = tentative_g
                f_score = tentative_g + cube_distance(neighbor, goal)
                counter += 1
                heapq.heappush(open_set, (f_score, counter, neighbor))

    return None


def get_attack_positions(
    attacker: CreatureStack,
    target: CreatureStack,
    battlefield: Battlefield,
) -> list[CubeCoord]:
    """Get hexes adjacent to target that the attacker can reach for melee."""
    if target.position is None:
        return []

    reachable = movement_range(attacker, battlefield)
    adjacent = cube_neighbors(target.position)

    positions = []
    for adj in adjacent:
        if adj == attacker.position:
            positions.append(adj)  # already adjacent
        elif adj in reachable:
            positions.append(adj)

    return positions


def crosses_wall(attacker_pos: CubeCoord, target_pos: CubeCoord) -> bool:
    """Check if attacker and target are on opposite sides of the wall column."""
    a_col = cube_to_offset(attacker_pos).col
    t_col = cube_to_offset(target_pos).col
    return (a_col < WALL_COL) != (t_col < WALL_COL)
