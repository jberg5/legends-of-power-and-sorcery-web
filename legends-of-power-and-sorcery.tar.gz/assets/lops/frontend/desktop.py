"""Desktop frontend — wraps existing renderer and input modules."""

from __future__ import annotations

import pygame

from lops.input.adventure_input import AdventureInputHandler
from lops.input.handler import InputHandler
from lops.renderer.adventure_renderer import AdventureRenderer
from lops.renderer.adventure_ui import AdventureUI
from lops.renderer.core import GameRenderer
from lops.renderer.hero_modal import HeroModal
from lops.renderer.sidebar import SidebarPanel
from lops.renderer.town_screen import TownScreen
from lops.renderer.welcome_screen import WelcomeScreen


class DesktopFrontend:
    """Provides factory methods for all desktop renderer/input components."""

    viewport_w: int = 1024
    sidebar_w: int = 256
    screen_h: int = 720

    def __init__(self, screen: pygame.Surface) -> None:
        self.screen = screen

    def create_welcome_screen(self) -> WelcomeScreen:
        return WelcomeScreen(self.screen)

    def create_adventure_renderer(self, world_map, *, layered_map=None) -> AdventureRenderer:
        return AdventureRenderer(
            self.screen, world_map, viewport_w=self.viewport_w,
            layered_map=layered_map,
        )

    def create_adventure_ui(self) -> AdventureUI:
        return AdventureUI(self.screen, viewport_w=self.viewport_w)

    def create_sidebar(self, world_map, *, layered_map=None) -> SidebarPanel | None:
        if self.sidebar_w > 0:
            return SidebarPanel(
                self.screen, x=self.viewport_w, width=self.sidebar_w,
                world_map=world_map, layered_map=layered_map,
            )
        return None

    def create_town_screen(self) -> TownScreen:
        return TownScreen(self.screen)

    def create_hero_modal(self) -> HeroModal:
        return HeroModal(self.screen)

    def create_combat_renderer(self, engine, *, player_side=None) -> GameRenderer:
        kwargs = {}
        if player_side is not None:
            kwargs["player_side"] = player_side
        return GameRenderer(self.screen, engine, **kwargs)

    def create_combat_input(self, engine, renderer, *, player_side=None) -> InputHandler:
        kwargs = {}
        if player_side is not None:
            kwargs["player_side"] = player_side
        return InputHandler(engine, renderer, **kwargs)

    def create_adventure_input(self, director, renderer, ui, *, anim_state=None) -> AdventureInputHandler:
        return AdventureInputHandler(director, renderer, ui, anim_state=anim_state)
