"""Mobile frontend — touch-friendly renderers and input handlers.

Reuses desktop renderers for the heavy lifting (hex grid, creatures,
animations) but swaps in mobile-specific UI overlays and touch input.
"""

from __future__ import annotations

import pygame

from lops.input_mobile.adventure_input import MobileAdventureInput
from lops.input_mobile.handler import MobileCombatInput
from lops.renderer.adventure_renderer import AdventureRenderer
from lops.renderer.core import GameRenderer
from lops.renderer.hero_modal import HeroModal
from lops.renderer.sidebar import SidebarPanel
from lops.renderer.town_screen import TownScreen
from lops.renderer.welcome_screen import WelcomeScreen
from lops.renderer_mobile.adventure_ui import MobileAdventureUI


class MobileFrontend:
    """Provides factory methods for mobile renderer/input components."""

    sidebar_w: int = 0  # sidebar is overlay, not in layout
    screen_h: int

    def __init__(self, screen: pygame.Surface, viewport_w: int, screen_h: int) -> None:
        self.screen = screen
        self.viewport_w = viewport_w
        self.screen_h = screen_h

        # Track mobile combat input for button drawing
        self._combat_input: MobileCombatInput | None = None

    def create_welcome_screen(self) -> WelcomeScreen:
        return WelcomeScreen(self.screen)

    def create_adventure_renderer(self, world_map, *, layered_map=None) -> AdventureRenderer:
        return AdventureRenderer(
            self.screen, world_map, viewport_w=self.viewport_w,
            layered_map=layered_map,
        )

    def create_adventure_ui(self) -> MobileAdventureUI:
        return MobileAdventureUI(self.screen, viewport_w=self.viewport_w)

    def create_sidebar(self, world_map, *, layered_map=None) -> SidebarPanel | None:
        # Create sidebar positioned as right-edge overlay (not in layout).
        # MobileAdventureUI manages its visibility via toggle button.
        sidebar_w = 256
        x = self.viewport_w - sidebar_w
        return SidebarPanel(
            self.screen, x=x, width=sidebar_w,
            world_map=world_map, layered_map=layered_map,
        )

    def create_town_screen(self) -> TownScreen:
        return TownScreen(self.screen)

    def create_hero_modal(self) -> HeroModal:
        return HeroModal(self.screen)

    def create_combat_renderer(self, engine, *, player_side=None) -> GameRenderer:
        kwargs = {}
        if player_side is not None:
            kwargs["player_side"] = player_side
        return GameRenderer(self.screen, engine, **kwargs)

    def create_combat_input(self, engine, renderer, *, player_side=None) -> MobileCombatInput:
        kwargs = {}
        if player_side is not None:
            kwargs["player_side"] = player_side
        ci = MobileCombatInput(engine, renderer, **kwargs)
        self._combat_input = ci
        return ci

    def create_adventure_input(self, director, renderer, ui, *, anim_state=None) -> MobileAdventureInput:
        return MobileAdventureInput(
            director, renderer, ui, anim_state=anim_state,
        )
