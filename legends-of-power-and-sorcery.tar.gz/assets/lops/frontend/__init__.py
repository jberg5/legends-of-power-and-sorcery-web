"""Frontend abstraction layer for desktop and mobile rendering."""
