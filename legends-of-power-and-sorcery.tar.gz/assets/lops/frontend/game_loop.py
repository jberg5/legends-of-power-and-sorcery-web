"""Main game loop — extracted from main.py.

Receives a frontend object that provides factory methods for renderers and
input handlers.  The loop logic (mode transitions, AI turns, animation,
event routing) is frontend-agnostic.
"""

from __future__ import annotations

import asyncio

import pygame

from lops.adventure.game_director import GameDirector, GameMode
from lops.adventure.map_objects import (
    TownSite,
    TreasureChest,
    WanderingMonster,
)
from lops.adventure.movement_anim import AdventureAnimState, AnimSpeed
from lops.ai.opponent import AIOpponent
from lops.game_log import GameLog
from lops.models import Side


class GameLoop:
    """Drives the main event loop using a pluggable frontend."""

    def __init__(self, screen: pygame.Surface, frontend) -> None:
        self.screen = screen
        self.frontend = frontend

        self.game_log = GameLog()
        self.director = GameDirector()
        self.director.game_log = self.game_log
        self.director.mode = GameMode.WELCOME
        self.welcome_screen = frontend.create_welcome_screen()

        # Initialized after faction selection
        self.adv_renderer = None
        self.adv_ui = None
        self.town_screen = None
        self.sidebar = None
        self.anim_state = None
        self.adv_input = None
        self.hero_modal = None

        # Combat renderer/input (created on demand)
        self.combat_renderer = None
        self.combat_input = None
        self.combat_ai = None
        self.combat_end_timer = 0.0

    def _init_adventure(self) -> None:
        """Initialize adventure UI after faction selection and game setup."""
        fe = self.frontend
        d = self.director
        self.adv_renderer = fe.create_adventure_renderer(
            d.world_map, layered_map=d.layered_map,
        )
        self.adv_ui = fe.create_adventure_ui()
        self.town_screen = fe.create_town_screen()
        self.sidebar = fe.create_sidebar(
            d.world_map, layered_map=d.layered_map,
        )
        self.anim_state = AdventureAnimState()
        self.adv_input = fe.create_adventure_input(
            d, self.adv_renderer, self.adv_ui, anim_state=self.anim_state,
        )
        self.hero_modal = fe.create_hero_modal()
        player = d.adventure_state.players[0]
        self.adv_renderer.center_on_hex(player.position)

    async def run(self) -> None:
        """Run the game loop until the user quits."""
        clock = pygame.time.Clock()
        running = True

        while running:
            dt = clock.tick(60) / 1000.0

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    break
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    if self.director.mode == GameMode.WELCOME:
                        running = False
                        break
                    elif self.director.mode == GameMode.COMBAT:
                        pass  # no escape from combat
                    elif self.director.mode == GameMode.TOWN_SCREEN:
                        self.director.close_town_screen()
                        self.adv_input.refresh_move_range()
                    elif self.director.mode == GameMode.HERO_MODAL:
                        self.director.close_hero_modal()
                        self.adv_input.refresh_move_range()
                    else:
                        running = False
                        break

                if self.director.mode == GameMode.WELCOME:
                    if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                        result = self.welcome_screen.handle_click(event.pos)
                        if result is not None and hasattr(result, "faction"):
                            self.director.setup_new_game(
                                seed=42,
                                player_faction=result.faction,
                                map_cols=result.map_size.cols,
                                map_rows=result.map_size.rows,
                                difficulty=result.difficulty,
                            )
                            self._init_adventure()
                    continue

                if self.director.mode == GameMode.HERO_MODAL:
                    self._handle_hero_modal_event(event)

                elif self.director.mode == GameMode.ADVENTURE:
                    running = self._handle_adventure_event(event, running)

                elif self.director.mode == GameMode.COMBAT:
                    if self.combat_input:
                        self.combat_input.handle_event(event)

                elif self.director.mode == GameMode.TOWN_SCREEN:
                    self._handle_town_screen_event(event)

            if not running:
                break

            # --- Update ---
            if self.director.mode == GameMode.ADVENTURE:
                self._update_adventure(dt)

            elif self.director.mode == GameMode.COMBAT:
                self._update_combat(dt)

            # --- Draw ---
            self._draw()

            pygame.display.flip()
            await asyncio.sleep(0)

        self.game_log.close()
        pygame.quit()

    # ------------------------------------------------------------------
    # Event handling helpers
    # ------------------------------------------------------------------

    def _handle_hero_modal_event(self, event) -> None:
        if event.type == pygame.MOUSEWHEEL:
            self.hero_modal.handle_scroll(event.y)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            human = self.director.adventure_state.players[0]
            hs = human.active_hero_state
            if hs:
                result = self.hero_modal.handle_click(event.pos, hs.hero)
                if result == "-1":
                    self.director.close_hero_modal()
                    self.adv_input.refresh_move_range()

    def _handle_adventure_event(self, event, running: bool) -> bool:
        fe = self.frontend
        # Sidebar scroll
        if (
            self.sidebar is not None
            and event.type == pygame.MOUSEWHEEL
            and pygame.mouse.get_pos()[0] >= fe.viewport_w
        ):
            self.sidebar.handle_scroll(event.y)
        # Route clicks: sidebar vs map
        elif (
            self.sidebar is not None
            and event.type == pygame.MOUSEBUTTONDOWN
            and event.button == 1
            and event.pos[0] >= fe.viewport_w
        ):
            if not self.anim_state.is_animating:
                sidebar_result = self.sidebar.handle_click(
                    event.pos, self.director.adventure_state
                )
                if sidebar_result == "layer_toggle":
                    pass  # toggle already handled in sidebar
                elif sidebar_result == "minimap_click":
                    hex_pos = self.sidebar.minimap_to_world_hex(event.pos)
                    if hex_pos is not None:
                        self.adv_renderer.center_on_hex(hex_pos)
                elif sidebar_result and sidebar_result.startswith("hero_select:"):
                    hero_idx = int(sidebar_result.split(":")[1])
                    human = self.director.adventure_state.players[0]
                    self.adv_input._select_hero(human, hero_idx)
                elif sidebar_result and sidebar_result.startswith("town_click:"):
                    tid = int(sidebar_result.split(":")[1])
                    for obj in self.director.adventure_state.map_objects:
                        if isinstance(obj, TownSite) and id(obj) == tid:
                            self.adv_renderer.center_on_hex(obj.position)
                            self.director.open_town_screen(obj)
                            break
        else:
            result = self.adv_input.handle_event(event)
            if result == "combat":
                self._create_combat(self.director.combat_engine)
            elif result == "quit":
                return False
        return running

    def _handle_town_screen_event(self, event) -> None:
        if event.type == pygame.MOUSEWHEEL:
            self.town_screen.handle_scroll(event.y)
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.town_screen.handle_mouse_up()
            self.town_screen.handle_marketplace_mouse_up()
        elif event.type == pygame.MOUSEMOTION:
            self.town_screen.handle_mouse_motion(event.pos)
            if self.director.active_town and self.director.active_town.town:
                _mp = self.director.adventure_state.current_player
                self.town_screen.handle_marketplace_mouse_motion(event.pos, _mp)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            # Check scrollbar drag first
            if self.town_screen.handle_mouse_down(event.pos):
                pass  # scrollbar consumed the click
            elif (
                self.director.active_town
                and self.director.active_town.town
                and self.town_screen.handle_marketplace_mouse_down(
                    event.pos,
                    self.director.adventure_state.current_player,
                )
            ):
                pass  # marketplace slider consumed the click
            elif self.director.active_town and self.director.active_town.town:
                town = self.director.active_town.town
                player = self.director.adventure_state.current_player
                from lops.adventure.buildings import BuildingId

                _hat = self.director._hero_at_town(self.director.active_town)
                self.town_screen.hero_at_town = _hat is not None
                self.town_screen.hero_at_town_army = _hat.army if _hat else None
                self.town_screen.has_tavern = BuildingId.TAVERN in town.buildings
                self.town_screen.has_merchant = (
                    BuildingId.ARTIFACT_MERCHANT in town.buildings
                )
                self.town_screen.has_marketplace = (
                    BuildingId.MARKETPLACE in town.buildings
                )
                self.town_screen.marketplace_count = (
                    self.director.get_marketplace_count(player)
                )
                result = self.town_screen.handle_click(event.pos, town, player)
                if result == -1:
                    self.director.close_town_screen()
                    self.adv_input.refresh_move_range()
                elif isinstance(result, str) and result.startswith("upgrade:"):
                    army_slot = int(result.split(":")[1])
                    self.director.upgrade_creature_at_town(army_slot)
                elif isinstance(result, str) and result.startswith("buy_artifact:"):
                    art_idx = int(result.split(":")[1])
                    self.director.buy_artifact(art_idx)
                elif isinstance(result, str) and result.startswith("hire_hero:"):
                    hero_idx = int(result.split(":")[1])
                    self.director.hire_hero(self.director.active_town, hero_idx)
                    self.adv_input.refresh_move_range()
                elif isinstance(result, str) and result.startswith("garrison_to:"):
                    parts = result.split(":")
                    slot = int(parts[1])
                    count = int(parts[2]) if len(parts) > 2 else None
                    self.director.transfer_to_garrison(slot, count)
                elif isinstance(result, str) and result.startswith("garrison_from:"):
                    parts = result.split(":")
                    slot = int(parts[1])
                    count = int(parts[2]) if len(parts) > 2 else None
                    self.director.transfer_from_garrison(slot, count)
                elif isinstance(result, str) and result.startswith("trade:"):
                    parts = result.split(":")
                    self.director.execute_trade(
                        player, parts[1], parts[2], int(parts[3])
                    )
                elif isinstance(result, int) and result >= 0:
                    dwelling = town.dwellings[result]
                    unit_cost = dwelling.active_cost_per_unit
                    max_afford = player.gold // unit_cost
                    count = min(dwelling.available, max_afford)
                    self.director.recruit_from_town(result, count)
                elif result is not None:
                    self.director.build_in_town(result)

    # ------------------------------------------------------------------
    # Update helpers
    # ------------------------------------------------------------------

    def _update_adventure(self, dt: float) -> None:
        self.adv_renderer.update(dt)
        self.adv_ui.update(dt)
        self.adv_input.update()

        # --- Animation update ---
        if self.anim_state.is_animating:
            self._update_adventure_animation(dt)

        # AI turn (not animating)
        elif not self.anim_state.is_animating:
            self._update_ai_turn()

    def _update_adventure_animation(self, dt: float) -> None:
        entered_hex = self.anim_state.update(dt)
        anim = self.anim_state.active

        # Incremental fog reveal
        if entered_hex is not None and anim is not None:
            anim.player.reveal_around(entered_hex)

        # Camera follows animated hero
        if anim is not None:
            should_follow = True
            if anim.player.is_ai:
                human = self.director.adventure_state.players[0]
                cur_hex = anim.hex_path[anim.current_step]
                should_follow = cur_hex in human.revealed
            if should_follow:
                wx, wy = anim.current_world_pos
                self.adv_renderer.camera.center_on_world(wx, wy)

        # Animation finished — apply move and resolve event
        if anim is not None and anim.finished:
            self._resolve_animation_finished(anim)

    def _resolve_animation_finished(self, anim) -> None:
        dest = anim.destination
        pending = anim.pending_event
        anim_player = anim.player
        _anim_hs = anim_player.active_hero_state
        _anim_layer = _anim_hs.layer if _anim_hs else 0
        self.anim_state.clear()

        resolved = self.director.apply_move(anim_player, dest, pending)

        if resolved == "treasure_chest":
            self._resolve_treasure_chest(anim_player, dest, _anim_layer)
        elif resolved == "artifact":
            self.adv_ui.set_status(self.director.last_event_description)
            self.adv_input.refresh_move_range()
        elif resolved == "resource":
            self.adv_ui.set_status(self.director.last_event_description)
            self.adv_input.refresh_move_range()
        elif resolved == "mine_captured":
            self.adv_ui.set_status(self.director.last_event_description)
            self.adv_input.refresh_move_range()
        elif resolved == "monster":
            self._resolve_monster(anim_player, dest, _anim_layer)
        elif resolved == "own_town":
            self._resolve_own_town(anim_player, dest, _anim_layer)
        elif resolved in ("enemy_town", "neutral_town"):
            self._resolve_enemy_town(anim_player, dest, _anim_layer)
        elif resolved == "enemy_hero":
            self._resolve_enemy_hero(anim_player, dest)
        elif resolved == "campfire":
            self.adv_ui.set_status(self.director.last_event_description)
            self.adv_input.refresh_move_range()
            if anim_player.is_ai:
                self._ai_end_turn()
        elif resolved == "stat_booster":
            obj = self.director.adventure_state.find_object_at(dest, layer=_anim_layer)
            if obj and hasattr(obj, "name"):
                self.adv_ui.set_status(self.director.last_event_description)
            self.adv_input.refresh_move_range()
            if anim_player.is_ai:
                self._ai_end_turn()
        elif resolved == "arena":
            if anim_player.is_ai:
                h = anim_player.hero
                choice = "attack" if h.attack <= h.defense else "defense"
                self.director.resolve_arena(anim_player, choice)
                self.director.end_turn()
                self.adv_input.refresh_move_range()
                if not self.director.adventure_state.game_over:
                    self.adv_renderer.center_on_hex(
                        self.director.adventure_state.current_player.position
                    )
            else:
                self.adv_ui.show_arena_dialog()
        elif resolved == "magic_well":
            self.adv_ui.set_status(self.director.last_event_description)
            self.adv_input.refresh_move_range()
            if anim_player.is_ai:
                self._ai_end_turn()
        elif resolved in ("pandora_guarded", "creature_bank"):
            self._resolve_guarded_object(anim_player, dest, _anim_layer)
        elif resolved == "pandora_unguarded":
            self.adv_ui.set_status(self.director.last_event_description)
            self.adv_input.refresh_move_range()
            if anim_player.is_ai:
                self._ai_end_turn()
        elif resolved == "dwelling_visit":
            self._resolve_dwelling_visit(anim_player, dest, _anim_layer)
        elif resolved == "hill_fort":
            if anim_player.is_ai:
                for i in range(7):
                    self.director.upgrade_creature_at_hill_fort(anim_player, i)
                self._ai_end_turn()
            else:
                self.adv_ui.show_hill_fort_dialog()
        elif resolved == "gate":
            self.adv_ui.set_status(self.director.last_event_description)
            self.adv_input.refresh_move_range()
            hs_gate = (anim_player.active_hero_state
                       if not anim_player.is_ai else None)
            if hs_gate and hs_gate.position:
                if self.sidebar is not None:
                    self.sidebar.minimap_layer = hs_gate.layer
                self.adv_renderer.center_on_hex(hs_gate.position)
            if anim_player.is_ai:
                self._ai_end_turn()
        elif resolved == "library_too_low":
            self.adv_ui.set_status(self.director.last_event_description)
            self.adv_input.refresh_move_range()
        else:
            # No special event — just finished moving
            if anim_player.is_ai:
                self._ai_end_turn()
            else:
                self.adv_input.refresh_move_range()

    def _resolve_treasure_chest(self, anim_player, dest, layer: int) -> None:
        obj = self.director.adventure_state.find_object_at(dest, layer=layer)
        if isinstance(obj, TreasureChest) and not anim_player.is_ai:
            if obj.is_artifact:
                art_name = ""
                if obj.artifact_id is not None:
                    from lops.data.artifacts import ARTIFACT_REGISTRY
                    art_name = ARTIFACT_REGISTRY[obj.artifact_id].name
                self.adv_ui.show_chest_dialog(
                    obj.gold_amount, obj.xp_amount,
                    is_artifact=True, artifact_name=art_name,
                )
            else:
                self.adv_ui.show_chest_dialog(obj.gold_amount, obj.xp_amount)
        elif isinstance(obj, TreasureChest) and anim_player.is_ai:
            self.director.resolve_treasure_chest(anim_player, "gold")
            self._ai_end_turn()

    def _resolve_monster(self, anim_player, dest, layer: int) -> None:
        obj = self.director.adventure_state.find_object_at(dest, layer=layer)
        if isinstance(obj, WanderingMonster):
            if anim_player.is_ai:
                self.director._run_ai_combat(anim_player, obj)
                self._ai_end_turn()
            else:
                self.director.start_monster_combat(anim_player, obj)
                self._create_combat(self.director.combat_engine)

    def _resolve_own_town(self, anim_player, dest, layer: int) -> None:
        if not anim_player.is_ai:
            obj = self.director.adventure_state.find_object_at(dest, layer=layer)
            if isinstance(obj, TownSite):
                self.director.open_town_screen(obj)
        else:
            ai_ctrl = self.director._ai_controllers.get(anim_player.player_id)
            if ai_ctrl:
                ai_ctrl.auto_recruit()
                ai_ctrl.auto_pickup_garrison()
            self._ai_end_turn()

    def _resolve_enemy_town(self, anim_player, dest, layer: int) -> None:
        obj = self.director.adventure_state.find_object_at(dest, layer=layer)
        if not isinstance(obj, TownSite):
            return
        if anim_player.is_ai:
            town = obj.town
            has_fort = town and self.director._get_fort_level(town) is not None
            _dp, _dh = self.director._find_defender_at_town(obj, anim_player)
            has_defenders = town and (town.garrison or _dh is not None)
            if has_fort and has_defenders:
                defending_human = self.director._town_has_human_defender(
                    obj, anim_player
                )
                self.director.start_siege_combat(anim_player, obj)
                if self.director.combat_engine and defending_human:
                    self._create_combat(
                        self.director.combat_engine,
                        player_side=Side.DEFENDER,
                        ai_side=Side.ATTACKER,
                    )
                elif self.director.combat_engine:
                    self.director.combat_engine.run_headless()
                    self.director.on_combat_finished()
                    self._ai_end_turn()
            else:
                self.director.capture_town(anim_player, obj)
                self._ai_end_turn()
        else:
            town = obj.town
            has_fort = town and self.director._get_fort_level(town) is not None
            def_player, def_hs = self.director._find_defender_at_town(
                obj, anim_player
            )
            has_defenders = town and (town.garrison or def_hs is not None)
            if has_fort and has_defenders:
                self.director.start_siege_combat(anim_player, obj)
                self._create_combat(self.director.combat_engine)
            else:
                self.director.capture_town(anim_player, obj)
                self.adv_ui.set_status(f"Captured {obj.name}!")
                self.adv_input.refresh_move_range()

    def _resolve_enemy_hero(self, anim_player, dest) -> None:
        if anim_player.is_ai:
            for other in self.director.adventure_state.players:
                if other.player_id != anim_player.player_id and not other.defeated:
                    if other.hero_at(dest) is not None:
                        if not other.is_ai:
                            self.director.start_hero_combat(
                                anim_player, other, dest
                            )
                            self._create_combat(
                                self.director.combat_engine,
                                player_side=Side.DEFENDER,
                                ai_side=Side.ATTACKER,
                            )
                        else:
                            self.director._run_ai_hero_combat(
                                anim_player, other, dest
                            )
                            self._ai_end_turn()
                        break
        else:
            for other in self.director.adventure_state.players:
                if other.player_id != anim_player.player_id and not other.defeated:
                    if other.hero_at(dest) is not None:
                        self.director.start_hero_combat(
                            anim_player, other, dest
                        )
                        self._create_combat(self.director.combat_engine)
                        break

    def _resolve_guarded_object(self, anim_player, dest, layer: int) -> None:
        from lops.adventure.map_objects import CreatureBank, PandorasBox

        obj = self.director.adventure_state.find_object_at(dest, layer=layer)
        if obj and (isinstance(obj, PandorasBox) or isinstance(obj, CreatureBank)):
            if anim_player.is_ai:
                self.director._run_ai_combat(anim_player, obj)
                self._ai_end_turn()
            else:
                self.director.start_monster_combat(anim_player, obj)
                self._create_combat(self.director.combat_engine)

    def _resolve_dwelling_visit(self, anim_player, dest, layer: int) -> None:
        if anim_player.is_ai:
            from lops.adventure.map_objects import CreatureDwelling

            obj = self.director.adventure_state.find_object_at(dest, layer=layer)
            if isinstance(obj, CreatureDwelling) and obj.available > 0:
                self.director.recruit_from_dwelling(anim_player, obj.available)
            self._ai_end_turn()
        else:
            self.adv_ui.show_dwelling_dialog()

    def _update_ai_turn(self) -> None:
        current = self.director.adventure_state.current_player
        if (
            current.is_ai
            and not current.defeated
            and not self.director.adventure_state.game_over
        ):
            if self.anim_state.speed == AnimSpeed.INSTANT:
                ai_event = self.director.run_ai_turn()
                if ai_event == "combat":
                    self._create_combat(
                        self.director.combat_engine,
                        player_side=Side.DEFENDER,
                        ai_side=Side.ATTACKER,
                    )
                else:
                    self._ai_end_turn()
            else:
                # Animated AI turn
                result = self.director.prepare_ai_turn()
                if result is not None:
                    hex_path, event = result
                    pixel_path = [
                        self.adv_renderer.hex_world_center(h) for h in hex_path
                    ]
                    ai_player = self.director.adventure_state.current_player
                    hs = ai_player.active_hero_state
                    self.anim_state.start_move(
                        hs, ai_player, hex_path, pixel_path, event
                    )
                else:
                    self._ai_end_turn()

    def _update_combat(self, dt: float) -> None:
        if not self.combat_renderer:
            return
        self.combat_renderer.update(dt)
        self.combat_input.update()

        # Sync auto-combat flag to renderer for UI display
        self.combat_renderer.auto_combat = self.combat_input.auto_combat

        # AI takes actions (enemy AI + player auto-battle)
        engine = self.director.combat_engine
        if engine and not engine.is_over() and not self.combat_renderer.is_animating:
            current_side = engine.current_side()
            if self.combat_ai and current_side == self.combat_ai.side:
                self.combat_ai.take_turn()
            elif (
                self.combat_input.auto_combat
                and current_side == self.combat_input.player_side
            ):
                auto_ai = AIOpponent(engine, side=self.combat_input.player_side)
                auto_ai.take_turn()

        # Check if combat is over
        if engine and engine.is_over() and not self.combat_renderer.is_animating:
            if self.combat_end_timer <= 0:
                self.combat_end_timer = 2.0
            else:
                self.combat_end_timer -= dt
                if self.combat_end_timer <= 0:
                    self._finish_combat()

    def _finish_combat(self) -> None:
        ai_was_attacker = (
            self.combat_ai is not None
            and self.combat_ai.side == Side.ATTACKER
        )
        self.director.on_combat_finished()
        # Show reward + level-up messages
        status_parts = []
        if self.director.last_event_description:
            status_parts.append(self.director.last_event_description)
        if self.director._pending_level_ups:
            from lops.experience import format_level_up

            msgs = [format_level_up(r) for r in self.director._pending_level_ups]
            status_parts.extend(msgs)
            self.director._pending_level_ups = None
        if status_parts:
            self.adv_ui.set_status(" | ".join(status_parts), 4.0)
        self.combat_renderer = None
        self.combat_input = None
        self.combat_ai = None
        self.combat_end_timer = 0.0
        if ai_was_attacker:
            current = self.director.adventure_state.current_player
            if current.is_ai and not current.defeated:
                self.director.end_turn()
        self.adv_input.refresh_move_range()
        if not self.director.adventure_state.game_over:
            self.adv_renderer.center_on_hex(
                self.director.adventure_state.current_player.position
            )

    # ------------------------------------------------------------------
    # Drawing
    # ------------------------------------------------------------------

    def _draw(self) -> None:
        if self.director.mode == GameMode.WELCOME:
            self.welcome_screen.draw()

        elif self.director.mode == GameMode.ADVENTURE:
            self._draw_adventure()

        elif self.director.mode == GameMode.COMBAT:
            if self.combat_renderer:
                self.combat_renderer.draw()

        elif self.director.mode == GameMode.TOWN_SCREEN:
            self._draw_adventure()
            if self.director.active_town and self.director.active_town.town:
                player = self.director.adventure_state.current_player
                _hat2 = self.director._hero_at_town(self.director.active_town)
                self.town_screen.hero_at_town = _hat2 is not None
                self.town_screen.hero_at_town_army = _hat2.army if _hat2 else None
                from lops.adventure.buildings import BuildingId as _BID

                self.town_screen.has_tavern = (
                    _BID.TAVERN in self.director.active_town.town.buildings
                )
                self.town_screen.has_merchant = (
                    _BID.ARTIFACT_MERCHANT in self.director.active_town.town.buildings
                )
                self.town_screen.has_marketplace = (
                    _BID.MARKETPLACE in self.director.active_town.town.buildings
                )
                self.town_screen.marketplace_count = (
                    self.director.get_marketplace_count(player)
                )
                self.town_screen.draw(self.director.active_town.town, player)

        elif self.director.mode == GameMode.HERO_MODAL:
            self._draw_adventure()
            human = self.director.adventure_state.players[0]
            hs = human.active_hero_state
            if hs:
                self.hero_modal.draw(hs.hero)

    def _draw_adventure(self) -> None:
        human = self.director.adventure_state.players[0]
        hero_hs = human.active_hero_state
        hero_layer = hero_hs.layer if hero_hs else 0
        revealed = human.revealed_for_layer(hero_layer)
        visible = self.director.adventure_state.visible_hexes(
            human.player_id, layer=hero_layer
        )
        self.adv_renderer.draw(
            self.director.adventure_state,
            revealed=revealed,
            visible=visible,
            anim_state=self.anim_state,
            current_layer=hero_layer,
        )
        self.adv_ui.draw(self.director.adventure_state, anim_state=self.anim_state)
        if self.sidebar is not None:
            minimap_revealed = human.revealed_for_layer(self.sidebar.minimap_layer)
            self.sidebar.draw(
                self.director.adventure_state,
                revealed=revealed,
                visible=visible,
                camera=self.adv_renderer.camera,
                minimap_revealed=minimap_revealed,
            )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _create_combat(self, engine, *, player_side=None, ai_side=None) -> None:
        """Create combat renderer, input handler, and AI from the frontend."""
        fe = self.frontend
        self.combat_renderer = fe.create_combat_renderer(
            engine, player_side=player_side
        )
        self.combat_input = fe.create_combat_input(
            engine, self.combat_renderer, player_side=player_side
        )
        self.combat_ai = AIOpponent(
            engine, side=ai_side if ai_side is not None else Side.DEFENDER
        )

    def _ai_end_turn(self) -> None:
        """End AI turn, refresh move range, and center camera."""
        self.director.end_turn()
        self.adv_input.refresh_move_range()
        if not self.director.adventure_state.game_over:
            self.adv_renderer.center_on_hex(
                self.director.adventure_state.current_player.position
            )
