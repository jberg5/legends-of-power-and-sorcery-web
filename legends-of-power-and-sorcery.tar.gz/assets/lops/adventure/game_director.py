"""GameDirector: orchestrates ADVENTURE <-> COMBAT <-> TOWN_SCREEN transitions."""

from __future__ import annotations

from enum import Enum, auto

from lops.adventure.adventure_state import AdventureState, HeroState, PlayerState
from lops.adventure.ai_hero import AdventureAI
from lops.adventure.buildings import BuildingId
from lops.game_log import GameLog
from lops.adventure.hero_movement import find_path, movement_range, path_cost
from lops.adventure.layered_map import LayeredMap
from lops.adventure.map_objects import (
    ArtifactPickup,
    Campfire,
    CreatureBank,
    CreatureDwelling,
    HillFort,
    MagicWell,
    Mine,
    PandorasBox,
    ResourcePickup,
    StatBooster,
    SubterraneanGate,
    TownSite,
    TreasureChest,
    WanderingMonster,
)
from lops.adventure.resources import Resources
from lops.adventure.town import FactionId, Town, create_town
from lops.adventure.world_map import WorldMap
from lops.combat import CombatEngine
from lops.data.creatures import CreatureType, make_stack
from lops.data.maps import generate_default_map, generate_layered_map
from lops.hex import CubeCoord, OffsetCoord, offset_to_cube
from lops.models import Army, Battlefield, CreatureStack, Hero, Side
from lops.siege import FortLevel, create_siege_info


class GameMode(Enum):
    WELCOME = auto()
    ADVENTURE = auto()
    COMBAT = auto()
    TOWN_SCREEN = auto()
    HERO_MODAL = auto()


class GameDirector:
    """Top-level game state machine."""

    def __init__(self):
        self.mode = GameMode.ADVENTURE
        self.world_map: WorldMap | None = None
        self.layered_map: LayeredMap | None = None
        self.adventure_state: AdventureState | None = None

        # Game log (set by caller, e.g. main.py)
        self.game_log: GameLog | None = None

        # Combat state (transient)
        self.combat_engine: CombatEngine | None = None
        self.combat_opponent = None  # the map object or player we're fighting
        self.combat_attacker_player: PlayerState | None = None
        self.combat_attacker_hero: HeroState | None = None
        self.combat_defender_hero: HeroState | None = None

        # Town screen state
        self.active_town: TownSite | None = None
        self._siege_defending_player: PlayerState | None = None

        # AI controllers
        self._ai_controllers: dict[int, AdventureAI] = {}
        self._ai_has_built_this_turn: bool = False  # prevent double build/recruit

        # Difficulty settings (set in setup_new_game, default to NORMAL)
        from lops.difficulty import DIFFICULTY_PRESETS, Difficulty

        self.difficulty = Difficulty.NORMAL
        self.difficulty_settings = DIFFICULTY_PRESETS[Difficulty.NORMAL]

        # Last event description for UI status messages
        self.last_event_description: str = ""

        # Combat XP tracking
        self._combat_original_enemy_stacks: list[tuple[str, int, int]] | None = None
        self._combat_original_attacker_stacks: list[tuple[str, int, int]] | None = None
        self._combat_is_hero_or_siege: bool = False
        self._pending_level_ups: list[dict] | None = None

    @property
    def _map(self) -> WorldMap:
        """Non-None world map (for use after setup_new_game).

        Returns the surface map (layer 0) by default for backward compat.
        """
        assert self.world_map is not None
        return self.world_map

    def _map_for(self, layer: int) -> WorldMap:
        """Get map for a specific layer. Falls back to world_map if no layered map."""
        if self.layered_map is not None:
            return self.layered_map.get_map(layer)
        assert self.world_map is not None
        return self.world_map

    def _hero_map(self, player: PlayerState) -> WorldMap:
        """Get the map for the current hero's layer."""
        hs = player.active_hero_state
        layer = hs.layer if hs else 0
        return self._map_for(layer)

    def _hero_layer(self, player: PlayerState) -> int:
        """Get the current hero's layer."""
        hs = player.active_hero_state
        return hs.layer if hs else 0

    @property
    def _state(self) -> AdventureState:
        """Non-None adventure state (for use after setup_new_game)."""
        assert self.adventure_state is not None
        return self.adventure_state

    @property
    def _gl(self) -> GameLog | None:
        """Game log shortcut for concise guarded calls."""
        return self.game_log

    def setup_new_game(
        self,
        seed: int | None = None,
        player_faction: FactionId = FactionId.CASTLE,
        ai_faction: FactionId | None = None,
        map_cols: int = 36,
        map_rows: int = 24,
        difficulty=None,
    ):
        """Initialize a new adventure game.

        player_faction: the faction for the human player's town/army.
        ai_faction: the faction for the AI. None = random different from player.
        map_cols/map_rows: map dimensions (default 36x24 "test" size).
        difficulty: Difficulty enum or None (defaults to NORMAL).
        """
        from lops.difficulty import (
            DIFFICULTY_PRESETS,
            Difficulty,
            DifficultySettings,
        )

        if difficulty is None:
            difficulty = Difficulty.NORMAL
        self.difficulty = difficulty
        self.difficulty_settings: DifficultySettings = DIFFICULTY_PRESETS[difficulty]
        import random as _rng

        if ai_faction is None:
            others = [f for f in FactionId if f != player_faction]
            ai_faction = _rng.choice(others)

        if self._gl:
            self._gl.log_setup(seed, player_faction, ai_faction, map_cols, map_rows)
        self.layered_map = generate_layered_map(
            cols=map_cols, rows=map_rows, seed=seed
        )
        self.world_map = self.layered_map.surface
        cols, rows = self._map.cols, self._map.rows

        # Town positions
        town1_pos = offset_to_cube(OffsetCoord(3, rows // 2))
        town2_pos = offset_to_cube(OffsetCoord(cols - 4, rows // 2))

        # Create towns with faction-appropriate names
        town1_name = _random_town_name(player_faction, _rng)
        town2_name = _random_town_name(ai_faction, _rng)
        town1 = create_town(player_faction, town1_name, owner_id=0, starter=True)
        town2 = create_town(ai_faction, town2_name, owner_id=1, starter=True)

        town_site1 = TownSite(position=town1_pos, owner=0, town=town1, name=town1_name)
        town_site2 = TownSite(position=town2_pos, owner=1, town=town2, name=town2_name)

        # Create heroes and armies from faction data

        player_hero = self._create_faction_hero(player_faction)
        player_army = self._create_faction_army(player_faction)

        ai_hero = self._create_faction_hero(ai_faction)
        ai_army = self._create_faction_army(ai_faction)

        # Place heroes near their towns
        player_start = self._find_passable_near(town1_pos)
        ai_start = self._find_passable_near(town2_pos)

        from lops.adventure.adventure_state import HeroState

        player_state = PlayerState(player_id=0, town_id="town_0", is_ai=False)
        player_state.add_hero(
            HeroState(hero=player_hero, army=player_army, position=player_start)
        )

        ai_state = PlayerState(player_id=1, town_id="town_1", is_ai=True)
        ai_state.add_hero(HeroState(hero=ai_hero, army=ai_army, position=ai_start))

        # Create map objects
        neutral_towns = self._generate_neutral_towns(
            town1_pos, town2_pos, _rng, player_faction, ai_faction
        )

        # Build roads connecting neutral towns to the main road network
        if neutral_towns:
            from lops.adventure.world_map import Terrain
            from lops.data.maps import build_road

            # Find the nearest road hex for each neutral town and connect
            road_hexes = [
                p
                for p in self._map.all_positions()
                if self._map.get_tile(p)
                and (t := self._map.get_tile(p)) is not None and t.terrain == Terrain.ROAD
            ]
            for site in neutral_towns:
                if not road_hexes:
                    break
                # Find closest road hex to this neutral town
                from lops.hex import cube_distance as _cd

                nearest = min(road_hexes, key=lambda rh: _cd(rh, site.position))
                build_road(self._map, nearest, site.position)
                # Add newly created road hexes to the set for next iterations
                road_hexes = [
                    p
                    for p in self._map.all_positions()
                    if self._map.get_tile(p)
                    and (t := self._map.get_tile(p)) is not None and t.terrain == Terrain.ROAD
                ]

        # Build roads connecting gates to the road network (like towns)
        if self.layered_map is not None and self.layered_map.gates:
            from lops.adventure.world_map import Terrain as _Terrain
            from lops.data.maps import build_road as _build_road

            road_hexes = [
                p
                for p in self._map.all_positions()
                if (t := self._map.get_tile(p)) is not None
                and t.terrain == _Terrain.ROAD
            ]
            for gate in self.layered_map.gates:
                if not road_hexes:
                    break
                from lops.hex import cube_distance as _cd2

                nearest = min(road_hexes, key=lambda rh: _cd2(rh, gate.surface_pos))
                _build_road(self._map, nearest, gate.surface_pos)
                # Restore gate hex to grass — road terminates AT the gate
                self._map.set_terrain(gate.surface_pos, _Terrain.GRASS)
                # Refresh road set for next gate
                road_hexes = [
                    p
                    for p in self._map.all_positions()
                    if (t := self._map.get_tile(p)) is not None
                    and t.terrain == _Terrain.ROAD
                ]

        map_objects: list = [town_site1, town_site2] + neutral_towns
        # Track used positions across all generators to prevent overlaps
        used = {obj.position for obj in map_objects if hasattr(obj, "position")}
        # Reserve gate positions so no other objects overlap them
        if self.layered_map is not None:
            for gate in self.layered_map.gates:
                used.add(gate.surface_pos)
        for gen in (
            self._generate_mines,
            self._generate_monsters,
            self._generate_resources,
            self._generate_artifact_pickups,
            self._generate_treasure_chests,
            self._generate_campfires,
            self._generate_stat_boosters,
            self._generate_magic_wells,
            self._generate_pandoras_boxes,
            self._generate_creature_banks,
            self._generate_creature_dwellings,
            self._generate_hill_forts,
        ):
            new_objs = gen(town1_pos, town2_pos, used)
            for obj in new_objs:
                used.add(obj.position)
            map_objects.extend(new_objs)

        # Add subterranean gate objects for both layers
        if self.layered_map is not None:
            for gate in self.layered_map.gates:
                map_objects.append(
                    SubterraneanGate(
                        position=gate.surface_pos, layer=0, pair_id=gate.pair_id
                    )
                )
                map_objects.append(
                    SubterraneanGate(
                        position=gate.underground_pos, layer=1, pair_id=gate.pair_id
                    )
                )

            # Generate underground content
            underground_objs = self._generate_underground_objects(
                _rng, map_cols, map_rows
            )
            map_objects.extend(underground_objs)

        self.adventure_state = AdventureState(
            players=[player_state, ai_state],
            map_objects=map_objects,
        )

        # Reveal starting positions (layer 0)
        player_state.reveal_around(player_start, layer=0)
        ai_state.reveal_around(ai_start, layer=0)

        # Heroes learn guild spells from their starter towns
        town1.hero_learn_spells(player_hero)
        town2.hero_learn_spells(ai_hero)

        # Refresh tavern heroes (exclude heroes already in play)
        self._refresh_all_taverns()

        # Set up AI
        ai_ctrl = AdventureAI(ai_state, self._state, self._map)
        ai_ctrl.game_log = self.game_log
        ai_ctrl._layered_map = self.layered_map
        ai_ctrl.difficulty_settings = self.difficulty_settings
        self._ai_controllers[1] = ai_ctrl

        self.mode = GameMode.ADVENTURE

    def _refresh_all_taverns(self):
        """Refresh tavern hero pool and artifact merchants. Called at game start and weekly."""
        from lops.adventure.map_objects import TownSite

        used = set()
        for p in self._state.players:
            for hs in p.all_alive_heroes():
                used.add(hs.hero.name)
        for obj in self._state.map_objects:
            if isinstance(obj, TownSite) and obj.town is not None:
                obj.town.refresh_tavern(used)
                obj.town.refresh_merchant()

    def _create_faction_hero(self, faction_id: FactionId) -> Hero:
        """Create a starting hero for the given faction."""
        from lops.data.heroes import create_hero_from_def, get_faction_heroes
        from lops.skills import HeroSkill, SkillId, SkillLevel
        from lops.spells import SpellId

        heroes = get_faction_heroes(faction_id)
        if heroes:
            hero = create_hero_from_def(heroes[0])
        else:
            hero = Hero(name="Hero", attack=2, defense=2, spell_power=1, knowledge=1)
        # Ensure hero has Logistics and a starting spell
        if not hero.has_skill(SkillId.LOGISTICS):
            hero.skills.append(HeroSkill(SkillId.LOGISTICS, SkillLevel.BASIC))
        if SpellId.MAGIC_ARROW not in hero.spells:
            hero.spells.append(SpellId.MAGIC_ARROW)
        return hero

    def _create_faction_army(self, faction_id: FactionId) -> list:
        """Create a starting army (tiers 1-4) for the given faction."""
        from lops.adventure.town import CASTLE_DWELLINGS, FACTION_DWELLINGS

        dwellings = FACTION_DWELLINGS.get(faction_id, CASTLE_DWELLINGS)
        army = []
        # Tiers 1-4 with decreasing counts
        counts = [20, 12, 8, 6]
        for i, count in enumerate(counts):
            if i < len(dwellings):
                ct = dwellings[i][0]
                army.append(make_stack(ct, count))
        return army

    def _make_hired_hero_army(self, town) -> list:
        """Create a small starting army for a newly hired hero, using the town's faction."""
        from lops.adventure.town import CASTLE_DWELLINGS, FACTION_DWELLINGS

        dwellings = FACTION_DWELLINGS.get(town.faction_id, CASTLE_DWELLINGS)
        army = []
        # Tier 1: 20 creatures, Tier 2: 5 creatures
        if len(dwellings) >= 1:
            army.append(make_stack(dwellings[0][0], 20))
        if len(dwellings) >= 2:
            army.append(make_stack(dwellings[1][0], 5))
        return army

    def _find_passable_near(self, pos: CubeCoord, layer: int = 0) -> CubeCoord:
        """Find a passable hex near pos (preferably pos itself)."""
        wmap = self._map_for(layer)
        if wmap.is_passable(pos):
            return pos
        for n in wmap.neighbors(pos):
            if wmap.is_passable(n):
                return n
        return pos

    @property
    def _map_scale(self) -> float:
        """Scale factor relative to base 36x24 map. Used to scale object counts."""
        if self.world_map is None:
            return 1.0
        return (self._map.cols * self._map.rows) / (36 * 24)

    def _generate_mines(
        self, town1: CubeCoord, town2: CubeCoord, used: set[CubeCoord] | None = None
    ) -> list[Mine]:
        """Place mines symmetrically on the map. Count scales with map size."""
        import random

        from lops.adventure.resources import ResourceType
        from lops.hex import cube_distance

        rng = random.Random(77)

        # Base 9 mines, plus extra pairs of wood/ore/rare for larger maps
        mine_configs = [
            (ResourceType.GOLD, 0),
            (ResourceType.WOOD, 1),
            (ResourceType.WOOD, 1),
            (ResourceType.ORE, 1),
            (ResourceType.ORE, 1),
            (ResourceType.MERCURY, 2),
            (ResourceType.SULFUR, 2),
            (ResourceType.CRYSTAL, 2),
            (ResourceType.GEMS, 2),
        ]
        # Scale mines with map size (sqrt growth)
        import math

        extra = int(7 * (math.sqrt(self._map_scale) - 1))
        rare_types = [
            ResourceType.MERCURY,
            ResourceType.SULFUR,
            ResourceType.CRYSTAL,
            ResourceType.GEMS,
        ]
        for i in range(extra):
            if i % 3 == 0:
                mine_configs.append((ResourceType.GOLD, 0))
            elif i % 3 == 1:
                mine_configs.append(
                    (rng.choice([ResourceType.WOOD, ResourceType.ORE]), 1)
                )
            else:
                mine_configs.append((rng.choice(rare_types), 2))

        cols, rows = self._map.cols, self._map.rows
        mid_col = cols // 2
        mid_row = rows // 2

        from lops.adventure.world_map import Terrain

        all_positions = [
            p
            for p in self._map.all_positions()
            if self._map.is_passable(p)
            and (t := self._map.get_tile(p)) is not None and t.terrain != Terrain.ROAD
        ]
        used_positions: set[CubeCoord] = {town1, town2}
        if used:
            used_positions |= used
        mines: list[Mine] = []

        # Sort positions by distance from map center for placement

        center = offset_to_cube(OffsetCoord(mid_col, mid_row))

        rng.shuffle(all_positions)

        for i, (rtype, zone) in enumerate(mine_configs):
            best_pos: CubeCoord | None = None
            best_score = float("inf")

            for pos in all_positions:
                if pos in used_positions:
                    continue
                d1 = cube_distance(pos, town1)
                d2 = cube_distance(pos, town2)
                dc = cube_distance(pos, center)

                # Must be away from towns
                if d1 < 3 or d2 < 3:
                    continue

                # Must be at least 3 hexes from any existing mine
                too_close = False
                for m in mines:
                    if cube_distance(pos, m.position) < 3:
                        too_close = True
                        break
                if too_close:
                    continue

                if zone == 0:
                    # Center mine: minimize distance to center
                    score = dc
                elif zone == 1:
                    # Near one side: alternate between sides
                    if i % 2 == 1:
                        score = d1 + abs(dc - 5)  # closer to town1
                    else:
                        score = d2 + abs(dc - 5)  # closer to town2
                else:
                    # Mid-range: moderate distance from both
                    score = abs(d1 - d2) + abs(dc - 7)

                if score < best_score:
                    best_score = score
                    best_pos = pos

            if best_pos is not None:
                mines.append(Mine(position=best_pos, resource_type=rtype))
                used_positions.add(best_pos)

        return mines

    def _generate_monsters(
        self, town1: CubeCoord, town2: CubeCoord, used: set[CubeCoord] | None = None
    ) -> list[WanderingMonster]:
        """Place wandering monsters on the map. Count scales with map size."""
        import random

        from lops.hex import cube_distance

        rng = random.Random(42)
        monsters = []

        # Base monster groups (progressively harder away from towns)
        monster_configs = [
            # (creature_type, count, min_distance_from_any_town)
            (CreatureType.PIKEMAN, 15, 3),
            (CreatureType.PIKEMAN, 20, 4),
            (CreatureType.ARCHER, 10, 4),
            (CreatureType.ARCHER, 15, 5),
            (CreatureType.GRIFFIN, 5, 5),
            (CreatureType.GRIFFIN, 8, 6),
            (CreatureType.SWORDSMAN, 4, 6),
            (CreatureType.SWORDSMAN, 6, 7),
            (CreatureType.MONK, 5, 7),
            (CreatureType.CAVALIER, 3, 8),
        ]
        # Add extra monsters for larger maps (sqrt scaling)
        import math

        extra = int(10 * (math.sqrt(self._map_scale) - 1))
        extra_pool = [
            (CreatureType.PIKEMAN, 25, 4),
            (CreatureType.ARCHER, 20, 5),
            (CreatureType.GRIFFIN, 10, 6),
            (CreatureType.SWORDSMAN, 8, 7),
            (CreatureType.MONK, 6, 8),
            (CreatureType.CAVALIER, 4, 9),
        ]
        for i in range(extra):
            monster_configs.append(extra_pool[i % len(extra_pool)])

        used_positions: set[CubeCoord] = {town1, town2}
        if used:
            used_positions |= used
        from lops.adventure.world_map import Terrain as _Terrain

        all_positions = [
            p
            for p in self._map.all_positions()
            if self._map.is_passable(p)
            and (t := self._map.get_tile(p)) is not None and t.terrain != _Terrain.ROAD
        ]
        rng.shuffle(all_positions)

        for ct, count, min_dist in monster_configs:
            for pos in all_positions:
                if pos in used_positions:
                    continue
                d1 = cube_distance(pos, town1)
                d2 = cube_distance(pos, town2)
                if d1 >= min_dist and d2 >= min_dist:
                    army = [make_stack(ct, count)]
                    name = f"{CREATURE_REGISTRY_NAMES.get(ct, 'Monsters')}"
                    monsters.append(
                        WanderingMonster(position=pos, army=army, name=name)
                    )
                    used_positions.add(pos)
                    break

        return monsters

    def _generate_resources(
        self, town1: CubeCoord, town2: CubeCoord, used: set[CubeCoord] | None = None
    ) -> list[ResourcePickup]:
        """Place gold piles on the map."""
        import random

        from lops.hex import cube_distance

        rng = random.Random(99)
        resources = []

        occupied = {town1, town2}
        if used:
            occupied |= used

        from lops.adventure.world_map import Terrain as _T

        all_positions = [
            p
            for p in self._map.all_positions()
            if self._map.is_passable(p)
            and (t := self._map.get_tile(p)) is not None and t.terrain != _T.ROAD
        ]
        rng.shuffle(all_positions)

        base_gold = [300, 400, 500, 500, 600, 750, 800, 1000]
        import math

        extra = int(8 * (math.sqrt(self._map_scale) - 1))
        extra_gold = [rng.choice([400, 500, 600, 750, 1000]) for _ in range(extra)]
        gold_amounts = base_gold + extra_gold
        placed = 0
        for pos in all_positions:
            if pos in occupied:
                continue
            if placed >= len(gold_amounts):
                break
            d1 = cube_distance(pos, town1)
            d2 = cube_distance(pos, town2)
            if d1 >= 2 and d2 >= 2:
                resources.append(
                    ResourcePickup(position=pos, gold=gold_amounts[placed])
                )
                occupied.add(pos)
                placed += 1

        return resources

    # --- Movement ---

    def prepare_move(self, player: PlayerState, destination: CubeCoord):
        """Compute path & deduct MP but don't update position.

        Returns (hex_path, event_type) or None if move is invalid.
        """
        from lops.skills import SkillId

        hero_map = self._hero_map(player)
        pf = player.hero.skill_value(SkillId.PATHFINDING)
        if player.position is None:
            return None
        path = find_path(
            player.position,
            destination,
            hero_map,
            self._get_blocked_hexes(player, allow=destination),
            pathfinding_reduction=pf,
        )
        if path is None:
            return None

        cost = path_cost(path, hero_map, pathfinding_reduction=pf)
        if cost > player.movement_points:
            return None

        player.movement_points -= cost
        event = self._check_destination_event(player, destination)
        return (path, event)

    def apply_move(
        self, player: PlayerState, destination: CubeCoord, event: str | None
    ) -> str | None:
        """Set hero position and resolve non-combat events.

        Returns event type for combat events (caller starts combat),
        or None when fully resolved.
        """
        self.last_event_description = ""
        hs = player.active_hero_state
        hero_layer = hs.layer if hs else 0
        player.position = destination
        player.reveal_around(destination, layer=hero_layer)

        if event in ("monster", "enemy_hero", "enemy_town", "neutral_town"):
            return event
        if event == "treasure_chest":
            return "treasure_chest"
        if event == "gate":
            obj = self._state.find_object_at(destination, layer=hero_layer)
            if isinstance(obj, SubterraneanGate):
                self._traverse_gate(player, obj)
            return "gate"
        if event == "resource":
            obj = self._state.find_object_at(destination, layer=hero_layer)
            if isinstance(obj, ResourcePickup):
                self.last_event_description = f"Found {obj.gold} gold!"
                player.gold += obj.gold
                self._state.remove_object(obj)
            return "resource"
        if event == "artifact":
            obj = self._state.find_object_at(destination, layer=hero_layer)
            if isinstance(obj, ArtifactPickup):
                self.last_event_description = f"Found artifact: {obj.name}!"
                self._pickup_artifact(player, obj)
            return "artifact"
        if event == "mine_captured":
            obj = self._state.find_object_at(destination, layer=hero_layer)
            if isinstance(obj, Mine):
                obj.owner = player.player_id
                self.last_event_description = f"Captured {obj.name}!"
            return "mine_captured"
        if event == "own_town":
            obj = self._state.find_object_at(destination, layer=hero_layer)
            if isinstance(obj, TownSite) and obj.town:
                obj.town.hero_learn_spells(player.hero)
                if BuildingId.MAGE_GUILD_1 in obj.town.buildings:
                    player.hero.mana = player.hero.effective_knowledge() * 10
            return "own_town"
        if event == "campfire":
            obj = self._state.find_object_at(destination, layer=hero_layer)
            if isinstance(obj, Campfire):
                desc = f"Campfire: +{obj.gold} gold"
                player.gold += obj.gold
                if obj.resource_type and obj.resource_amount:
                    res = Resources()
                    setattr(res, obj.resource_type.name.lower(), obj.resource_amount)
                    player.resources.add_in_place(res)
                    desc += f", +{obj.resource_amount} {obj.resource_type.name.lower()}"
                self.last_event_description = desc
                self._state.remove_object(obj)
            return "campfire"
        if event == "stat_booster":
            obj = self._state.find_object_at(destination, layer=hero_layer)
            if isinstance(obj, StatBooster):
                self._resolve_stat_booster(player, obj)
            return "stat_booster"
        if event == "arena":
            return "arena"  # needs player choice
        if event == "library_too_low":
            return "library_too_low"
        if event == "magic_well":
            obj = self._state.find_object_at(destination, layer=hero_layer)
            if isinstance(obj, MagicWell):
                self._resolve_magic_well(player, obj)
            return "magic_well"
        if event in ("pandora_guarded", "creature_bank"):
            return event  # combat events
        if event == "pandora_unguarded":
            obj = self._state.find_object_at(destination, layer=hero_layer)
            if isinstance(obj, PandorasBox):
                self._resolve_pandora_rewards(player, obj)
            return "pandora_unguarded"
        if event == "dwelling_visit":
            return "dwelling_visit"
        if event == "hill_fort":
            return "hill_fort"
        return None

    def _check_destination_event(
        self, player: PlayerState, destination: CubeCoord
    ) -> str | None:
        """Predict what event would occur at destination (without executing it)."""
        hs = player.active_hero_state
        hero_layer = hs.layer if hs else 0

        # Enemy hero check
        for other in self._state.players:
            if other.player_id != player.player_id and not other.defeated:
                if other.hero_at(destination, layer=hero_layer) is not None:
                    town_obj = self._state.find_object_at(destination, layer=hero_layer)
                    if (
                        isinstance(town_obj, TownSite)
                        and town_obj.owner == other.player_id
                        and town_obj.town
                        and self._get_fort_level(town_obj.town) is not None
                    ):
                        return "enemy_town"
                    return "enemy_hero"

        obj = self._state.find_object_at(destination, layer=hero_layer)
        if obj is not None:
            if isinstance(obj, ResourcePickup):
                return "resource"
            elif isinstance(obj, ArtifactPickup):
                return "artifact"
            elif isinstance(obj, TreasureChest):
                return "treasure_chest"
            elif isinstance(obj, Mine):
                if obj.owner != player.player_id:
                    return "mine_captured"
                return None
            elif isinstance(obj, WanderingMonster):
                return "monster"
            elif isinstance(obj, TownSite):
                if obj.owner == player.player_id:
                    return "own_town"
                elif obj.owner is not None:
                    return "enemy_town"
                return "neutral_town"
            elif isinstance(obj, Campfire):
                return "campfire"
            elif isinstance(obj, StatBooster):
                if hs and hs.hero_id not in obj.visited_by:
                    if obj.booster_type == "arena":
                        return "arena"
                    return "stat_booster"
                return None
            elif isinstance(obj, MagicWell):
                if hs and obj.can_visit(hs.hero_id, self._state.day):
                    return "magic_well"
                return None
            elif isinstance(obj, PandorasBox):
                return "pandora_guarded" if obj.is_guarded else "pandora_unguarded"
            elif isinstance(obj, CreatureBank):
                return "creature_bank"
            elif isinstance(obj, CreatureDwelling):
                return "dwelling_visit" if obj.available > 0 else None
            elif isinstance(obj, HillFort):
                return "hill_fort"
            elif isinstance(obj, SubterraneanGate):
                return "gate"
        return None

    def prepare_ai_turn(self):
        """Run AI build/recruit, decide destination, prepare move (don't execute).

        Returns (hex_path, event_type) or None if AI has nothing to do.
        """
        player = self._state.current_player
        if not player.is_ai or player.defeated:
            return None

        ai = self._ai_controllers.get(player.player_id)
        if ai is None:
            return None

        # Hire a hero first if we have none (before spending gold on buildings/recruits)
        if player.position is None:
            ai.auto_hire_hero(self)
        if player.position is None:
            return None  # still no hero

        # Build/recruit only once per turn (not again after returning from combat)
        if not self._ai_has_built_this_turn:
            ai.auto_build()
            ai.auto_recruit()
            ai.auto_equip_artifacts()
            self._ai_has_built_this_turn = True

        destination = ai.take_turn()
        if destination is None:
            return None

        return self.prepare_move(player, destination)

    def get_player_movement_range(self) -> dict[CubeCoord, int]:
        """Get movement range for current human player.

        Includes enemy hero positions as valid destinations (triggers combat).
        """
        player = self._state.current_player
        if player.position is None:
            return {}
        hero_map = self._hero_map(player)
        blocked = self._get_blocked_hexes(player)
        from lops.skills import SkillId

        pf = player.hero.skill_value(SkillId.PATHFINDING)
        reachable = movement_range(
            player.position,
            player.movement_points,
            hero_map,
            blocked,
            pathfinding_reduction=pf,
        )

        # Add visible enemy hero positions if adjacent to any reachable hex.
        hs = player.active_hero_state
        hero_layer = hs.layer if hs else 0
        visible = self._state.visible_hexes(player.player_id, layer=hero_layer)
        from lops.data.terrain import TERRAIN_COST

        for enemy in self._state.players:
            if enemy.player_id == player.player_id or enemy.defeated:
                continue
            for ehs in enemy.alive_heroes():
                epos = ehs.position
                if epos is None or ehs.layer != hero_layer:
                    continue
                if not hero_map.is_passable(epos):
                    continue
                if epos not in visible:
                    continue
                tile = hero_map.get_tile(epos)
                enter_cost = TERRAIN_COST.get(tile.terrain, 100) if tile else 100
                # Check all neighbors to find the cheapest path to the enemy
                best_cost = reachable.get(epos, float("inf"))
                for neighbor in hero_map.neighbors(epos):
                    if neighbor in reachable:
                        total_cost = reachable[neighbor] + enter_cost
                        if (
                            total_cost <= player.movement_points
                            and total_cost < best_cost
                        ):
                            best_cost = total_cost
                # Also check if enemy is directly adjacent to hero
                if player.position:
                    for n in hero_map.neighbors(player.position):
                        if n == epos and enter_cost < best_cost:
                            best_cost = enter_cost
                if best_cost <= player.movement_points:
                    reachable[epos] = int(best_cost)

        return reachable

    def move_hero(self, player: PlayerState, destination: CubeCoord) -> str | None:
        """Move a hero to destination. Returns event type or None.

        Events: 'monster', 'resource', 'town', 'enemy_hero', 'gate', None
        """
        self.last_event_description = ""
        from lops.skills import SkillId

        hs = player.active_hero_state
        hero_layer = hs.layer if hs else 0
        hero_map = self._map_for(hero_layer)

        pf = player.hero.skill_value(SkillId.PATHFINDING)
        if player.position is None:
            return None
        path = find_path(
            player.position,
            destination,
            hero_map,
            self._get_blocked_hexes(player, allow=destination),
            pathfinding_reduction=pf,
        )
        if path is None:
            return None

        cost = path_cost(path, hero_map, pathfinding_reduction=pf)
        if cost > player.movement_points:
            return None

        player.movement_points -= cost
        player.position = destination
        player.reveal_around(destination, layer=hero_layer)
        if self._gl:
            self._gl.log_move(player, destination, None)

        # Check for enemy hero — but if they're in a fortified town, trigger siege instead
        for other in self._state.players:
            if other.player_id != player.player_id and not other.defeated:
                if other.hero_at(destination, layer=hero_layer) is not None:
                    town_obj = self._state.find_object_at(destination, layer=hero_layer)
                    if (
                        isinstance(town_obj, TownSite)
                        and town_obj.owner == other.player_id
                        and town_obj.town
                        and self._get_fort_level(town_obj.town) is not None
                    ):
                        return "enemy_town"
                    return "enemy_hero"

        # Check map objects at the destination
        obj = self._state.find_object_at(destination, layer=hero_layer)
        if obj is not None:
            if isinstance(obj, ResourcePickup):
                player.gold += obj.gold
                self.last_event_description = f"Found {obj.gold} gold!"
                self._state.remove_object(obj)
                return "resource"
            elif isinstance(obj, ArtifactPickup):
                art_name = obj.name
                self._pickup_artifact(player, obj)
                self.last_event_description = f"Found artifact: {art_name}!"
                return "artifact"
            elif isinstance(obj, TreasureChest):
                return "treasure_chest"
            elif isinstance(obj, Mine):
                if obj.owner != player.player_id:
                    obj.owner = player.player_id
                    self.last_event_description = f"Captured {obj.name}!"
                    return "mine_captured"
                return None  # already own this mine
            elif isinstance(obj, WanderingMonster):
                return "monster"
            elif isinstance(obj, TownSite):
                if obj.owner == player.player_id:
                    if obj.town:
                        obj.town.hero_learn_spells(player.hero)
                        # Full mana restore if town has a Mage Guild
                        if BuildingId.MAGE_GUILD_1 in obj.town.buildings:
                            player.hero.mana = player.hero.effective_knowledge() * 10
                    return "own_town"
                elif obj.owner is not None:
                    return "enemy_town"
                return "neutral_town"
            elif isinstance(obj, Campfire):
                player.gold += obj.gold
                desc = f"Campfire: +{obj.gold} gold"
                if obj.resource_type and obj.resource_amount:
                    res = Resources()
                    setattr(res, obj.resource_type.name.lower(), obj.resource_amount)
                    player.resources.add_in_place(res)
                    desc += f", +{obj.resource_amount} {obj.resource_type.name.lower()}"
                self.last_event_description = desc
                self._state.remove_object(obj)
                return "campfire"
            elif isinstance(obj, StatBooster):
                return self._resolve_stat_booster(player, obj)
            elif isinstance(obj, MagicWell):
                return self._resolve_magic_well(player, obj)
            elif isinstance(obj, PandorasBox):
                if obj.is_guarded:
                    return "pandora_guarded"
                return self._resolve_pandora_rewards(player, obj)
            elif isinstance(obj, CreatureBank):
                return "creature_bank"
            elif isinstance(obj, CreatureDwelling):
                return "dwelling_visit" if obj.available > 0 else None
            elif isinstance(obj, HillFort):
                return "hill_fort"
            elif isinstance(obj, SubterraneanGate):
                return self._traverse_gate(player, obj)

        return None

    def _traverse_gate(self, player: PlayerState, gate: SubterraneanGate) -> str | None:
        """Teleport hero through a subterranean gate to the other layer."""
        if self.layered_map is None:
            return None
        hs = player.active_hero_state
        if hs is None:
            return None

        dest = self.layered_map.gate_destination(gate.position, gate.layer)
        if dest is None:
            return None

        dest_pos, dest_layer = dest
        dest_map = self._map_for(dest_layer)

        # Check destination is passable
        if not dest_map.is_passable(dest_pos):
            dest_pos = self._find_passable_near(dest_pos, layer=dest_layer)

        # Teleport hero
        hs.position = dest_pos
        hs.layer = dest_layer
        player.reveal_around(dest_pos, layer=dest_layer)

        layer_name = "Underground" if dest_layer == 1 else "Surface"
        self.last_event_description = f"Entered {layer_name} via Subterranean Gate"
        return "gate"

    def _resolve_stat_booster(
        self, player: PlayerState, obj: StatBooster
    ) -> str | None:
        """Apply stat booster effect. Returns event string or None."""
        hs = player.active_hero_state
        if hs is None or hs.hero_id in obj.visited_by:
            return None
        if obj.booster_type == "arena":
            return "arena"  # needs player choice
        if obj.booster_type == "library":
            if hs.hero.level < 10:
                self.last_event_description = (
                    "Library of Enlightenment requires level 10!"
                )
                return "library_too_low"
            obj.visited_by.add(hs.hero_id)
            for stat in ("attack", "defense", "spell_power", "knowledge"):
                setattr(hs.hero, stat, getattr(hs.hero, stat) + 2)
            self.last_event_description = (
                f"{obj.name}: +2 Attack, +2 Defense, +2 Spell Power, +2 Knowledge!"
            )
            return "stat_booster"
        obj.visited_by.add(hs.hero_id)
        if obj.xp_amount > 0:
            from lops.experience import grant_xp

            self._pending_level_ups = grant_xp(hs.hero, obj.xp_amount)
            self.last_event_description = f"{obj.name}: +{obj.xp_amount} XP!"
        if obj.stat:
            setattr(hs.hero, obj.stat, getattr(hs.hero, obj.stat) + obj.amount)
            stat_display = {
                "attack": "Attack",
                "defense": "Defense",
                "spell_power": "Spell Power",
                "knowledge": "Knowledge",
            }
            self.last_event_description = (
                f"{obj.name}: +{obj.amount} {stat_display.get(obj.stat, obj.stat)}!"
            )
        return "stat_booster"

    def _resolve_magic_well(self, player: PlayerState, obj: MagicWell) -> str | None:
        """Restore hero mana if not visited this week."""
        hs = player.active_hero_state
        if hs is None:
            return None
        if not obj.can_visit(hs.hero_id, self._state.day):
            return None
        obj.visited_by[hs.hero_id] = self._state.day
        old_mana = hs.hero.mana
        hs.hero.mana = hs.hero.effective_knowledge() * 10
        restored = hs.hero.mana - old_mana
        self.last_event_description = f"Magic Well: +{restored} mana (full)!"
        return "magic_well"

    def _resolve_pandora_rewards(self, player: PlayerState, obj: PandorasBox) -> str:
        """Grant Pandora's Box rewards and remove it."""
        hs = player.active_hero_state
        parts = []
        if obj.gold_reward:
            player.gold += obj.gold_reward
            parts.append(f"+{obj.gold_reward} gold")
        if obj.xp_reward and hs:
            from lops.experience import grant_xp

            self._pending_level_ups = grant_xp(hs.hero, obj.xp_reward)
            parts.append(f"+{obj.xp_reward} XP")
        if obj.resource_reward:
            player.resources.add_in_place(obj.resource_reward)
            for rtype in ("wood", "ore", "mercury", "sulfur", "crystal", "gems"):
                val = getattr(obj.resource_reward, rtype, 0)
                if val > 0:
                    parts.append(f"+{val} {rtype}")
        if obj.artifact_reward and hs:
            from lops.artifacts import ArtifactInstance
            from lops.data.artifacts import ARTIFACT_REGISTRY

            if hs.hero.equipment:
                hs.hero.equipment.equip(ArtifactInstance(artifact_id=obj.artifact_reward))
            art_name = ARTIFACT_REGISTRY.get(obj.artifact_reward)
            if art_name:
                parts.append(f"artifact: {art_name.name}")
        if obj.creature_reward and hs:
            for stack in obj.creature_reward:
                self._merge_stack_into_army(hs, stack)
                parts.append(f"{stack.count}x {stack.stats.name}")
        self.last_event_description = "Pandora's Box: " + (
            ", ".join(parts) if parts else "empty!"
        )
        self._state.remove_object(obj)
        return "pandora_unguarded"

    def _grant_random_artifact(self, hs, artifact_class_name: str):
        """Pick a random artifact of the given class and equip it on the hero."""
        if hs is None:
            return
        import random

        from lops.artifacts import ArtifactClass, ArtifactInstance
        from lops.data.artifacts import ARTIFACTS_BY_CLASS

        cls = ArtifactClass[artifact_class_name]
        pool = ARTIFACTS_BY_CLASS.get(cls, [])
        if pool:
            art_id = random.choice(pool)
            hs.hero.equipment.equip(ArtifactInstance(artifact_id=art_id))

    def resolve_arena(self, player: PlayerState, choice: str):
        """Resolve arena choice: 'attack' or 'defense'."""
        if player.position is None:
            return
        obj = self._state.find_object_at(player.position, layer=self._hero_layer(player))
        if not isinstance(obj, StatBooster) or obj.booster_type != "arena":
            return
        hs = player.active_hero_state
        if hs is None or hs.hero_id in obj.visited_by:
            return
        obj.visited_by.add(hs.hero_id)
        if choice == "attack":
            hs.hero.attack += 2
        else:
            hs.hero.defense += 2

    def recruit_from_dwelling(self, player: PlayerState, count: int) -> bool:
        """Recruit creatures from a map dwelling."""
        if player.position is None:
            return False
        obj = self._state.find_object_at(player.position, layer=self._hero_layer(player))
        if not isinstance(obj, CreatureDwelling):
            return False
        hs = player.active_hero_state
        if hs is None:
            return False
        actual = min(count, obj.available)
        total_cost = actual * obj.cost_per_unit
        if player.resources.gold < total_cost:
            actual = player.resources.gold // obj.cost_per_unit
            total_cost = actual * obj.cost_per_unit
        if actual <= 0:
            return False
        # Check if army has room before spending gold
        stack = make_stack(obj.creature_type, actual)
        if not self._merge_stack_into_army(hs, stack):
            return False
        player.resources.gold -= total_cost
        obj.available -= actual
        return True

    def upgrade_creature_at_hill_fort(
        self, player: PlayerState, army_slot: int
    ) -> bool:
        """Upgrade a creature at the Hill Fort (no dwelling requirement)."""
        from lops.adventure.buildings import CREATURE_UPGRADES, UPGRADED_RECRUIT_COST
        from lops.data.creatures import CREATURE_REGISTRY

        hs = player.active_hero_state
        if hs is None or army_slot < 0 or army_slot >= len(hs.army):
            return False
        stack = hs.army[army_slot]
        if not stack.alive:
            return False
        # Find creature type from stats name
        base_ct = None
        for ct, stats in CREATURE_REGISTRY.items():
            if stats.name == stack.stats.name:
                base_ct = ct
                break
        if base_ct is None:
            return False
        upgraded_ct = CREATURE_UPGRADES.get(base_ct)
        if upgraded_ct is None:
            return False
        upgraded_stats = CREATURE_REGISTRY[upgraded_ct]
        if stack.stats.name == upgraded_stats.name:
            return False  # already upgraded
        upg_cost = UPGRADED_RECRUIT_COST.get(upgraded_ct, 0)
        # Find base cost from dwelling data
        base_cost = self._find_base_recruit_cost(base_ct)
        diff = max(0, upg_cost - base_cost)
        total_cost = diff * stack.count
        if player.resources.gold < total_cost:
            return False
        player.resources.gold -= total_cost
        stack.stats = upgraded_stats
        stack.current_hp = stack.stats.hp
        stack.shots_left = stack.stats.shots
        return True

    def _find_base_recruit_cost(self, creature_type) -> int:
        """Find the base recruitment cost for a creature type from faction data."""
        from lops.adventure.town import FACTION_DWELLINGS

        for faction_id, dwellings in FACTION_DWELLINGS.items():
            for ct_type, _growth, cost in dwellings:
                if ct_type == creature_type:
                    return cost
        return 0

    def resolve_treasure_chest(
        self, player: PlayerState, choice: str
    ) -> list[dict] | None:
        """Resolve a treasure chest pickup.

        choice: 'gold' or 'xp'
        Returns level-up results if XP caused level-ups, else None.
        """
        if player.position is None:
            return None
        obj = self._state.find_object_at(player.position, layer=self._hero_layer(player))
        if not isinstance(obj, TreasureChest):
            return None

        level_ups = None
        if obj.is_artifact and obj.artifact_id is not None:
            from lops.artifacts import ArtifactInstance

            hs = player.active_hero_state
            if hs is not None and hs.hero.equipment:
                hs.hero.equipment.equip(ArtifactInstance(artifact_id=obj.artifact_id))
        elif choice == "gold":
            player.gold += obj.gold_amount
        elif choice == "xp":
            from lops.experience import grant_xp
            from lops.skills import SkillId

            hero = player.hero
            base_xp = obj.xp_amount
            learning_bonus = hero.skill_value(SkillId.LEARNING)
            total_xp = int(base_xp * (1.0 + learning_bonus))
            level_ups = grant_xp(hero, total_xp)

        if self._gl:
            self._gl.log_treasure_chest(
                player,
                choice,
                obj.gold_amount if choice == "gold" else obj.xp_amount,
            )
        self._state.remove_object(obj)
        return level_ups

    def _get_blocked_hexes(
        self, player: PlayerState, allow: CubeCoord | None = None
    ) -> set[CubeCoord]:
        """Get hexes blocked by other heroes (enemy + friendly except active).

        Only includes heroes on the same layer as the active hero.
        If allow is given, that hex is excluded from the blocked set
        (used when pathfinding to an enemy hero's position).
        """
        blocked = set()
        active = player.active_hero_state
        hero_layer = active.layer if active else 0
        for p in self._state.players:
            if p.defeated:
                continue
            for hs in p.alive_heroes():
                if hs is active:
                    continue  # don't block the moving hero
                if hs.position is not None and hs.layer == hero_layer:
                    blocked.add(hs.position)
        if allow is not None:
            blocked.discard(allow)
        return blocked

    # --- Artifact helpers ---

    def _roll_monster_drop(self, monster: WanderingMonster, winner_hs) -> bool:
        """Roll for artifact drop from defeated monster. Returns True if dropped."""
        import random

        strength = 0.0
        for s in monster.army:
            avg_dmg = (s.stats.min_damage + s.stats.max_damage) / 2
            strength += s.count * avg_dmg * s.stats.hp * 0.01

        from lops.artifacts import ArtifactClass, ArtifactInstance
        from lops.data.artifacts import ARTIFACTS_BY_CLASS

        if strength < 5:
            chance, pool_class = 0.10, ArtifactClass.TREASURE
        elif strength < 15:
            chance, pool_class = 0.15, ArtifactClass.TREASURE
        elif strength < 40:
            chance, pool_class = 0.12, ArtifactClass.MINOR
        else:
            chance, pool_class = 0.10, ArtifactClass.MAJOR

        if random.random() < chance:
            pool = ARTIFACTS_BY_CLASS[pool_class]
            if pool:
                art_id = random.choice(pool)
                winner_hs.hero.equipment.equip(ArtifactInstance(artifact_id=art_id))
                return True
        return False

    def _loot_artifacts(self, winner_hero, loser_hero) -> list[str]:
        """Transfer all artifacts from loser to winner. Returns looted artifact names."""
        from lops.equipment import HeroEquipment

        if loser_hero.equipment is None:
            return []
        looted = loser_hero.equipment.all_artifacts()
        names = [a.definition.name for a in looted if a.definition]
        for art in looted:
            winner_hero.equipment.equip(art)
        loser_hero.equipment = HeroEquipment()
        return names

    def _pickup_artifact(self, player: PlayerState, obj: ArtifactPickup):
        """Pick up an artifact from the map and equip it to the active hero."""
        from lops.artifacts import ArtifactInstance

        artifact = ArtifactInstance(artifact_id=obj.artifact_id)
        hs = player.active_hero_state
        if hs is not None and hs.hero.equipment:
            hs.hero.equipment.equip(artifact)
        self._state.remove_object(obj)

    def _collect_objects_at(self, player: PlayerState, pos: CubeCoord):
        """Auto-collect any remaining pickups at a position (after combat)."""
        layer = self._hero_layer(player)
        while True:
            obj = self._state.find_object_at(pos, layer=layer)
            if obj is None:
                break
            if isinstance(obj, ResourcePickup):
                player.gold += obj.gold
                self._state.remove_object(obj)
            elif isinstance(obj, ArtifactPickup):
                self._pickup_artifact(player, obj)
            elif isinstance(obj, Campfire):
                player.gold += obj.gold
                if obj.resource_type and obj.resource_amount:
                    from lops.adventure.resources import Resources

                    res = Resources()
                    setattr(res, obj.resource_type.name.lower(), obj.resource_amount)
                    player.resources.add_in_place(res)
                self._state.remove_object(obj)
            elif isinstance(obj, Mine):
                if obj.owner != player.player_id:
                    obj.owner = player.player_id
                break  # mines stay alive, don't loop forever
            else:
                break  # treasure chests need user interaction, stop here

    def _generate_artifact_pickups(
        self, town1: CubeCoord, town2: CubeCoord, used: set[CubeCoord] | None = None
    ) -> list[ArtifactPickup]:
        """Place artifact pickups on the map."""
        import random

        from lops.artifacts import ArtifactClass
        from lops.data.artifacts import ARTIFACTS_BY_CLASS
        from lops.hex import cube_distance

        rng = random.Random(55)

        # Placement configs: (artifact_class, min_distance_from_town)
        configs = [
            (ArtifactClass.TREASURE, 4),
            (ArtifactClass.TREASURE, 4),
            (ArtifactClass.TREASURE, 5),
            (ArtifactClass.MINOR, 5),
            (ArtifactClass.MINOR, 6),
            (ArtifactClass.MAJOR, 7),
        ]
        # Scale for larger maps (sqrt growth)
        import math

        extra = int(7 * (math.sqrt(self._map_scale) - 1))
        for i in range(extra):
            if i % 3 == 0:
                configs.append((ArtifactClass.TREASURE, 4))
            elif i % 3 == 1:
                configs.append((ArtifactClass.MINOR, 5))
            else:
                configs.append((ArtifactClass.MAJOR, 7))

        occupied = {town1, town2}
        if used:
            occupied |= used

        from lops.adventure.world_map import Terrain

        all_positions = [
            p
            for p in self._map.all_positions()
            if self._map.is_passable(p)
            and (t := self._map.get_tile(p)) is not None and t.terrain != Terrain.ROAD
        ]
        rng.shuffle(all_positions)

        pickups: list[ArtifactPickup] = []
        used_artifact_ids: set = set()

        for art_class, min_dist in configs:
            pool = [
                aid
                for aid in ARTIFACTS_BY_CLASS[art_class]
                if aid not in used_artifact_ids
            ]
            if not pool:
                continue
            art_id = rng.choice(pool)

            for pos in all_positions:
                if pos in occupied:
                    continue
                d1 = cube_distance(pos, town1)
                d2 = cube_distance(pos, town2)
                if d1 >= min_dist and d2 >= min_dist:
                    pickups.append(ArtifactPickup(position=pos, artifact_id=art_id))
                    occupied.add(pos)
                    used_artifact_ids.add(art_id)
                    break

        return pickups

    def _generate_treasure_chests(
        self, town1: CubeCoord, town2: CubeCoord, used: set[CubeCoord] | None = None
    ) -> list[TreasureChest]:
        """Place ~5 treasure chests on the map."""
        import random

        from lops.hex import cube_distance

        rng = random.Random(88)

        occupied = {town1, town2}
        if used:
            occupied |= used

        from lops.adventure.world_map import Terrain

        all_positions = [
            p
            for p in self._map.all_positions()
            if self._map.is_passable(p)
            and (t := self._map.get_tile(p)) is not None and t.terrain != Terrain.ROAD
        ]
        rng.shuffle(all_positions)

        chests: list[TreasureChest] = []
        tier_weights = [32, 32, 31]  # tier 0, 1, 2

        import math

        num_chests = max(5, int(9 * math.sqrt(self._map_scale)))
        for _ in range(num_chests):
            tier = rng.choices([0, 1, 2], weights=tier_weights, k=1)[0]

            # 5% chance of artifact chest
            is_artifact = rng.random() < 0.05
            artifact_id = None
            if is_artifact:
                from lops.artifacts import ArtifactClass
                from lops.data.artifacts import ARTIFACTS_BY_CLASS

                pool = ARTIFACTS_BY_CLASS.get(ArtifactClass.TREASURE, [])
                if pool:
                    artifact_id = rng.choice(pool)
                else:
                    is_artifact = False

            for pos in all_positions:
                if pos in occupied:
                    continue
                d1 = cube_distance(pos, town1)
                d2 = cube_distance(pos, town2)
                if d1 >= 3 and d2 >= 3:
                    chests.append(
                        TreasureChest(
                            position=pos,
                            tier=tier,
                            is_artifact=is_artifact,
                            artifact_id=artifact_id,
                        )
                    )
                    occupied.add(pos)
                    break

        return chests

    def _generate_campfires(
        self, town1: CubeCoord, town2: CubeCoord, used: set[CubeCoord] | None = None
    ) -> list[Campfire]:
        """Place ~6 campfires on the map (gold + small resource bonus)."""
        import math
        import random

        from lops.adventure.resources import ResourceType
        from lops.hex import cube_distance

        rng = random.Random(66)

        occupied = {town1, town2}
        if used:
            occupied |= used

        from lops.adventure.world_map import Terrain as _T

        all_positions = [
            p
            for p in self._map.all_positions()
            if self._map.is_passable(p)
            and (t := self._map.get_tile(p)) is not None and t.terrain != _T.ROAD
        ]
        rng.shuffle(all_positions)

        num_campfires = max(6, int(6 * math.sqrt(self._map_scale)))
        non_gold_types = [rt for rt in ResourceType if rt != ResourceType.GOLD]
        campfires: list[Campfire] = []

        for _ in range(num_campfires):
            gold = rng.randint(400, 600)
            res_type = rng.choice(non_gold_types)
            res_amount = rng.randint(2, 6)

            for pos in all_positions:
                if pos in occupied:
                    continue
                d1 = cube_distance(pos, town1)
                d2 = cube_distance(pos, town2)
                if d1 >= 3 and d2 >= 3:
                    campfires.append(
                        Campfire(
                            position=pos,
                            gold=gold,
                            resource_type=res_type,
                            resource_amount=res_amount,
                        )
                    )
                    occupied.add(pos)
                    break

        return campfires

    def _generate_stat_boosters(
        self, town1: CubeCoord, town2: CubeCoord, used: set[CubeCoord] | None = None
    ) -> list[StatBooster]:
        """Place stat boosters: 1 of each 8 types + extras for larger maps. Avoids roads."""
        import math
        import random

        from lops.adventure.world_map import Terrain
        from lops.hex import cube_distance

        rng = random.Random(44)

        occupied = {town1, town2}
        if used:
            occupied |= used

        all_positions = [
            p
            for p in self._map.all_positions()
            if self._map.is_passable(p)
            and (t := self._map.get_tile(p)) is not None and t.terrain != Terrain.ROAD
        ]
        rng.shuffle(all_positions)

        # Base set: one of each type
        booster_defs = [
            ("learning_stone", None, 0, 1000),
            ("gazebo", None, 0, 1000),
            ("mercenary_camp", "attack", 1, 0),
            ("marletto_tower", "defense", 1, 0),
            ("garden_of_revelation", "knowledge", 1, 0),
            ("colosseum_of_the_magi", "spell_power", 1, 0),
            ("arena", None, 2, 0),
            ("library", None, 2, 0),
        ]
        # Add extras for larger maps
        extra = int(8 * (math.sqrt(self._map_scale) - 1))
        for i in range(extra):
            booster_defs.append(booster_defs[i % len(booster_defs)])

        boosters: list[StatBooster] = []

        for btype, stat, amount, xp_amount in booster_defs:
            for pos in all_positions:
                if pos in occupied:
                    continue
                d1 = cube_distance(pos, town1)
                d2 = cube_distance(pos, town2)
                if d1 >= 4 and d2 >= 4:
                    boosters.append(
                        StatBooster(
                            position=pos,
                            booster_type=btype,
                            stat=stat,
                            amount=amount,
                            xp_amount=xp_amount,
                        )
                    )
                    occupied.add(pos)
                    break

        return boosters

    def _generate_magic_wells(
        self, town1: CubeCoord, town2: CubeCoord, used: set[CubeCoord] | None = None
    ) -> list[MagicWell]:
        """Place 2-3 magic wells on the map. Avoids roads."""
        import math
        import random

        from lops.adventure.world_map import Terrain
        from lops.hex import cube_distance

        rng = random.Random(33)

        occupied = {town1, town2}
        if used:
            occupied |= used

        all_positions = [
            p
            for p in self._map.all_positions()
            if self._map.is_passable(p)
            and (t := self._map.get_tile(p)) is not None and t.terrain != Terrain.ROAD
        ]
        rng.shuffle(all_positions)

        num_wells = max(2, int(3 * math.sqrt(self._map_scale)))
        wells: list[MagicWell] = []

        for _ in range(num_wells):
            for pos in all_positions:
                if pos in occupied:
                    continue
                d1 = cube_distance(pos, town1)
                d2 = cube_distance(pos, town2)
                if d1 >= 4 and d2 >= 4:
                    wells.append(MagicWell(position=pos))
                    occupied.add(pos)
                    break

        return wells

    def _generate_pandoras_boxes(
        self, town1: CubeCoord, town2: CubeCoord, used: set[CubeCoord] | None = None
    ) -> list[PandorasBox]:
        """Place ~3 Pandora's Boxes with random rewards, possibly guarded."""
        import math
        import random

        from lops.hex import cube_distance

        rng = random.Random(77)

        occupied = {town1, town2}
        if used:
            occupied |= used

        from lops.adventure.world_map import Terrain as _T

        all_positions = [
            p
            for p in self._map.all_positions()
            if self._map.is_passable(p)
            and (t := self._map.get_tile(p)) is not None and t.terrain != _T.ROAD
        ]
        rng.shuffle(all_positions)

        num_boxes = max(3, int(3 * math.sqrt(self._map_scale)))
        boxes: list[PandorasBox] = []

        for _ in range(num_boxes):
            # 50% chance of guards
            guards = []
            if rng.random() < 0.5:
                guard_options = [
                    (CreatureType.GRIFFIN, rng.randint(5, 10)),
                    (CreatureType.SWORDSMAN, rng.randint(3, 6)),
                ]
                ct, count = rng.choice(guard_options)
                guards = [make_stack(ct, count)]

            # Random rewards
            gold_reward = rng.randint(2000, 5000)
            xp_reward = rng.randint(1500, 3000)
            artifact_reward = None
            creature_reward = []

            # 15% artifact reward
            if rng.random() < 0.15:
                from lops.artifacts import ArtifactClass
                from lops.data.artifacts import ARTIFACTS_BY_CLASS

                art_class = rng.choice([ArtifactClass.TREASURE, ArtifactClass.MINOR])
                pool = ARTIFACTS_BY_CLASS.get(art_class, [])
                if pool:
                    artifact_reward = rng.choice(pool)

            # 20% creature reward (tier 1-3)
            if rng.random() < 0.20:
                creature_options = [
                    (CreatureType.PIKEMAN, rng.randint(10, 20)),
                    (CreatureType.ARCHER, rng.randint(5, 15)),
                    (CreatureType.GRIFFIN, rng.randint(3, 8)),
                ]
                ct, count = rng.choice(creature_options)
                creature_reward = [make_stack(ct, count)]

            for pos in all_positions:
                if pos in occupied:
                    continue
                d1 = cube_distance(pos, town1)
                d2 = cube_distance(pos, town2)
                if d1 >= 5 and d2 >= 5:
                    boxes.append(
                        PandorasBox(
                            position=pos,
                            guards=guards,
                            gold_reward=gold_reward,
                            xp_reward=xp_reward,
                            artifact_reward=artifact_reward,
                            creature_reward=creature_reward,
                        )
                    )
                    occupied.add(pos)
                    break

        return boxes

    def _generate_creature_banks(
        self, town1: CubeCoord, town2: CubeCoord, used: set[CubeCoord] | None = None
    ) -> list[CreatureBank]:
        """Place 3-4 creature banks on the map. Avoids roads."""
        import math
        import random

        from lops.adventure.world_map import Terrain
        from lops.data.creature_banks import CREATURE_BANK_TYPES
        from lops.hex import cube_distance

        rng = random.Random(22)

        occupied = {town1, town2}
        if used:
            occupied |= used

        all_positions = [
            p
            for p in self._map.all_positions()
            if self._map.is_passable(p)
            and (t := self._map.get_tile(p)) is not None and t.terrain != Terrain.ROAD
        ]
        rng.shuffle(all_positions)

        num_banks = max(3, int(4 * math.sqrt(self._map_scale)))
        banks: list[CreatureBank] = []

        for _ in range(num_banks):
            bank_type_index = rng.randint(0, len(CREATURE_BANK_TYPES) - 1)

            for pos in all_positions:
                if pos in occupied:
                    continue
                d1 = cube_distance(pos, town1)
                d2 = cube_distance(pos, town2)
                if d1 >= 5 and d2 >= 5:
                    banks.append(
                        CreatureBank(position=pos, bank_type_index=bank_type_index)
                    )
                    occupied.add(pos)
                    break

        return banks

    def _generate_creature_dwellings(
        self, town1: CubeCoord, town2: CubeCoord, used: set[CubeCoord] | None = None
    ) -> list[CreatureDwelling]:
        """Place 4-6 creature dwellings (tiers 1-4 across all factions)."""
        import math
        import random

        from lops.adventure.town import FACTION_DWELLINGS
        from lops.hex import cube_distance

        rng = random.Random(55)

        occupied = {town1, town2}
        if used:
            occupied |= used

        from lops.adventure.world_map import Terrain as _T

        all_positions = [
            p
            for p in self._map.all_positions()
            if self._map.is_passable(p)
            and (t := self._map.get_tile(p)) is not None and t.terrain != _T.ROAD
        ]
        rng.shuffle(all_positions)

        # Collect tier 1-4 creatures from all factions
        tier_1_4_pool = []
        for faction_id, dwellings in FACTION_DWELLINGS.items():
            for tier_idx, (ct, growth, cost) in enumerate(dwellings):
                if tier_idx < 4:  # tiers 1-4 only
                    tier_1_4_pool.append((ct, growth, cost))

        num_dwellings = max(4, int(6 * math.sqrt(self._map_scale)))
        dwellings_out: list[CreatureDwelling] = []

        for _ in range(num_dwellings):
            ct, growth, cost = rng.choice(tier_1_4_pool)

            for pos in all_positions:
                if pos in occupied:
                    continue
                d1 = cube_distance(pos, town1)
                d2 = cube_distance(pos, town2)
                if d1 >= 4 and d2 >= 4:
                    dwellings_out.append(
                        CreatureDwelling(
                            position=pos,
                            creature_type=ct,
                            growth_per_week=growth,
                            cost_per_unit=cost,
                            available=growth,
                        )
                    )
                    occupied.add(pos)
                    break

        return dwellings_out

    def _generate_hill_forts(
        self, town1: CubeCoord, town2: CubeCoord, used: set[CubeCoord] | None = None
    ) -> list[HillFort]:
        """Place 1-2 hill forts on the map. Avoids roads."""
        import math
        import random

        from lops.adventure.world_map import Terrain
        from lops.hex import cube_distance

        rng = random.Random(11)

        occupied = {town1, town2}
        if used:
            occupied |= used

        all_positions = [
            p
            for p in self._map.all_positions()
            if self._map.is_passable(p)
            and (t := self._map.get_tile(p)) is not None and t.terrain != Terrain.ROAD
        ]
        rng.shuffle(all_positions)

        num_forts = max(1, int(2 * math.sqrt(self._map_scale)))
        forts: list[HillFort] = []

        for _ in range(num_forts):
            for pos in all_positions:
                if pos in occupied:
                    continue
                d1 = cube_distance(pos, town1)
                d2 = cube_distance(pos, town2)
                if d1 >= 5 and d2 >= 5:
                    forts.append(HillFort(position=pos))
                    occupied.add(pos)
                    break

        return forts

    def _generate_underground_objects(self, rng, cols: int, rows: int) -> list:
        """Generate map objects for the underground layer.

        Underground has: tougher monsters, rare resource mines,
        creature banks, fewer stat boosters.
        """
        import random

        from lops.adventure.resources import ResourceType
        from lops.hex import cube_distance

        if self.layered_map is None:
            return []
        umap = self.layered_map.underground

        # Collect passable positions
        passable = [p for p in umap.all_positions() if umap.is_passable(p)]
        rng_u = random.Random(rng.randint(0, 999999))
        rng_u.shuffle(passable)

        used: set[CubeCoord] = set()
        # Reserve gate landing zones
        for gate in self.layered_map.gates:
            used.add(gate.underground_pos)
            for n in umap.neighbors(gate.underground_pos):
                used.add(n)

        objects: list = []

        def _place(count: int, factory) -> list:
            placed = []
            seen = 0
            for pos in passable:
                if pos in used:
                    continue
                if len(placed) >= count:
                    break
                seen += 1
                if seen > len(passable):
                    break
                obj = factory(pos)
                if obj is not None:
                    placed.append(obj)
                    used.add(pos)
            return placed

        # Rare resource mines (mercury, sulfur, crystal, gems)
        rare_types = [
            ResourceType.MERCURY,
            ResourceType.SULFUR,
            ResourceType.CRYSTAL,
            ResourceType.GEMS,
        ]
        mine_count = max(3, int(4 * (cols * rows) / (36 * 24)))
        mine_types = [rare_types[i % len(rare_types)] for i in range(mine_count)]
        # Add a gold mine too
        mine_types.append(ResourceType.GOLD)
        idx = [0]

        def _mine_factory(pos):
            if idx[0] >= len(mine_types):
                return None
            m = Mine(position=pos, resource_type=mine_types[idx[0]], layer=1)
            idx[0] += 1
            return m

        objects.extend(_place(len(mine_types), _mine_factory))

        # Tougher wandering monsters (tier 4-7)
        monster_configs = [
            (CreatureType.SWORDSMAN, 12),
            (CreatureType.MONK, 10),
            (CreatureType.CAVALIER, 6),
            (CreatureType.CHAMPION, 4),
            (CreatureType.ANGEL, 2),
            (CreatureType.ARCHANGEL, 1),
            (CreatureType.SWORDSMAN, 15),
            (CreatureType.CAVALIER, 8),
        ]
        m_idx = [0]

        def _monster_factory(pos):
            if m_idx[0] >= len(monster_configs):
                return None
            ct, count = monster_configs[m_idx[0]]
            m_idx[0] += 1
            from lops.data.creatures import CREATURE_REGISTRY

            stats = CREATURE_REGISTRY.get(ct)
            name = stats.name if stats else "Monsters"
            return WanderingMonster(
                position=pos, army=[make_stack(ct, count)], name=name, layer=1
            )

        objects.extend(_place(len(monster_configs), _monster_factory))

        # Resource pickups (gold piles)
        gold_count = max(3, int(5 * (cols * rows) / (36 * 24)))
        objects.extend(
            _place(
                gold_count,
                lambda pos: ResourcePickup(
                    position=pos, gold=rng_u.choice([500, 750, 1000]), layer=1
                ),
            )
        )

        # Creature banks
        from lops.data.creature_banks import CREATURE_BANK_TYPES

        bank_count = min(3, len(CREATURE_BANK_TYPES))
        b_idx = [0]

        def _bank_factory(pos):
            if b_idx[0] >= bank_count:
                return None
            # Pick higher-tier banks for underground
            bank_idx = min(b_idx[0] + 2, len(CREATURE_BANK_TYPES) - 1)
            b_idx[0] += 1
            return CreatureBank(position=pos, bank_type_index=bank_idx, layer=1)

        objects.extend(_place(bank_count, _bank_factory))

        # Treasure chests (higher tier)
        chest_count = max(2, int(3 * (cols * rows) / (36 * 24)))
        objects.extend(
            _place(
                chest_count,
                lambda pos: TreasureChest(position=pos, tier=rng_u.randint(1, 2), layer=1),
            )
        )

        return objects

    def _generate_neutral_towns(
        self,
        town1: CubeCoord,
        town2: CubeCoord,
        rng,
        player_faction: FactionId,
        ai_faction: FactionId,
    ) -> list[TownSite]:
        """Place neutral towns on larger maps with garrison defenders."""
        import math

        from lops.adventure.town import FACTION_DWELLINGS
        from lops.hex import cube_distance

        cols, rows = self._map.cols, self._map.rows

        # Number of neutral towns scales with map size: 0 for test, 1-2 for small, 2-4 for large
        num_neutral = max(0, int(2 * (math.sqrt(self._map_scale) - 1)))
        if num_neutral == 0:
            return []

        # Pick random factions for neutral towns (any faction)
        all_factions = list(FactionId)

        # Find candidate positions: well-spaced from player towns and each other
        from lops.adventure.world_map import Terrain

        all_positions = [
            p
            for p in self._map.all_positions()
            if self._map.is_passable(p)
            and (t := self._map.get_tile(p)) is not None and t.terrain not in (Terrain.ROAD, Terrain.WATER)
        ]
        rng.shuffle(all_positions)

        min_dist_from_players = max(8, cols // 5)
        min_dist_between = max(8, cols // 6)
        placed_positions: list[CubeCoord] = []
        neutral_sites: list[TownSite] = []

        for _ in range(num_neutral):
            for pos in all_positions:
                d1 = cube_distance(pos, town1)
                d2 = cube_distance(pos, town2)
                if d1 < min_dist_from_players or d2 < min_dist_from_players:
                    continue
                # Space from other neutral towns
                too_close = any(
                    cube_distance(pos, p) < min_dist_between for p in placed_positions
                )
                if too_close:
                    continue

                # Place a neutral town here
                faction = rng.choice(all_factions)
                town_name = _random_town_name(faction, rng)
                town = create_town(faction, town_name, owner_id=None, starter=False)

                # Give it minimal buildings: Village Hall, Tavern, Fort
                from lops.adventure.buildings import BuildingId

                town.buildings = {
                    BuildingId.VILLAGE_HALL,
                    BuildingId.TAVERN,
                    BuildingId.FORT,
                }

                # Build the first 3-4 dwellings
                bdict = town._get_buildings_dict()
                dwelling_bids = [
                    bid
                    for bid, bdef in bdict.items()
                    if bdef.unlocks_creature is not None
                ]
                for i, bid in enumerate(dwelling_bids[:4]):
                    town.buildings.add(bid)
                    for dwelling in town.dwellings:
                        if dwelling.creature_type == bdict[bid].unlocks_creature:
                            dwelling.built = True
                            break

                # Stock garrison with tier 1-3 creatures from this faction
                dwellings_config = FACTION_DWELLINGS.get(faction, [])
                garrison = []
                garrison_counts = [12, 8, 5]  # tier 1, 2, 3
                for tier_idx, count in enumerate(garrison_counts):
                    if tier_idx < len(dwellings_config):
                        ct = dwellings_config[tier_idx][0]
                        garrison.append(make_stack(ct, count))
                town.garrison = garrison

                # Clear terrain around the town
                self._map.set_terrain(pos, Terrain.GRASS)
                for n in self._map.neighbors(pos):
                    tile = self._map.get_tile(n)
                    if tile and tile.terrain in (Terrain.MOUNTAIN, Terrain.WATER):
                        self._map.set_terrain(n, Terrain.GRASS)

                site = TownSite(position=pos, owner=None, town=town, name=town_name)
                neutral_sites.append(site)
                placed_positions.append(pos)
                break

        return neutral_sites

    # --- Combat transitions ---

    def _attach_combat_log(self):
        """Register game log callback on the active combat engine."""
        if self.game_log and self.combat_engine:
            self.combat_engine.on_action.append(self.game_log.on_combat_action_callback)

    def _capture_enemy_stacks(
        self, stacks: list[CreatureStack]
    ) -> list[tuple[str, int, int]]:
        """Record original counts of enemy stacks for XP calculation."""
        return [(s.stats.name, s.count, s.stats.hp) for s in stacks if s.alive]

    def _award_combat_xp(self, winner: Side, atk_hs, def_hs) -> int:
        """Award XP to the winning hero after combat. Returns XP awarded."""
        from lops.experience import award_combat_xp, grant_xp
        from lops.skills import SkillId

        if winner == Side.ATTACKER and atk_hs is not None:
            hero = atk_hs.hero
            orig = self._combat_original_enemy_stacks or []
            if self.combat_engine:
                survivors = [
                    (s.stats.name, s.count)
                    for s in self.combat_engine.battlefield.defender.stacks
                    if s.alive
                ]
            else:
                survivors = None
            base_xp = award_combat_xp(
                hero, orig, survivors, self._combat_is_hero_or_siege
            )
            learning_bonus = hero.skill_value(SkillId.LEARNING)
            total_xp = int(base_xp * (1.0 + learning_bonus))
            self._pending_level_ups = grant_xp(hero, total_xp)
            return total_xp

        elif winner == Side.DEFENDER and def_hs is not None:
            hero = def_hs.hero
            orig = getattr(self, "_combat_original_attacker_stacks", None) or []
            if self.combat_engine:
                survivors = [
                    (s.stats.name, s.count)
                    for s in self.combat_engine.battlefield.attacker.stacks
                    if s.alive
                ]
            else:
                survivors = None
            base_xp = award_combat_xp(
                hero, orig, survivors, self._combat_is_hero_or_siege
            )
            learning_bonus = hero.skill_value(SkillId.LEARNING)
            total_xp = int(base_xp * (1.0 + learning_bonus))
            self._pending_level_ups = grant_xp(hero, total_xp)
            return total_xp
        else:
            self._pending_level_ups = None
            return 0

    def start_monster_combat(self, player: PlayerState, monster):
        """Transition to combat against a wandering monster, Pandora's Box, or creature bank."""
        hs = player.active_hero_state
        attacker_army = self._build_combat_army_from_hero(hs, Side.ATTACKER)

        # Extract defender army based on object type
        if isinstance(monster, PandorasBox):
            raw_army = monster.guards
        elif isinstance(monster, CreatureBank):
            raw_army = monster.make_guard_army()
        else:
            raw_army = monster.army
        defender_stacks = [
            self._clone_stack(s, Side.DEFENDER, i)
            for i, s in enumerate(raw_army)
            if s.alive
        ]
        name = getattr(monster, "name", "Monster")
        defender_army = Army(
            hero=Hero(name="Monster"), stacks=defender_stacks, side=Side.DEFENDER
        )

        self._combat_original_enemy_stacks = self._capture_enemy_stacks(defender_stacks)
        self._combat_original_attacker_stacks = None
        self._combat_is_hero_or_siege = False

        battlefield = Battlefield(attacker=attacker_army, defender=defender_army)
        self.combat_engine = CombatEngine(battlefield)
        self.combat_engine.start_combat()
        self._attach_combat_log()
        self.combat_opponent = monster
        self.combat_attacker_player = player
        self.combat_attacker_hero = hs
        self.mode = GameMode.COMBAT
        if self._gl:
            self._gl.log_combat_start(player, f"Monster: {name}")

    def start_hero_combat(
        self,
        attacker: PlayerState,
        defender: PlayerState,
        position: CubeCoord | None = None,
    ):
        """Transition to combat between two heroes.

        position: the hex where combat occurs. Used to find the correct
        defending hero (not just the selected one). Falls back to
        active_hero_state if not provided.
        """
        atk_hs = attacker.active_hero_state
        def_hs = defender.hero_at(position) if position else None
        if def_hs is None:
            def_hs = defender.active_hero_state
        atk_army = self._build_combat_army_from_hero(atk_hs, Side.ATTACKER)
        def_army = self._build_combat_army_from_hero(def_hs, Side.DEFENDER)

        # Capture both sides for XP (winner gets XP from killed enemies)
        self._combat_original_enemy_stacks = self._capture_enemy_stacks(def_army.stacks)
        self._combat_original_attacker_stacks = self._capture_enemy_stacks(
            atk_army.stacks
        )
        self._combat_is_hero_or_siege = True

        battlefield = Battlefield(attacker=atk_army, defender=def_army)
        self.combat_engine = CombatEngine(battlefield)
        self.combat_engine.start_combat()
        self._attach_combat_log()
        self.combat_opponent = defender
        self.combat_attacker_player = attacker
        self.combat_attacker_hero = atk_hs
        self.combat_defender_hero = def_hs
        self.mode = GameMode.COMBAT
        if self._gl:
            self._gl.log_combat_start(attacker, f"Hero: {def_hs.hero.name if def_hs else '?'}")

    def start_siege_combat(self, attacker_player: PlayerState, town_site: TownSite):
        """Transition to siege combat against a fortified town."""
        town = town_site.town
        if town is None:
            return

        # Determine fort level
        fort_level = self._get_fort_level(town)
        if fort_level is None:
            self.capture_town(attacker_player, town_site)
            return

        # Build defender army from garrison + defending hero (if any)
        defender_stacks: list[CreatureStack] = []
        for i, s in enumerate(town.garrison):
            if s.alive:
                defender_stacks.append(
                    self._clone_stack(s, Side.DEFENDER, len(defender_stacks))
                )

        defending_player, defending_hs = self._find_defender_at_town(
            town_site, attacker_player
        )
        if defending_hs is not None:
            for s in defending_hs.army:
                if s.alive:
                    merged = False
                    for existing in defender_stacks:
                        if existing.stats.name == s.stats.name:
                            existing.count += s.count
                            merged = True
                            break
                    if not merged and len(defender_stacks) < 7:
                        defender_stacks.append(
                            self._clone_stack(s, Side.DEFENDER, len(defender_stacks))
                        )

        if not defender_stacks:
            self.capture_town(attacker_player, town_site)
            return

        siege_info = create_siege_info(fort_level)
        defender_hero = defending_hs.hero if defending_hs else Hero(name="Garrison")
        defender_army = Army(
            hero=defender_hero, stacks=defender_stacks, side=Side.DEFENDER
        )
        atk_hs = attacker_player.active_hero_state
        attacker_army = self._build_combat_army_from_hero(atk_hs, Side.ATTACKER)

        # XP tracking
        self._combat_original_enemy_stacks = self._capture_enemy_stacks(defender_stacks)
        self._combat_original_attacker_stacks = self._capture_enemy_stacks(
            attacker_army.stacks
        )
        self._combat_is_hero_or_siege = True

        battlefield = Battlefield(
            attacker=attacker_army, defender=defender_army, siege_info=siege_info
        )
        self.combat_engine = CombatEngine(battlefield)
        self.combat_engine.start_combat()
        self._attach_combat_log()
        self.combat_opponent = town_site
        self.combat_attacker_player = attacker_player
        self.combat_attacker_hero = atk_hs
        self.combat_defender_hero = defending_hs
        self._siege_defending_player = defending_player
        self.mode = GameMode.COMBAT
        if self._gl:
            self._gl.log_combat_start(
                attacker_player,
                f"Siege: {town_site.name}",
                is_siege=True,
            )

    def _get_fort_level(self, town: Town) -> FortLevel | None:
        """Determine the fort level from town buildings."""
        if BuildingId.CASTLE in town.buildings:
            return FortLevel.CASTLE
        if BuildingId.CITADEL in town.buildings:
            return FortLevel.CITADEL
        if BuildingId.FORT in town.buildings:
            return FortLevel.FORT
        return None

    def _town_has_human_defender(
        self, town_site: TownSite, attacker: PlayerState
    ) -> bool:
        """Check if the town belongs to or is defended by a human player."""
        # Check town owner
        for p in self._state.players:
            if p.player_id == town_site.owner and not p.is_ai:
                return True
        return False

    def _find_defender_at_town(self, town_site: TownSite, attacker: PlayerState):
        """Find a defending hero state at the town (not the attacker's). Returns (player, hero_state) or (None, None)."""
        for p in self._state.players:
            if p.player_id != attacker.player_id and not p.defeated:
                hs = p.hero_at(town_site.position)
                if hs is not None:
                    return p, hs
        return None, None

    def on_combat_finished(self):
        """Handle combat result and return to adventure mode."""
        if self.combat_engine is None:
            return

        winner = self.combat_engine.winner
        attacker = self.combat_attacker_player
        if attacker is None:
            return
        atk_hs = self.combat_attacker_hero
        _looted_names: list[str] = []
        def_hs = self.combat_defender_hero

        if winner == Side.ATTACKER:
            # Sync attacker hero's army
            if atk_hs is not None:
                self._sync_army_from_combat(
                    atk_hs, self.combat_engine.battlefield.attacker
                )
            else:
                self._sync_army_from_combat(
                    attacker, self.combat_engine.battlefield.attacker
                )

            if isinstance(self.combat_opponent, WanderingMonster):
                self._state.remove_object(self.combat_opponent)
                # Roll for artifact drop from monster
                if atk_hs is not None:
                    self._roll_monster_drop(self.combat_opponent, atk_hs)
                # Auto-collect any remaining objects at this position
                if atk_hs is not None and attacker is not None and atk_hs.position is not None:
                    self._collect_objects_at(attacker, atk_hs.position)
            elif isinstance(self.combat_opponent, PandorasBox) and attacker is not None:
                self._resolve_pandora_rewards(attacker, self.combat_opponent)
            elif isinstance(self.combat_opponent, CreatureBank):
                bank_def = self.combat_opponent.bank_def
                parts = []
                gold = bank_def.get("gold", 0)
                if gold:
                    attacker.gold += gold
                    parts.append(f"+{gold} gold")
                if bank_def.get("resources"):
                    attacker.resources.add_in_place(bank_def["resources"])
                    res = bank_def["resources"]
                    for rtype in (
                        "wood",
                        "ore",
                        "mercury",
                        "sulfur",
                        "crystal",
                        "gems",
                    ):
                        val = getattr(res, rtype, 0)
                        if val > 0:
                            parts.append(f"+{val} {rtype}")
                if bank_def.get("artifact_class"):
                    self._grant_random_artifact(atk_hs, bank_def["artifact_class"])
                    parts.append(f"+ {bank_def['artifact_class'].lower()} artifact")
                self.last_event_description = (
                    f"{self.combat_opponent.name}: " + ", ".join(parts) if parts else ""
                )
                self._state.remove_object(self.combat_opponent)
            elif isinstance(self.combat_opponent, TownSite):
                self.capture_town(attacker, self.combat_opponent)
                if self.combat_opponent.town:
                    self.combat_opponent.town.garrison.clear()
                # Remove defending hero (they lost) and loot artifacts
                defending_player = self._siege_defending_player
                if defending_player is not None and def_hs is not None:
                    if atk_hs is not None:
                        _looted_names = self._loot_artifacts(atk_hs.hero, def_hs.hero)
                    defending_player.remove_hero(def_hs)
                    self._check_player_defeat(defending_player)
                self._state.check_victory()
            elif isinstance(self.combat_opponent, PlayerState):
                # Hero-vs-hero: defender's hero dies, loot artifacts
                if def_hs is not None:
                    if atk_hs is not None:
                        _looted_names = self._loot_artifacts(atk_hs.hero, def_hs.hero)
                    self.combat_opponent.remove_hero(def_hs)
                    self._check_player_defeat(self.combat_opponent)
                else:
                    self.combat_opponent.defeated = True
                self._state.check_victory()
        else:
            # Attacker lost — attacker hero dies
            if isinstance(self.combat_opponent, TownSite):
                defending_player = self._siege_defending_player
                if defending_player is not None and def_hs is not None:
                    self._sync_army_from_combat(
                        def_hs, self.combat_engine.battlefield.defender
                    )
                else:
                    town = self.combat_opponent.town
                    if town is not None:
                        surviving = [
                            s
                            for s in self.combat_engine.battlefield.defender.stacks
                            if s.alive
                        ]
                        town.garrison = [
                            CreatureStack(
                                stats=s.stats, count=s.count, current_hp=s.current_hp
                            )
                            for s in surviving
                        ]
            elif isinstance(self.combat_opponent, PlayerState):
                if def_hs is not None:
                    self._sync_army_from_combat(
                        def_hs, self.combat_engine.battlefield.defender
                    )
                else:
                    self._sync_army_from_combat(
                        self.combat_opponent, self.combat_engine.battlefield.defender
                    )

            # Loot attacker's artifacts before removing
            if atk_hs is not None:
                if isinstance(self.combat_opponent, PlayerState) and def_hs is not None:
                    _looted_names = self._loot_artifacts(def_hs.hero, atk_hs.hero)
                elif isinstance(self.combat_opponent, TownSite):
                    defending_player = self._siege_defending_player
                    if defending_player is not None and def_hs is not None:
                        _looted_names = self._loot_artifacts(def_hs.hero, atk_hs.hero)

            # Remove attacker's hero
            if atk_hs is not None:
                attacker.remove_hero(atk_hs)
                self._check_player_defeat(attacker)
            else:
                attacker.defeated = True
            self._state.check_victory()

        # Award XP to the winning hero
        xp_earned = 0
        if winner is not None:
            xp_earned = self._award_combat_xp(winner, atk_hs, def_hs)
        opponent_desc = getattr(
            self.combat_opponent, "name", str(type(self.combat_opponent).__name__)
        )
        if self._gl:
            self._gl.log_combat_end(
                winner,
                attacker,
                opponent_desc,
                level_ups=self._pending_level_ups,
            )

        # Build post-combat description for status banner
        desc_parts: list[str] = []
        # Preserve any reward description already set (e.g. creature bank loot)
        if self.last_event_description:
            desc_parts.append(self.last_event_description)
        if xp_earned > 0:
            desc_parts.append(f"+{xp_earned} XP")
        if _looted_names:
            if len(_looted_names) <= 2:
                desc_parts.append("Looted: " + ", ".join(_looted_names))
            else:
                desc_parts.append(f"Looted {len(_looted_names)} artifacts")
        if desc_parts:
            self.last_event_description = " | ".join(desc_parts)

        self.combat_engine = None
        self.combat_opponent = None
        self.combat_attacker_player = None
        self.combat_attacker_hero = None
        self.combat_defender_hero = None
        self._siege_defending_player = None
        self._combat_original_enemy_stacks = None
        self._combat_original_attacker_stacks = None
        self._combat_is_hero_or_siege = False
        self.mode = GameMode.ADVENTURE

    def _check_player_defeat(self, player: PlayerState):
        """Check if player should be marked defeated (no heroes + no towns)."""
        if player.all_alive_heroes():
            return  # still has heroes
        from lops.adventure.map_objects import TownSite

        owns_towns = any(
            isinstance(obj, TownSite) and obj.owner == player.player_id
            for obj in self._state.map_objects
        )
        if not owns_towns:
            player.defeated = True

    def _build_combat_army_from_hero(self, hs, side: Side) -> Army:
        """Build a combat Army from a specific HeroState."""
        stacks = [
            self._clone_stack(s, side, i) for i, s in enumerate(hs.army) if s.alive
        ]
        return Army(hero=hs.hero, stacks=stacks, side=side)

    def _clone_stack(
        self, stack: CreatureStack, side: Side, index: int
    ) -> CreatureStack:
        """Clone a stack for combat (preserving count/hp)."""
        return CreatureStack(
            stats=stack.stats,
            count=stack.count,
            current_hp=stack.current_hp,
            side=side,
            slot_index=index,
        )

    def _sync_army_from_combat(self, army_owner, combat_army: Army):
        """Update army stacks with post-combat state.

        army_owner: anything with .army (PlayerState or HeroState).
        """
        surviving = [s for s in combat_army.stacks if s.alive]
        for adv_stack in army_owner.army:
            for combat_stack in surviving:
                if combat_stack.stats.name == adv_stack.stats.name:
                    adv_stack.count = combat_stack.count
                    adv_stack.current_hp = combat_stack.current_hp
                    break
            else:
                adv_stack.count = 0
                adv_stack.current_hp = 0
        army_owner.army = [s for s in army_owner.army if s.alive]

    # --- Town screen ---

    def open_town_screen(self, town_site: TownSite):
        self.active_town = town_site
        self.mode = GameMode.TOWN_SCREEN

    def close_town_screen(self):
        self.active_town = None
        self.mode = GameMode.ADVENTURE

    # --- Marketplace ---

    def get_marketplace_count(self, player: PlayerState) -> int:
        """Count how many marketplaces this player owns across all towns."""
        count = 0
        for obj in self._state.map_objects:
            if (
                isinstance(obj, TownSite)
                and obj.owner == player.player_id
                and obj.town is not None
                and BuildingId.MARKETPLACE in obj.town.buildings
            ):
                count += 1
        return count

    @staticmethod
    def get_exchange_rate(
        marketplace_count: int, sell_type: str, buy_type: str
    ) -> tuple[int, int]:
        """Return (sell_amount, buy_amount) ratio for a trade.

        HoMM3 exchange rate table:
        - 1 marketplace: 5:1 resource:resource, sell 1 res -> 100g, buy 1 res -> 500g
        - 2 marketplaces: 4:1, 125g, 400g
        - 3 marketplaces: 3:1, 166g, 333g
        - 4+ marketplaces: 2:1, 250g, 250g
        """
        mp = max(1, marketplace_count)

        if sell_type == "gold" and buy_type == "gold":
            return (0, 0)  # can't trade gold for gold

        if sell_type != "gold" and buy_type != "gold":
            # Resource-to-resource
            if mp >= 4:
                return (2, 1)
            elif mp >= 3:
                return (3, 1)
            elif mp >= 2:
                return (4, 1)
            else:
                return (5, 1)

        if sell_type != "gold" and buy_type == "gold":
            # Sell resource for gold
            if mp >= 4:
                return (1, 250)
            elif mp >= 3:
                return (1, 166)
            elif mp >= 2:
                return (1, 125)
            else:
                return (1, 100)

        # sell_type == "gold" and buy_type != "gold"
        # Buy resource with gold
        if mp >= 4:
            return (250, 1)
        elif mp >= 3:
            return (333, 1)
        elif mp >= 2:
            return (400, 1)
        else:
            return (500, 1)

    def execute_trade(
        self, player: PlayerState, sell_type: str, buy_type: str, sell_amount: int
    ) -> bool:
        """Execute a marketplace trade. Returns True on success."""
        if sell_type == buy_type:
            return False
        mp_count = self.get_marketplace_count(player)
        if mp_count < 1:
            return False
        sell_ratio, buy_ratio = self.get_exchange_rate(mp_count, sell_type, buy_type)
        if sell_ratio <= 0 or buy_ratio <= 0:
            return False
        if sell_amount < sell_ratio:
            return False  # not enough to make a single trade
        # How many full trades can we do?
        trades = sell_amount // sell_ratio
        total_sell = trades * sell_ratio
        total_buy = trades * buy_ratio

        # Check player has enough
        current = getattr(player.resources, sell_type, 0)
        if current < total_sell:
            return False

        # Execute
        setattr(player.resources, sell_type, current - total_sell)
        current_buy = getattr(player.resources, buy_type, 0)
        setattr(player.resources, buy_type, current_buy + total_buy)

        if self._gl:
            self._gl.log_pickup(
                player,
                f"Traded {total_sell} {sell_type} for {total_buy} {buy_type}",
            )
        return True

    def open_hero_modal(self):
        self.mode = GameMode.HERO_MODAL

    def close_hero_modal(self):
        self.mode = GameMode.ADVENTURE

    def recruit_from_town(self, dwelling_index: int, count: int) -> bool:
        """Recruit creatures from the active town.

        If a hero is at the town, recruited stacks go to the hero's army.
        Otherwise they go to the town garrison.
        """
        if self.active_town is None or self.active_town.town is None:
            return False
        player = self._state.current_player
        town = self.active_town.town
        stack, cost = town.recruit(dwelling_index, count, player.resources)
        if stack is None:
            return False
        player.gold -= cost
        if self._gl:
            self._gl.log_recruit(player, stack.stats.name, stack.count, cost)

        hero_at_town = self._hero_at_town(self.active_town)
        if hero_at_town is not None:
            if not self._merge_stack_into_army(hero_at_town, stack):
                # Army full — overflow to garrison
                self._merge_stack_into_garrison(town, stack)
        else:
            self._merge_stack_into_garrison(town, stack)
        return True

    def upgrade_creature_at_town(self, army_slot: int) -> bool:
        """Upgrade a creature stack in the hero's army at the active town.

        Pays the per-unit cost difference (upgraded cost - base cost).
        Requires the town's dwelling for that creature tier to be upgraded.
        Returns True on success.
        """
        if self.active_town is None or self.active_town.town is None:
            return False
        player = self._state.current_player
        hero_hs = self._hero_at_town(self.active_town)
        if hero_hs is None:
            return False
        if army_slot < 0 or army_slot >= len(hero_hs.army):
            return False

        stack = hero_hs.army[army_slot]
        if not stack.alive:
            return False

        # Find if this creature type can be upgraded via a dwelling in this town
        from lops.adventure.buildings import CREATURE_UPGRADES, UPGRADED_RECRUIT_COST

        _base_ct = stack.stats.name_to_type() if hasattr(stack.stats, "name_to_type") else None
        upgraded_ct = CREATURE_UPGRADES.get(_base_ct) if _base_ct is not None else None

        # Look up by matching creature type from the dwelling config
        town = self.active_town.town
        for dwelling in town.dwellings:
            if not dwelling.upgraded:
                continue
            # Check if this stack matches the base creature of this dwelling
            if dwelling.creature_type.name == self._creature_type_for_stats(
                stack.stats
            ):
                upgraded_type = CREATURE_UPGRADES.get(dwelling.creature_type)
                if upgraded_type is None:
                    continue
                # Stack is already upgraded?
                from lops.data.creatures import CREATURE_REGISTRY

                if stack.stats == CREATURE_REGISTRY[upgraded_type]:
                    return False  # already upgraded

                upg_cost = UPGRADED_RECRUIT_COST.get(upgraded_type, 0)
                base_cost = dwelling.cost_per_unit
                diff = upg_cost - base_cost
                total_cost = diff * stack.count
                if total_cost < 0:
                    total_cost = 0
                if player.resources.gold < total_cost:
                    return False

                # Perform the upgrade
                old_name = stack.stats.name
                player.resources.gold -= total_cost
                stack.stats = CREATURE_REGISTRY[upgraded_type]
                stack.current_hp = stack.stats.hp  # heal to new max
                stack.shots_left = stack.stats.shots
                if self._gl:
                    self._gl.log_upgrade_creature(
                        player,
                        old_name,
                        CREATURE_REGISTRY[upgraded_type].name,
                        stack.count,
                        total_cost,
                    )
                return True

        return False

    def _creature_type_for_stats(self, stats) -> str | None:
        """Find CreatureType name matching a CreatureStats object."""
        from lops.data.creatures import CREATURE_REGISTRY

        for ct, s in CREATURE_REGISTRY.items():
            if s is stats or s.name == stats.name:
                return ct.name
        return None

    def get_upgrade_info(self, army_slot: int) -> dict | None:
        """Get upgrade info for an army slot at the active town.

        Returns {upgraded_name, cost_per_unit, total_cost, count} or None.
        """
        if self.active_town is None or self.active_town.town is None:
            return None
        hero_hs = self._hero_at_town(self.active_town)
        if hero_hs is None:
            return None
        if army_slot < 0 or army_slot >= len(hero_hs.army):
            return None

        stack = hero_hs.army[army_slot]
        if not stack.alive:
            return None

        from lops.adventure.buildings import CREATURE_UPGRADES, UPGRADED_RECRUIT_COST
        from lops.data.creatures import CREATURE_REGISTRY

        town = self.active_town.town
        for dwelling in town.dwellings:
            if not dwelling.upgraded:
                continue
            ct_name = self._creature_type_for_stats(stack.stats)
            if ct_name == dwelling.creature_type.name:
                upgraded_type = CREATURE_UPGRADES.get(dwelling.creature_type)
                if upgraded_type is None:
                    continue
                # Already upgraded?
                if stack.stats == CREATURE_REGISTRY[upgraded_type]:
                    return None
                upg_cost = UPGRADED_RECRUIT_COST.get(upgraded_type, 0)
                base_cost = dwelling.cost_per_unit
                diff = max(0, upg_cost - base_cost)
                return {
                    "upgraded_name": CREATURE_REGISTRY[upgraded_type].name,
                    "cost_per_unit": diff,
                    "total_cost": diff * stack.count,
                    "count": stack.count,
                }
        return None

    def build_in_town(self, building_id) -> bool:
        """Build a structure in the active town."""
        if self.active_town is None or self.active_town.town is None:
            return False
        player = self._state.current_player
        town = self.active_town.town
        bdict = town._get_buildings_dict()
        bdef = bdict.get(building_id)
        gold_cost = bdef.cost.gold if bdef else 0
        remaining = town.build(building_id, player.resources)
        if remaining is None:
            return False
        player.resources = remaining
        if self._gl:
            self._gl.log_build(player, bdef.name if bdef else str(building_id.name), gold_cost)

        # If mage guild was built, populate spells and teach hero
        _GUILD_LEVELS = {
            BuildingId.MAGE_GUILD_1: 1,
            BuildingId.MAGE_GUILD_2: 2,
            BuildingId.MAGE_GUILD_3: 3,
            BuildingId.MAGE_GUILD_4: 4,
            BuildingId.MAGE_GUILD_5: 5,
        }
        if building_id in _GUILD_LEVELS:
            level = _GUILD_LEVELS[building_id]
            town.populate_guild_level(level)
            # Teach spells to hero at town
            hero_at = self._hero_at_town(self.active_town)
            if hero_at is not None:
                town.hero_learn_spells(hero_at.hero)

        return True

    def buy_artifact(self, artifact_index: int) -> bool:
        """Buy an artifact from the town's artifact merchant."""
        if self.active_town is None or self.active_town.town is None:
            return False
        town = self.active_town.town
        if artifact_index < 0 or artifact_index >= len(town.merchant_artifacts):
            return False
        art_id = town.merchant_artifacts[artifact_index]
        from lops.data.artifacts import ARTIFACT_COST

        cost = ARTIFACT_COST.get(art_id, 5000)
        player = self._state.current_player
        if player.resources.gold < cost:
            return False
        hero_at = self._hero_at_town(self.active_town)
        if hero_at is None:
            return False
        player.resources.gold -= cost
        from lops.artifacts import ArtifactInstance

        if hero_at.hero.equipment:
            hero_at.hero.equipment.equip(ArtifactInstance(artifact_id=art_id))
        town.merchant_artifacts.pop(artifact_index)
        if self._gl:
            self._gl.log_buy_artifact(player, str(art_id), cost)
        return True

    def _merge_stack_into_army(self, army_owner, new_stack: CreatureStack) -> bool:
        """Add recruited stack to army, merging with existing if possible.

        army_owner: anything with an .army list (PlayerState or HeroState).
        Returns True if the stack was placed, False if army is full.
        """
        for existing in army_owner.army:
            if existing.stats.name == new_stack.stats.name and existing.alive:
                existing.count += new_stack.count
                return True
        if len(army_owner.army) < 7:
            army_owner.army.append(new_stack)
            return True
        return False

    def _merge_stack_into_garrison(self, town: Town, new_stack: CreatureStack):
        """Add a stack to the town garrison, merging by creature name if possible."""
        for existing in town.garrison:
            if existing.stats.name == new_stack.stats.name and existing.alive:
                existing.count += new_stack.count
                return
        if len(town.garrison) < 7:
            town.garrison.append(new_stack)

    def _hero_at_town(self, town_site: TownSite) -> HeroState | None:
        """Find the owner's hero at the town position, or None."""
        for p in self._state.players:
            if not p.defeated and p.player_id == town_site.owner:
                hs = p.hero_at(town_site.position)
                if hs is not None:
                    return hs
        return None

    def hire_hero(self, town_site: TownSite, hero_def_index: int) -> bool:
        """Hire a hero from the tavern. Returns True on success."""
        from lops.adventure.adventure_state import HeroState
        from lops.data.heroes import HERO_HIRE_COST, create_hero_from_def

        player = self._state.current_player
        town = town_site.town
        if town is None or BuildingId.TAVERN not in town.buildings:
            return False
        if hero_def_index < 0 or hero_def_index >= len(town.tavern_heroes):
            return False
        if player.resources.gold < HERO_HIRE_COST:
            return False
        if len(player.alive_heroes()) >= 5:
            return False
        # Only 1 hero allowed at town position for now
        if self._hero_at_town(town_site) is not None:
            return False

        hero_def = town.tavern_heroes[hero_def_index]
        hero = create_hero_from_def(hero_def)
        army = self._make_hired_hero_army(town)

        hs = HeroState(hero=hero, army=army, position=town_site.position)
        if not player.add_hero(hs):
            return False

        player.resources.gold -= HERO_HIRE_COST
        town.tavern_heroes.pop(hero_def_index)
        player.reveal_for_hero(hs)
        town.hero_learn_spells(hero)
        if self._gl:
            self._gl.log_hire_hero(player, hero.name)
        return True

    def hire_hero_for_player(
        self, player: PlayerState, town_site: TownSite, hero_def_index: int
    ) -> bool:
        """Hire a hero for a specific player (used by AI)."""
        from lops.adventure.adventure_state import HeroState
        from lops.data.heroes import HERO_HIRE_COST, create_hero_from_def

        town = town_site.town
        if town is None or BuildingId.TAVERN not in town.buildings:
            return False
        if hero_def_index < 0 or hero_def_index >= len(town.tavern_heroes):
            return False
        if player.resources.gold < HERO_HIRE_COST:
            return False
        if len(player.alive_heroes()) >= 5:
            return False
        if self._hero_at_town(town_site) is not None:
            return False

        hero_def = town.tavern_heroes[hero_def_index]
        hero = create_hero_from_def(hero_def)
        army = self._make_hired_hero_army(town)

        hs = HeroState(hero=hero, army=army, position=town_site.position)
        if not player.add_hero(hs):
            return False

        player.resources.gold -= HERO_HIRE_COST
        town.tavern_heroes.pop(hero_def_index)
        player.reveal_for_hero(hs)
        town.hero_learn_spells(hero)
        return True

    def transfer_to_garrison(self, slot_index: int, count: int | None = None) -> bool:
        """Move creatures from hero army to town garrison.

        If count is None or >= stack size, moves the entire stack.
        Otherwise splits: count creatures go to garrison, remainder stays.
        Hero must always keep at least 1 creature in their army.
        """
        if self.active_town is None or self.active_town.town is None:
            return False
        hero_player = self._hero_at_town(self.active_town)
        if hero_player is None:
            return False
        if slot_index < 0 or slot_index >= len(hero_player.army):
            return False

        stack = hero_player.army[slot_index]
        if not stack.alive:
            return False

        alive_count = sum(1 for s in hero_player.army if s.alive)
        is_last_stack = alive_count <= 1
        town = self.active_town.town

        # Resolve how many to move
        move_all = count is None or count >= stack.count
        if move_all:
            if is_last_stack:
                # Last stack: clamp to partial transfer, keeping 1 behind
                count = stack.count - 1
                if count <= 0:
                    return False
            else:
                # Move the entire stack
                hero_player.army.pop(slot_index)
                self._merge_stack_into_garrison(town, stack)
                return True

        # Partial transfer
        assert count is not None
        if count <= 0:
            return False
        if is_last_stack:
            count = min(count, stack.count - 1)
            if count <= 0:
                return False
        # Check garrison has room (unless merging)
        has_merge_target = any(
            s.stats.name == stack.stats.name and s.alive for s in town.garrison
        )
        if not has_merge_target and len(town.garrison) >= 7:
            return False
        # Split: reduce hero stack, create new stack for garrison
        stack.count -= count
        new_stack = CreatureStack(
            stats=stack.stats,
            count=count,
            current_hp=stack.stats.hp,
        )
        self._merge_stack_into_garrison(town, new_stack)
        return True

    def transfer_from_garrison(
        self, garrison_index: int, count: int | None = None
    ) -> bool:
        """Move creatures from garrison to hero army.

        If count is None or >= stack size, moves the entire stack.
        Otherwise splits: count creatures go to hero, remainder stays.
        """
        if self.active_town is None or self.active_town.town is None:
            return False
        hero_player = self._hero_at_town(self.active_town)
        if hero_player is None:
            return False
        town = self.active_town.town
        if garrison_index < 0 or garrison_index >= len(town.garrison):
            return False

        stack = town.garrison[garrison_index]
        if not stack.alive:
            return False

        if count is None or count >= stack.count:
            # Move entire stack
            if len(hero_player.army) >= 7:
                # Check if we can merge
                has_merge = any(
                    s.stats.name == stack.stats.name and s.alive
                    for s in hero_player.army
                )
                if not has_merge:
                    return False
            town.garrison.pop(garrison_index)
            self._merge_stack_into_army(hero_player, stack)
        else:
            if count <= 0:
                return False
            # Check hero army has room (unless merging)
            has_merge_target = any(
                s.stats.name == stack.stats.name and s.alive for s in hero_player.army
            )
            if not has_merge_target and len(hero_player.army) >= 7:
                return False
            # Split: reduce garrison stack, add to hero
            stack.count -= count
            new_stack = CreatureStack(
                stats=stack.stats,
                count=count,
                current_hp=stack.stats.hp,
            )
            self._merge_stack_into_army(hero_player, new_stack)
        return True

    # --- AI turn ---

    def run_ai_turn(self) -> str | None:
        """Execute the AI player's full turn, using all available movement points.

        Returns 'combat' if interactive combat was triggered, else None.
        The AI keeps moving until it runs out of MP or targets.
        """
        player = self._state.current_player
        if not player.is_ai or player.defeated:
            return None

        ai = self._ai_controllers.get(player.player_id)
        if ai is None:
            return None

        # Hire a hero first if we have none (before spending gold on buildings/recruits)
        if player.position is None:
            ai.auto_hire_hero(self)
        if player.position is None:
            return None  # still no hero

        # Build/recruit only once per turn (not again after returning from combat)
        if not self._ai_has_built_this_turn:
            ai.auto_build()
            ai.auto_recruit()
            ai.auto_equip_artifacts()
            self._ai_has_built_this_turn = True

        # Loop: keep moving until out of MP or no targets
        max_moves = self.difficulty_settings.max_moves_per_turn
        for _ in range(max_moves):
            if player.movement_points <= 0 or player.defeated:
                break

            destination = ai.take_turn()
            if destination is None:
                break

            event = self.move_hero(player, destination)

            if event == "treasure_chest":
                choice = "xp" if self.difficulty_settings.prefer_xp_from_chests else "gold"
                self.resolve_treasure_chest(player, choice)
                continue  # keep moving
            elif event == "gate":
                continue  # traversed gate, keep moving
            elif event in ("mine_captured", "resource", "artifact", "campfire",
                           "stat_booster", "magic_well"):
                continue  # picked up, keep moving
            elif event == "monster":
                monster = self._state.find_object_at(
                    player.position, layer=self._hero_layer(player)
                )
                if isinstance(monster, WanderingMonster):
                    self._run_ai_combat(player, monster)
                if player.defeated:
                    break
                continue  # keep moving after combat
            elif event in ("enemy_town", "neutral_town"):
                obj = self._state.find_object_at(
                    player.position, layer=self._hero_layer(player)
                )
                if isinstance(obj, TownSite):
                    town = obj.town
                    has_fort = town and self._get_fort_level(town) is not None
                    _dp, _dh = self._find_defender_at_town(obj, player)
                    has_defenders = town and (town.garrison or _dh is not None)
                    if has_fort and has_defenders:
                        defending_human = self._town_has_human_defender(obj, player)
                        self.start_siege_combat(player, obj)
                        if self.combat_engine and defending_human:
                            return "combat"  # interactive: human defends
                        elif self.combat_engine:
                            self.combat_engine.run_headless()
                            self.on_combat_finished()
                    else:
                        self.capture_town(player, obj)
                if player.defeated:
                    break
                continue
            elif event == "enemy_hero":
                for other in self._state.players:
                    if other.player_id != player.player_id and not other.defeated:
                        if other.hero_at(player.position) is not None:
                            if not other.is_ai:
                                self.start_hero_combat(player, other, player.position)
                                return "combat"
                            else:
                                self._run_ai_hero_combat(
                                    player, other, player.position
                                )
                                break
                if player.defeated:
                    break
                continue
            elif event == "own_town":
                ai.auto_recruit()
                ai.auto_pickup_garrison()
                continue  # keep moving after town visit
            elif event in ("pandora_guarded", "creature_bank"):
                obj = self._state.find_object_at(
                    player.position, layer=self._hero_layer(player)
                )
                if obj:
                    self._run_ai_combat(player, obj)
                if player.defeated:
                    break
                continue
            else:
                # Unknown or None event — keep trying
                continue

        return None

    def _run_ai_combat(self, player: PlayerState, monster):
        """Run combat for AI player (headless)."""
        self.start_monster_combat(player, monster)
        if self.combat_engine:
            self.combat_engine.run_headless()
            self.on_combat_finished()

    def _run_ai_hero_combat(
        self,
        attacker: PlayerState,
        defender: PlayerState,
        position: CubeCoord | None = None,
    ):
        """Run hero-vs-hero combat (headless for AI attacker)."""
        self.start_hero_combat(attacker, defender, position)
        if self.combat_engine:
            self.combat_engine.run_headless()
            self.on_combat_finished()

    # --- Adventure spells ---

    def get_adventure_spells(self, player: PlayerState) -> list:
        """Return list of adventure-castable spells for the active hero."""
        from lops.data.spells import SPELL_REGISTRY
        from lops.spells import SpellEffect

        hero_state = player.active_hero_state
        if hero_state is None:
            return []
        hero = hero_state.hero
        if not hero.spells:
            return []

        spells = []
        for spell_id in hero.spells:
            spell = SPELL_REGISTRY.get(spell_id)
            if spell and spell.effect == SpellEffect.ADVENTURE:
                from lops.spells import get_mana_cost

                cost = get_mana_cost(hero, spell)
                if hero.mana >= cost:
                    spells.append(spell)
        return spells

    def cast_adventure_spell(
        self, player: PlayerState, spell_id, target=None
    ) -> str | None:
        """Cast an adventure map spell. Returns result message or None on failure."""
        from lops.data.spells import SPELL_REGISTRY
        from lops.spells import SpellEffect, SpellId, get_mana_cost

        spell = SPELL_REGISTRY.get(spell_id)
        if spell is None or spell.effect != SpellEffect.ADVENTURE:
            return None

        hero_state = player.active_hero_state
        if hero_state is None:
            return None
        hero = hero_state.hero

        cost = get_mana_cost(hero, spell)
        if hero.mana < cost:
            return None

        result = None

        if spell_id == SpellId.TOWN_PORTAL:
            result = self._cast_town_portal(player, hero_state, hero)
        elif spell_id == SpellId.DIMENSION_DOOR:
            result = self._cast_dimension_door(player, hero_state, hero, target)
        elif spell_id == SpellId.FLY:
            result = self._cast_fly(player, hero_state, hero)
        elif spell_id == SpellId.WATER_WALK:
            result = self._cast_water_walk(player, hero_state, hero)
        elif spell_id == SpellId.VISIONS:
            result = self._cast_visions(player, hero_state, hero)

        if result is not None:
            hero.mana -= cost
        return result

    def _cast_town_portal(self, player, hero_state, hero) -> str | None:
        """Teleport hero to nearest owned town."""
        from lops.hex import cube_distance

        owned_towns = [
            obj
            for obj in self._state.map_objects
            if isinstance(obj, TownSite) and obj.owner == player.player_id
        ]
        if not owned_towns:
            return None

        # Find nearest owned town
        nearest = min(
            owned_towns, key=lambda t: cube_distance(hero_state.position, t.position)
        )
        hero_state.position = nearest.position
        hero_state.movement_points = 0  # costs all movement
        return f"{hero.name} teleported to {nearest.name}!"

    def _cast_dimension_door(self, player, hero_state, hero, target) -> str | None:
        """Teleport hero to a visible hex within range."""
        if target is None:
            return None

        from lops.hex import cube_distance

        max_range = 10  # tiles
        dist = cube_distance(hero_state.position, target)
        if dist > max_range:
            return None

        # Must be revealed
        if target not in player.revealed:
            return None

        hero_state.position = target
        hero_state.movement_points = max(0, hero_state.movement_points - 300)
        return f"{hero.name} dimension-doored to a new location!"

    def _cast_fly(self, player, hero_state, hero) -> str | None:
        """Grant Fly buff - hero can cross water/mountains this turn."""
        hero_state.can_fly = True
        return f"{hero.name} can now fly!"

    def _cast_water_walk(self, player, hero_state, hero) -> str | None:
        """Grant Water Walk - hero can cross water this turn."""
        hero_state.can_water_walk = True
        return f"{hero.name} can now walk on water!"

    def _cast_visions(self, player, hero_state, hero) -> str | None:
        """Reveal nearest enemy hero army composition."""
        from lops.hex import cube_distance

        # Find nearest enemy hero
        nearest_enemy = None
        min_dist = float("inf")
        for p in self._state.players:
            if p.player_id == player.player_id:
                continue
            for hs in p.heroes:
                if hs.position is None or hero_state.position is None:
                    continue
                dist = cube_distance(hero_state.position, hs.position)
                if dist < min_dist:
                    min_dist = dist
                    nearest_enemy = hs

        if nearest_enemy is None:
            return "No enemy heroes found."

        # Build army description
        lines = [
            f"Enemy hero {nearest_enemy.hero.name} (Lv{nearest_enemy.hero.level}):"
        ]
        for stack in nearest_enemy.army:
            if stack.alive:
                lines.append(f"  {stack.count}x {stack.stats.name}")
        return "\n".join(lines)

    # --- End turn ---

    def end_turn(self):
        """End the current player's turn."""
        self._ai_has_built_this_turn = False
        old_week = self._state.week
        self._state.end_turn()
        if self._gl:
            self._gl.log_end_turn(
                self._state.current_player,
                self._state.day,
                self._state.week,
            )
        if self._state.week != old_week:
            self._refresh_all_taverns()

    # --- Town capture ---

    def capture_town(self, player: PlayerState, town_site: TownSite):
        """Capture a town for the given player."""
        old_owner_id = town_site.owner
        town_site.owner = player.player_id
        if self._gl:
            self._gl.log_capture_town(player, town_site.name)
        if town_site.town:
            town_site.town.owner_id = player.player_id
        # Check if the old owner is now defeated
        if old_owner_id is not None and old_owner_id != player.player_id:
            for p in self._state.players:
                if p.player_id == old_owner_id and not p.defeated:
                    self._check_player_defeat(p)
                    break
            self._state.check_victory()


# Helper name lookup
from lops.data.creatures import CREATURE_REGISTRY

CREATURE_REGISTRY_NAMES = {ct: stats.name for ct, stats in CREATURE_REGISTRY.items()}

# Faction town name pools (from HoMM3 wiki)
_TOWN_NAMES: dict[FactionId, list[str]] = {
    FactionId.CASTLE: [
        "Whitestone",
        "Goldenhall",
        "Bright Tower",
        "Eaglecrest",
        "Sunhaven",
        "Lionheart",
        "Silver Helm",
        "Gryphon Ridge",
        "Crownguard",
        "Valor Keep",
        "Dawn's Light",
        "King's Rest",
        "Highcastle",
        "Shining Fort",
        "Royal Gate",
        "Blessed March",
    ],
    FactionId.NECROPOLIS: [
        "Agony",
        "Blackquarter",
        "Blight",
        "Cessacioun",
        "Coldreign",
        "Coldsoul",
        "Death's Gate",
        "Dark Cloud",
        "Dark Eternal",
        "Ghostwind",
        "Grave Raven",
        "Haunt's Wind",
        "Sanctum",
        "Shadow Keep",
        "Terminus",
        "Worm Warren",
    ],
    FactionId.INFERNO: [
        "Ashburn",
        "Brimstone",
        "Char",
        "Cinder",
        "Devil's Maw",
        "Ember",
        "Fire Lord",
        "Flame",
        "Hellfrost",
        "Inferno",
        "Magma",
        "Perdition",
        "Purgatory",
        "Searing",
        "Scorch",
        "Sulphur Springs",
    ],
    FactionId.DUNGEON: [
        "Ambush",
        "Backstab",
        "Conspiracy",
        "Dark Cavern",
        "Deep Shadow",
        "Doom Hollow",
        "Dusk",
        "Endless Night",
        "Fell Moon",
        "Midnight",
        "Night Fang",
        "Obsidian",
        "Shadow Gate",
        "Stalactite",
        "Undertow",
        "Venom",
    ],
}


def _random_town_name(faction_id: FactionId, rng) -> str:
    """Pick a random town name for the given faction."""
    names = _TOWN_NAMES.get(faction_id, _TOWN_NAMES[FactionId.CASTLE])
    result: str = rng.choice(names)
    return result
