"""Adventure AI: controls the AI hero's movement and decisions."""

from __future__ import annotations

from lops.adventure.adventure_state import AdventureState, PlayerState
from lops.adventure.buildings import BuildingId
from lops.game_log import GameLog
from lops.adventure.hero_movement import movement_range
from lops.adventure.map_objects import (
    HillFort,
    Mine,
    PandorasBox,
    ResourcePickup,
    TownSite,
    TreasureChest,
    WanderingMonster,
)
from lops.adventure.world_map import WorldMap
from lops.hex import CubeCoord, cube_distance


def estimate_army_strength(army: list) -> float:
    """Rough estimate of army power for AI decisions."""
    total = 0.0
    for stack in army:
        if stack.alive:
            avg_dmg = (stack.stats.min_damage + stack.stats.max_damage) / 2
            total += stack.count * avg_dmg * stack.stats.hp * 0.01
    return total


class AdventureAI:
    """Heuristic AI for adventure map decisions."""

    def __init__(
        self, player: PlayerState, adventure_state: AdventureState, world_map: WorldMap
    ):
        self.player = player
        self.state = adventure_state
        self.world_map = world_map
        self._layered_map = None  # set by GameDirector if available
        self.game_log: GameLog | None = None  # set by GameDirector
        self.difficulty_settings = None  # set by GameDirector

    @property
    def _monster_threshold(self) -> float:
        if self.difficulty_settings:
            return self.difficulty_settings.attack_threshold_monster
        return 1.5

    @property
    def _hero_threshold(self) -> float:
        if self.difficulty_settings:
            return self.difficulty_settings.attack_threshold_hero
        return 1.8

    @property
    def _explore_weight(self) -> float:
        if self.difficulty_settings:
            return self.difficulty_settings.explore_weight
        return 1.0

    @property
    def _active_map(self) -> WorldMap:
        """Get the map for the hero's current layer."""
        hs = self.player.active_hero_state
        if hs and self._layered_map is not None:
            return self._layered_map.get_map(hs.layer)
        return self.world_map

    def take_turn(self) -> CubeCoord | None:
        """Decide where to move this turn. Returns destination hex or None to end turn.

        Priority:
        1. Visit own town if creatures available and have gold
        2. Attack enemy town if strong enough (recapture or conquer)
        3. Attack enemy hero if strong enough
        4. Capture nearest reachable uncaptured/enemy mine
        5. Collect nearest reachable resource
        6. Attack nearest beatable monster
        7. Move toward nearest high-value target (enemy town > enemy hero)
        8. End turn
        """
        blocked = self._get_blocked_hexes()
        from lops.skills import SkillId

        pf = self.player.hero.skill_value(SkillId.PATHFINDING)
        if self.player.position is None:
            return None
        active_map = self._active_map
        reachable = movement_range(
            self.player.position,
            self.player.movement_points,
            active_map,
            blocked,
            pathfinding_reduction=pf,
        )

        # Add enemy hero/town positions if adjacent to reachable hexes
        self._add_enemy_targets_to_reachable(reachable)

        def _decide(reason: str, dest: CubeCoord) -> CubeCoord:
            if self.game_log:
                self.game_log.log_ai_decision(self.player, reason)
            return dest

        # Check if we should visit our town
        town_dest = self._consider_town_visit(reachable)
        if town_dest is not None:
            return _decide("visit own town (recruit/garrison)", town_dest)

        # Attack enemy town if reachable and we're strong enough
        town_attack = self._find_attackable_enemy_town(reachable)
        if town_attack is not None:
            return _decide("attack enemy town", town_attack)

        # Attack enemy hero if reachable and we're strong enough
        hero_attack = self._find_attackable_enemy_hero(reachable)
        if hero_attack is not None:
            return _decide("attack enemy hero", hero_attack)

        # Look for capturable mines
        mine_dest = self._find_capturable_mine(reachable)
        if mine_dest is not None:
            return _decide("capture mine", mine_dest)

        # Stat boosters (free stats are high priority)
        booster_dest = self._find_nearest_stat_booster(reachable)
        if booster_dest is not None:
            return _decide("visit stat booster", booster_dest)

        # Capturable dwellings (like mines)
        dwelling_dest = self._find_capturable_dwelling(reachable)
        if dwelling_dest is not None:
            return _decide("capture dwelling", dwelling_dest)

        # Look for resources
        resource_dest = self._find_nearest_resource(reachable)
        if resource_dest is not None:
            return _decide("collect gold pickup", resource_dest)

        # Treasure chests (XP is very valuable for leveling)
        chest_dest = self._find_nearest_treasure_chest(reachable)
        if chest_dest is not None:
            return _decide("collect treasure chest", chest_dest)

        # Campfires
        campfire_dest = self._find_nearest_campfire(reachable)
        if campfire_dest is not None:
            return _decide("collect campfire", campfire_dest)

        # Look for artifact pickups
        artifact_dest = self._find_nearest_artifact(reachable)
        if artifact_dest is not None:
            return _decide("collect artifact", artifact_dest)

        # Magic well (if low mana)
        well_dest = self._find_magic_well(reachable)
        if well_dest is not None:
            return _decide("visit magic well", well_dest)

        # Hill Fort (upgrade creatures for free/cheap)
        hill_fort_dest = self._find_hill_fort(reachable)
        if hill_fort_dest is not None:
            return _decide("visit hill fort", hill_fort_dest)

        # Unguarded Pandora's Boxes
        pandora_dest = self._find_unguarded_pandora(reachable)
        if pandora_dest is not None:
            return _decide("open Pandora's Box", pandora_dest)

        # Creature banks (if strong enough)
        bank_dest = self._find_beatable_creature_bank(reachable)
        if bank_dest is not None:
            return _decide("raid creature bank", bank_dest)

        # Guarded Pandora's Boxes (if strong enough)
        gpandora_dest = self._find_beatable_pandora(reachable)
        if gpandora_dest is not None:
            return _decide("raid guarded Pandora's Box", gpandora_dest)

        # Look for beatable monsters
        monster_dest = self._find_beatable_monster(reachable)
        if monster_dest is not None:
            return _decide("attack beatable monster", monster_dest)

        # Move toward best target
        advance_dest = self._advance_toward_target(reachable)
        if advance_dest is not None:
            return _decide("advance toward target", advance_dest)

        if self.game_log:
            self.game_log.log_ai_decision(
                self.player,
                f"idle (no reachable targets, {len(reachable)} hexes in range)",
            )
        return None  # end turn

    def _gold_reserved_for_building(self) -> int:
        """Calculate gold to reserve for the next building the AI wants to build."""
        for obj in self.state.map_objects:
            if (
                isinstance(obj, TownSite)
                and obj.owner == self.player.player_id
                and obj.town
            ):
                town = obj.town
                build_priority = self._get_build_priority(town)
                for bid in build_priority:
                    if bid in town.buildings:
                        continue  # already built
                    from lops.adventure.buildings import get_faction_buildings

                    bdict = get_faction_buildings(town.faction_id)
                    bdef = bdict.get(bid)
                    if bdef is None:
                        continue
                    # Check prereqs are met
                    if all(p in town.buildings for p in bdef.prerequisites):
                        return bdef.cost.gold
                break  # only check first owned town
        return 0

    def auto_recruit(self):
        """Recruit creatures at own town. Reserves gold for the next building."""
        hs = self.player.active_hero_state
        frac = self.difficulty_settings.building_reserve_fraction if self.difficulty_settings else 1.0
        reserved = int(self._gold_reserved_for_building() * frac)
        for obj in self.state.map_objects:
            if (
                isinstance(obj, TownSite)
                and obj.owner == self.player.player_id
                and obj.town
            ):
                town = obj.town
                hero_at_town = hs is not None and hs.position == obj.position
                for i, dwelling in enumerate(town.dwellings):
                    if dwelling.built and dwelling.available > 0:
                        # Don't spend gold reserved for buildings
                        available_gold = self.player.gold - reserved
                        if available_gold <= 0:
                            break
                        # Limit recruitment to what we can afford after reserve
                        unit_cost = dwelling.active_cost_per_unit
                        max_afford = available_gold // unit_cost if unit_cost > 0 else dwelling.available
                        count = min(dwelling.available, max_afford)
                        if count <= 0:
                            continue
                        stack, cost = town.recruit(
                            i, count, self.player.resources
                        )
                        if stack and cost > 0:
                            self.player.gold -= cost
                            dest = "army" if hero_at_town else "garrison"
                            if self.game_log:
                                self.game_log.log_ai_decision(
                                    self.player,
                                    f"recruit {stack.stats.name} x{stack.count} → {dest} ({cost}g)",
                                )
                            if hero_at_town:
                                self._merge_or_add_stack(stack)
                            else:
                                self._merge_or_add_garrison(town, stack)

    def _merge_or_add_garrison(self, town, new_stack):
        """Merge stack into town garrison or add as new slot."""
        for existing in town.garrison:
            if existing.stats.name == new_stack.stats.name and existing.alive:
                existing.count += new_stack.count
                return
        if len(town.garrison) < 7:
            town.garrison.append(new_stack)

    def auto_pickup_garrison(self):
        """Pick up all garrison creatures when hero is at own town."""
        hs = self.player.active_hero_state
        if hs is None:
            return
        for obj in self.state.map_objects:
            if (
                isinstance(obj, TownSite)
                and obj.owner == self.player.player_id
                and obj.town
            ):
                if obj.position != hs.position:
                    continue
                town = obj.town
                kept = []
                for stack in town.garrison:
                    if not stack.alive:
                        continue
                    # Try to merge into hero army
                    merged = False
                    for existing in hs.army:
                        if existing.stats.name == stack.stats.name and existing.alive:
                            existing.count += stack.count
                            merged = True
                            break
                    if not merged and len(hs.army) < 7:
                        hs.army.append(stack)
                        merged = True
                    if not merged:
                        kept.append(stack)  # army full, leave in garrison
                town.garrison = kept

    def auto_equip_artifacts(self):
        """Auto-equip artifacts: best (highest ai_value) first."""
        hero = self.player.hero
        if hero.equipment is None:
            return
        all_arts = hero.equipment.all_artifacts()
        if not all_arts:
            return
        all_arts.sort(key=lambda a: a.definition.ai_value, reverse=True)
        from lops.equipment import HeroEquipment

        hero.equipment = HeroEquipment()
        for art in all_arts:
            hero.equipment.equip(art)

    def auto_hire_hero(self, director) -> bool:
        """Try to hire a hero from the tavern if we have no heroes. Returns True if hired."""
        if self.player.alive_heroes():
            return False  # already have heroes
        from lops.data.heroes import HERO_HIRE_COST

        if self.player.resources.gold < HERO_HIRE_COST:
            return False
        for obj in self.state.map_objects:
            if (
                isinstance(obj, TownSite)
                and obj.owner == self.player.player_id
                and obj.town
            ):
                if obj.town.tavern_heroes:
                    if director.hire_hero_for_player(self.player, obj, 0):
                        return True
        return False

    def auto_build(self):
        """Build structures in AI's town. Dynamically generates priority from faction data."""
        for obj in self.state.map_objects:
            if (
                isinstance(obj, TownSite)
                and obj.owner == self.player.player_id
                and obj.town
            ):
                town = obj.town
                build_priority = self._get_build_priority(town)
                _GUILD_LEVELS = {
                    BuildingId.MAGE_GUILD_1: 1,
                    BuildingId.MAGE_GUILD_2: 2,
                    BuildingId.MAGE_GUILD_3: 3,
                }
                for bid in build_priority:
                    if town.can_build(bid, self.player.resources):
                        remaining = town.build(bid, self.player.resources)
                        if remaining is not None:
                            self.player.resources = remaining
                            if self.game_log:
                                self.game_log.log_ai_decision(
                                    self.player, f"built {bid.name}"
                                )
                            # Populate mage guild spells and teach hero
                            if bid in _GUILD_LEVELS:
                                town.populate_guild_level(_GUILD_LEVELS[bid])
                                town.hero_learn_spells(self.player.hero)
                            break  # one building per turn

    def _get_build_priority(self, town) -> list:
        """Generate build priority list from the town's faction building tree."""
        from lops.adventure.buildings import get_faction_buildings

        bdict = get_faction_buildings(town.faction_id)

        # Categorize buildings
        infra: list[BuildingId] = []  # infrastructure (Fort, Blacksmith, etc.)
        dwellings_base = []  # base dwellings (unlock creatures)
        dwellings_upg = []  # upgrade dwellings
        economy = []  # town halls, marketplace
        mage_guilds = []
        fortifications = []
        special = []

        for bid, bdef in bdict.items():
            if bid in (BuildingId.FORT,):
                infra.insert(0, bid)  # Fort first
            elif bid in (
                BuildingId.BLACKSMITH,
                BuildingId.MARKETPLACE,
                BuildingId.STABLES,
            ):
                infra.append(bid)
            elif bid in (
                BuildingId.TOWN_HALL,
                BuildingId.CITY_HALL,
                BuildingId.CAPITOL,
            ):
                economy.append(bid)
            elif bid in (BuildingId.CITADEL, BuildingId.CASTLE):
                fortifications.append(bid)
            elif bid in (
                BuildingId.MAGE_GUILD_1,
                BuildingId.MAGE_GUILD_2,
                BuildingId.MAGE_GUILD_3,
                BuildingId.MAGE_GUILD_4,
                BuildingId.MAGE_GUILD_5,
            ):
                mage_guilds.append(bid)
            elif bid == BuildingId.RESOURCE_SILO:
                economy.append(bid)
            elif bid == BuildingId.ARTIFACT_MERCHANT:
                special.append(bid)
            elif bid in (BuildingId.VILLAGE_HALL, BuildingId.TAVERN):
                pass  # already built in starter towns
            elif bdef.unlocks_creature is not None:
                dwellings_base.append(bid)
            elif bdef.upgrades_creature is not None:
                dwellings_upg.append(bid)

        # Interleave economy/forts with dwellings for balanced progression:
        # Fort first (enables dwellings), then alternate dwellings with economy/forts
        # Priority: Fort, 2 dwellings, Town Hall, MG1, 2 more dwellings, City Hall,
        #           Citadel, remaining dwellings, more MGs, Capitol, Castle, upgrades
        early_eco = [b for b in economy if b in (BuildingId.TOWN_HALL, BuildingId.CITY_HALL)]
        late_eco = [b for b in economy if b not in early_eco]
        early_fort = [b for b in fortifications if b == BuildingId.CITADEL]
        late_fort = [b for b in fortifications if b != BuildingId.CITADEL]
        return (
            infra
            + dwellings_base[:2]
            + early_eco[:1]  # Town Hall
            + mage_guilds[:1]  # MG1 (prereq for City Hall)
            + dwellings_base[2:4]
            + early_eco[1:]  # City Hall
            + early_fort  # Citadel
            + dwellings_base[4:]
            + mage_guilds[1:3]
            + late_eco  # Capitol, Resource Silo
            + late_fort  # Castle
            + dwellings_upg
            + special
        )

    def _merge_or_add_stack(self, new_stack):
        """Merge stack into army or add as new slot."""
        for existing in self.player.army:
            if existing.stats.name == new_stack.stats.name and existing.alive:
                existing.count += new_stack.count
                return
        if len(self.player.army) < 7:
            self.player.army.append(new_stack)

    def _get_blocked_hexes(self) -> set[CubeCoord]:
        """Get hexes blocked by all other heroes (enemy + friendly except active)."""
        blocked = set()
        active = self.player.active_hero_state
        hero_layer = active.layer if active else 0
        for p in self.state.players:
            if p.defeated:
                continue
            for hs in p.alive_heroes():
                if hs is active:
                    continue
                if hs.position is not None and hs.layer == hero_layer:
                    blocked.add(hs.position)
        return blocked

    def _add_enemy_targets_to_reachable(self, reachable: dict[CubeCoord, int]):
        """Add all enemy hero positions to reachable if adjacent to any reachable hex."""
        from lops.data.terrain import TERRAIN_COST

        active_map = self._active_map
        hero_layer = (self.player.active_hero_state.layer
                      if self.player.active_hero_state else 0)
        for p in self.state.players:
            if p.player_id == self.player.player_id or p.defeated:
                continue
            for ehs in p.alive_heroes():
                pos = ehs.position
                if pos is None or pos in reachable or ehs.layer != hero_layer:
                    continue
                tile = active_map.get_tile(pos)
                enter_cost = TERRAIN_COST.get(tile.terrain, 100) if tile else 100
                if self.player.position:
                    for n in active_map.neighbors(self.player.position):
                        if n == pos:
                            reachable[pos] = enter_cost
                            break
                    else:
                        for n in active_map.neighbors(pos):
                            if n in reachable:
                                total = reachable[n] + enter_cost
                                if total <= self.player.movement_points:
                                    if pos not in reachable or total < reachable[pos]:
                                        reachable[pos] = total
                else:
                    for n in self.world_map.neighbors(pos):
                        if n in reachable:
                            total = reachable[n] + enter_cost
                            if total <= self.player.movement_points:
                                if pos not in reachable or total < reachable[pos]:
                                    reachable[pos] = total
                            break

    def _consider_town_visit(self, reachable: dict[CubeCoord, int]) -> CubeCoord | None:
        """Visit own town if it has significant recruitable creatures or garrison.

        Skip if hero is already at the town (recruiting already happened).
        Only return to town if the recruitable army value justifies the trip,
        to avoid oscillating between town and nearby targets.
        """
        best_pos: CubeCoord | None = None
        best_value = 0.0
        for obj in self.state.map_objects:
            if (
                isinstance(obj, TownSite)
                and obj.owner == self.player.player_id
                and obj.town
            ):
                # Don't re-visit if already standing on the town
                if obj.position == self.player.position:
                    continue
                if obj.position not in reachable:
                    continue

                # Estimate value of recruitable creatures
                recruit_value = 0.0
                for d in obj.town.dwellings:
                    if d.built and d.available > 0 and self.player.gold >= d.cost_per_unit:
                        affordable = min(d.available, self.player.gold // d.cost_per_unit)
                        recruit_value += affordable * d.cost_per_unit

                # Estimate value of garrison
                garrison_value = 0.0
                for s in obj.town.garrison:
                    if s.alive:
                        avg_dmg = (s.stats.min_damage + s.stats.max_damage) / 2
                        garrison_value += s.count * avg_dmg * s.stats.hp * 0.5

                total_value = recruit_value + garrison_value

                # Only worth visiting if substantial value (at least 500g worth)
                # and value scales with distance — farther towns need more value
                travel_cost = reachable[obj.position]
                threshold = 500 + travel_cost * 0.5
                if total_value >= threshold and total_value > best_value:
                    best_value = total_value
                    best_pos = obj.position

        return best_pos

    def _find_capturable_mine(
        self, reachable: dict[CubeCoord, int]
    ) -> CubeCoord | None:
        """Find nearest reachable mine not owned by us."""
        best_pos: CubeCoord | None = None
        best_cost = float("inf")
        for obj in self.state.map_objects:
            if (
                isinstance(obj, Mine)
                and obj.alive
                and obj.owner != self.player.player_id
            ):
                if obj.position in reachable:
                    cost = reachable[obj.position]
                    if cost < best_cost:
                        best_cost = cost
                        best_pos = obj.position
        return best_pos

    def _find_nearest_resource(
        self, reachable: dict[CubeCoord, int]
    ) -> CubeCoord | None:
        """Find nearest reachable gold pickup."""
        best_pos: CubeCoord | None = None
        best_cost = float("inf")
        for obj in self.state.map_objects:
            if isinstance(obj, ResourcePickup) and obj.alive:
                if obj.position in reachable:
                    cost = reachable[obj.position]
                    if cost < best_cost:
                        best_cost = cost
                        best_pos = obj.position
        return best_pos

    def _find_nearest_treasure_chest(
        self, reachable: dict[CubeCoord, int]
    ) -> CubeCoord | None:
        """Find nearest reachable treasure chest."""
        best_pos: CubeCoord | None = None
        best_cost = float("inf")
        for obj in self.state.map_objects:
            if isinstance(obj, TreasureChest) and obj.alive:
                if obj.position in reachable:
                    cost = reachable[obj.position]
                    if cost < best_cost:
                        best_cost = cost
                        best_pos = obj.position
        return best_pos

    def _find_nearest_artifact(
        self, reachable: dict[CubeCoord, int]
    ) -> CubeCoord | None:
        """Find nearest reachable artifact pickup."""
        from lops.adventure.map_objects import ArtifactPickup

        best_pos: CubeCoord | None = None
        best_cost = float("inf")
        for obj in self.state.map_objects:
            if isinstance(obj, ArtifactPickup) and obj.alive:
                if obj.position in reachable:
                    cost = reachable[obj.position]
                    if cost < best_cost:
                        best_cost = cost
                        best_pos = obj.position
        return best_pos

    def _find_nearest_stat_booster(
        self, reachable: dict[CubeCoord, int]
    ) -> CubeCoord | None:
        """Find nearest reachable stat booster not yet visited by this hero."""
        from lops.adventure.map_objects import StatBooster

        hs = self.player.active_hero_state
        if hs is None:
            return None
        hero_id = hs.hero_id
        best_pos: CubeCoord | None = None
        best_cost = float("inf")
        for obj in self.state.map_objects:
            if isinstance(obj, StatBooster) and obj.alive:
                if hero_id not in obj.visited_by and obj.position in reachable:
                    # Skip library if too low level
                    if obj.booster_type == "library" and hs.hero.level < 10:
                        continue
                    cost = reachable[obj.position]
                    if cost < best_cost:
                        best_cost = cost
                        best_pos = obj.position
        return best_pos

    def _find_nearest_campfire(
        self, reachable: dict[CubeCoord, int]
    ) -> CubeCoord | None:
        """Find nearest reachable campfire."""
        from lops.adventure.map_objects import Campfire

        best_pos: CubeCoord | None = None
        best_cost = float("inf")
        for obj in self.state.map_objects:
            if isinstance(obj, Campfire) and obj.alive:
                if obj.position in reachable:
                    cost = reachable[obj.position]
                    if cost < best_cost:
                        best_cost = cost
                        best_pos = obj.position
        return best_pos

    def _find_magic_well(self, reachable: dict[CubeCoord, int]) -> CubeCoord | None:
        """Find reachable magic well if hero has low mana."""
        from lops.adventure.map_objects import MagicWell

        hs = self.player.active_hero_state
        if hs is None:
            return None
        max_mana = hs.hero.effective_knowledge() * 10
        if max_mana <= 0 or hs.hero.mana >= max_mana * 0.5:
            return None  # don't bother if mana is over 50%
        hero_id = hs.hero_id
        day = self.state.day
        best_pos: CubeCoord | None = None
        best_cost = float("inf")
        for obj in self.state.map_objects:
            if isinstance(obj, MagicWell) and obj.alive:
                if obj.can_visit(hero_id, day) and obj.position in reachable:
                    cost = reachable[obj.position]
                    if cost < best_cost:
                        best_cost = cost
                        best_pos = obj.position
        return best_pos

    def _find_capturable_dwelling(
        self, reachable: dict[CubeCoord, int]
    ) -> CubeCoord | None:
        """Find nearest reachable creature dwelling with available creatures."""
        from lops.adventure.map_objects import CreatureDwelling

        best_pos: CubeCoord | None = None
        best_cost = float("inf")
        for obj in self.state.map_objects:
            if isinstance(obj, CreatureDwelling) and obj.alive and obj.available > 0:
                if obj.position in reachable:
                    cost = reachable[obj.position]
                    if cost < best_cost:
                        best_cost = cost
                        best_pos = obj.position
        return best_pos

    def _find_beatable_creature_bank(
        self, reachable: dict[CubeCoord, int]
    ) -> CubeCoord | None:
        """Find nearest reachable creature bank we can beat."""
        from lops.adventure.map_objects import CreatureBank

        my_strength = estimate_army_strength(self.player.army)
        best_pos: CubeCoord | None = None
        best_cost = float("inf")
        for obj in self.state.map_objects:
            if isinstance(obj, CreatureBank) and obj.alive:
                if obj.position in reachable:
                    guard_army = obj.make_guard_army()
                    guard_strength = estimate_army_strength(guard_army)
                    if my_strength > guard_strength * self._monster_threshold:
                        cost = reachable[obj.position]
                        if cost < best_cost:
                            best_cost = cost
                            best_pos = obj.position
        return best_pos

    def _find_hill_fort(
        self, reachable: dict[CubeCoord, int]
    ) -> CubeCoord | None:
        """Find a reachable Hill Fort if hero has upgradable creatures."""
        from lops.adventure.buildings import CREATURE_UPGRADES
        from lops.data.creatures import CREATURE_REGISTRY

        hs = self.player.active_hero_state
        if hs is None:
            return None
        # Check if any army stacks can be upgraded
        has_upgradable = False
        for stack in hs.army:
            if not stack.alive:
                continue
            for ct, stats in CREATURE_REGISTRY.items():
                if stats.name == stack.stats.name:
                    if CREATURE_UPGRADES.get(ct) is not None:
                        upgraded_stats = CREATURE_REGISTRY.get(CREATURE_UPGRADES[ct])
                        if upgraded_stats and upgraded_stats.name != stack.stats.name:
                            has_upgradable = True
                    break
        if not has_upgradable:
            return None

        best_pos: CubeCoord | None = None
        best_cost = float("inf")
        for obj in self.state.map_objects:
            if isinstance(obj, HillFort) and obj.alive:
                if obj.position in reachable:
                    cost = reachable[obj.position]
                    if cost < best_cost:
                        best_cost = cost
                        best_pos = obj.position
        return best_pos

    def _find_unguarded_pandora(
        self, reachable: dict[CubeCoord, int]
    ) -> CubeCoord | None:
        """Find nearest reachable unguarded Pandora's Box."""
        best_pos: CubeCoord | None = None
        best_cost = float("inf")
        for obj in self.state.map_objects:
            if isinstance(obj, PandorasBox) and obj.alive and not obj.is_guarded:
                if obj.position in reachable:
                    cost = reachable[obj.position]
                    if cost < best_cost:
                        best_cost = cost
                        best_pos = obj.position
        return best_pos

    def _find_beatable_pandora(
        self, reachable: dict[CubeCoord, int]
    ) -> CubeCoord | None:
        """Find nearest reachable guarded Pandora's Box we can beat."""
        my_strength = estimate_army_strength(self.player.army)
        best_pos: CubeCoord | None = None
        best_cost = float("inf")
        for obj in self.state.map_objects:
            if isinstance(obj, PandorasBox) and obj.alive and obj.is_guarded:
                if obj.position in reachable:
                    guard_strength = estimate_army_strength(obj.guards)
                    if my_strength > guard_strength * self._monster_threshold:
                        cost = reachable[obj.position]
                        if cost < best_cost:
                            best_cost = cost
                            best_pos = obj.position
        return best_pos

    def _find_beatable_monster(
        self, reachable: dict[CubeCoord, int]
    ) -> CubeCoord | None:
        """Find nearest reachable monster that we can probably beat."""
        my_strength = estimate_army_strength(self.player.army)
        best_pos: CubeCoord | None = None
        best_cost = float("inf")
        for obj in self.state.map_objects:
            if isinstance(obj, WanderingMonster) and obj.alive:
                if obj.position in reachable:
                    monster_strength = estimate_army_strength(obj.army)
                    if my_strength > monster_strength * self._monster_threshold:
                        cost = reachable[obj.position]
                        if cost < best_cost:
                            best_cost = cost
                            best_pos = obj.position
        return best_pos

    def _find_attackable_enemy_town(
        self, reachable: dict[CubeCoord, int]
    ) -> CubeCoord | None:
        """Find a reachable enemy or neutral town we can attack/capture."""
        my_strength = estimate_army_strength(self.player.army)

        best_pos: CubeCoord | None = None
        best_score = float("-inf")
        for obj in self.state.map_objects:
            if not isinstance(obj, TownSite) or not obj.alive:
                continue
            if obj.owner == self.player.player_id:
                continue
            if obj.position not in reachable:
                continue

            # Estimate town defense strength
            defense_strength = 0.0
            if obj.town and obj.town.garrison:
                defense_strength += estimate_army_strength(obj.town.garrison)
            # Check if defending heroes are at the town
            for p in self.state.players:
                if p.player_id != self.player.player_id and not p.defeated:
                    ehs = p.hero_at(obj.position)
                    if ehs is not None:
                        defense_strength += estimate_army_strength(ehs.army)

            # Attack if we have a comfortable margin (1.8x for defended, always for undefended)
            if defense_strength == 0 or my_strength > defense_strength * self._hero_threshold:
                # Prefer undefended, then closer; neutral towns are valuable targets
                score = -reachable[obj.position] + (100 if defense_strength == 0 else 0)
                if score > best_score:
                    best_score = score
                    best_pos = obj.position

        return best_pos

    def _find_attackable_enemy_hero(
        self, reachable: dict[CubeCoord, int]
    ) -> CubeCoord | None:
        """Find a reachable enemy hero we can beat."""
        my_strength = estimate_army_strength(self.player.army)

        for p in self.state.players:
            if p.player_id == self.player.player_id or p.defeated:
                continue
            for ehs in p.alive_heroes():
                if ehs.position not in reachable:
                    continue
                enemy_strength = estimate_army_strength(ehs.army)
                if my_strength > enemy_strength * self._hero_threshold:
                    return ehs.position
        return None

    def _advance_toward_target(
        self, reachable: dict[CubeCoord, int]
    ) -> CubeCoord | None:
        """Move toward the highest-value target: enemy towns first, then heroes."""
        if not reachable:
            return None

        hero_layer = (self.player.active_hero_state.layer
                      if self.player.active_hero_state else 0)

        # Collect potential targets with priorities (same layer only)
        targets: list[tuple[CubeCoord, float]] = []  # (position, priority)

        # Enemy and neutral towns (high priority)
        for obj in self.state.map_objects:
            if isinstance(obj, TownSite) and obj.alive and obj.layer == hero_layer:
                if obj.owner != self.player.player_id:
                    priority = 2.5 if obj.owner is None else 3.0
                    targets.append((obj.position, priority))

        # Enemy heroes (same layer)
        for p in self.state.players:
            if p.player_id != self.player.player_id and not p.defeated:
                for ehs in p.alive_heroes():
                    if ehs.position is not None and ehs.layer == hero_layer:
                        targets.append((ehs.position, 1.0))

        # Unclaimed mines (same layer)
        for obj in self.state.map_objects:
            if isinstance(obj, Mine) and obj.alive and obj.layer == hero_layer:
                if obj.owner != self.player.player_id:
                    targets.append((obj.position, 1.5))

        # Free pickups (same layer)
        from lops.adventure.map_objects import (
            ArtifactPickup,
            Campfire,
            SubterraneanGate,
        )

        for obj in self.state.map_objects:
            if not obj.alive or getattr(obj, "layer", 0) != hero_layer:
                continue
            if isinstance(obj, ResourcePickup):
                targets.append((obj.position, 0.8))
            elif isinstance(obj, TreasureChest):
                targets.append((obj.position, 1.3))
            elif isinstance(obj, Campfire):
                targets.append((obj.position, 0.7))
            elif isinstance(obj, ArtifactPickup):
                targets.append((obj.position, 1.2))
            elif isinstance(obj, SubterraneanGate):
                # Gates are interesting exploration targets
                targets.append((obj.position, 0.6))

        if not targets:
            return None

        # Pick the target with best priority / distance ratio
        my_pos = self.player.position
        if my_pos is None:
            return None
        best_target: CubeCoord | None = None
        best_score = float("-inf")
        for tpos, priority in targets:
            dist = cube_distance(my_pos, tpos)
            if dist == 0:
                continue
            score = priority * self._explore_weight / dist
            if score > best_score:
                best_score = score
                best_target = tpos

        if best_target is None:
            return None

        # Find the reachable hex closest to this target
        best_pos: CubeCoord | None = None
        if my_pos is None:
            return None
        best_dist = cube_distance(my_pos, best_target)
        for pos in reachable:
            d = cube_distance(pos, best_target)
            if d < best_dist:
                best_dist = d
                best_pos = pos
        return best_pos
