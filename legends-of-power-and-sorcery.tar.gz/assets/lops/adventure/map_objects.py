"""Map objects: wandering monsters, resource pickups, mines, town sites,
campfires, stat boosters, magic wells, creature banks, dwellings, etc."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from lops.adventure.resources import Resources, ResourceType
from lops.hex import CubeCoord
from lops.models import CreatureStack

if TYPE_CHECKING:
    from lops.adventure.town import Town
    from lops.artifacts import ArtifactId
    from lops.data.creatures import CreatureType


@dataclass
class WanderingMonster:
    """A group of monsters guarding a location on the map."""

    position: CubeCoord
    army: list[CreatureStack] = field(default_factory=list)
    alive: bool = True
    name: str = "Monsters"
    layer: int = 0


@dataclass
class ResourcePickup:
    """A pile of gold on the map."""

    position: CubeCoord
    gold: int = 500
    alive: bool = True
    layer: int = 0


@dataclass
class TownSite:
    """A town location on the map."""

    position: CubeCoord
    owner: int | None = None  # player_id of owner, None = neutral
    town: Town | None = None
    alive: bool = True  # always True for towns
    name: str = "Town"
    layer: int = 0


# Mine production rates per day
MINE_PRODUCTION: dict[ResourceType, Resources] = {
    ResourceType.GOLD: Resources(gold=1000),
    ResourceType.WOOD: Resources(wood=2),
    ResourceType.ORE: Resources(ore=2),
    ResourceType.MERCURY: Resources(mercury=1),
    ResourceType.SULFUR: Resources(sulfur=1),
    ResourceType.CRYSTAL: Resources(crystal=1),
    ResourceType.GEMS: Resources(gems=1),
}

MINE_NAMES: dict[ResourceType, str] = {
    ResourceType.GOLD: "Gold Mine",
    ResourceType.WOOD: "Sawmill",
    ResourceType.ORE: "Ore Pit",
    ResourceType.MERCURY: "Alchemist's Lab",
    ResourceType.SULFUR: "Sulfur Dune",
    ResourceType.CRYSTAL: "Crystal Cavern",
    ResourceType.GEMS: "Gem Pond",
}


@dataclass
class Mine:
    """A capturable resource-producing mine on the map."""

    position: CubeCoord
    resource_type: ResourceType
    owner: int | None = None  # player_id of owner, None = uncaptured
    alive: bool = True
    layer: int = 0  # always True for mines

    @property
    def name(self) -> str:
        return MINE_NAMES.get(self.resource_type, "Mine")

    def daily_income(self) -> Resources:
        """Resources produced per day when owned."""
        return MINE_PRODUCTION.get(self.resource_type, Resources())


# Treasure chest tier definitions: (gold_amount, xp_amount)
CHEST_TIERS = [
    (1000, 500),  # tier 0
    (1500, 1000),  # tier 1
    (2000, 1500),  # tier 2
]


@dataclass
class TreasureChest:
    """A treasure chest on the map offering gold or XP."""

    position: CubeCoord
    tier: int = 0  # 0, 1, or 2
    is_artifact: bool = False
    artifact_id: ArtifactId | None = None
    alive: bool = True
    layer: int = 0

    @property
    def gold_amount(self) -> int:
        return CHEST_TIERS[self.tier][0]

    @property
    def xp_amount(self) -> int:
        return CHEST_TIERS[self.tier][1]

    @property
    def name(self) -> str:
        return "Treasure Chest"


@dataclass
class ArtifactPickup:
    """An artifact lying on the map, ready to be picked up."""

    position: CubeCoord
    artifact_id: ArtifactId
    alive: bool = True
    layer: int = 0

    @property
    def name(self) -> str:
        from lops.data.artifacts import ARTIFACT_REGISTRY

        return ARTIFACT_REGISTRY[self.artifact_id].name


# ── Tier 1 & 2 Map Objects ─────────────────────────────────────────


@dataclass
class Campfire:
    """A campfire granting random gold + a small resource bonus. One-time."""

    position: CubeCoord
    gold: int = 500
    resource_type: ResourceType | None = None
    resource_amount: int = 0
    alive: bool = True
    layer: int = 0

    @property
    def name(self) -> str:
        return "Campfire"


BOOSTER_NAMES = {
    "learning_stone": "Learning Stone",
    "gazebo": "Gazebo",
    "mercenary_camp": "Mercenary Camp",
    "marletto_tower": "Marletto Tower",
    "garden_of_revelation": "Garden of Revelation",
    "colosseum_of_the_magi": "Colosseum of the Magi",
    "arena": "Arena",
    "library": "Library of Enlightenment",
}


@dataclass
class StatBooster:
    """One-time-per-hero stat boosting site (persistent on map)."""

    position: CubeCoord
    booster_type: str  # key into BOOSTER_NAMES
    stat: str | None = None  # 'attack', 'defense', 'spell_power', 'knowledge'
    amount: int = 1
    xp_amount: int = 0
    visited_by: set = field(default_factory=set)  # hero_id set
    alive: bool = True
    layer: int = 0

    @property
    def name(self) -> str:
        return BOOSTER_NAMES.get(self.booster_type, "Stat Booster")


@dataclass
class MagicWell:
    """Restores hero mana to full. Once per week per hero."""

    position: CubeCoord
    visited_by: dict[int, int] = field(default_factory=dict)  # hero_id -> day_visited
    alive: bool = True
    layer: int = 0

    @property
    def name(self) -> str:
        return "Magic Well"

    def can_visit(self, hero_id: int, current_day: int) -> bool:
        if hero_id not in self.visited_by:
            return True
        visited_week = (self.visited_by[hero_id] - 1) // 7
        current_week = (current_day - 1) // 7
        return current_week > visited_week


@dataclass
class PandorasBox:
    """A mysterious box with random rewards, possibly guarded."""

    position: CubeCoord
    guards: list[CreatureStack] = field(default_factory=list)
    gold_reward: int = 0
    xp_reward: int = 0
    resource_reward: Resources | None = None
    artifact_reward: ArtifactId | None = None
    creature_reward: list[CreatureStack] = field(default_factory=list)
    alive: bool = True
    layer: int = 0

    @property
    def name(self) -> str:
        return "Pandora's Box"

    @property
    def is_guarded(self) -> bool:
        return bool(self.guards)


@dataclass
class CreatureBank:
    """A guarded treasure hoard. Fight the guards, win rewards."""

    position: CubeCoord
    bank_type_index: int = 0
    alive: bool = True
    layer: int = 0

    @property
    def bank_def(self) -> dict:
        from lops.data.creature_banks import CREATURE_BANK_TYPES

        return CREATURE_BANK_TYPES[self.bank_type_index]

    @property
    def name(self) -> str:
        result: str = self.bank_def["name"]
        return result

    def make_guard_army(self) -> list[CreatureStack]:
        from lops.data.creatures import make_stack

        return [make_stack(ct, count) for ct, count in self.bank_def["guards"]]


@dataclass
class CreatureDwelling:
    """A map dwelling that produces and sells creatures weekly."""

    position: CubeCoord
    creature_type: CreatureType
    growth_per_week: int = 0
    cost_per_unit: int = 0
    available: int = 0
    owner: int | None = None
    alive: bool = True
    layer: int = 0

    @property
    def name(self) -> str:
        from lops.data.creatures import CREATURE_REGISTRY

        stats = CREATURE_REGISTRY.get(self.creature_type)
        return f"{stats.name} Dwelling" if stats else "Dwelling"

    def apply_weekly_growth(self):
        self.available += self.growth_per_week


@dataclass
class HillFort:
    """Upgrades creatures for a cost, no town dwelling required."""

    position: CubeCoord
    alive: bool = True
    layer: int = 0

    @property
    def name(self) -> str:
        return "Hill Fort"


@dataclass
class SubterraneanGate:
    """A portal connecting the surface and underground layers."""

    position: CubeCoord
    layer: int = 0
    pair_id: int = 0  # gates with the same pair_id are linked
    alive: bool = True

    @property
    def name(self) -> str:
        return "Subterranean Gate"
