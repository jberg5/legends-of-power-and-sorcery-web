"""Town building system: building definitions, costs, prerequisites, creature upgrades."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto

from lops.adventure.resources import Resources
from lops.data.creatures import CreatureType


class BuildingId(Enum):
    # Town hall chain (gold income)
    VILLAGE_HALL = auto()
    TOWN_HALL = auto()
    CITY_HALL = auto()
    CAPITOL = auto()

    # Infrastructure
    TAVERN = auto()
    BLACKSMITH = auto()
    MARKETPLACE = auto()
    STABLES = auto()

    # Fortifications (creature growth bonus)
    FORT = auto()
    CITADEL = auto()
    CASTLE = auto()

    # Base dwellings (tier 1-7)
    GUARDHOUSE = auto()  # Pikeman
    ARCHERS_TOWER = auto()  # Archer
    GRIFFIN_TOWER = auto()  # Griffin
    BARRACKS = auto()  # Swordsman
    MONASTERY = auto()  # Monk
    TRAINING_GROUNDS = auto()  # Cavalier
    PORTAL_OF_GLORY = auto()  # Angel

    # Upgraded dwellings (tier 1-7)
    UPG_GUARDHOUSE = auto()  # Halberdier
    UPG_ARCHERS_TOWER = auto()  # Marksman
    UPG_GRIFFIN_TOWER = auto()  # Royal Griffin
    UPG_BARRACKS = auto()  # Crusader
    UPG_MONASTERY = auto()  # Zealot
    UPG_TRAINING_GROUNDS = auto()  # Champion
    UPG_PORTAL_OF_GLORY = auto()  # Archangel

    # Special buildings
    ARTIFACT_MERCHANT = auto()
    RESOURCE_SILO = auto()

    # Mage Guilds (levels 1-5)
    MAGE_GUILD_1 = auto()
    MAGE_GUILD_2 = auto()
    MAGE_GUILD_3 = auto()
    MAGE_GUILD_4 = auto()
    MAGE_GUILD_5 = auto()

    # --- Necropolis dwellings ---
    NECRO_CURSED_TEMPLE = auto()
    NECRO_GRAVEYARD = auto()
    NECRO_TOMB_OF_SOULS = auto()
    NECRO_ESTATE = auto()
    NECRO_MAUSOLEUM = auto()
    NECRO_HALL_OF_DARKNESS = auto()
    NECRO_DRAGON_VAULT = auto()
    UPG_NECRO_CURSED_TEMPLE = auto()
    UPG_NECRO_GRAVEYARD = auto()
    UPG_NECRO_TOMB_OF_SOULS = auto()
    UPG_NECRO_ESTATE = auto()
    UPG_NECRO_MAUSOLEUM = auto()
    UPG_NECRO_HALL_OF_DARKNESS = auto()
    UPG_NECRO_DRAGON_VAULT = auto()

    # --- Inferno dwellings ---
    INFERNO_IMP_CRUCIBLE = auto()
    INFERNO_HALL_OF_SINS = auto()
    INFERNO_KENNELS = auto()
    INFERNO_DEMON_GATE = auto()
    INFERNO_HELL_HOLE = auto()
    INFERNO_FIRE_LAKE = auto()
    INFERNO_FORSAKEN_PALACE = auto()
    UPG_INFERNO_IMP_CRUCIBLE = auto()
    UPG_INFERNO_HALL_OF_SINS = auto()
    UPG_INFERNO_KENNELS = auto()
    UPG_INFERNO_DEMON_GATE = auto()
    UPG_INFERNO_HELL_HOLE = auto()
    UPG_INFERNO_FIRE_LAKE = auto()
    UPG_INFERNO_FORSAKEN_PALACE = auto()

    # --- Dungeon dwellings ---
    DUNGEON_WARREN = auto()
    DUNGEON_HARPY_LOFT = auto()
    DUNGEON_PILLAR_OF_EYES = auto()
    DUNGEON_CHAPEL_OF_STILLED_VOICES = auto()
    DUNGEON_LABYRINTH = auto()
    DUNGEON_MANTICORE_LAIR = auto()
    DUNGEON_DRAGON_CAVE = auto()
    UPG_DUNGEON_WARREN = auto()
    UPG_DUNGEON_HARPY_LOFT = auto()
    UPG_DUNGEON_PILLAR_OF_EYES = auto()
    UPG_DUNGEON_CHAPEL_OF_STILLED_VOICES = auto()
    UPG_DUNGEON_LABYRINTH = auto()
    UPG_DUNGEON_MANTICORE_LAIR = auto()
    UPG_DUNGEON_DRAGON_CAVE = auto()

    # --- Rampart dwellings ---
    RAMPART_CENTAUR_STABLES = auto()
    RAMPART_DWARF_COTTAGE = auto()
    RAMPART_HOMESTEAD = auto()
    RAMPART_ENCHANTED_SPRING = auto()
    RAMPART_DENDROID_ARCHES = auto()
    RAMPART_UNICORN_GLADE = auto()
    RAMPART_DRAGON_CLIFFS = auto()
    UPG_RAMPART_CENTAUR_STABLES = auto()
    UPG_RAMPART_DWARF_COTTAGE = auto()
    UPG_RAMPART_HOMESTEAD = auto()
    UPG_RAMPART_ENCHANTED_SPRING = auto()
    UPG_RAMPART_DENDROID_ARCHES = auto()
    UPG_RAMPART_UNICORN_GLADE = auto()
    UPG_RAMPART_DRAGON_CLIFFS = auto()

    # --- Tower dwellings ---
    TOWER_WORKSHOP = auto()
    TOWER_PARAPET = auto()
    TOWER_GOLEM_FACTORY = auto()
    TOWER_MAGE_TOWER = auto()
    TOWER_ALTAR_OF_WISHES = auto()
    TOWER_GOLDEN_PAVILION = auto()
    TOWER_CLOUD_TEMPLE = auto()
    UPG_TOWER_WORKSHOP = auto()
    UPG_TOWER_PARAPET = auto()
    UPG_TOWER_GOLEM_FACTORY = auto()
    UPG_TOWER_MAGE_TOWER = auto()
    UPG_TOWER_ALTAR_OF_WISHES = auto()
    UPG_TOWER_GOLDEN_PAVILION = auto()
    UPG_TOWER_CLOUD_TEMPLE = auto()

    # --- Stronghold dwellings ---
    STRONGHOLD_GOBLIN_BARRACKS = auto()
    STRONGHOLD_WOLF_PEN = auto()
    STRONGHOLD_ORC_TOWER = auto()
    STRONGHOLD_OGRE_FORT = auto()
    STRONGHOLD_CLIFF_NEST = auto()
    STRONGHOLD_CYCLOPS_CAVE = auto()
    STRONGHOLD_BEHEMOTH_LAIR = auto()
    UPG_STRONGHOLD_GOBLIN_BARRACKS = auto()
    UPG_STRONGHOLD_WOLF_PEN = auto()
    UPG_STRONGHOLD_ORC_TOWER = auto()
    UPG_STRONGHOLD_OGRE_FORT = auto()
    UPG_STRONGHOLD_CLIFF_NEST = auto()
    UPG_STRONGHOLD_CYCLOPS_CAVE = auto()
    UPG_STRONGHOLD_BEHEMOTH_LAIR = auto()

    # --- Fortress dwellings ---
    FORTRESS_GNOLL_HUT = auto()
    FORTRESS_LIZARD_DEN = auto()
    FORTRESS_SERPENT_FLY_HIVE = auto()
    FORTRESS_BASILISK_PIT = auto()
    FORTRESS_GORGON_LAIR = auto()
    FORTRESS_WYVERN_NEST = auto()
    FORTRESS_HYDRA_POND = auto()
    UPG_FORTRESS_GNOLL_HUT = auto()
    UPG_FORTRESS_LIZARD_DEN = auto()
    UPG_FORTRESS_SERPENT_FLY_HIVE = auto()
    UPG_FORTRESS_BASILISK_PIT = auto()
    UPG_FORTRESS_GORGON_LAIR = auto()
    UPG_FORTRESS_WYVERN_NEST = auto()
    UPG_FORTRESS_HYDRA_POND = auto()

    # --- Conflux dwellings ---
    CONFLUX_MAGIC_LANTERN = auto()
    CONFLUX_ALTAR_OF_AIR = auto()
    CONFLUX_ALTAR_OF_WATER = auto()
    CONFLUX_ALTAR_OF_FIRE = auto()
    CONFLUX_ALTAR_OF_EARTH = auto()
    CONFLUX_ALTAR_OF_THOUGHT = auto()
    CONFLUX_PYRE = auto()
    UPG_CONFLUX_MAGIC_LANTERN = auto()
    UPG_CONFLUX_ALTAR_OF_AIR = auto()
    UPG_CONFLUX_ALTAR_OF_WATER = auto()
    UPG_CONFLUX_ALTAR_OF_FIRE = auto()
    UPG_CONFLUX_ALTAR_OF_EARTH = auto()
    UPG_CONFLUX_ALTAR_OF_THOUGHT = auto()
    UPG_CONFLUX_PYRE = auto()


@dataclass(frozen=True)
class BuildingDef:
    """Definition for a buildable structure."""

    building_id: BuildingId
    name: str
    cost: Resources
    prerequisites: tuple[BuildingId, ...] = ()
    unlocks_creature: CreatureType | None = None
    upgrades_creature: CreatureType | None = None  # upgraded creature this enables
    daily_gold: int = 0
    growth_bonus: float = 0.0  # multiplier added to base growth (0.5 = +50%)


# HoMM3-accurate Castle faction buildings
# Source: https://heroes.thelazy.net/index.php/Castle
CASTLE_BUILDINGS: dict[BuildingId, BuildingDef] = {
    # Town hall chain
    BuildingId.VILLAGE_HALL: BuildingDef(
        building_id=BuildingId.VILLAGE_HALL,
        name="Village Hall",
        cost=Resources(),  # free, every town starts with it
        daily_gold=500,
    ),
    BuildingId.TAVERN: BuildingDef(
        building_id=BuildingId.TAVERN,
        name="Tavern",
        cost=Resources(gold=500, wood=5),
        prerequisites=(BuildingId.VILLAGE_HALL,),
    ),
    BuildingId.TOWN_HALL: BuildingDef(
        building_id=BuildingId.TOWN_HALL,
        name="Town Hall",
        cost=Resources(gold=2500),
        prerequisites=(BuildingId.VILLAGE_HALL, BuildingId.TAVERN),
        daily_gold=1000,
    ),
    BuildingId.BLACKSMITH: BuildingDef(
        building_id=BuildingId.BLACKSMITH,
        name="Blacksmith",
        cost=Resources(gold=1000, wood=5),
    ),
    BuildingId.MARKETPLACE: BuildingDef(
        building_id=BuildingId.MARKETPLACE,
        name="Marketplace",
        cost=Resources(gold=500, wood=5),
    ),
    BuildingId.CITY_HALL: BuildingDef(
        building_id=BuildingId.CITY_HALL,
        name="City Hall",
        cost=Resources(gold=5000),
        prerequisites=(
            BuildingId.TOWN_HALL,
            BuildingId.MARKETPLACE,
            BuildingId.MAGE_GUILD_1,
            BuildingId.BLACKSMITH,
        ),
        daily_gold=2000,
    ),
    BuildingId.CAPITOL: BuildingDef(
        building_id=BuildingId.CAPITOL,
        name="Capitol",
        cost=Resources(gold=10000),
        prerequisites=(BuildingId.CITY_HALL, BuildingId.CASTLE),
        daily_gold=4000,
    ),
    # Fortifications
    BuildingId.FORT: BuildingDef(
        building_id=BuildingId.FORT,
        name="Fort",
        cost=Resources(gold=5000, wood=20, ore=20),
    ),
    BuildingId.CITADEL: BuildingDef(
        building_id=BuildingId.CITADEL,
        name="Citadel",
        cost=Resources(gold=2500, ore=5),
        prerequisites=(BuildingId.FORT,),
        growth_bonus=0.5,
    ),
    BuildingId.CASTLE: BuildingDef(
        building_id=BuildingId.CASTLE,
        name="Castle",
        cost=Resources(gold=5000, wood=10, ore=10),
        prerequisites=(BuildingId.CITADEL,),
        growth_bonus=1.0,
    ),
    # Base dwellings
    # Source: https://heroes.thelazy.net/index.php/Castle (building tree)
    BuildingId.GUARDHOUSE: BuildingDef(
        building_id=BuildingId.GUARDHOUSE,
        name="Guardhouse",
        cost=Resources(gold=500, ore=10),
        prerequisites=(BuildingId.FORT,),
        unlocks_creature=CreatureType.PIKEMAN,
    ),
    BuildingId.ARCHERS_TOWER: BuildingDef(
        building_id=BuildingId.ARCHERS_TOWER,
        name="Archers' Tower",
        cost=Resources(gold=1000, wood=5, ore=5),
        prerequisites=(BuildingId.GUARDHOUSE,),
        unlocks_creature=CreatureType.ARCHER,
    ),
    BuildingId.BARRACKS: BuildingDef(
        building_id=BuildingId.BARRACKS,
        name="Barracks",
        cost=Resources(gold=2000, ore=5),
        prerequisites=(BuildingId.BLACKSMITH,),
        unlocks_creature=CreatureType.SWORDSMAN,
    ),
    BuildingId.GRIFFIN_TOWER: BuildingDef(
        building_id=BuildingId.GRIFFIN_TOWER,
        name="Griffin Tower",
        cost=Resources(gold=1000, ore=5),
        prerequisites=(BuildingId.BARRACKS,),
        unlocks_creature=CreatureType.GRIFFIN,
    ),
    BuildingId.MONASTERY: BuildingDef(
        building_id=BuildingId.MONASTERY,
        name="Monastery",
        cost=Resources(
            gold=3000, wood=5, ore=5, mercury=2, sulfur=2, crystal=2, gems=2
        ),
        prerequisites=(BuildingId.MAGE_GUILD_1,),
        unlocks_creature=CreatureType.MONK,
    ),
    BuildingId.STABLES: BuildingDef(
        building_id=BuildingId.STABLES,
        name="Stables",
        cost=Resources(gold=2000, wood=10),
    ),
    BuildingId.TRAINING_GROUNDS: BuildingDef(
        building_id=BuildingId.TRAINING_GROUNDS,
        name="Training Grounds",
        cost=Resources(
            gold=3000, wood=5, ore=5, mercury=2, sulfur=2, crystal=2, gems=2
        ),
        prerequisites=(BuildingId.STABLES,),
        unlocks_creature=CreatureType.CAVALIER,
    ),
    BuildingId.PORTAL_OF_GLORY: BuildingDef(
        building_id=BuildingId.PORTAL_OF_GLORY,
        name="Portal of Glory",
        cost=Resources(gold=5000, wood=20),
        prerequisites=(BuildingId.MONASTERY,),
        unlocks_creature=CreatureType.ANGEL,
    ),
    # Upgraded dwellings
    BuildingId.UPG_GUARDHOUSE: BuildingDef(
        building_id=BuildingId.UPG_GUARDHOUSE,
        name="Upg. Guardhouse",
        cost=Resources(gold=1000, ore=5),
        prerequisites=(BuildingId.GUARDHOUSE,),
        upgrades_creature=CreatureType.HALBERDIER,
    ),
    BuildingId.UPG_ARCHERS_TOWER: BuildingDef(
        building_id=BuildingId.UPG_ARCHERS_TOWER,
        name="Upg. Archers' Tower",
        cost=Resources(gold=1000, wood=5, ore=5),
        prerequisites=(BuildingId.ARCHERS_TOWER,),
        upgrades_creature=CreatureType.MARKSMAN,
    ),
    BuildingId.UPG_GRIFFIN_TOWER: BuildingDef(
        building_id=BuildingId.UPG_GRIFFIN_TOWER,
        name="Upg. Griffin Tower",
        cost=Resources(gold=1000, ore=5),
        prerequisites=(BuildingId.GRIFFIN_TOWER,),
        upgrades_creature=CreatureType.ROYAL_GRIFFIN,
    ),
    BuildingId.UPG_BARRACKS: BuildingDef(
        building_id=BuildingId.UPG_BARRACKS,
        name="Upg. Barracks",
        cost=Resources(gold=2000, ore=5, sulfur=5),
        prerequisites=(BuildingId.BARRACKS,),
        upgrades_creature=CreatureType.CRUSADER,
    ),
    BuildingId.UPG_MONASTERY: BuildingDef(
        building_id=BuildingId.UPG_MONASTERY,
        name="Upg. Monastery",
        cost=Resources(
            gold=1000, wood=2, ore=2, mercury=2, sulfur=2, crystal=2, gems=2
        ),
        prerequisites=(BuildingId.MONASTERY,),
        upgrades_creature=CreatureType.ZEALOT,
    ),
    BuildingId.UPG_TRAINING_GROUNDS: BuildingDef(
        building_id=BuildingId.UPG_TRAINING_GROUNDS,
        name="Upg. Training Grounds",
        cost=Resources(
            gold=1000, wood=2, ore=2, mercury=2, sulfur=2, crystal=2, gems=2
        ),
        prerequisites=(BuildingId.TRAINING_GROUNDS,),
        upgrades_creature=CreatureType.CHAMPION,
    ),
    BuildingId.UPG_PORTAL_OF_GLORY: BuildingDef(
        building_id=BuildingId.UPG_PORTAL_OF_GLORY,
        name="Upg. Portal of Glory",
        cost=Resources(gold=20000, mercury=10, sulfur=10, crystal=10, gems=10),
        prerequisites=(BuildingId.PORTAL_OF_GLORY,),
        upgrades_creature=CreatureType.ARCHANGEL,
    ),
    # Special buildings
    BuildingId.ARTIFACT_MERCHANT: BuildingDef(
        building_id=BuildingId.ARTIFACT_MERCHANT,
        name="Artifact Merchant",
        cost=Resources(gold=10000, wood=10, ore=10),
        prerequisites=(BuildingId.TOWN_HALL,),
    ),
    BuildingId.RESOURCE_SILO: BuildingDef(
        building_id=BuildingId.RESOURCE_SILO,
        name="Resource Silo",
        cost=Resources(gold=5000, ore=5),
        prerequisites=(BuildingId.MARKETPLACE,),
    ),
    # Mage Guilds
    BuildingId.MAGE_GUILD_1: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_1,
        name="Mage Guild Level 1",
        cost=Resources(gold=2000, wood=5, ore=5),
    ),
    BuildingId.MAGE_GUILD_2: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_2,
        name="Mage Guild Level 2",
        cost=Resources(gold=3000, wood=5, ore=5, crystal=4, gems=4),
        prerequisites=(BuildingId.MAGE_GUILD_1,),
    ),
    BuildingId.MAGE_GUILD_3: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_3,
        name="Mage Guild Level 3",
        cost=Resources(gold=5000, wood=5, ore=5, crystal=6, gems=6),
        prerequisites=(BuildingId.MAGE_GUILD_2,),
    ),
    BuildingId.MAGE_GUILD_4: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_4,
        name="Mage Guild Level 4",
        cost=Resources(
            gold=8000, wood=5, ore=5, crystal=8, gems=8, mercury=4, sulfur=4
        ),
        prerequisites=(BuildingId.MAGE_GUILD_3,),
    ),
    BuildingId.MAGE_GUILD_5: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_5,
        name="Mage Guild Level 5",
        cost=Resources(
            gold=12000, wood=5, ore=5, crystal=10, gems=10, mercury=6, sulfur=6
        ),
        prerequisites=(BuildingId.MAGE_GUILD_4,),
    ),
}

# HoMM3-accurate Necropolis faction buildings
NECROPOLIS_BUILDINGS: dict[BuildingId, BuildingDef] = {
    # Town hall chain
    BuildingId.VILLAGE_HALL: BuildingDef(
        building_id=BuildingId.VILLAGE_HALL,
        name="Village Hall",
        cost=Resources(),
        daily_gold=500,
    ),
    BuildingId.TAVERN: BuildingDef(
        building_id=BuildingId.TAVERN,
        name="Tavern",
        cost=Resources(gold=500, wood=5),
        prerequisites=(BuildingId.VILLAGE_HALL,),
    ),
    BuildingId.TOWN_HALL: BuildingDef(
        building_id=BuildingId.TOWN_HALL,
        name="Town Hall",
        cost=Resources(gold=2500),
        prerequisites=(BuildingId.VILLAGE_HALL, BuildingId.TAVERN),
        daily_gold=1000,
    ),
    BuildingId.BLACKSMITH: BuildingDef(
        building_id=BuildingId.BLACKSMITH,
        name="Blacksmith",
        cost=Resources(gold=1000, wood=5),
    ),
    BuildingId.MARKETPLACE: BuildingDef(
        building_id=BuildingId.MARKETPLACE,
        name="Marketplace",
        cost=Resources(gold=500, wood=5),
    ),
    BuildingId.CITY_HALL: BuildingDef(
        building_id=BuildingId.CITY_HALL,
        name="City Hall",
        cost=Resources(gold=5000),
        prerequisites=(
            BuildingId.TOWN_HALL,
            BuildingId.MARKETPLACE,
            BuildingId.MAGE_GUILD_1,
            BuildingId.BLACKSMITH,
        ),
        daily_gold=2000,
    ),
    BuildingId.CAPITOL: BuildingDef(
        building_id=BuildingId.CAPITOL,
        name="Capitol",
        cost=Resources(gold=10000),
        prerequisites=(BuildingId.CITY_HALL, BuildingId.CASTLE),
        daily_gold=4000,
    ),
    # Fortifications
    BuildingId.FORT: BuildingDef(
        building_id=BuildingId.FORT,
        name="Fort",
        cost=Resources(gold=5000, wood=20, ore=20),
    ),
    BuildingId.CITADEL: BuildingDef(
        building_id=BuildingId.CITADEL,
        name="Citadel",
        cost=Resources(gold=2500, ore=5),
        prerequisites=(BuildingId.FORT,),
        growth_bonus=0.5,
    ),
    BuildingId.CASTLE: BuildingDef(
        building_id=BuildingId.CASTLE,
        name="Castle",
        cost=Resources(gold=5000, wood=10, ore=10),
        prerequisites=(BuildingId.CITADEL,),
        growth_bonus=1.0,
    ),
    # Mage Guilds
    BuildingId.MAGE_GUILD_1: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_1,
        name="Mage Guild Level 1",
        cost=Resources(gold=2000, wood=5, ore=5),
    ),
    BuildingId.MAGE_GUILD_2: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_2,
        name="Mage Guild Level 2",
        cost=Resources(gold=3000, wood=5, ore=5, crystal=4, gems=4),
        prerequisites=(BuildingId.MAGE_GUILD_1,),
    ),
    BuildingId.MAGE_GUILD_3: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_3,
        name="Mage Guild Level 3",
        cost=Resources(gold=5000, wood=5, ore=5, crystal=6, gems=6),
        prerequisites=(BuildingId.MAGE_GUILD_2,),
    ),
    BuildingId.MAGE_GUILD_4: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_4,
        name="Mage Guild Level 4",
        cost=Resources(
            gold=8000, wood=5, ore=5, crystal=8, gems=8, mercury=4, sulfur=4
        ),
        prerequisites=(BuildingId.MAGE_GUILD_3,),
    ),
    BuildingId.MAGE_GUILD_5: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_5,
        name="Mage Guild Level 5",
        cost=Resources(
            gold=12000, wood=5, ore=5, crystal=10, gems=10, mercury=6, sulfur=6
        ),
        prerequisites=(BuildingId.MAGE_GUILD_4,),
    ),
    # Special buildings
    BuildingId.ARTIFACT_MERCHANT: BuildingDef(
        building_id=BuildingId.ARTIFACT_MERCHANT,
        name="Artifact Merchant",
        cost=Resources(gold=10000, wood=10, ore=10),
        prerequisites=(BuildingId.TOWN_HALL,),
    ),
    BuildingId.RESOURCE_SILO: BuildingDef(
        building_id=BuildingId.RESOURCE_SILO,
        name="Resource Silo",
        cost=Resources(gold=5000, ore=5),
        prerequisites=(BuildingId.MARKETPLACE,),
    ),
    # Necropolis dwellings
    BuildingId.NECRO_CURSED_TEMPLE: BuildingDef(
        building_id=BuildingId.NECRO_CURSED_TEMPLE,
        name="Cursed Temple",
        cost=Resources(gold=400, ore=5),
        prerequisites=(BuildingId.FORT,),
        unlocks_creature=CreatureType.SKELETON,
    ),
    BuildingId.NECRO_GRAVEYARD: BuildingDef(
        building_id=BuildingId.NECRO_GRAVEYARD,
        name="Graveyard",
        cost=Resources(gold=1000, wood=5, ore=5),
        prerequisites=(BuildingId.NECRO_CURSED_TEMPLE,),
        unlocks_creature=CreatureType.WALKING_DEAD,
    ),
    BuildingId.NECRO_TOMB_OF_SOULS: BuildingDef(
        building_id=BuildingId.NECRO_TOMB_OF_SOULS,
        name="Tomb of Souls",
        cost=Resources(gold=1500, ore=5),
        prerequisites=(BuildingId.NECRO_GRAVEYARD,),
        unlocks_creature=CreatureType.WIGHT,
    ),
    BuildingId.NECRO_ESTATE: BuildingDef(
        building_id=BuildingId.NECRO_ESTATE,
        name="Estate",
        cost=Resources(gold=2000, wood=5, ore=5),
        prerequisites=(BuildingId.NECRO_TOMB_OF_SOULS,),
        unlocks_creature=CreatureType.VAMPIRE,
    ),
    BuildingId.NECRO_MAUSOLEUM: BuildingDef(
        building_id=BuildingId.NECRO_MAUSOLEUM,
        name="Mausoleum",
        cost=Resources(gold=3000, wood=10, ore=10),
        prerequisites=(BuildingId.MAGE_GUILD_1,),
        unlocks_creature=CreatureType.LICH,
    ),
    BuildingId.NECRO_HALL_OF_DARKNESS: BuildingDef(
        building_id=BuildingId.NECRO_HALL_OF_DARKNESS,
        name="Hall of Darkness",
        cost=Resources(gold=3500, wood=5, ore=5),
        prerequisites=(BuildingId.NECRO_ESTATE,),
        unlocks_creature=CreatureType.BLACK_KNIGHT,
    ),
    BuildingId.NECRO_DRAGON_VAULT: BuildingDef(
        building_id=BuildingId.NECRO_DRAGON_VAULT,
        name="Dragon Vault",
        cost=Resources(gold=10000, ore=10, sulfur=10),
        prerequisites=(BuildingId.NECRO_MAUSOLEUM,),
        unlocks_creature=CreatureType.BONE_DRAGON,
    ),
    # Necropolis upgraded dwellings
    BuildingId.UPG_NECRO_CURSED_TEMPLE: BuildingDef(
        building_id=BuildingId.UPG_NECRO_CURSED_TEMPLE,
        name="Upg. Cursed Temple",
        cost=Resources(gold=1000, ore=5),
        prerequisites=(BuildingId.NECRO_CURSED_TEMPLE,),
        upgrades_creature=CreatureType.SKELETON_WARRIOR,
    ),
    BuildingId.UPG_NECRO_GRAVEYARD: BuildingDef(
        building_id=BuildingId.UPG_NECRO_GRAVEYARD,
        name="Upg. Graveyard",
        cost=Resources(gold=1000, wood=5),
        prerequisites=(BuildingId.NECRO_GRAVEYARD,),
        upgrades_creature=CreatureType.ZOMBIE,
    ),
    BuildingId.UPG_NECRO_TOMB_OF_SOULS: BuildingDef(
        building_id=BuildingId.UPG_NECRO_TOMB_OF_SOULS,
        name="Upg. Tomb of Souls",
        cost=Resources(gold=1500, ore=5, mercury=5),
        prerequisites=(BuildingId.NECRO_TOMB_OF_SOULS,),
        upgrades_creature=CreatureType.WRAITH,
    ),
    BuildingId.UPG_NECRO_ESTATE: BuildingDef(
        building_id=BuildingId.UPG_NECRO_ESTATE,
        name="Upg. Estate",
        cost=Resources(gold=2000, wood=5, ore=5),
        prerequisites=(BuildingId.NECRO_ESTATE,),
        upgrades_creature=CreatureType.VAMPIRE_LORD,
    ),
    BuildingId.UPG_NECRO_MAUSOLEUM: BuildingDef(
        building_id=BuildingId.UPG_NECRO_MAUSOLEUM,
        name="Upg. Mausoleum",
        cost=Resources(gold=3000, ore=5, gems=5),
        prerequisites=(BuildingId.NECRO_MAUSOLEUM,),
        upgrades_creature=CreatureType.POWER_LICH,
    ),
    BuildingId.UPG_NECRO_HALL_OF_DARKNESS: BuildingDef(
        building_id=BuildingId.UPG_NECRO_HALL_OF_DARKNESS,
        name="Upg. Hall of Darkness",
        cost=Resources(gold=3000, wood=5, ore=5),
        prerequisites=(BuildingId.NECRO_HALL_OF_DARKNESS,),
        upgrades_creature=CreatureType.DREAD_KNIGHT,
    ),
    BuildingId.UPG_NECRO_DRAGON_VAULT: BuildingDef(
        building_id=BuildingId.UPG_NECRO_DRAGON_VAULT,
        name="Upg. Dragon Vault",
        cost=Resources(gold=5000, ore=5, sulfur=5),
        prerequisites=(BuildingId.NECRO_DRAGON_VAULT,),
        upgrades_creature=CreatureType.GHOST_DRAGON,
    ),
}

# HoMM3-accurate Inferno faction buildings
INFERNO_BUILDINGS: dict[BuildingId, BuildingDef] = {
    # Town hall chain
    BuildingId.VILLAGE_HALL: BuildingDef(
        building_id=BuildingId.VILLAGE_HALL,
        name="Village Hall",
        cost=Resources(),
        daily_gold=500,
    ),
    BuildingId.TAVERN: BuildingDef(
        building_id=BuildingId.TAVERN,
        name="Tavern",
        cost=Resources(gold=500, wood=5),
        prerequisites=(BuildingId.VILLAGE_HALL,),
    ),
    BuildingId.TOWN_HALL: BuildingDef(
        building_id=BuildingId.TOWN_HALL,
        name="Town Hall",
        cost=Resources(gold=2500),
        prerequisites=(BuildingId.VILLAGE_HALL, BuildingId.TAVERN),
        daily_gold=1000,
    ),
    BuildingId.BLACKSMITH: BuildingDef(
        building_id=BuildingId.BLACKSMITH,
        name="Blacksmith",
        cost=Resources(gold=1000, wood=5),
    ),
    BuildingId.MARKETPLACE: BuildingDef(
        building_id=BuildingId.MARKETPLACE,
        name="Marketplace",
        cost=Resources(gold=500, wood=5),
    ),
    BuildingId.CITY_HALL: BuildingDef(
        building_id=BuildingId.CITY_HALL,
        name="City Hall",
        cost=Resources(gold=5000),
        prerequisites=(
            BuildingId.TOWN_HALL,
            BuildingId.MARKETPLACE,
            BuildingId.MAGE_GUILD_1,
            BuildingId.BLACKSMITH,
        ),
        daily_gold=2000,
    ),
    BuildingId.CAPITOL: BuildingDef(
        building_id=BuildingId.CAPITOL,
        name="Capitol",
        cost=Resources(gold=10000),
        prerequisites=(BuildingId.CITY_HALL, BuildingId.CASTLE),
        daily_gold=4000,
    ),
    # Fortifications
    BuildingId.FORT: BuildingDef(
        building_id=BuildingId.FORT,
        name="Fort",
        cost=Resources(gold=5000, wood=20, ore=20),
    ),
    BuildingId.CITADEL: BuildingDef(
        building_id=BuildingId.CITADEL,
        name="Citadel",
        cost=Resources(gold=2500, ore=5),
        prerequisites=(BuildingId.FORT,),
        growth_bonus=0.5,
    ),
    BuildingId.CASTLE: BuildingDef(
        building_id=BuildingId.CASTLE,
        name="Castle",
        cost=Resources(gold=5000, wood=10, ore=10),
        prerequisites=(BuildingId.CITADEL,),
        growth_bonus=1.0,
    ),
    # Mage Guilds
    BuildingId.MAGE_GUILD_1: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_1,
        name="Mage Guild Level 1",
        cost=Resources(gold=2000, wood=5, ore=5),
    ),
    BuildingId.MAGE_GUILD_2: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_2,
        name="Mage Guild Level 2",
        cost=Resources(gold=3000, wood=5, ore=5, crystal=4, gems=4),
        prerequisites=(BuildingId.MAGE_GUILD_1,),
    ),
    BuildingId.MAGE_GUILD_3: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_3,
        name="Mage Guild Level 3",
        cost=Resources(gold=5000, wood=5, ore=5, crystal=6, gems=6),
        prerequisites=(BuildingId.MAGE_GUILD_2,),
    ),
    BuildingId.MAGE_GUILD_4: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_4,
        name="Mage Guild Level 4",
        cost=Resources(
            gold=8000, wood=5, ore=5, crystal=8, gems=8, mercury=4, sulfur=4
        ),
        prerequisites=(BuildingId.MAGE_GUILD_3,),
    ),
    BuildingId.MAGE_GUILD_5: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_5,
        name="Mage Guild Level 5",
        cost=Resources(
            gold=12000, wood=5, ore=5, crystal=10, gems=10, mercury=6, sulfur=6
        ),
        prerequisites=(BuildingId.MAGE_GUILD_4,),
    ),
    # Special buildings
    BuildingId.ARTIFACT_MERCHANT: BuildingDef(
        building_id=BuildingId.ARTIFACT_MERCHANT,
        name="Artifact Merchant",
        cost=Resources(gold=10000, wood=10, ore=10),
        prerequisites=(BuildingId.TOWN_HALL,),
    ),
    BuildingId.RESOURCE_SILO: BuildingDef(
        building_id=BuildingId.RESOURCE_SILO,
        name="Resource Silo",
        cost=Resources(gold=5000, ore=5),
        prerequisites=(BuildingId.MARKETPLACE,),
    ),
    # Inferno dwellings
    BuildingId.INFERNO_IMP_CRUCIBLE: BuildingDef(
        building_id=BuildingId.INFERNO_IMP_CRUCIBLE,
        name="Imp Crucible",
        cost=Resources(gold=400),
        prerequisites=(BuildingId.FORT,),
        unlocks_creature=CreatureType.IMP,
    ),
    BuildingId.INFERNO_HALL_OF_SINS: BuildingDef(
        building_id=BuildingId.INFERNO_HALL_OF_SINS,
        name="Hall of Sins",
        cost=Resources(gold=1000, ore=5),
        prerequisites=(BuildingId.INFERNO_IMP_CRUCIBLE,),
        unlocks_creature=CreatureType.GOG,
    ),
    BuildingId.INFERNO_KENNELS: BuildingDef(
        building_id=BuildingId.INFERNO_KENNELS,
        name="Kennels",
        cost=Resources(gold=1500, wood=5, ore=5),
        prerequisites=(BuildingId.INFERNO_HALL_OF_SINS,),
        unlocks_creature=CreatureType.HELL_HOUND,
    ),
    BuildingId.INFERNO_DEMON_GATE: BuildingDef(
        building_id=BuildingId.INFERNO_DEMON_GATE,
        name="Demon Gate",
        cost=Resources(gold=2000, wood=5, ore=5),
        prerequisites=(BuildingId.INFERNO_KENNELS,),
        unlocks_creature=CreatureType.DEMON,
    ),
    BuildingId.INFERNO_HELL_HOLE: BuildingDef(
        building_id=BuildingId.INFERNO_HELL_HOLE,
        name="Hell Hole",
        cost=Resources(gold=3000, wood=5, ore=5, mercury=2),
        prerequisites=(BuildingId.INFERNO_DEMON_GATE,),
        unlocks_creature=CreatureType.PIT_FIEND,
    ),
    BuildingId.INFERNO_FIRE_LAKE: BuildingDef(
        building_id=BuildingId.INFERNO_FIRE_LAKE,
        name="Fire Lake",
        cost=Resources(gold=4000, ore=5, sulfur=5),
        prerequisites=(BuildingId.INFERNO_HELL_HOLE,),
        unlocks_creature=CreatureType.EFREETI,
    ),
    BuildingId.INFERNO_FORSAKEN_PALACE: BuildingDef(
        building_id=BuildingId.INFERNO_FORSAKEN_PALACE,
        name="Forsaken Palace",
        cost=Resources(gold=10000, mercury=5, sulfur=10),
        prerequisites=(BuildingId.INFERNO_FIRE_LAKE, BuildingId.MAGE_GUILD_1),
        unlocks_creature=CreatureType.DEVIL,
    ),
    # Inferno upgraded dwellings
    BuildingId.UPG_INFERNO_IMP_CRUCIBLE: BuildingDef(
        building_id=BuildingId.UPG_INFERNO_IMP_CRUCIBLE,
        name="Upg. Imp Crucible",
        cost=Resources(gold=1000),
        prerequisites=(BuildingId.INFERNO_IMP_CRUCIBLE,),
        upgrades_creature=CreatureType.FAMILIAR,
    ),
    BuildingId.UPG_INFERNO_HALL_OF_SINS: BuildingDef(
        building_id=BuildingId.UPG_INFERNO_HALL_OF_SINS,
        name="Upg. Hall of Sins",
        cost=Resources(gold=1000, ore=5),
        prerequisites=(BuildingId.INFERNO_HALL_OF_SINS,),
        upgrades_creature=CreatureType.MAGOG,
    ),
    BuildingId.UPG_INFERNO_KENNELS: BuildingDef(
        building_id=BuildingId.UPG_INFERNO_KENNELS,
        name="Upg. Kennels",
        cost=Resources(gold=1500, wood=5),
        prerequisites=(BuildingId.INFERNO_KENNELS,),
        upgrades_creature=CreatureType.CERBERUS,
    ),
    BuildingId.UPG_INFERNO_DEMON_GATE: BuildingDef(
        building_id=BuildingId.UPG_INFERNO_DEMON_GATE,
        name="Upg. Demon Gate",
        cost=Resources(gold=2000, ore=5),
        prerequisites=(BuildingId.INFERNO_DEMON_GATE,),
        upgrades_creature=CreatureType.HORNED_DEMON,
    ),
    BuildingId.UPG_INFERNO_HELL_HOLE: BuildingDef(
        building_id=BuildingId.UPG_INFERNO_HELL_HOLE,
        name="Upg. Hell Hole",
        cost=Resources(gold=2000, wood=5, ore=5),
        prerequisites=(BuildingId.INFERNO_HELL_HOLE,),
        upgrades_creature=CreatureType.PIT_LORD,
    ),
    BuildingId.UPG_INFERNO_FIRE_LAKE: BuildingDef(
        building_id=BuildingId.UPG_INFERNO_FIRE_LAKE,
        name="Upg. Fire Lake",
        cost=Resources(gold=3000, ore=5, sulfur=5),
        prerequisites=(BuildingId.INFERNO_FIRE_LAKE,),
        upgrades_creature=CreatureType.EFREET_SULTAN,
    ),
    BuildingId.UPG_INFERNO_FORSAKEN_PALACE: BuildingDef(
        building_id=BuildingId.UPG_INFERNO_FORSAKEN_PALACE,
        name="Upg. Forsaken Palace",
        cost=Resources(gold=5000, mercury=5, sulfur=5),
        prerequisites=(BuildingId.INFERNO_FORSAKEN_PALACE,),
        upgrades_creature=CreatureType.ARCH_DEVIL,
    ),
}

# HoMM3-accurate Dungeon faction buildings
DUNGEON_BUILDINGS: dict[BuildingId, BuildingDef] = {
    # Town hall chain
    BuildingId.VILLAGE_HALL: BuildingDef(
        building_id=BuildingId.VILLAGE_HALL,
        name="Village Hall",
        cost=Resources(),
        daily_gold=500,
    ),
    BuildingId.TAVERN: BuildingDef(
        building_id=BuildingId.TAVERN,
        name="Tavern",
        cost=Resources(gold=500, wood=5),
        prerequisites=(BuildingId.VILLAGE_HALL,),
    ),
    BuildingId.TOWN_HALL: BuildingDef(
        building_id=BuildingId.TOWN_HALL,
        name="Town Hall",
        cost=Resources(gold=2500),
        prerequisites=(BuildingId.VILLAGE_HALL, BuildingId.TAVERN),
        daily_gold=1000,
    ),
    BuildingId.BLACKSMITH: BuildingDef(
        building_id=BuildingId.BLACKSMITH,
        name="Blacksmith",
        cost=Resources(gold=1000, wood=5),
    ),
    BuildingId.MARKETPLACE: BuildingDef(
        building_id=BuildingId.MARKETPLACE,
        name="Marketplace",
        cost=Resources(gold=500, wood=5),
    ),
    BuildingId.CITY_HALL: BuildingDef(
        building_id=BuildingId.CITY_HALL,
        name="City Hall",
        cost=Resources(gold=5000),
        prerequisites=(
            BuildingId.TOWN_HALL,
            BuildingId.MARKETPLACE,
            BuildingId.MAGE_GUILD_1,
            BuildingId.BLACKSMITH,
        ),
        daily_gold=2000,
    ),
    BuildingId.CAPITOL: BuildingDef(
        building_id=BuildingId.CAPITOL,
        name="Capitol",
        cost=Resources(gold=10000),
        prerequisites=(BuildingId.CITY_HALL, BuildingId.CASTLE),
        daily_gold=4000,
    ),
    # Fortifications
    BuildingId.FORT: BuildingDef(
        building_id=BuildingId.FORT,
        name="Fort",
        cost=Resources(gold=5000, wood=20, ore=20),
    ),
    BuildingId.CITADEL: BuildingDef(
        building_id=BuildingId.CITADEL,
        name="Citadel",
        cost=Resources(gold=2500, ore=5),
        prerequisites=(BuildingId.FORT,),
        growth_bonus=0.5,
    ),
    BuildingId.CASTLE: BuildingDef(
        building_id=BuildingId.CASTLE,
        name="Castle",
        cost=Resources(gold=5000, wood=10, ore=10),
        prerequisites=(BuildingId.CITADEL,),
        growth_bonus=1.0,
    ),
    # Mage Guilds
    BuildingId.MAGE_GUILD_1: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_1,
        name="Mage Guild Level 1",
        cost=Resources(gold=2000, wood=5, ore=5),
    ),
    BuildingId.MAGE_GUILD_2: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_2,
        name="Mage Guild Level 2",
        cost=Resources(gold=3000, wood=5, ore=5, crystal=4, gems=4),
        prerequisites=(BuildingId.MAGE_GUILD_1,),
    ),
    BuildingId.MAGE_GUILD_3: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_3,
        name="Mage Guild Level 3",
        cost=Resources(gold=5000, wood=5, ore=5, crystal=6, gems=6),
        prerequisites=(BuildingId.MAGE_GUILD_2,),
    ),
    BuildingId.MAGE_GUILD_4: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_4,
        name="Mage Guild Level 4",
        cost=Resources(
            gold=8000, wood=5, ore=5, crystal=8, gems=8, mercury=4, sulfur=4
        ),
        prerequisites=(BuildingId.MAGE_GUILD_3,),
    ),
    BuildingId.MAGE_GUILD_5: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_5,
        name="Mage Guild Level 5",
        cost=Resources(
            gold=12000, wood=5, ore=5, crystal=10, gems=10, mercury=6, sulfur=6
        ),
        prerequisites=(BuildingId.MAGE_GUILD_4,),
    ),
    # Special buildings
    BuildingId.ARTIFACT_MERCHANT: BuildingDef(
        building_id=BuildingId.ARTIFACT_MERCHANT,
        name="Artifact Merchant",
        cost=Resources(gold=10000, wood=10, ore=10),
        prerequisites=(BuildingId.TOWN_HALL,),
    ),
    BuildingId.RESOURCE_SILO: BuildingDef(
        building_id=BuildingId.RESOURCE_SILO,
        name="Resource Silo",
        cost=Resources(gold=5000, ore=5),
        prerequisites=(BuildingId.MARKETPLACE,),
    ),
    # Dungeon dwellings
    BuildingId.DUNGEON_WARREN: BuildingDef(
        building_id=BuildingId.DUNGEON_WARREN,
        name="Warren",
        cost=Resources(gold=500, ore=5),
        prerequisites=(BuildingId.FORT,),
        unlocks_creature=CreatureType.TROGLODYTE,
    ),
    BuildingId.DUNGEON_HARPY_LOFT: BuildingDef(
        building_id=BuildingId.DUNGEON_HARPY_LOFT,
        name="Harpy Loft",
        cost=Resources(gold=1000, wood=5, ore=5),
        prerequisites=(BuildingId.DUNGEON_WARREN,),
        unlocks_creature=CreatureType.HARPY,
    ),
    BuildingId.DUNGEON_PILLAR_OF_EYES: BuildingDef(
        building_id=BuildingId.DUNGEON_PILLAR_OF_EYES,
        name="Pillar of Eyes",
        cost=Resources(gold=1500, ore=5, crystal=5),
        prerequisites=(BuildingId.DUNGEON_HARPY_LOFT,),
        unlocks_creature=CreatureType.BEHOLDER,
    ),
    BuildingId.DUNGEON_CHAPEL_OF_STILLED_VOICES: BuildingDef(
        building_id=BuildingId.DUNGEON_CHAPEL_OF_STILLED_VOICES,
        name="Chapel of Stilled Voices",
        cost=Resources(gold=2000, wood=5, ore=5),
        prerequisites=(BuildingId.DUNGEON_PILLAR_OF_EYES,),
        unlocks_creature=CreatureType.MEDUSA,
    ),
    BuildingId.DUNGEON_LABYRINTH: BuildingDef(
        building_id=BuildingId.DUNGEON_LABYRINTH,
        name="Labyrinth",
        cost=Resources(gold=3000, ore=10),
        prerequisites=(BuildingId.DUNGEON_CHAPEL_OF_STILLED_VOICES,),
        unlocks_creature=CreatureType.MINOTAUR,
    ),
    BuildingId.DUNGEON_MANTICORE_LAIR: BuildingDef(
        building_id=BuildingId.DUNGEON_MANTICORE_LAIR,
        name="Manticore Lair",
        cost=Resources(gold=4000, ore=5, mercury=5),
        prerequisites=(BuildingId.DUNGEON_LABYRINTH,),
        unlocks_creature=CreatureType.MANTICORE,
    ),
    BuildingId.DUNGEON_DRAGON_CAVE: BuildingDef(
        building_id=BuildingId.DUNGEON_DRAGON_CAVE,
        name="Dragon Cave",
        cost=Resources(gold=15000, ore=10, sulfur=10),
        prerequisites=(BuildingId.DUNGEON_MANTICORE_LAIR, BuildingId.MAGE_GUILD_1),
        unlocks_creature=CreatureType.RED_DRAGON,
    ),
    # Dungeon upgraded dwellings
    BuildingId.UPG_DUNGEON_WARREN: BuildingDef(
        building_id=BuildingId.UPG_DUNGEON_WARREN,
        name="Upg. Warren",
        cost=Resources(gold=1000, ore=5),
        prerequisites=(BuildingId.DUNGEON_WARREN,),
        upgrades_creature=CreatureType.INFERNAL_TROGLODYTE,
    ),
    BuildingId.UPG_DUNGEON_HARPY_LOFT: BuildingDef(
        building_id=BuildingId.UPG_DUNGEON_HARPY_LOFT,
        name="Upg. Harpy Loft",
        cost=Resources(gold=1000, wood=5),
        prerequisites=(BuildingId.DUNGEON_HARPY_LOFT,),
        upgrades_creature=CreatureType.HARPY_HAG,
    ),
    BuildingId.UPG_DUNGEON_PILLAR_OF_EYES: BuildingDef(
        building_id=BuildingId.UPG_DUNGEON_PILLAR_OF_EYES,
        name="Upg. Pillar of Eyes",
        cost=Resources(gold=1500, ore=5, crystal=5),
        prerequisites=(BuildingId.DUNGEON_PILLAR_OF_EYES,),
        upgrades_creature=CreatureType.EVIL_EYE,
    ),
    BuildingId.UPG_DUNGEON_CHAPEL_OF_STILLED_VOICES: BuildingDef(
        building_id=BuildingId.UPG_DUNGEON_CHAPEL_OF_STILLED_VOICES,
        name="Upg. Chapel of Stilled Voices",
        cost=Resources(gold=2000, wood=5, ore=5),
        prerequisites=(BuildingId.DUNGEON_CHAPEL_OF_STILLED_VOICES,),
        upgrades_creature=CreatureType.MEDUSA_QUEEN,
    ),
    BuildingId.UPG_DUNGEON_LABYRINTH: BuildingDef(
        building_id=BuildingId.UPG_DUNGEON_LABYRINTH,
        name="Upg. Labyrinth",
        cost=Resources(gold=2000, ore=5),
        prerequisites=(BuildingId.DUNGEON_LABYRINTH,),
        upgrades_creature=CreatureType.MINOTAUR_KING,
    ),
    BuildingId.UPG_DUNGEON_MANTICORE_LAIR: BuildingDef(
        building_id=BuildingId.UPG_DUNGEON_MANTICORE_LAIR,
        name="Upg. Manticore Lair",
        cost=Resources(gold=3000, ore=5, mercury=5),
        prerequisites=(BuildingId.DUNGEON_MANTICORE_LAIR,),
        upgrades_creature=CreatureType.SCORPICORE,
    ),
    BuildingId.UPG_DUNGEON_DRAGON_CAVE: BuildingDef(
        building_id=BuildingId.UPG_DUNGEON_DRAGON_CAVE,
        name="Upg. Dragon Cave",
        cost=Resources(gold=5000, ore=10, sulfur=10),
        prerequisites=(BuildingId.DUNGEON_DRAGON_CAVE,),
        upgrades_creature=CreatureType.BLACK_DRAGON,
    ),
}

# HoMM3-accurate Rampart faction buildings
RAMPART_BUILDINGS: dict[BuildingId, BuildingDef] = {
    # Town hall chain
    BuildingId.VILLAGE_HALL: BuildingDef(
        building_id=BuildingId.VILLAGE_HALL,
        name="Village Hall",
        cost=Resources(),
        daily_gold=500,
    ),
    BuildingId.TAVERN: BuildingDef(
        building_id=BuildingId.TAVERN,
        name="Tavern",
        cost=Resources(gold=500, wood=5),
        prerequisites=(BuildingId.VILLAGE_HALL,),
    ),
    BuildingId.TOWN_HALL: BuildingDef(
        building_id=BuildingId.TOWN_HALL,
        name="Town Hall",
        cost=Resources(gold=2500),
        prerequisites=(BuildingId.VILLAGE_HALL, BuildingId.TAVERN),
        daily_gold=1000,
    ),
    BuildingId.BLACKSMITH: BuildingDef(
        building_id=BuildingId.BLACKSMITH,
        name="Blacksmith",
        cost=Resources(gold=1000, wood=5),
    ),
    BuildingId.MARKETPLACE: BuildingDef(
        building_id=BuildingId.MARKETPLACE,
        name="Marketplace",
        cost=Resources(gold=500, wood=5),
    ),
    BuildingId.CITY_HALL: BuildingDef(
        building_id=BuildingId.CITY_HALL,
        name="City Hall",
        cost=Resources(gold=5000),
        prerequisites=(
            BuildingId.TOWN_HALL,
            BuildingId.MARKETPLACE,
            BuildingId.MAGE_GUILD_1,
            BuildingId.BLACKSMITH,
        ),
        daily_gold=2000,
    ),
    BuildingId.CAPITOL: BuildingDef(
        building_id=BuildingId.CAPITOL,
        name="Capitol",
        cost=Resources(gold=10000),
        prerequisites=(BuildingId.CITY_HALL, BuildingId.CASTLE),
        daily_gold=4000,
    ),
    # Fortifications
    BuildingId.FORT: BuildingDef(
        building_id=BuildingId.FORT,
        name="Fort",
        cost=Resources(gold=5000, wood=20, ore=20),
    ),
    BuildingId.CITADEL: BuildingDef(
        building_id=BuildingId.CITADEL,
        name="Citadel",
        cost=Resources(gold=2500, ore=5),
        prerequisites=(BuildingId.FORT,),
        growth_bonus=0.5,
    ),
    BuildingId.CASTLE: BuildingDef(
        building_id=BuildingId.CASTLE,
        name="Castle",
        cost=Resources(gold=5000, wood=10, ore=10),
        prerequisites=(BuildingId.CITADEL,),
        growth_bonus=1.0,
    ),
    # Mage Guilds
    BuildingId.MAGE_GUILD_1: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_1,
        name="Mage Guild Level 1",
        cost=Resources(gold=2000, wood=5, ore=5),
    ),
    BuildingId.MAGE_GUILD_2: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_2,
        name="Mage Guild Level 2",
        cost=Resources(gold=3000, wood=5, ore=5, crystal=4, gems=4),
        prerequisites=(BuildingId.MAGE_GUILD_1,),
    ),
    BuildingId.MAGE_GUILD_3: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_3,
        name="Mage Guild Level 3",
        cost=Resources(gold=5000, wood=5, ore=5, crystal=6, gems=6),
        prerequisites=(BuildingId.MAGE_GUILD_2,),
    ),
    BuildingId.MAGE_GUILD_4: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_4,
        name="Mage Guild Level 4",
        cost=Resources(
            gold=8000, wood=5, ore=5, crystal=8, gems=8, mercury=4, sulfur=4
        ),
        prerequisites=(BuildingId.MAGE_GUILD_3,),
    ),
    BuildingId.MAGE_GUILD_5: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_5,
        name="Mage Guild Level 5",
        cost=Resources(
            gold=12000, wood=5, ore=5, crystal=10, gems=10, mercury=6, sulfur=6
        ),
        prerequisites=(BuildingId.MAGE_GUILD_4,),
    ),
    # Special buildings
    BuildingId.ARTIFACT_MERCHANT: BuildingDef(
        building_id=BuildingId.ARTIFACT_MERCHANT,
        name="Artifact Merchant",
        cost=Resources(gold=10000, wood=10, ore=10),
        prerequisites=(BuildingId.TOWN_HALL,),
    ),
    BuildingId.RESOURCE_SILO: BuildingDef(
        building_id=BuildingId.RESOURCE_SILO,
        name="Resource Silo",
        cost=Resources(gold=5000, ore=5),
        prerequisites=(BuildingId.MARKETPLACE,),
    ),
    # Rampart dwellings
    BuildingId.RAMPART_CENTAUR_STABLES: BuildingDef(
        building_id=BuildingId.RAMPART_CENTAUR_STABLES,
        name="Centaur Stables",
        cost=Resources(gold=500, wood=5),
        prerequisites=(BuildingId.FORT,),
        unlocks_creature=CreatureType.CENTAUR,
    ),
    BuildingId.RAMPART_DWARF_COTTAGE: BuildingDef(
        building_id=BuildingId.RAMPART_DWARF_COTTAGE,
        name="Dwarf Cottage",
        cost=Resources(gold=1000, wood=5),
        prerequisites=(BuildingId.FORT, BuildingId.RAMPART_CENTAUR_STABLES),
        unlocks_creature=CreatureType.DWARF,
    ),
    BuildingId.RAMPART_HOMESTEAD: BuildingDef(
        building_id=BuildingId.RAMPART_HOMESTEAD,
        name="Homestead",
        cost=Resources(gold=1000, wood=5),
        prerequisites=(BuildingId.RAMPART_DWARF_COTTAGE,),
        unlocks_creature=CreatureType.WOOD_ELF,
    ),
    BuildingId.RAMPART_ENCHANTED_SPRING: BuildingDef(
        building_id=BuildingId.RAMPART_ENCHANTED_SPRING,
        name="Enchanted Spring",
        cost=Resources(gold=1500, wood=10),
        prerequisites=(BuildingId.RAMPART_HOMESTEAD,),
        unlocks_creature=CreatureType.PEGASUS,
    ),
    BuildingId.RAMPART_DENDROID_ARCHES: BuildingDef(
        building_id=BuildingId.RAMPART_DENDROID_ARCHES,
        name="Dendroid Arches",
        cost=Resources(gold=2000, crystal=10),
        prerequisites=(BuildingId.RAMPART_ENCHANTED_SPRING,),
        unlocks_creature=CreatureType.DENDROID_GUARD,
    ),
    BuildingId.RAMPART_UNICORN_GLADE: BuildingDef(
        building_id=BuildingId.RAMPART_UNICORN_GLADE,
        name="Unicorn Glade",
        cost=Resources(gold=2000, crystal=10),
        prerequisites=(BuildingId.RAMPART_DENDROID_ARCHES,),
        unlocks_creature=CreatureType.UNICORN,
    ),
    BuildingId.RAMPART_DRAGON_CLIFFS: BuildingDef(
        building_id=BuildingId.RAMPART_DRAGON_CLIFFS,
        name="Dragon Cliffs",
        cost=Resources(gold=10000, ore=30, crystal=20),
        prerequisites=(BuildingId.RAMPART_UNICORN_GLADE, BuildingId.MAGE_GUILD_2),
        unlocks_creature=CreatureType.GREEN_DRAGON,
    ),
    # Rampart upgraded dwellings
    BuildingId.UPG_RAMPART_CENTAUR_STABLES: BuildingDef(
        building_id=BuildingId.UPG_RAMPART_CENTAUR_STABLES,
        name="Upg. Centaur Stables",
        cost=Resources(gold=1000, wood=5),
        prerequisites=(BuildingId.RAMPART_CENTAUR_STABLES,),
        upgrades_creature=CreatureType.CENTAUR_CAPTAIN,
    ),
    BuildingId.UPG_RAMPART_DWARF_COTTAGE: BuildingDef(
        building_id=BuildingId.UPG_RAMPART_DWARF_COTTAGE,
        name="Upg. Dwarf Cottage",
        cost=Resources(gold=1000, wood=5),
        prerequisites=(BuildingId.RAMPART_DWARF_COTTAGE,),
        upgrades_creature=CreatureType.BATTLE_DWARF,
    ),
    BuildingId.UPG_RAMPART_HOMESTEAD: BuildingDef(
        building_id=BuildingId.UPG_RAMPART_HOMESTEAD,
        name="Upg. Homestead",
        cost=Resources(gold=1000, wood=5),
        prerequisites=(BuildingId.RAMPART_HOMESTEAD,),
        upgrades_creature=CreatureType.GRAND_ELF,
    ),
    BuildingId.UPG_RAMPART_ENCHANTED_SPRING: BuildingDef(
        building_id=BuildingId.UPG_RAMPART_ENCHANTED_SPRING,
        name="Upg. Enchanted Spring",
        cost=Resources(gold=1500, crystal=10),
        prerequisites=(BuildingId.RAMPART_ENCHANTED_SPRING,),
        upgrades_creature=CreatureType.SILVER_PEGASUS,
    ),
    BuildingId.UPG_RAMPART_DENDROID_ARCHES: BuildingDef(
        building_id=BuildingId.UPG_RAMPART_DENDROID_ARCHES,
        name="Upg. Dendroid Arches",
        cost=Resources(gold=2000, crystal=5),
        prerequisites=(BuildingId.RAMPART_DENDROID_ARCHES,),
        upgrades_creature=CreatureType.DENDROID_SOLDIER,
    ),
    BuildingId.UPG_RAMPART_UNICORN_GLADE: BuildingDef(
        building_id=BuildingId.UPG_RAMPART_UNICORN_GLADE,
        name="Upg. Unicorn Glade",
        cost=Resources(gold=2000, crystal=5),
        prerequisites=(BuildingId.RAMPART_UNICORN_GLADE,),
        upgrades_creature=CreatureType.WAR_UNICORN,
    ),
    BuildingId.UPG_RAMPART_DRAGON_CLIFFS: BuildingDef(
        building_id=BuildingId.UPG_RAMPART_DRAGON_CLIFFS,
        name="Upg. Dragon Cliffs",
        cost=Resources(gold=20000, ore=30, crystal=20),
        prerequisites=(BuildingId.RAMPART_DRAGON_CLIFFS,),
        upgrades_creature=CreatureType.GOLD_DRAGON,
    ),
}

# HoMM3-accurate Tower faction buildings
TOWER_BUILDINGS: dict[BuildingId, BuildingDef] = {
    # Town hall chain
    BuildingId.VILLAGE_HALL: BuildingDef(
        building_id=BuildingId.VILLAGE_HALL,
        name="Village Hall",
        cost=Resources(),
        daily_gold=500,
    ),
    BuildingId.TAVERN: BuildingDef(
        building_id=BuildingId.TAVERN,
        name="Tavern",
        cost=Resources(gold=500, wood=5),
        prerequisites=(BuildingId.VILLAGE_HALL,),
    ),
    BuildingId.TOWN_HALL: BuildingDef(
        building_id=BuildingId.TOWN_HALL,
        name="Town Hall",
        cost=Resources(gold=2500),
        prerequisites=(BuildingId.VILLAGE_HALL, BuildingId.TAVERN),
        daily_gold=1000,
    ),
    BuildingId.BLACKSMITH: BuildingDef(
        building_id=BuildingId.BLACKSMITH,
        name="Blacksmith",
        cost=Resources(gold=1000, wood=5),
    ),
    BuildingId.MARKETPLACE: BuildingDef(
        building_id=BuildingId.MARKETPLACE,
        name="Marketplace",
        cost=Resources(gold=500, wood=5),
    ),
    BuildingId.CITY_HALL: BuildingDef(
        building_id=BuildingId.CITY_HALL,
        name="City Hall",
        cost=Resources(gold=5000),
        prerequisites=(
            BuildingId.TOWN_HALL,
            BuildingId.MARKETPLACE,
            BuildingId.MAGE_GUILD_1,
            BuildingId.BLACKSMITH,
        ),
        daily_gold=2000,
    ),
    BuildingId.CAPITOL: BuildingDef(
        building_id=BuildingId.CAPITOL,
        name="Capitol",
        cost=Resources(gold=10000),
        prerequisites=(BuildingId.CITY_HALL, BuildingId.CASTLE),
        daily_gold=4000,
    ),
    # Fortifications
    BuildingId.FORT: BuildingDef(
        building_id=BuildingId.FORT,
        name="Fort",
        cost=Resources(gold=5000, wood=20, ore=20),
    ),
    BuildingId.CITADEL: BuildingDef(
        building_id=BuildingId.CITADEL,
        name="Citadel",
        cost=Resources(gold=2500, ore=5),
        prerequisites=(BuildingId.FORT,),
        growth_bonus=0.5,
    ),
    BuildingId.CASTLE: BuildingDef(
        building_id=BuildingId.CASTLE,
        name="Castle",
        cost=Resources(gold=5000, wood=10, ore=10),
        prerequisites=(BuildingId.CITADEL,),
        growth_bonus=1.0,
    ),
    # Mage Guilds
    BuildingId.MAGE_GUILD_1: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_1,
        name="Mage Guild Level 1",
        cost=Resources(gold=2000, wood=5, ore=5),
    ),
    BuildingId.MAGE_GUILD_2: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_2,
        name="Mage Guild Level 2",
        cost=Resources(gold=3000, wood=5, ore=5, crystal=4, gems=4),
        prerequisites=(BuildingId.MAGE_GUILD_1,),
    ),
    BuildingId.MAGE_GUILD_3: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_3,
        name="Mage Guild Level 3",
        cost=Resources(gold=5000, wood=5, ore=5, crystal=6, gems=6),
        prerequisites=(BuildingId.MAGE_GUILD_2,),
    ),
    BuildingId.MAGE_GUILD_4: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_4,
        name="Mage Guild Level 4",
        cost=Resources(
            gold=8000, wood=5, ore=5, crystal=8, gems=8, mercury=4, sulfur=4
        ),
        prerequisites=(BuildingId.MAGE_GUILD_3,),
    ),
    BuildingId.MAGE_GUILD_5: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_5,
        name="Mage Guild Level 5",
        cost=Resources(
            gold=12000, wood=5, ore=5, crystal=10, gems=10, mercury=6, sulfur=6
        ),
        prerequisites=(BuildingId.MAGE_GUILD_4,),
    ),
    # Special buildings
    BuildingId.ARTIFACT_MERCHANT: BuildingDef(
        building_id=BuildingId.ARTIFACT_MERCHANT,
        name="Artifact Merchant",
        cost=Resources(gold=10000, wood=10, ore=10),
        prerequisites=(BuildingId.TOWN_HALL,),
    ),
    BuildingId.RESOURCE_SILO: BuildingDef(
        building_id=BuildingId.RESOURCE_SILO,
        name="Resource Silo",
        cost=Resources(gold=5000, ore=5),
        prerequisites=(BuildingId.MARKETPLACE,),
    ),
    # Tower dwellings
    BuildingId.TOWER_WORKSHOP: BuildingDef(
        building_id=BuildingId.TOWER_WORKSHOP,
        name="Workshop",
        cost=Resources(gold=300, wood=5, ore=5),
        prerequisites=(BuildingId.FORT,),
        unlocks_creature=CreatureType.GREMLIN,
    ),
    BuildingId.TOWER_PARAPET: BuildingDef(
        building_id=BuildingId.TOWER_PARAPET,
        name="Parapet",
        cost=Resources(gold=1000, ore=10),
        prerequisites=(BuildingId.FORT,),
        unlocks_creature=CreatureType.STONE_GARGOYLE,
    ),
    BuildingId.TOWER_GOLEM_FACTORY: BuildingDef(
        building_id=BuildingId.TOWER_GOLEM_FACTORY,
        name="Golem Factory",
        cost=Resources(gold=1500, wood=5, ore=5),
        prerequisites=(BuildingId.TOWER_WORKSHOP, BuildingId.TOWER_PARAPET),
        unlocks_creature=CreatureType.STONE_GOLEM,
    ),
    BuildingId.TOWER_MAGE_TOWER: BuildingDef(
        building_id=BuildingId.TOWER_MAGE_TOWER,
        name="Mage Tower",
        cost=Resources(gold=2500, wood=5, ore=5, gems=5),
        prerequisites=(BuildingId.TOWER_GOLEM_FACTORY, BuildingId.MAGE_GUILD_1),
        unlocks_creature=CreatureType.MAGE,
    ),
    BuildingId.TOWER_ALTAR_OF_WISHES: BuildingDef(
        building_id=BuildingId.TOWER_ALTAR_OF_WISHES,
        name="Altar of Wishes",
        cost=Resources(gold=2000, wood=5),
        prerequisites=(BuildingId.TOWER_MAGE_TOWER,),
        unlocks_creature=CreatureType.GENIE,
    ),
    BuildingId.TOWER_GOLDEN_PAVILION: BuildingDef(
        building_id=BuildingId.TOWER_GOLDEN_PAVILION,
        name="Golden Pavilion",
        cost=Resources(gold=4000, wood=5, ore=5, mercury=2, sulfur=2, crystal=2, gems=2),
        prerequisites=(BuildingId.TOWER_ALTAR_OF_WISHES,),
        unlocks_creature=CreatureType.NAGA,
    ),
    BuildingId.TOWER_CLOUD_TEMPLE: BuildingDef(
        building_id=BuildingId.TOWER_CLOUD_TEMPLE,
        name="Cloud Temple",
        cost=Resources(gold=5000, wood=10, ore=10, gems=10),
        prerequisites=(BuildingId.TOWER_GOLDEN_PAVILION,),
        unlocks_creature=CreatureType.GIANT,
    ),
    # Tower upgraded dwellings
    BuildingId.UPG_TOWER_WORKSHOP: BuildingDef(
        building_id=BuildingId.UPG_TOWER_WORKSHOP,
        name="Upg. Workshop",
        cost=Resources(gold=1000),
        prerequisites=(BuildingId.TOWER_WORKSHOP,),
        upgrades_creature=CreatureType.MASTER_GREMLIN,
    ),
    BuildingId.UPG_TOWER_PARAPET: BuildingDef(
        building_id=BuildingId.UPG_TOWER_PARAPET,
        name="Upg. Parapet",
        cost=Resources(gold=1500, ore=5),
        prerequisites=(BuildingId.TOWER_PARAPET,),
        upgrades_creature=CreatureType.OBSIDIAN_GARGOYLE,
    ),
    BuildingId.UPG_TOWER_GOLEM_FACTORY: BuildingDef(
        building_id=BuildingId.UPG_TOWER_GOLEM_FACTORY,
        name="Upg. Golem Factory",
        cost=Resources(gold=1000, ore=5, mercury=5),
        prerequisites=(BuildingId.TOWER_GOLEM_FACTORY,),
        upgrades_creature=CreatureType.IRON_GOLEM,
    ),
    BuildingId.UPG_TOWER_MAGE_TOWER: BuildingDef(
        building_id=BuildingId.UPG_TOWER_MAGE_TOWER,
        name="Upg. Mage Tower",
        cost=Resources(gold=2000, wood=5, ore=5),
        prerequisites=(BuildingId.TOWER_MAGE_TOWER,),
        upgrades_creature=CreatureType.ARCH_MAGE,
    ),
    BuildingId.UPG_TOWER_ALTAR_OF_WISHES: BuildingDef(
        building_id=BuildingId.UPG_TOWER_ALTAR_OF_WISHES,
        name="Upg. Altar of Wishes",
        cost=Resources(gold=3000, wood=5, ore=5, crystal=6, gems=6),
        prerequisites=(BuildingId.TOWER_ALTAR_OF_WISHES,),
        upgrades_creature=CreatureType.MASTER_GENIE,
    ),
    BuildingId.UPG_TOWER_GOLDEN_PAVILION: BuildingDef(
        building_id=BuildingId.UPG_TOWER_GOLDEN_PAVILION,
        name="Upg. Golden Pavilion",
        cost=Resources(gold=3000, mercury=3, sulfur=3, crystal=3, gems=3),
        prerequisites=(BuildingId.TOWER_GOLDEN_PAVILION,),
        upgrades_creature=CreatureType.NAGA_QUEEN,
    ),
    BuildingId.UPG_TOWER_CLOUD_TEMPLE: BuildingDef(
        building_id=BuildingId.UPG_TOWER_CLOUD_TEMPLE,
        name="Upg. Cloud Temple",
        cost=Resources(gold=25000, wood=5, ore=5, gems=30),
        prerequisites=(BuildingId.TOWER_CLOUD_TEMPLE,),
        upgrades_creature=CreatureType.TITAN,
    ),
}

# HoMM3-accurate Stronghold faction buildings
STRONGHOLD_BUILDINGS: dict[BuildingId, BuildingDef] = {
    # Town hall chain
    BuildingId.VILLAGE_HALL: BuildingDef(
        building_id=BuildingId.VILLAGE_HALL,
        name="Village Hall",
        cost=Resources(),
        daily_gold=500,
    ),
    BuildingId.TAVERN: BuildingDef(
        building_id=BuildingId.TAVERN,
        name="Tavern",
        cost=Resources(gold=500, wood=5),
        prerequisites=(BuildingId.VILLAGE_HALL,),
    ),
    BuildingId.TOWN_HALL: BuildingDef(
        building_id=BuildingId.TOWN_HALL,
        name="Town Hall",
        cost=Resources(gold=2500),
        prerequisites=(BuildingId.VILLAGE_HALL, BuildingId.TAVERN),
        daily_gold=1000,
    ),
    BuildingId.BLACKSMITH: BuildingDef(
        building_id=BuildingId.BLACKSMITH,
        name="Blacksmith",
        cost=Resources(gold=1000, wood=5),
    ),
    BuildingId.MARKETPLACE: BuildingDef(
        building_id=BuildingId.MARKETPLACE,
        name="Marketplace",
        cost=Resources(gold=500, wood=5),
    ),
    BuildingId.CITY_HALL: BuildingDef(
        building_id=BuildingId.CITY_HALL,
        name="City Hall",
        cost=Resources(gold=5000),
        prerequisites=(
            BuildingId.TOWN_HALL,
            BuildingId.MARKETPLACE,
            BuildingId.MAGE_GUILD_1,
            BuildingId.BLACKSMITH,
        ),
        daily_gold=2000,
    ),
    BuildingId.CAPITOL: BuildingDef(
        building_id=BuildingId.CAPITOL,
        name="Capitol",
        cost=Resources(gold=10000),
        prerequisites=(BuildingId.CITY_HALL, BuildingId.CASTLE),
        daily_gold=4000,
    ),
    # Fortifications
    BuildingId.FORT: BuildingDef(
        building_id=BuildingId.FORT,
        name="Fort",
        cost=Resources(gold=5000, wood=20, ore=20),
    ),
    BuildingId.CITADEL: BuildingDef(
        building_id=BuildingId.CITADEL,
        name="Citadel",
        cost=Resources(gold=2500, ore=5),
        prerequisites=(BuildingId.FORT,),
        growth_bonus=0.5,
    ),
    BuildingId.CASTLE: BuildingDef(
        building_id=BuildingId.CASTLE,
        name="Castle",
        cost=Resources(gold=5000, wood=10, ore=10),
        prerequisites=(BuildingId.CITADEL,),
        growth_bonus=1.0,
    ),
    # Mage Guilds (Stronghold maxes out at level 3)
    BuildingId.MAGE_GUILD_1: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_1,
        name="Mage Guild Level 1",
        cost=Resources(gold=2000, wood=5, ore=5),
    ),
    BuildingId.MAGE_GUILD_2: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_2,
        name="Mage Guild Level 2",
        cost=Resources(gold=3000, wood=5, ore=5, crystal=4, gems=4),
        prerequisites=(BuildingId.MAGE_GUILD_1,),
    ),
    BuildingId.MAGE_GUILD_3: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_3,
        name="Mage Guild Level 3",
        cost=Resources(gold=5000, wood=5, ore=5, crystal=6, gems=6),
        prerequisites=(BuildingId.MAGE_GUILD_2,),
    ),
    # Special buildings
    BuildingId.ARTIFACT_MERCHANT: BuildingDef(
        building_id=BuildingId.ARTIFACT_MERCHANT,
        name="Artifact Merchant",
        cost=Resources(gold=10000, wood=10, ore=10),
        prerequisites=(BuildingId.TOWN_HALL,),
    ),
    BuildingId.RESOURCE_SILO: BuildingDef(
        building_id=BuildingId.RESOURCE_SILO,
        name="Resource Silo",
        cost=Resources(gold=5000, ore=5),
        prerequisites=(BuildingId.MARKETPLACE,),
    ),
    # Stronghold dwellings
    BuildingId.STRONGHOLD_GOBLIN_BARRACKS: BuildingDef(
        building_id=BuildingId.STRONGHOLD_GOBLIN_BARRACKS,
        name="Goblin Barracks",
        cost=Resources(gold=200, wood=5, ore=5),
        prerequisites=(BuildingId.FORT,),
        unlocks_creature=CreatureType.GOBLIN,
    ),
    BuildingId.STRONGHOLD_WOLF_PEN: BuildingDef(
        building_id=BuildingId.STRONGHOLD_WOLF_PEN,
        name="Wolf Pen",
        cost=Resources(gold=1000, wood=10, ore=5),
        prerequisites=(BuildingId.FORT, BuildingId.STRONGHOLD_GOBLIN_BARRACKS),
        unlocks_creature=CreatureType.WOLF_RIDER,
    ),
    BuildingId.STRONGHOLD_ORC_TOWER: BuildingDef(
        building_id=BuildingId.STRONGHOLD_ORC_TOWER,
        name="Orc Tower",
        cost=Resources(gold=1000, wood=5, ore=5),
        prerequisites=(BuildingId.STRONGHOLD_WOLF_PEN,),
        unlocks_creature=CreatureType.ORC,
    ),
    BuildingId.STRONGHOLD_OGRE_FORT: BuildingDef(
        building_id=BuildingId.STRONGHOLD_OGRE_FORT,
        name="Ogre Fort",
        cost=Resources(gold=1000, wood=5, ore=5),
        prerequisites=(BuildingId.STRONGHOLD_ORC_TOWER, BuildingId.MAGE_GUILD_1),
        unlocks_creature=CreatureType.OGRE,
    ),
    BuildingId.STRONGHOLD_CLIFF_NEST: BuildingDef(
        building_id=BuildingId.STRONGHOLD_CLIFF_NEST,
        name="Cliff Nest",
        cost=Resources(gold=1000, wood=2, ore=2),
        prerequisites=(BuildingId.STRONGHOLD_OGRE_FORT,),
        unlocks_creature=CreatureType.ROC,
    ),
    BuildingId.STRONGHOLD_CYCLOPS_CAVE: BuildingDef(
        building_id=BuildingId.STRONGHOLD_CYCLOPS_CAVE,
        name="Cyclops Cave",
        cost=Resources(gold=2000, wood=5, ore=5),
        prerequisites=(BuildingId.STRONGHOLD_CLIFF_NEST,),
        unlocks_creature=CreatureType.CYCLOPS,
    ),
    BuildingId.STRONGHOLD_BEHEMOTH_LAIR: BuildingDef(
        building_id=BuildingId.STRONGHOLD_BEHEMOTH_LAIR,
        name="Behemoth Lair",
        cost=Resources(gold=10000, wood=10, ore=10, crystal=10),
        prerequisites=(BuildingId.STRONGHOLD_CYCLOPS_CAVE,),
        unlocks_creature=CreatureType.BEHEMOTH,
    ),
    # Stronghold upgraded dwellings
    BuildingId.UPG_STRONGHOLD_GOBLIN_BARRACKS: BuildingDef(
        building_id=BuildingId.UPG_STRONGHOLD_GOBLIN_BARRACKS,
        name="Upg. Goblin Barracks",
        cost=Resources(gold=1000, wood=5, ore=5),
        prerequisites=(BuildingId.STRONGHOLD_GOBLIN_BARRACKS,),
        upgrades_creature=CreatureType.HOBGOBLIN,
    ),
    BuildingId.UPG_STRONGHOLD_WOLF_PEN: BuildingDef(
        building_id=BuildingId.UPG_STRONGHOLD_WOLF_PEN,
        name="Upg. Wolf Pen",
        cost=Resources(gold=1000, wood=5, ore=5),
        prerequisites=(BuildingId.STRONGHOLD_WOLF_PEN,),
        upgrades_creature=CreatureType.WOLF_RAIDER,
    ),
    BuildingId.UPG_STRONGHOLD_ORC_TOWER: BuildingDef(
        building_id=BuildingId.UPG_STRONGHOLD_ORC_TOWER,
        name="Upg. Orc Tower",
        cost=Resources(gold=1000, wood=5, ore=5),
        prerequisites=(BuildingId.STRONGHOLD_ORC_TOWER,),
        upgrades_creature=CreatureType.ORC_CHIEFTAIN,
    ),
    BuildingId.UPG_STRONGHOLD_OGRE_FORT: BuildingDef(
        building_id=BuildingId.UPG_STRONGHOLD_OGRE_FORT,
        name="Upg. Ogre Fort",
        cost=Resources(gold=1000, wood=5, ore=5),
        prerequisites=(BuildingId.STRONGHOLD_OGRE_FORT,),
        upgrades_creature=CreatureType.OGRE_MAGE,
    ),
    BuildingId.UPG_STRONGHOLD_CLIFF_NEST: BuildingDef(
        building_id=BuildingId.UPG_STRONGHOLD_CLIFF_NEST,
        name="Upg. Cliff Nest",
        cost=Resources(gold=2000, wood=20),
        prerequisites=(BuildingId.STRONGHOLD_CLIFF_NEST,),
        upgrades_creature=CreatureType.THUNDERBIRD,
    ),
    BuildingId.UPG_STRONGHOLD_CYCLOPS_CAVE: BuildingDef(
        building_id=BuildingId.UPG_STRONGHOLD_CYCLOPS_CAVE,
        name="Upg. Cyclops Cave",
        cost=Resources(gold=3500, ore=20),
        prerequisites=(BuildingId.STRONGHOLD_CYCLOPS_CAVE,),
        upgrades_creature=CreatureType.CYCLOPS_KING,
    ),
    BuildingId.UPG_STRONGHOLD_BEHEMOTH_LAIR: BuildingDef(
        building_id=BuildingId.UPG_STRONGHOLD_BEHEMOTH_LAIR,
        name="Upg. Behemoth Lair",
        cost=Resources(gold=15000, wood=10, ore=10, crystal=20),
        prerequisites=(BuildingId.STRONGHOLD_BEHEMOTH_LAIR,),
        upgrades_creature=CreatureType.ANCIENT_BEHEMOTH,
    ),
}

# HoMM3-accurate Fortress faction buildings
FORTRESS_BUILDINGS: dict[BuildingId, BuildingDef] = {
    # Town hall chain
    BuildingId.VILLAGE_HALL: BuildingDef(
        building_id=BuildingId.VILLAGE_HALL,
        name="Village Hall",
        cost=Resources(),
        daily_gold=500,
    ),
    BuildingId.TAVERN: BuildingDef(
        building_id=BuildingId.TAVERN,
        name="Tavern",
        cost=Resources(gold=500, wood=5),
        prerequisites=(BuildingId.VILLAGE_HALL,),
    ),
    BuildingId.TOWN_HALL: BuildingDef(
        building_id=BuildingId.TOWN_HALL,
        name="Town Hall",
        cost=Resources(gold=2500),
        prerequisites=(BuildingId.VILLAGE_HALL, BuildingId.TAVERN),
        daily_gold=1000,
    ),
    BuildingId.BLACKSMITH: BuildingDef(
        building_id=BuildingId.BLACKSMITH,
        name="Blacksmith",
        cost=Resources(gold=1000, wood=5),
    ),
    BuildingId.MARKETPLACE: BuildingDef(
        building_id=BuildingId.MARKETPLACE,
        name="Marketplace",
        cost=Resources(gold=500, wood=5),
    ),
    BuildingId.CITY_HALL: BuildingDef(
        building_id=BuildingId.CITY_HALL,
        name="City Hall",
        cost=Resources(gold=5000),
        prerequisites=(
            BuildingId.TOWN_HALL,
            BuildingId.MARKETPLACE,
            BuildingId.MAGE_GUILD_1,
            BuildingId.BLACKSMITH,
        ),
        daily_gold=2000,
    ),
    BuildingId.CAPITOL: BuildingDef(
        building_id=BuildingId.CAPITOL,
        name="Capitol",
        cost=Resources(gold=10000),
        prerequisites=(BuildingId.CITY_HALL, BuildingId.CASTLE),
        daily_gold=4000,
    ),
    # Fortifications
    BuildingId.FORT: BuildingDef(
        building_id=BuildingId.FORT,
        name="Fort",
        cost=Resources(gold=5000, wood=20, ore=20),
    ),
    BuildingId.CITADEL: BuildingDef(
        building_id=BuildingId.CITADEL,
        name="Citadel",
        cost=Resources(gold=2500, ore=5),
        prerequisites=(BuildingId.FORT,),
        growth_bonus=0.5,
    ),
    BuildingId.CASTLE: BuildingDef(
        building_id=BuildingId.CASTLE,
        name="Castle",
        cost=Resources(gold=5000, wood=10, ore=10),
        prerequisites=(BuildingId.CITADEL,),
        growth_bonus=1.0,
    ),
    # Mage Guilds (Fortress maxes out at level 3)
    BuildingId.MAGE_GUILD_1: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_1,
        name="Mage Guild Level 1",
        cost=Resources(gold=2000, wood=5, ore=5),
    ),
    BuildingId.MAGE_GUILD_2: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_2,
        name="Mage Guild Level 2",
        cost=Resources(gold=3000, wood=5, ore=5, crystal=4, gems=4),
        prerequisites=(BuildingId.MAGE_GUILD_1,),
    ),
    BuildingId.MAGE_GUILD_3: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_3,
        name="Mage Guild Level 3",
        cost=Resources(gold=5000, wood=5, ore=5, crystal=6, gems=6),
        prerequisites=(BuildingId.MAGE_GUILD_2,),
    ),
    # Special buildings
    BuildingId.ARTIFACT_MERCHANT: BuildingDef(
        building_id=BuildingId.ARTIFACT_MERCHANT,
        name="Artifact Merchant",
        cost=Resources(gold=10000, wood=10, ore=10),
        prerequisites=(BuildingId.TOWN_HALL,),
    ),
    BuildingId.RESOURCE_SILO: BuildingDef(
        building_id=BuildingId.RESOURCE_SILO,
        name="Resource Silo",
        cost=Resources(gold=5000, ore=5),
        prerequisites=(BuildingId.MARKETPLACE,),
    ),
    # Fortress dwellings
    BuildingId.FORTRESS_GNOLL_HUT: BuildingDef(
        building_id=BuildingId.FORTRESS_GNOLL_HUT,
        name="Gnoll Hut",
        cost=Resources(gold=400, wood=10),
        prerequisites=(BuildingId.FORT,),
        unlocks_creature=CreatureType.GNOLL,
    ),
    BuildingId.FORTRESS_LIZARD_DEN: BuildingDef(
        building_id=BuildingId.FORTRESS_LIZARD_DEN,
        name="Lizard Den",
        cost=Resources(gold=1000, wood=5),
        prerequisites=(BuildingId.FORTRESS_GNOLL_HUT,),
        unlocks_creature=CreatureType.LIZARDMAN,
    ),
    BuildingId.FORTRESS_SERPENT_FLY_HIVE: BuildingDef(
        building_id=BuildingId.FORTRESS_SERPENT_FLY_HIVE,
        name="Serpent Fly Hive",
        cost=Resources(gold=1000, wood=5, mercury=2, sulfur=2),
        prerequisites=(BuildingId.FORTRESS_GNOLL_HUT,),
        unlocks_creature=CreatureType.SERPENT_FLY,
    ),
    BuildingId.FORTRESS_BASILISK_PIT: BuildingDef(
        building_id=BuildingId.FORTRESS_BASILISK_PIT,
        name="Basilisk Pit",
        cost=Resources(gold=2000, wood=5, ore=10),
        prerequisites=(BuildingId.FORTRESS_LIZARD_DEN,),
        unlocks_creature=CreatureType.BASILISK,
    ),
    BuildingId.FORTRESS_GORGON_LAIR: BuildingDef(
        building_id=BuildingId.FORTRESS_GORGON_LAIR,
        name="Gorgon Lair",
        cost=Resources(gold=2500, wood=10, ore=10, mercury=5, sulfur=5),
        prerequisites=(BuildingId.FORTRESS_BASILISK_PIT,),
        unlocks_creature=CreatureType.GORGON,
    ),
    BuildingId.FORTRESS_WYVERN_NEST: BuildingDef(
        building_id=BuildingId.FORTRESS_WYVERN_NEST,
        name="Wyvern Nest",
        cost=Resources(gold=3500, wood=15),
        prerequisites=(BuildingId.FORTRESS_SERPENT_FLY_HIVE,),
        unlocks_creature=CreatureType.WYVERN,
    ),
    BuildingId.FORTRESS_HYDRA_POND: BuildingDef(
        building_id=BuildingId.FORTRESS_HYDRA_POND,
        name="Hydra Pond",
        cost=Resources(gold=10000, wood=10, ore=10, sulfur=10),
        prerequisites=(
            BuildingId.FORTRESS_WYVERN_NEST,
            BuildingId.FORTRESS_GORGON_LAIR,
        ),
        unlocks_creature=CreatureType.HYDRA,
    ),
    # Fortress upgraded dwellings
    BuildingId.UPG_FORTRESS_GNOLL_HUT: BuildingDef(
        building_id=BuildingId.UPG_FORTRESS_GNOLL_HUT,
        name="Upg. Gnoll Hut",
        cost=Resources(gold=1000, wood=10),
        prerequisites=(BuildingId.FORTRESS_GNOLL_HUT,),
        upgrades_creature=CreatureType.GNOLL_MARAUDER,
    ),
    BuildingId.UPG_FORTRESS_LIZARD_DEN: BuildingDef(
        building_id=BuildingId.UPG_FORTRESS_LIZARD_DEN,
        name="Upg. Lizard Den",
        cost=Resources(gold=1000, wood=5),
        prerequisites=(BuildingId.FORTRESS_LIZARD_DEN,),
        upgrades_creature=CreatureType.LIZARD_WARRIOR,
    ),
    BuildingId.UPG_FORTRESS_SERPENT_FLY_HIVE: BuildingDef(
        building_id=BuildingId.UPG_FORTRESS_SERPENT_FLY_HIVE,
        name="Upg. Serpent Fly Hive",
        cost=Resources(gold=1000, mercury=2, sulfur=2),
        prerequisites=(BuildingId.FORTRESS_SERPENT_FLY_HIVE,),
        upgrades_creature=CreatureType.DRAGON_FLY,
    ),
    BuildingId.UPG_FORTRESS_BASILISK_PIT: BuildingDef(
        building_id=BuildingId.UPG_FORTRESS_BASILISK_PIT,
        name="Upg. Basilisk Pit",
        cost=Resources(gold=2000, wood=5, ore=5),
        prerequisites=(BuildingId.FORTRESS_BASILISK_PIT,),
        upgrades_creature=CreatureType.GREATER_BASILISK,
    ),
    BuildingId.UPG_FORTRESS_GORGON_LAIR: BuildingDef(
        building_id=BuildingId.UPG_FORTRESS_GORGON_LAIR,
        name="Upg. Gorgon Lair",
        cost=Resources(gold=2000, wood=5, ore=5),
        prerequisites=(BuildingId.FORTRESS_GORGON_LAIR,),
        upgrades_creature=CreatureType.MIGHTY_GORGON,
    ),
    BuildingId.UPG_FORTRESS_WYVERN_NEST: BuildingDef(
        building_id=BuildingId.UPG_FORTRESS_WYVERN_NEST,
        name="Upg. Wyvern Nest",
        cost=Resources(gold=3000, wood=10, mercury=10),
        prerequisites=(BuildingId.FORTRESS_WYVERN_NEST,),
        upgrades_creature=CreatureType.WYVERN_MONARCH,
    ),
    BuildingId.UPG_FORTRESS_HYDRA_POND: BuildingDef(
        building_id=BuildingId.UPG_FORTRESS_HYDRA_POND,
        name="Upg. Hydra Pond",
        cost=Resources(gold=15000, wood=10, sulfur=20),
        prerequisites=(BuildingId.FORTRESS_HYDRA_POND,),
        upgrades_creature=CreatureType.CHAOS_HYDRA,
    ),
}

# HoMM3-accurate Conflux faction buildings
CONFLUX_BUILDINGS: dict[BuildingId, BuildingDef] = {
    # Town hall chain
    BuildingId.VILLAGE_HALL: BuildingDef(
        building_id=BuildingId.VILLAGE_HALL,
        name="Village Hall",
        cost=Resources(),
        daily_gold=500,
    ),
    BuildingId.TAVERN: BuildingDef(
        building_id=BuildingId.TAVERN,
        name="Tavern",
        cost=Resources(gold=500, wood=5),
        prerequisites=(BuildingId.VILLAGE_HALL,),
    ),
    BuildingId.TOWN_HALL: BuildingDef(
        building_id=BuildingId.TOWN_HALL,
        name="Town Hall",
        cost=Resources(gold=2500),
        prerequisites=(BuildingId.VILLAGE_HALL, BuildingId.TAVERN),
        daily_gold=1000,
    ),
    BuildingId.BLACKSMITH: BuildingDef(
        building_id=BuildingId.BLACKSMITH,
        name="Blacksmith",
        cost=Resources(gold=1000, wood=5),
    ),
    BuildingId.MARKETPLACE: BuildingDef(
        building_id=BuildingId.MARKETPLACE,
        name="Marketplace",
        cost=Resources(gold=500, wood=5),
    ),
    BuildingId.CITY_HALL: BuildingDef(
        building_id=BuildingId.CITY_HALL,
        name="City Hall",
        cost=Resources(gold=5000),
        prerequisites=(
            BuildingId.TOWN_HALL,
            BuildingId.MARKETPLACE,
            BuildingId.MAGE_GUILD_1,
            BuildingId.BLACKSMITH,
        ),
        daily_gold=2000,
    ),
    BuildingId.CAPITOL: BuildingDef(
        building_id=BuildingId.CAPITOL,
        name="Capitol",
        cost=Resources(gold=10000),
        prerequisites=(BuildingId.CITY_HALL, BuildingId.CASTLE),
        daily_gold=4000,
    ),
    # Fortifications
    BuildingId.FORT: BuildingDef(
        building_id=BuildingId.FORT,
        name="Fort",
        cost=Resources(gold=5000, wood=20, ore=20),
    ),
    BuildingId.CITADEL: BuildingDef(
        building_id=BuildingId.CITADEL,
        name="Citadel",
        cost=Resources(gold=2500, ore=5),
        prerequisites=(BuildingId.FORT,),
        growth_bonus=0.5,
    ),
    BuildingId.CASTLE: BuildingDef(
        building_id=BuildingId.CASTLE,
        name="Castle",
        cost=Resources(gold=5000, wood=10, ore=10),
        prerequisites=(BuildingId.CITADEL,),
        growth_bonus=1.0,
    ),
    # Mage Guilds
    BuildingId.MAGE_GUILD_1: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_1,
        name="Mage Guild Level 1",
        cost=Resources(gold=2000, wood=5, ore=5),
    ),
    BuildingId.MAGE_GUILD_2: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_2,
        name="Mage Guild Level 2",
        cost=Resources(gold=3000, wood=5, ore=5, crystal=4, gems=4),
        prerequisites=(BuildingId.MAGE_GUILD_1,),
    ),
    BuildingId.MAGE_GUILD_3: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_3,
        name="Mage Guild Level 3",
        cost=Resources(gold=5000, wood=5, ore=5, crystal=6, gems=6),
        prerequisites=(BuildingId.MAGE_GUILD_2,),
    ),
    BuildingId.MAGE_GUILD_4: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_4,
        name="Mage Guild Level 4",
        cost=Resources(
            gold=8000, wood=5, ore=5, crystal=8, gems=8, mercury=4, sulfur=4
        ),
        prerequisites=(BuildingId.MAGE_GUILD_3,),
    ),
    BuildingId.MAGE_GUILD_5: BuildingDef(
        building_id=BuildingId.MAGE_GUILD_5,
        name="Mage Guild Level 5",
        cost=Resources(
            gold=12000, wood=5, ore=5, crystal=10, gems=10, mercury=6, sulfur=6
        ),
        prerequisites=(BuildingId.MAGE_GUILD_4,),
    ),
    # Special buildings
    BuildingId.ARTIFACT_MERCHANT: BuildingDef(
        building_id=BuildingId.ARTIFACT_MERCHANT,
        name="Artifact Merchant",
        cost=Resources(gold=10000, wood=10, ore=10),
        prerequisites=(BuildingId.TOWN_HALL,),
    ),
    BuildingId.RESOURCE_SILO: BuildingDef(
        building_id=BuildingId.RESOURCE_SILO,
        name="Resource Silo",
        cost=Resources(gold=5000, ore=5),
        prerequisites=(BuildingId.MARKETPLACE,),
    ),
    # Conflux dwellings
    BuildingId.CONFLUX_MAGIC_LANTERN: BuildingDef(
        building_id=BuildingId.CONFLUX_MAGIC_LANTERN,
        name="Magic Lantern",
        cost=Resources(gold=300, wood=5, ore=5),
        prerequisites=(BuildingId.FORT,),
        unlocks_creature=CreatureType.PIXIE,
    ),
    BuildingId.CONFLUX_ALTAR_OF_AIR: BuildingDef(
        building_id=BuildingId.CONFLUX_ALTAR_OF_AIR,
        name="Altar of Air",
        cost=Resources(gold=1500, ore=5),
        prerequisites=(BuildingId.CONFLUX_MAGIC_LANTERN,),
        unlocks_creature=CreatureType.AIR_ELEMENTAL,
    ),
    BuildingId.CONFLUX_ALTAR_OF_WATER: BuildingDef(
        building_id=BuildingId.CONFLUX_ALTAR_OF_WATER,
        name="Altar of Water",
        cost=Resources(gold=1500, ore=5),
        prerequisites=(BuildingId.CONFLUX_MAGIC_LANTERN,),
        unlocks_creature=CreatureType.WATER_ELEMENTAL,
    ),
    BuildingId.CONFLUX_ALTAR_OF_FIRE: BuildingDef(
        building_id=BuildingId.CONFLUX_ALTAR_OF_FIRE,
        name="Altar of Fire",
        cost=Resources(gold=2000, ore=5, mercury=5),
        prerequisites=(BuildingId.CONFLUX_ALTAR_OF_AIR,),
        unlocks_creature=CreatureType.FIRE_ELEMENTAL,
    ),
    BuildingId.CONFLUX_ALTAR_OF_EARTH: BuildingDef(
        building_id=BuildingId.CONFLUX_ALTAR_OF_EARTH,
        name="Altar of Earth",
        cost=Resources(gold=2000, ore=10),
        prerequisites=(BuildingId.CONFLUX_ALTAR_OF_WATER,),
        unlocks_creature=CreatureType.EARTH_ELEMENTAL,
    ),
    BuildingId.CONFLUX_ALTAR_OF_THOUGHT: BuildingDef(
        building_id=BuildingId.CONFLUX_ALTAR_OF_THOUGHT,
        name="Altar of Thought",
        cost=Resources(gold=3000, wood=5, ore=5, mercury=2, sulfur=2, crystal=2, gems=2),
        prerequisites=(
            BuildingId.CONFLUX_ALTAR_OF_FIRE,
            BuildingId.CONFLUX_ALTAR_OF_EARTH,
        ),
        unlocks_creature=CreatureType.PSYCHIC_ELEMENTAL,
    ),
    BuildingId.CONFLUX_PYRE: BuildingDef(
        building_id=BuildingId.CONFLUX_PYRE,
        name="Pyre",
        cost=Resources(gold=15000, wood=10, ore=10, mercury=20),
        prerequisites=(BuildingId.CONFLUX_ALTAR_OF_THOUGHT,),
        unlocks_creature=CreatureType.FIREBIRD,
    ),
    # Conflux upgraded dwellings
    BuildingId.UPG_CONFLUX_MAGIC_LANTERN: BuildingDef(
        building_id=BuildingId.UPG_CONFLUX_MAGIC_LANTERN,
        name="Upg. Magic Lantern",
        cost=Resources(gold=1000),
        prerequisites=(BuildingId.CONFLUX_MAGIC_LANTERN,),
        upgrades_creature=CreatureType.SPRITE,
    ),
    BuildingId.UPG_CONFLUX_ALTAR_OF_AIR: BuildingDef(
        building_id=BuildingId.UPG_CONFLUX_ALTAR_OF_AIR,
        name="Upg. Altar of Air",
        cost=Resources(gold=1500, wood=2, mercury=2, gems=2),
        prerequisites=(BuildingId.CONFLUX_ALTAR_OF_AIR,),
        upgrades_creature=CreatureType.STORM_ELEMENTAL,
    ),
    BuildingId.UPG_CONFLUX_ALTAR_OF_WATER: BuildingDef(
        building_id=BuildingId.UPG_CONFLUX_ALTAR_OF_WATER,
        name="Upg. Altar of Water",
        cost=Resources(gold=2000, wood=5, ore=5),
        prerequisites=(BuildingId.CONFLUX_ALTAR_OF_WATER,),
        upgrades_creature=CreatureType.ICE_ELEMENTAL,
    ),
    BuildingId.UPG_CONFLUX_ALTAR_OF_FIRE: BuildingDef(
        building_id=BuildingId.UPG_CONFLUX_ALTAR_OF_FIRE,
        name="Upg. Altar of Fire",
        cost=Resources(gold=2000, wood=5, ore=5),
        prerequisites=(BuildingId.CONFLUX_ALTAR_OF_FIRE,),
        upgrades_creature=CreatureType.ENERGY_ELEMENTAL,
    ),
    BuildingId.UPG_CONFLUX_ALTAR_OF_EARTH: BuildingDef(
        building_id=BuildingId.UPG_CONFLUX_ALTAR_OF_EARTH,
        name="Upg. Altar of Earth",
        cost=Resources(gold=1000, sulfur=5),
        prerequisites=(BuildingId.CONFLUX_ALTAR_OF_EARTH,),
        upgrades_creature=CreatureType.MAGMA_ELEMENTAL,
    ),
    BuildingId.UPG_CONFLUX_ALTAR_OF_THOUGHT: BuildingDef(
        building_id=BuildingId.UPG_CONFLUX_ALTAR_OF_THOUGHT,
        name="Upg. Altar of Thought",
        cost=Resources(gold=3000, mercury=3, sulfur=3, crystal=3, gems=3),
        prerequisites=(BuildingId.CONFLUX_ALTAR_OF_THOUGHT,),
        upgrades_creature=CreatureType.MAGIC_ELEMENTAL,
    ),
    BuildingId.UPG_CONFLUX_PYRE: BuildingDef(
        building_id=BuildingId.UPG_CONFLUX_PYRE,
        name="Upg. Pyre",
        cost=Resources(gold=15000, wood=10, ore=10, mercury=20),
        prerequisites=(BuildingId.CONFLUX_PYRE,),
        upgrades_creature=CreatureType.PHOENIX,
    ),
}

# Reverse lookup: creature type -> building that unlocks it
CREATURE_TO_BUILDING: dict[CreatureType, BuildingId] = {}
for _bdict in (
    CASTLE_BUILDINGS,
    NECROPOLIS_BUILDINGS,
    INFERNO_BUILDINGS,
    DUNGEON_BUILDINGS,
    RAMPART_BUILDINGS,
    TOWER_BUILDINGS,
    STRONGHOLD_BUILDINGS,
    FORTRESS_BUILDINGS,
    CONFLUX_BUILDINGS,
):
    for _bid, _bdef in _bdict.items():
        if _bdef.unlocks_creature is not None:
            CREATURE_TO_BUILDING[_bdef.unlocks_creature] = _bid

# Base creature -> upgraded creature mapping
CREATURE_UPGRADES: dict[CreatureType, CreatureType] = {
    # Castle
    CreatureType.PIKEMAN: CreatureType.HALBERDIER,
    CreatureType.ARCHER: CreatureType.MARKSMAN,
    CreatureType.GRIFFIN: CreatureType.ROYAL_GRIFFIN,
    CreatureType.SWORDSMAN: CreatureType.CRUSADER,
    CreatureType.MONK: CreatureType.ZEALOT,
    CreatureType.CAVALIER: CreatureType.CHAMPION,
    CreatureType.ANGEL: CreatureType.ARCHANGEL,
    # Necropolis
    CreatureType.SKELETON: CreatureType.SKELETON_WARRIOR,
    CreatureType.WALKING_DEAD: CreatureType.ZOMBIE,
    CreatureType.WIGHT: CreatureType.WRAITH,
    CreatureType.VAMPIRE: CreatureType.VAMPIRE_LORD,
    CreatureType.LICH: CreatureType.POWER_LICH,
    CreatureType.BLACK_KNIGHT: CreatureType.DREAD_KNIGHT,
    CreatureType.BONE_DRAGON: CreatureType.GHOST_DRAGON,
    # Inferno
    CreatureType.IMP: CreatureType.FAMILIAR,
    CreatureType.GOG: CreatureType.MAGOG,
    CreatureType.HELL_HOUND: CreatureType.CERBERUS,
    CreatureType.DEMON: CreatureType.HORNED_DEMON,
    CreatureType.PIT_FIEND: CreatureType.PIT_LORD,
    CreatureType.EFREETI: CreatureType.EFREET_SULTAN,
    CreatureType.DEVIL: CreatureType.ARCH_DEVIL,
    # Dungeon
    CreatureType.TROGLODYTE: CreatureType.INFERNAL_TROGLODYTE,
    CreatureType.HARPY: CreatureType.HARPY_HAG,
    CreatureType.BEHOLDER: CreatureType.EVIL_EYE,
    CreatureType.MEDUSA: CreatureType.MEDUSA_QUEEN,
    CreatureType.MINOTAUR: CreatureType.MINOTAUR_KING,
    CreatureType.MANTICORE: CreatureType.SCORPICORE,
    CreatureType.RED_DRAGON: CreatureType.BLACK_DRAGON,
    # Rampart
    CreatureType.CENTAUR: CreatureType.CENTAUR_CAPTAIN,
    CreatureType.DWARF: CreatureType.BATTLE_DWARF,
    CreatureType.WOOD_ELF: CreatureType.GRAND_ELF,
    CreatureType.PEGASUS: CreatureType.SILVER_PEGASUS,
    CreatureType.DENDROID_GUARD: CreatureType.DENDROID_SOLDIER,
    CreatureType.UNICORN: CreatureType.WAR_UNICORN,
    CreatureType.GREEN_DRAGON: CreatureType.GOLD_DRAGON,
    # Tower
    CreatureType.GREMLIN: CreatureType.MASTER_GREMLIN,
    CreatureType.STONE_GARGOYLE: CreatureType.OBSIDIAN_GARGOYLE,
    CreatureType.STONE_GOLEM: CreatureType.IRON_GOLEM,
    CreatureType.MAGE: CreatureType.ARCH_MAGE,
    CreatureType.GENIE: CreatureType.MASTER_GENIE,
    CreatureType.NAGA: CreatureType.NAGA_QUEEN,
    CreatureType.GIANT: CreatureType.TITAN,
    # Stronghold
    CreatureType.GOBLIN: CreatureType.HOBGOBLIN,
    CreatureType.WOLF_RIDER: CreatureType.WOLF_RAIDER,
    CreatureType.ORC: CreatureType.ORC_CHIEFTAIN,
    CreatureType.OGRE: CreatureType.OGRE_MAGE,
    CreatureType.ROC: CreatureType.THUNDERBIRD,
    CreatureType.CYCLOPS: CreatureType.CYCLOPS_KING,
    CreatureType.BEHEMOTH: CreatureType.ANCIENT_BEHEMOTH,
    # Fortress
    CreatureType.GNOLL: CreatureType.GNOLL_MARAUDER,
    CreatureType.LIZARDMAN: CreatureType.LIZARD_WARRIOR,
    CreatureType.SERPENT_FLY: CreatureType.DRAGON_FLY,
    CreatureType.BASILISK: CreatureType.GREATER_BASILISK,
    CreatureType.GORGON: CreatureType.MIGHTY_GORGON,
    CreatureType.WYVERN: CreatureType.WYVERN_MONARCH,
    CreatureType.HYDRA: CreatureType.CHAOS_HYDRA,
    # Conflux
    CreatureType.PIXIE: CreatureType.SPRITE,
    CreatureType.AIR_ELEMENTAL: CreatureType.STORM_ELEMENTAL,
    CreatureType.WATER_ELEMENTAL: CreatureType.ICE_ELEMENTAL,
    CreatureType.FIRE_ELEMENTAL: CreatureType.ENERGY_ELEMENTAL,
    CreatureType.EARTH_ELEMENTAL: CreatureType.MAGMA_ELEMENTAL,
    CreatureType.PSYCHIC_ELEMENTAL: CreatureType.MAGIC_ELEMENTAL,
    CreatureType.FIREBIRD: CreatureType.PHOENIX,
}

# Recruitment cost per unit for upgraded creatures
UPGRADED_RECRUIT_COST: dict[CreatureType, int] = {
    # Castle
    CreatureType.HALBERDIER: 75,
    CreatureType.MARKSMAN: 150,
    CreatureType.ROYAL_GRIFFIN: 240,
    CreatureType.CRUSADER: 400,
    CreatureType.ZEALOT: 450,
    CreatureType.CHAMPION: 1200,
    CreatureType.ARCHANGEL: 5000,
    # Necropolis
    CreatureType.SKELETON_WARRIOR: 70,
    CreatureType.ZOMBIE: 125,
    CreatureType.WRAITH: 230,
    CreatureType.VAMPIRE_LORD: 500,
    CreatureType.POWER_LICH: 600,
    CreatureType.DREAD_KNIGHT: 1000,
    CreatureType.GHOST_DRAGON: 6000,
    # Inferno
    CreatureType.FAMILIAR: 60,
    CreatureType.MAGOG: 175,
    CreatureType.CERBERUS: 250,
    CreatureType.HORNED_DEMON: 270,
    CreatureType.PIT_LORD: 700,
    CreatureType.EFREET_SULTAN: 1100,
    CreatureType.ARCH_DEVIL: 4500,
    # Dungeon
    CreatureType.INFERNAL_TROGLODYTE: 65,
    CreatureType.HARPY_HAG: 170,
    CreatureType.EVIL_EYE: 280,
    CreatureType.MEDUSA_QUEEN: 330,
    CreatureType.MINOTAUR_KING: 575,
    CreatureType.SCORPICORE: 1050,
    CreatureType.BLACK_DRAGON: 8000,
    # Rampart
    CreatureType.CENTAUR_CAPTAIN: 90,
    CreatureType.BATTLE_DWARF: 150,
    CreatureType.GRAND_ELF: 225,
    CreatureType.SILVER_PEGASUS: 275,
    CreatureType.DENDROID_SOLDIER: 425,
    CreatureType.WAR_UNICORN: 950,
    CreatureType.GOLD_DRAGON: 4000,
    # Tower
    CreatureType.MASTER_GREMLIN: 40,
    CreatureType.OBSIDIAN_GARGOYLE: 160,
    CreatureType.IRON_GOLEM: 200,
    CreatureType.ARCH_MAGE: 450,
    CreatureType.MASTER_GENIE: 600,
    CreatureType.NAGA_QUEEN: 1600,
    CreatureType.TITAN: 5000,
    # Stronghold
    CreatureType.HOBGOBLIN: 50,
    CreatureType.WOLF_RAIDER: 140,
    CreatureType.ORC_CHIEFTAIN: 165,
    CreatureType.OGRE_MAGE: 400,
    CreatureType.THUNDERBIRD: 700,
    CreatureType.CYCLOPS_KING: 1100,
    CreatureType.ANCIENT_BEHEMOTH: 3000,
    # Fortress
    CreatureType.GNOLL_MARAUDER: 70,
    CreatureType.LIZARD_WARRIOR: 140,
    CreatureType.DRAGON_FLY: 240,
    CreatureType.GREATER_BASILISK: 400,
    CreatureType.MIGHTY_GORGON: 600,
    CreatureType.WYVERN_MONARCH: 1100,
    CreatureType.CHAOS_HYDRA: 3500,
    # Conflux
    CreatureType.SPRITE: 30,
    CreatureType.STORM_ELEMENTAL: 275,
    CreatureType.ICE_ELEMENTAL: 375,
    CreatureType.ENERGY_ELEMENTAL: 400,
    CreatureType.MAGMA_ELEMENTAL: 500,
    CreatureType.MAGIC_ELEMENTAL: 800,
    CreatureType.PHOENIX: 2000,
}


# --- Faction dispatch ---

# All faction building dicts (populated by faction data modules)
_ALL_FACTION_BUILDINGS: dict = {}


def get_faction_buildings(faction_id) -> dict[BuildingId, BuildingDef]:
    """Return the buildings dict for a given FactionId."""
    if not _ALL_FACTION_BUILDINGS:
        # Lazy-init: import and register all faction building dicts
        _ALL_FACTION_BUILDINGS["CASTLE"] = CASTLE_BUILDINGS
    faction_name = faction_id.name if hasattr(faction_id, "name") else str(faction_id)
    result = _ALL_FACTION_BUILDINGS.get(faction_name, CASTLE_BUILDINGS)
    assert isinstance(result, dict)
    return result


def register_faction_buildings(
    faction_name: str, buildings: dict[BuildingId, BuildingDef]
):
    """Register a faction's building definitions."""
    _ALL_FACTION_BUILDINGS[faction_name] = buildings


register_faction_buildings("NECROPOLIS", NECROPOLIS_BUILDINGS)
register_faction_buildings("INFERNO", INFERNO_BUILDINGS)
register_faction_buildings("DUNGEON", DUNGEON_BUILDINGS)
register_faction_buildings("RAMPART", RAMPART_BUILDINGS)
register_faction_buildings("TOWER", TOWER_BUILDINGS)
register_faction_buildings("STRONGHOLD", STRONGHOLD_BUILDINGS)
register_faction_buildings("FORTRESS", FORTRESS_BUILDINGS)
register_faction_buildings("CONFLUX", CONFLUX_BUILDINGS)
