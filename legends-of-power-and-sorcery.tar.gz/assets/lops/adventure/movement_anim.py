"""Movement animation state — pure game logic, no pygame imports."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto

from lops.hex import CubeCoord


class AnimSpeed(Enum):
    NORMAL = auto()  # 200 px/s
    FAST = auto()  # 400 px/s
    INSTANT = auto()  # skip animation


_SPEED_PX_PER_SEC = {
    AnimSpeed.NORMAL: 200.0,
    AnimSpeed.FAST: 400.0,
}

SPEED_LABELS = {
    AnimSpeed.NORMAL: "1x",
    AnimSpeed.FAST: "2x",
    AnimSpeed.INSTANT: ">>",
}

_CYCLE_ORDER = [AnimSpeed.NORMAL, AnimSpeed.FAST, AnimSpeed.INSTANT]


@dataclass
class MovementAnimation:
    """Tracks one hero moving along a hex path."""

    hero_state: object  # HeroState — avoid circular import
    player: object  # PlayerState
    hex_path: list[CubeCoord]
    pixel_path: list[tuple[float, float]]
    pending_event: str | None
    current_step: int = 0
    step_progress: float = 0.0  # 0..1 within current step
    finished: bool = False

    @property
    def current_world_pos(self) -> tuple[float, float]:
        """Interpolated world-pixel position between current step and next."""
        if self.finished or self.current_step >= len(self.pixel_path) - 1:
            return self.pixel_path[-1] if self.pixel_path else (0.0, 0.0)
        ax, ay = self.pixel_path[self.current_step]
        bx, by = self.pixel_path[self.current_step + 1]
        t = self.step_progress
        return (ax + (bx - ax) * t, ay + (by - ay) * t)

    @property
    def destination(self) -> CubeCoord:
        return self.hex_path[-1]


class AdventureAnimState:
    """Manages adventure map movement animation."""

    def __init__(self):
        self.speed: AnimSpeed = AnimSpeed.NORMAL
        self.active: MovementAnimation | None = None

    @property
    def is_animating(self) -> bool:
        return self.active is not None and not self.active.finished

    def start_move(
        self,
        hero_state: object,
        player: object,
        hex_path: list[CubeCoord],
        pixel_path: list[tuple[float, float]],
        pending_event: str | None,
    ):
        """Begin animating a hero along a path."""
        self.active = MovementAnimation(
            hero_state=hero_state,
            player=player,
            hex_path=hex_path,
            pixel_path=pixel_path,
            pending_event=pending_event,
        )

    def update(self, dt: float) -> CubeCoord | None:
        """Advance the animation by dt seconds.

        Returns the CubeCoord of a newly entered hex (for fog reveal), or None.
        """
        anim = self.active
        if anim is None or anim.finished:
            return None

        px_per_sec = _SPEED_PX_PER_SEC.get(self.speed, 200.0)
        if len(anim.pixel_path) < 2:
            anim.finished = True
            return None

        # Distance for current step
        ax, ay = anim.pixel_path[anim.current_step]
        bx, by = anim.pixel_path[anim.current_step + 1]
        step_dist = ((bx - ax) ** 2 + (by - ay) ** 2) ** 0.5
        if step_dist < 0.1:
            step_dist = 0.1

        # Advance progress
        anim.step_progress += (px_per_sec * dt) / step_dist
        entered_hex: CubeCoord | None = None

        while anim.step_progress >= 1.0:
            anim.step_progress -= 1.0
            anim.current_step += 1
            if anim.current_step >= len(anim.pixel_path) - 1:
                anim.finished = True
                anim.step_progress = 0.0
                # Return the final hex
                return anim.hex_path[-1]
            entered_hex = anim.hex_path[anim.current_step]
            # Recompute step distance for next segment
            ax, ay = anim.pixel_path[anim.current_step]
            bx, by = anim.pixel_path[anim.current_step + 1]
            step_dist = ((bx - ax) ** 2 + (by - ay) ** 2) ** 0.5
            if step_dist < 0.1:
                step_dist = 0.1

        return entered_hex

    def cycle_speed(self):
        """NORMAL -> FAST -> INSTANT -> NORMAL."""
        idx = _CYCLE_ORDER.index(self.speed)
        self.speed = _CYCLE_ORDER[(idx + 1) % len(_CYCLE_ORDER)]

    def finish_immediately(self):
        """Jump to end of current animation."""
        if self.active is not None:
            self.active.finished = True
            self.active.step_progress = 0.0
            self.active.current_step = len(self.active.pixel_path) - 1

    def clear(self):
        """Remove the current animation."""
        self.active = None
