"""Town: dwellings, buildings, recruitment, weekly growth."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum, auto

from lops.adventure.buildings import (
    CREATURE_UPGRADES,
    UPGRADED_RECRUIT_COST,
    BuildingId,
)
from lops.adventure.resources import Resources
from lops.data.creatures import CREATURE_REGISTRY, CreatureType, make_stack
from lops.models import CreatureStack


class FactionId(Enum):
    """Town faction types."""

    CASTLE = auto()
    NECROPOLIS = auto()
    INFERNO = auto()
    DUNGEON = auto()
    RAMPART = auto()
    TOWER = auto()
    STRONGHOLD = auto()
    FORTRESS = auto()
    CONFLUX = auto()


@dataclass
class DwellingSlot:
    """A dwelling that produces creatures each week."""

    creature_type: CreatureType
    growth_per_week: int
    cost_per_unit: int
    available: int = 0  # creatures available to recruit
    built: bool = False  # must be built before producing/recruiting
    upgraded: bool = False  # dwelling upgraded to produce stronger creature

    @property
    def active_creature_type(self) -> CreatureType:
        """The creature type currently produced (upgraded if available)."""
        if self.upgraded:
            return CREATURE_UPGRADES.get(self.creature_type, self.creature_type)
        return self.creature_type

    @property
    def active_cost_per_unit(self) -> int:
        """Recruitment cost per unit (upgraded cost if upgraded)."""
        if self.upgraded:
            upgraded_ct = CREATURE_UPGRADES.get(self.creature_type)
            if upgraded_ct:
                return UPGRADED_RECRUIT_COST.get(upgraded_ct, self.cost_per_unit)
        return self.cost_per_unit

    @property
    def creature_name(self) -> str:
        return CREATURE_REGISTRY[self.active_creature_type].name


# Castle faction dwelling configuration
CASTLE_DWELLINGS: list[tuple[CreatureType, int, int]] = [
    (CreatureType.PIKEMAN, 14, 60),
    (CreatureType.ARCHER, 9, 100),
    (CreatureType.GRIFFIN, 7, 200),
    (CreatureType.SWORDSMAN, 4, 300),
    (CreatureType.MONK, 3, 400),
    (CreatureType.CAVALIER, 2, 1000),
    (CreatureType.ANGEL, 1, 3000),
]

# Necropolis dwelling configuration
NECROPOLIS_DWELLINGS: list[tuple[CreatureType, int, int]] = [
    (CreatureType.SKELETON, 12, 60),
    (CreatureType.WALKING_DEAD, 8, 100),
    (CreatureType.WIGHT, 7, 200),
    (CreatureType.VAMPIRE, 4, 360),
    (CreatureType.LICH, 3, 550),
    (CreatureType.BLACK_KNIGHT, 2, 850),
    (CreatureType.BONE_DRAGON, 1, 1800),
]

# Inferno dwelling configuration
INFERNO_DWELLINGS: list[tuple[CreatureType, int, int]] = [
    (CreatureType.IMP, 15, 50),
    (CreatureType.GOG, 8, 125),
    (CreatureType.HELL_HOUND, 5, 200),
    (CreatureType.DEMON, 4, 250),
    (CreatureType.PIT_FIEND, 3, 500),
    (CreatureType.EFREETI, 2, 900),
    (CreatureType.DEVIL, 1, 2700),
]

# Dungeon dwelling configuration
DUNGEON_DWELLINGS: list[tuple[CreatureType, int, int]] = [
    (CreatureType.TROGLODYTE, 14, 50),
    (CreatureType.HARPY, 8, 130),
    (CreatureType.BEHOLDER, 7, 250),
    (CreatureType.MEDUSA, 4, 300),
    (CreatureType.MINOTAUR, 3, 500),
    (CreatureType.MANTICORE, 2, 850),
    (CreatureType.RED_DRAGON, 1, 2500),
]

# Rampart dwelling configuration
RAMPART_DWELLINGS: list[tuple[CreatureType, int, int]] = [
    (CreatureType.CENTAUR, 14, 70),
    (CreatureType.DWARF, 8, 120),
    (CreatureType.WOOD_ELF, 7, 200),
    (CreatureType.PEGASUS, 5, 250),
    (CreatureType.DENDROID_GUARD, 3, 350),
    (CreatureType.UNICORN, 2, 850),
    (CreatureType.GREEN_DRAGON, 1, 2400),
]

# Tower dwelling configuration
TOWER_DWELLINGS: list[tuple[CreatureType, int, int]] = [
    (CreatureType.GREMLIN, 16, 30),
    (CreatureType.STONE_GARGOYLE, 9, 130),
    (CreatureType.STONE_GOLEM, 6, 150),
    (CreatureType.MAGE, 4, 350),
    (CreatureType.GENIE, 3, 550),
    (CreatureType.NAGA, 2, 1100),
    (CreatureType.GIANT, 1, 2000),
]

# Stronghold dwelling configuration
STRONGHOLD_DWELLINGS: list[tuple[CreatureType, int, int]] = [
    (CreatureType.GOBLIN, 15, 40),
    (CreatureType.WOLF_RIDER, 9, 100),
    (CreatureType.ORC, 7, 150),
    (CreatureType.OGRE, 4, 300),
    (CreatureType.ROC, 3, 600),
    (CreatureType.CYCLOPS, 2, 750),
    (CreatureType.BEHEMOTH, 1, 1500),
]

# Fortress dwelling configuration
FORTRESS_DWELLINGS: list[tuple[CreatureType, int, int]] = [
    (CreatureType.GNOLL, 12, 50),
    (CreatureType.LIZARDMAN, 9, 110),
    (CreatureType.SERPENT_FLY, 8, 220),
    (CreatureType.BASILISK, 4, 325),
    (CreatureType.GORGON, 3, 525),
    (CreatureType.WYVERN, 2, 800),
    (CreatureType.HYDRA, 1, 2200),
]

# Conflux dwelling configuration
CONFLUX_DWELLINGS: list[tuple[CreatureType, int, int]] = [
    (CreatureType.PIXIE, 20, 25),
    (CreatureType.AIR_ELEMENTAL, 6, 250),
    (CreatureType.WATER_ELEMENTAL, 6, 300),
    (CreatureType.FIRE_ELEMENTAL, 4, 350),
    (CreatureType.EARTH_ELEMENTAL, 4, 400),
    (CreatureType.PSYCHIC_ELEMENTAL, 2, 750),
    (CreatureType.FIREBIRD, 2, 1500),
]


@dataclass
class Town:
    """A town with dwellings for recruitment and buildings."""

    name: str
    faction_id: FactionId = FactionId.CASTLE
    owner_id: int | None = None
    dwellings: list[DwellingSlot] = field(default_factory=list)
    garrison: list[CreatureStack] = field(default_factory=list)
    buildings: set[BuildingId] = field(default_factory=set)
    tavern_heroes: list = field(default_factory=list)  # list[HeroDef] available to hire
    merchant_artifacts: list = field(default_factory=list)  # list[ArtifactId] for sale
    guild_spells: dict = field(default_factory=dict)  # level -> list[SpellId]

    def _get_buildings_dict(self) -> dict:
        """Get the buildings definition dict for this town's faction."""
        from lops.adventure.buildings import get_faction_buildings

        return get_faction_buildings(self.faction_id)

    def refresh_merchant(self):
        """Refresh artifact merchant with 3 random artifacts for sale."""
        import random

        from lops.artifacts import ArtifactClass
        from lops.data.artifacts import ARTIFACTS_BY_CLASS

        if BuildingId.ARTIFACT_MERCHANT not in self.buildings:
            return
        pool = (
            ARTIFACTS_BY_CLASS[ArtifactClass.TREASURE]
            + ARTIFACTS_BY_CLASS[ArtifactClass.MINOR]
        )
        self.merchant_artifacts = random.sample(pool, min(3, len(pool)))

    def refresh_tavern(self, used_hero_names: set[str] | None = None):
        """Refresh tavern with 2 random available heroes."""
        import random

        from lops.data.heroes import get_faction_heroes

        if used_hero_names is None:
            used_hero_names = set()
        heroes = get_faction_heroes(self.faction_id)
        available = [h for h in heroes if h.name not in used_hero_names]
        self.tavern_heroes = random.sample(available, min(2, len(available)))

    def apply_weekly_growth(self):
        """Add weekly growth to built dwellings, applying fortification bonus."""
        mult = self.growth_multiplier()
        for dwelling in self.dwellings:
            if dwelling.built:
                growth = int(math.floor(dwelling.growth_per_week * mult))
                dwelling.available += growth

    def growth_multiplier(self) -> float:
        """Total growth multiplier from fortification buildings."""
        bdict = self._get_buildings_dict()
        bonus = 0.0
        for bid in self.buildings:
            bdef = bdict.get(bid)
            if bdef and bdef.growth_bonus > 0:
                bonus += bdef.growth_bonus
        return 1.0 + bonus

    def daily_gold_income(self) -> int:
        """Daily gold income from the highest town hall building."""
        bdict = self._get_buildings_dict()
        best = 0
        for bid in self.buildings:
            bdef = bdict.get(bid)
            if bdef and bdef.daily_gold > 0:
                best = max(best, bdef.daily_gold)
        return best

    def silo_daily_income(self) -> Resources:
        """Daily resource income from the Resource Silo, based on faction."""
        if BuildingId.RESOURCE_SILO not in self.buildings:
            return Resources()
        if self.faction_id in (FactionId.CASTLE, FactionId.NECROPOLIS):
            return Resources(wood=1, ore=1)
        elif self.faction_id == FactionId.INFERNO:
            return Resources(mercury=1)
        elif self.faction_id == FactionId.DUNGEON:
            return Resources(sulfur=1)
        elif self.faction_id == FactionId.RAMPART:
            return Resources(crystal=1)
        elif self.faction_id == FactionId.TOWER:
            return Resources(gems=1)
        elif self.faction_id in (FactionId.STRONGHOLD, FactionId.FORTRESS):
            return Resources(wood=1, ore=1)
        elif self.faction_id == FactionId.CONFLUX:
            return Resources(mercury=1)
        return Resources()

    def can_build(self, building_id: BuildingId, player_resources: Resources) -> bool:
        """Check if a building can be constructed."""
        if building_id in self.buildings:
            return False
        bdict = self._get_buildings_dict()
        bdef = bdict.get(building_id)
        if bdef is None:
            return False
        for prereq in bdef.prerequisites:
            if prereq not in self.buildings:
                return False
        return player_resources.can_afford(bdef.cost)

    def build(
        self, building_id: BuildingId, player_resources: Resources
    ) -> Resources | None:
        """Build a structure. Returns remaining resources or None if can't build."""
        if not self.can_build(building_id, player_resources):
            return None
        bdict = self._get_buildings_dict()
        bdef = bdict[building_id]
        self.buildings.add(building_id)

        # If this building unlocks a dwelling, mark it as built
        if bdef.unlocks_creature is not None:
            for dwelling in self.dwellings:
                if dwelling.creature_type == bdef.unlocks_creature:
                    dwelling.built = True
                    # Give initial availability if it was 0
                    if dwelling.available == 0:
                        dwelling.available = dwelling.growth_per_week
                    break

        # If this building upgrades a dwelling, mark it as upgraded
        if bdef.upgrades_creature is not None:
            # Find the base creature type for this upgrade
            for base_ct, upg_ct in CREATURE_UPGRADES.items():
                if upg_ct == bdef.upgrades_creature:
                    for dwelling in self.dwellings:
                        if dwelling.creature_type == base_ct:
                            dwelling.upgraded = True
                            break
                    break

        return player_resources.subtract(bdef.cost)

    def buildable_buildings(self, player_resources: Resources) -> list[BuildingId]:
        """Return list of buildings that can currently be constructed."""
        bdict = self._get_buildings_dict()
        return [bid for bid in bdict if self.can_build(bid, player_resources)]

    def mage_guild_level(self) -> int:
        """Return the highest mage guild level built (0 if none)."""
        level = 0
        guild_buildings = {
            BuildingId.MAGE_GUILD_1: 1,
            BuildingId.MAGE_GUILD_2: 2,
            BuildingId.MAGE_GUILD_3: 3,
            BuildingId.MAGE_GUILD_4: 4,
            BuildingId.MAGE_GUILD_5: 5,
        }
        for bid in self.buildings:
            if bid in guild_buildings:
                level = max(level, guild_buildings[bid])
        return level

    def populate_guild_level(self, level: int):
        """Randomly select 3-5 spells for a guild level (if not already populated)."""
        import random

        if level in self.guild_spells:
            return  # already populated
        from lops.data.spells import SPELLS_BY_LEVEL

        available = SPELLS_BY_LEVEL.get(level, [])
        if not available:
            return
        count = min(len(available), random.randint(3, 5))
        self.guild_spells[level] = random.sample(available, count)

    def available_spells_for_hero(self, hero) -> list:
        """Return all guild spells this hero can learn (respects Wisdom skill).

        No Wisdom: levels 1-2
        Basic Wisdom: levels 1-3
        Advanced: levels 1-4
        Expert: levels 1-5
        """
        from lops.skills import SkillId

        wisdom_level = hero.skill_level(SkillId.WISDOM)
        max_level = 2 + wisdom_level  # 0->2, 1->3, 2->4, 3->5
        max_level = min(max_level, self.mage_guild_level())

        spells = []
        for level in range(1, max_level + 1):
            spells.extend(self.guild_spells.get(level, []))
        return spells

    def hero_learn_spells(self, hero):
        """Hero learns all available guild spells they don't already know."""
        available = self.available_spells_for_hero(hero)
        known = set(hero.spells)
        for spell_id in available:
            if spell_id not in known:
                hero.spells.append(spell_id)
                known.add(spell_id)

    def recruit(
        self, dwelling_index: int, count: int, player_resources: Resources
    ) -> tuple[CreatureStack | None, int]:
        """Recruit creatures from a dwelling.

        Returns (new_stack_or_None, gold_spent).
        Only built dwellings allow recruitment.
        """
        if dwelling_index < 0 or dwelling_index >= len(self.dwellings):
            return None, 0

        dwelling = self.dwellings[dwelling_index]
        if not dwelling.built:
            return None, 0
        if count <= 0 or dwelling.available <= 0:
            return None, 0

        # Limit by availability and gold
        unit_cost = dwelling.active_cost_per_unit
        count = min(count, dwelling.available)
        max_affordable = player_resources.gold // unit_cost
        count = min(count, max_affordable)

        if count <= 0:
            return None, 0

        gold_spent = count * unit_cost
        dwelling.available -= count

        stack = make_stack(dwelling.active_creature_type, count)
        return stack, gold_spent


# Per-faction dwelling configurations: (creature_type, growth_per_week, cost_per_unit)
FACTION_DWELLINGS: dict[FactionId, list[tuple[CreatureType, int, int]]] = {
    FactionId.CASTLE: CASTLE_DWELLINGS,
    FactionId.NECROPOLIS: NECROPOLIS_DWELLINGS,
    FactionId.INFERNO: INFERNO_DWELLINGS,
    FactionId.DUNGEON: DUNGEON_DWELLINGS,
    FactionId.RAMPART: RAMPART_DWELLINGS,
    FactionId.TOWER: TOWER_DWELLINGS,
    FactionId.STRONGHOLD: STRONGHOLD_DWELLINGS,
    FactionId.FORTRESS: FORTRESS_DWELLINGS,
    FactionId.CONFLUX: CONFLUX_DWELLINGS,
}

# Shared infrastructure buildings every starter town gets
_SHARED_STARTER = {
    BuildingId.VILLAGE_HALL,
    BuildingId.TAVERN,
    BuildingId.FORT,
    BuildingId.BLACKSMITH,
    BuildingId.MARKETPLACE,
    BuildingId.MAGE_GUILD_1,
}

_FACTION_STARTER_BUILDINGS: dict[FactionId, set[BuildingId]] = {
    FactionId.CASTLE: _SHARED_STARTER
    | {
        BuildingId.STABLES,
        BuildingId.GUARDHOUSE,
        BuildingId.ARCHERS_TOWER,
        BuildingId.BARRACKS,
        BuildingId.GRIFFIN_TOWER,
        BuildingId.MONASTERY,
        BuildingId.TRAINING_GROUNDS,
        BuildingId.PORTAL_OF_GLORY,
    },
    FactionId.NECROPOLIS: _SHARED_STARTER
    | {
        BuildingId.NECRO_CURSED_TEMPLE,
        BuildingId.NECRO_GRAVEYARD,
        BuildingId.NECRO_TOMB_OF_SOULS,
        BuildingId.NECRO_ESTATE,
        BuildingId.NECRO_MAUSOLEUM,
        BuildingId.NECRO_HALL_OF_DARKNESS,
        BuildingId.NECRO_DRAGON_VAULT,
    },
    FactionId.INFERNO: _SHARED_STARTER
    | {
        BuildingId.INFERNO_IMP_CRUCIBLE,
        BuildingId.INFERNO_HALL_OF_SINS,
        BuildingId.INFERNO_KENNELS,
        BuildingId.INFERNO_DEMON_GATE,
        BuildingId.INFERNO_HELL_HOLE,
        BuildingId.INFERNO_FIRE_LAKE,
        BuildingId.INFERNO_FORSAKEN_PALACE,
    },
    FactionId.DUNGEON: _SHARED_STARTER
    | {
        BuildingId.DUNGEON_WARREN,
        BuildingId.DUNGEON_HARPY_LOFT,
        BuildingId.DUNGEON_PILLAR_OF_EYES,
        BuildingId.DUNGEON_CHAPEL_OF_STILLED_VOICES,
        BuildingId.DUNGEON_LABYRINTH,
        BuildingId.DUNGEON_MANTICORE_LAIR,
        BuildingId.DUNGEON_DRAGON_CAVE,
    },
    FactionId.RAMPART: _SHARED_STARTER
    | {
        BuildingId.RAMPART_CENTAUR_STABLES,
        BuildingId.RAMPART_DWARF_COTTAGE,
        BuildingId.RAMPART_HOMESTEAD,
        BuildingId.RAMPART_ENCHANTED_SPRING,
        BuildingId.RAMPART_DENDROID_ARCHES,
        BuildingId.RAMPART_UNICORN_GLADE,
        BuildingId.RAMPART_DRAGON_CLIFFS,
    },
    FactionId.TOWER: _SHARED_STARTER
    | {
        BuildingId.TOWER_WORKSHOP,
        BuildingId.TOWER_PARAPET,
        BuildingId.TOWER_GOLEM_FACTORY,
        BuildingId.TOWER_MAGE_TOWER,
        BuildingId.TOWER_ALTAR_OF_WISHES,
        BuildingId.TOWER_GOLDEN_PAVILION,
        BuildingId.TOWER_CLOUD_TEMPLE,
    },
    FactionId.STRONGHOLD: _SHARED_STARTER
    | {
        BuildingId.STRONGHOLD_GOBLIN_BARRACKS,
        BuildingId.STRONGHOLD_WOLF_PEN,
        BuildingId.STRONGHOLD_ORC_TOWER,
        BuildingId.STRONGHOLD_OGRE_FORT,
        BuildingId.STRONGHOLD_CLIFF_NEST,
        BuildingId.STRONGHOLD_CYCLOPS_CAVE,
        BuildingId.STRONGHOLD_BEHEMOTH_LAIR,
    },
    FactionId.FORTRESS: _SHARED_STARTER
    | {
        BuildingId.FORTRESS_GNOLL_HUT,
        BuildingId.FORTRESS_LIZARD_DEN,
        BuildingId.FORTRESS_SERPENT_FLY_HIVE,
        BuildingId.FORTRESS_BASILISK_PIT,
        BuildingId.FORTRESS_GORGON_LAIR,
        BuildingId.FORTRESS_WYVERN_NEST,
        BuildingId.FORTRESS_HYDRA_POND,
    },
    FactionId.CONFLUX: _SHARED_STARTER
    | {
        BuildingId.CONFLUX_MAGIC_LANTERN,
        BuildingId.CONFLUX_ALTAR_OF_AIR,
        BuildingId.CONFLUX_ALTAR_OF_WATER,
        BuildingId.CONFLUX_ALTAR_OF_FIRE,
        BuildingId.CONFLUX_ALTAR_OF_EARTH,
        BuildingId.CONFLUX_ALTAR_OF_THOUGHT,
        BuildingId.CONFLUX_PYRE,
    },
}


def register_faction_dwellings(
    faction_id: FactionId,
    dwellings: list[tuple[CreatureType, int, int]],
    starter_buildings: set[BuildingId],
):
    """Register a new faction's dwelling config and starter buildings."""
    FACTION_DWELLINGS[faction_id] = dwellings
    _FACTION_STARTER_BUILDINGS[faction_id] = starter_buildings


def create_town(
    faction_id: FactionId, name: str, owner_id: int | None = None, starter: bool = False
) -> Town:
    """Create a town of the given faction.

    If starter=True, all dwellings are pre-built with Fort, Village Hall, etc.
    """
    dwelling_config = FACTION_DWELLINGS.get(faction_id, CASTLE_DWELLINGS)
    dwellings = [
        DwellingSlot(
            creature_type=ct,
            growth_per_week=growth,
            cost_per_unit=cost,
            available=growth if starter else 0,
            built=starter,
        )
        for ct, growth, cost in dwelling_config
    ]

    buildings: set[BuildingId] = set()
    if starter:
        buildings = set(_FACTION_STARTER_BUILDINGS.get(faction_id, set()))

    town = Town(
        name=name,
        faction_id=faction_id,
        owner_id=owner_id,
        dwellings=dwellings,
        buildings=buildings,
    )

    if starter:
        town.populate_guild_level(1)

    return town


def create_castle_town(
    name: str, owner_id: int | None = None, starter: bool = False
) -> Town:
    """Create a Castle-faction town. Backwards-compatible wrapper."""
    return create_town(FactionId.CASTLE, name, owner_id, starter)
