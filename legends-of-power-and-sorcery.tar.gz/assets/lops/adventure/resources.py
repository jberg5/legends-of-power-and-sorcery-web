"""Resource system: 7 resource types with arithmetic operations."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto


class ResourceType(Enum):
    GOLD = auto()
    WOOD = auto()
    ORE = auto()
    MERCURY = auto()
    SULFUR = auto()
    CRYSTAL = auto()
    GEMS = auto()


@dataclass
class Resources:
    """Container for all 7 resource types with arithmetic helpers."""

    gold: int = 0
    wood: int = 0
    ore: int = 0
    mercury: int = 0
    sulfur: int = 0
    crystal: int = 0
    gems: int = 0

    def can_afford(self, cost: Resources) -> bool:
        return (
            self.gold >= cost.gold
            and self.wood >= cost.wood
            and self.ore >= cost.ore
            and self.mercury >= cost.mercury
            and self.sulfur >= cost.sulfur
            and self.crystal >= cost.crystal
            and self.gems >= cost.gems
        )

    def subtract(self, cost: Resources) -> Resources:
        """Return new Resources with cost subtracted."""
        return Resources(
            gold=self.gold - cost.gold,
            wood=self.wood - cost.wood,
            ore=self.ore - cost.ore,
            mercury=self.mercury - cost.mercury,
            sulfur=self.sulfur - cost.sulfur,
            crystal=self.crystal - cost.crystal,
            gems=self.gems - cost.gems,
        )

    def add(self, other: Resources) -> Resources:
        """Return new Resources with other added."""
        return Resources(
            gold=self.gold + other.gold,
            wood=self.wood + other.wood,
            ore=self.ore + other.ore,
            mercury=self.mercury + other.mercury,
            sulfur=self.sulfur + other.sulfur,
            crystal=self.crystal + other.crystal,
            gems=self.gems + other.gems,
        )

    def subtract_in_place(self, cost: Resources):
        """Mutate self by subtracting cost."""
        self.gold -= cost.gold
        self.wood -= cost.wood
        self.ore -= cost.ore
        self.mercury -= cost.mercury
        self.sulfur -= cost.sulfur
        self.crystal -= cost.crystal
        self.gems -= cost.gems

    def add_in_place(self, other: Resources):
        """Mutate self by adding other."""
        self.gold += other.gold
        self.wood += other.wood
        self.ore += other.ore
        self.mercury += other.mercury
        self.sulfur += other.sulfur
        self.crystal += other.crystal
        self.gems += other.gems

    def as_dict(self) -> dict[ResourceType, int]:
        return {
            ResourceType.GOLD: self.gold,
            ResourceType.WOOD: self.wood,
            ResourceType.ORE: self.ore,
            ResourceType.MERCURY: self.mercury,
            ResourceType.SULFUR: self.sulfur,
            ResourceType.CRYSTAL: self.crystal,
            ResourceType.GEMS: self.gems,
        }


def starting_resources() -> Resources:
    """Default starting resources for a new player."""
    return Resources(gold=2500, wood=5, ore=5)
