"""Hero movement on the adventure map: Dijkstra range and A* pathfinding."""

from __future__ import annotations

import heapq

from lops.adventure.world_map import WorldMap
from lops.data.terrain import TERRAIN_COST
from lops.hex import CubeCoord, cube_distance


def _effective_cost(base_cost: int, pathfinding_reduction: float) -> int:
    """Apply Pathfinding skill to terrain cost. Only reduces the penalty above 100."""
    if pathfinding_reduction <= 0 or base_cost <= 100:
        return base_cost
    penalty = base_cost - 100
    return 100 + int(penalty * (1.0 - pathfinding_reduction))


def movement_range(
    position: CubeCoord,
    movement_points: int,
    world_map: WorldMap,
    blocked: set[CubeCoord] | None = None,
    pathfinding_reduction: float = 0.0,
) -> dict[CubeCoord, int]:
    """Dijkstra from position, returning {reachable_hex: cost} within movement_points.

    blocked: set of hexes that can't be entered (e.g. other heroes).
    pathfinding_reduction: 0.0-0.75, reduces terrain penalty above base cost.
    """
    if blocked is None:
        blocked = set()

    costs: dict[CubeCoord, int] = {position: 0}
    counter = 0
    heap = [(0, counter, position)]  # (cost, tiebreaker, pos)

    while heap:
        cost, _, current = heapq.heappop(heap)

        if cost > costs.get(current, float("inf")):
            continue

        for neighbor in world_map.neighbors(current):
            if neighbor in blocked:
                continue
            if not world_map.is_passable(neighbor):
                continue

            tile = world_map.get_tile(neighbor)
            if tile is None:
                continue
            move_cost = TERRAIN_COST.get(tile.terrain, 100)
            if move_cost < 0:
                continue  # impassable

            move_cost = _effective_cost(move_cost, pathfinding_reduction)

            new_cost = cost + move_cost
            if new_cost > movement_points:
                continue
            if new_cost < costs.get(neighbor, float("inf")):
                costs[neighbor] = new_cost
                counter += 1
                heapq.heappush(heap, (new_cost, counter, neighbor))

    # Remove starting position from results
    costs.pop(position, None)
    return costs


def find_path(
    start: CubeCoord,
    goal: CubeCoord,
    world_map: WorldMap,
    blocked: set[CubeCoord] | None = None,
    pathfinding_reduction: float = 0.0,
) -> list[CubeCoord] | None:
    """A* pathfinding on the adventure map. Returns path [start, ..., goal] or None."""
    if blocked is None:
        blocked = set()

    if start == goal:
        return [start]

    counter = 0
    open_set = [(0, counter, start)]
    came_from: dict[CubeCoord, CubeCoord] = {}
    g_score: dict[CubeCoord, int] = {start: 0}

    while open_set:
        _, _, current = heapq.heappop(open_set)

        if current == goal:
            # Reconstruct path
            path = [current]
            while current in came_from:
                current = came_from[current]
                path.append(current)
            path.reverse()
            return path

        for neighbor in world_map.neighbors(current):
            if neighbor in blocked and neighbor != goal:
                continue
            if not world_map.is_passable(neighbor):
                continue

            tile = world_map.get_tile(neighbor)
            if tile is None:
                continue
            move_cost = TERRAIN_COST.get(tile.terrain, 100)
            if move_cost < 0:
                continue

            move_cost = _effective_cost(move_cost, pathfinding_reduction)

            tentative_g = g_score[current] + move_cost
            if tentative_g < g_score.get(neighbor, float("inf")):
                came_from[neighbor] = current
                g_score[neighbor] = tentative_g
                f = (
                    tentative_g + cube_distance(neighbor, goal) * 65
                )  # heuristic: min cost per hex
                counter += 1
                heapq.heappush(open_set, (f, counter, neighbor))

    return None


def path_cost(
    path: list[CubeCoord],
    world_map: WorldMap,
    pathfinding_reduction: float = 0.0,
) -> int:
    """Calculate the total movement cost of a path."""
    if not path or len(path) < 2:
        return 0
    total = 0
    for i in range(1, len(path)):
        tile = world_map.get_tile(path[i])
        if tile:
            cost = TERRAIN_COST.get(tile.terrain, 100)
            total += _effective_cost(cost, pathfinding_reduction)
    return total
