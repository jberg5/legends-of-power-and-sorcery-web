"""LayeredMap: wraps surface + underground WorldMap instances with gate connections."""

from __future__ import annotations

from dataclasses import dataclass, field

from lops.adventure.world_map import WorldMap
from lops.hex import CubeCoord


@dataclass
class GatePair:
    """A pair of subterranean gates linking surface and underground."""

    surface_pos: CubeCoord
    underground_pos: CubeCoord
    pair_id: int = 0


class LayeredMap:
    """Two-layer map: surface (0) and underground (1), connected by gate pairs."""

    def __init__(
        self,
        surface: WorldMap,
        underground: WorldMap,
        gates: list[GatePair] | None = None,
    ):
        self.maps: dict[int, WorldMap] = {0: surface, 1: underground}
        self.gates: list[GatePair] = gates or []

    @property
    def surface(self) -> WorldMap:
        return self.maps[0]

    @property
    def underground(self) -> WorldMap:
        return self.maps[1]

    def get_map(self, layer: int) -> WorldMap:
        return self.maps[layer]

    def gate_destination(
        self, pos: CubeCoord, layer: int
    ) -> tuple[CubeCoord, int] | None:
        """Given a gate position and layer, return the destination (pos, layer).

        Returns None if no gate exists at this position/layer.
        """
        for gate in self.gates:
            if layer == 0 and gate.surface_pos == pos:
                return (gate.underground_pos, 1)
            elif layer == 1 and gate.underground_pos == pos:
                return (gate.surface_pos, 0)
        return None
