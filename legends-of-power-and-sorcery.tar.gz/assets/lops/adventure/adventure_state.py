"""Adventure state: players, heroes, turns, day system."""

from __future__ import annotations

from dataclasses import dataclass, field

from lops.adventure.resources import Resources, starting_resources
from lops.hex import CubeCoord, hexes_in_radius
from lops.models import CreatureStack, Hero

DEFAULT_MOVEMENT_POINTS = 1500
DEFAULT_STARTING_GOLD = 2500
HERO_VISION_RADIUS = 5
MAX_HEROES_PER_PLAYER = 5

# HoMM3 base movement points by slowest creature speed
# Source: https://heroes.thelazy.net/index.php/Movement
_SPEED_TO_MOVEMENT: list[tuple[int, int]] = [
    (0, 1300),
    (1, 1360),
    (2, 1430),
    (3, 1500),
    (4, 1560),
    (5, 1630),
    (6, 1700),
    (7, 1760),
    (8, 1830),
    (9, 1900),
    (10, 1960),
]
_MAX_SPEED_MOVEMENT = 2000  # speed 11+


def base_movement_points(army: list["CreatureStack"]) -> int:
    """Calculate base movement points from the slowest creature in the army.

    If the army is empty, returns DEFAULT_MOVEMENT_POINTS.
    """
    alive = [s for s in army if s.count > 0]
    if not alive:
        return DEFAULT_MOVEMENT_POINTS
    slowest_speed = min(s.stats.speed for s in alive)
    for speed, points in _SPEED_TO_MOVEMENT:
        if slowest_speed <= speed:
            return points
    return _MAX_SPEED_MOVEMENT


def effective_movement_points(hero: "Hero", army: list["CreatureStack"]) -> int:
    """Calculate movement points including Logistics skill and artifact bonuses."""
    from lops.skills import SkillId

    base = base_movement_points(army)
    logistics = hero.skill_value(SkillId.LOGISTICS)
    if logistics > 0:
        base = int(base * (1.0 + logistics))
    base += hero.artifact_movement_bonus()
    return base


@dataclass
class HeroState:
    """State for a single hero on the adventure map."""

    hero: Hero
    army: list[CreatureStack] = field(default_factory=list)
    position: CubeCoord | None = None
    movement_points: int = DEFAULT_MOVEMENT_POINTS
    hero_id: int = 0
    can_fly: bool = False
    can_water_walk: bool = False
    layer: int = 0

    def vision_radius(self) -> int:
        from lops.skills import SkillId

        return (
            HERO_VISION_RADIUS
            + int(self.hero.skill_value(SkillId.SCOUTING))
            + self.hero.artifact_scouting_bonus()
        )

    @property
    def alive(self) -> bool:
        return any(s.count > 0 for s in self.army)


@dataclass
class PlayerState:
    """State for one player on the adventure map."""

    player_id: int
    heroes: list[HeroState] = field(default_factory=list)
    resources: Resources = field(default_factory=starting_resources)
    town_id: str | None = None
    is_ai: bool = False
    defeated: bool = False
    _revealed: dict[int, set[CubeCoord]] = field(default_factory=lambda: {0: set(), 1: set()})
    selected_hero_idx: int = 0
    _next_hero_id: int = 0

    @property
    def revealed(self) -> set[CubeCoord]:
        """Backward-compat: return surface layer revealed set."""
        return self._revealed.get(0, set())

    @revealed.setter
    def revealed(self, value: set[CubeCoord]):
        """Backward-compat: set surface layer revealed set."""
        self._revealed[0] = value

    def revealed_for_layer(self, layer: int) -> set[CubeCoord]:
        """Get revealed hexes for a specific layer."""
        return self._revealed.get(layer, set())

    # --- Hero management ---

    def add_hero(self, hs: HeroState) -> bool:
        """Add a hero. Returns False if at capacity."""
        if len(self.alive_heroes()) >= MAX_HEROES_PER_PLAYER:
            return False
        hs.hero_id = self._next_hero_id
        self._next_hero_id += 1
        self.heroes.append(hs)
        return True

    def remove_hero(self, hs: HeroState):
        """Remove a hero from the roster."""
        if hs in self.heroes:
            self.heroes.remove(hs)
        alive = self.alive_heroes()
        if self.selected_hero_idx >= len(alive):
            self.selected_hero_idx = max(0, len(alive) - 1)

    def alive_heroes(self) -> list[HeroState]:
        """Heroes alive and on the map (position is not None)."""
        return [h for h in self.heroes if h.alive and h.position is not None]

    def all_alive_heroes(self) -> list[HeroState]:
        """All heroes still alive (including garrisoned)."""
        return [h for h in self.heroes if h.alive]

    def hero_at(self, pos: CubeCoord, layer: int | None = None) -> HeroState | None:
        """Find a living hero at the given map position.

        If layer is given, only match heroes on that layer.
        """
        for h in self.heroes:
            if h.alive and h.position == pos:
                if layer is not None and h.layer != layer:
                    continue
                return h
        return None

    # --- Active hero (backward-compat bridge) ---

    @property
    def active_hero_state(self) -> HeroState | None:
        alive = self.all_alive_heroes()
        if not alive:
            return None
        idx = min(self.selected_hero_idx, len(alive) - 1)
        return alive[idx]

    @property
    def hero(self) -> Hero:
        hs = self.active_hero_state
        return hs.hero if hs else Hero(name="None")

    @property
    def army(self) -> list[CreatureStack]:
        hs = self.active_hero_state
        return hs.army if hs else []

    @army.setter
    def army(self, value: list[CreatureStack]):
        hs = self.active_hero_state
        if hs:
            hs.army = value

    @property
    def position(self) -> CubeCoord | None:
        hs = self.active_hero_state
        return hs.position if hs else None

    @position.setter
    def position(self, value: CubeCoord | None):
        hs = self.active_hero_state
        if hs:
            hs.position = value

    @property
    def movement_points(self) -> int:
        hs = self.active_hero_state
        return hs.movement_points if hs else 0

    @movement_points.setter
    def movement_points(self, value: int):
        hs = self.active_hero_state
        if hs:
            hs.movement_points = value

    # --- Vision ---

    def vision_radius(self) -> int:
        hs = self.active_hero_state
        return hs.vision_radius() if hs else HERO_VISION_RADIUS

    def reveal_around(self, pos: CubeCoord, layer: int | None = None):
        """Reveal hexes around a position using active hero's vision."""
        if layer is None:
            hs = self.active_hero_state
            layer = hs.layer if hs else 0
        if layer not in self._revealed:
            self._revealed[layer] = set()
        self._revealed[layer] |= hexes_in_radius(pos, self.vision_radius())

    def reveal_for_hero(self, hs: HeroState):
        """Reveal hexes for a specific hero."""
        if hs.position is not None:
            layer = hs.layer
            if layer not in self._revealed:
                self._revealed[layer] = set()
            self._revealed[layer] |= hexes_in_radius(hs.position, hs.vision_radius())

    # --- Resources ---

    @property
    def gold(self) -> int:
        return self.resources.gold

    @gold.setter
    def gold(self, value: int):
        self.resources.gold = value


@dataclass
class AdventureState:
    """Full adventure mode state."""

    players: list[PlayerState] = field(default_factory=list)
    current_player_index: int = 0
    day: int = 1
    map_objects: list = field(default_factory=list)
    game_over: bool = False
    winner_id: int | None = None

    @property
    def current_player(self) -> PlayerState:
        return self.players[self.current_player_index]

    @property
    def week(self) -> int:
        return (self.day - 1) // 7 + 1

    @property
    def day_of_week(self) -> int:
        """1-based day of week (1=Monday)."""
        return ((self.day - 1) % 7) + 1

    def end_turn(self):
        """Advance to next player. If all players have gone, advance the day."""
        self.current_player_index += 1
        if self.current_player_index >= len(self.players):
            self.current_player_index = 0
            self._advance_day()
        # Skip defeated players
        attempts = 0
        while self.current_player.defeated and attempts < len(self.players):
            self.current_player_index = (self.current_player_index + 1) % len(
                self.players
            )
            attempts += 1

        # Refresh movement points and regenerate mana for ALL heroes of incoming player
        if not self.current_player.defeated:
            from lops.skills import SkillId

            for hs in self.current_player.all_alive_heroes():
                hs.movement_points = effective_movement_points(hs.hero, hs.army)
                # Daily mana regen: +1 base + Mysticism bonus, capped at max
                hero = hs.hero
                mysticism_bonus = int(hero.skill_value(SkillId.MYSTICISM))
                regen = 1 + mysticism_bonus
                max_mana = hero.effective_knowledge() * 10
                hero.mana = min(hero.mana + regen, max_mana)

    def _advance_day(self):
        """New day: apply daily income, check for weekly growth."""
        self.day += 1
        self._apply_daily_income()
        if self.day_of_week == 1:
            self._apply_weekly_growth()

    def _apply_daily_income(self):
        """Apply mine income + town hall income + Estates skill for all players."""
        from lops.adventure.map_objects import Mine, TownSite
        from lops.skills import SkillId

        for player in self.players:
            if player.defeated:
                continue
            # Town hall income + resource silo
            for obj in self.map_objects:
                if (
                    isinstance(obj, TownSite)
                    and obj.owner == player.player_id
                    and obj.town
                ):
                    player.resources.gold += obj.town.daily_gold_income()
                    player.resources.add_in_place(obj.town.silo_daily_income())
            # Mine income
            for obj in self.map_objects:
                if (
                    isinstance(obj, Mine)
                    and obj.owner == player.player_id
                    and obj.alive
                ):
                    income = obj.daily_income()
                    player.resources.add_in_place(income)
            # Estates skill income from ALL heroes
            for hs in player.all_alive_heroes():
                estates = hs.hero.skill_value(SkillId.ESTATES)
                if estates > 0:
                    player.resources.gold += int(estates)

    def _apply_weekly_growth(self):
        """Refill town dwellings and map dwellings at start of each week."""
        from lops.adventure.map_objects import CreatureDwelling, TownSite

        for obj in self.map_objects:
            if isinstance(obj, TownSite) and obj.town is not None:
                obj.town.apply_weekly_growth()
            elif isinstance(obj, CreatureDwelling) and obj.alive:
                obj.apply_weekly_growth()

    def visible_hexes(self, player_id: int, layer: int | None = None) -> set[CubeCoord]:
        """Compute currently visible hexes for a player (union of all heroes).

        If layer is given, only include heroes on that layer.
        """
        visible: set[CubeCoord] = set()
        for p in self.players:
            if p.player_id == player_id and not p.defeated:
                for hs in p.alive_heroes():
                    if hs.position is not None:
                        if layer is not None and hs.layer != layer:
                            continue
                        visible |= hexes_in_radius(hs.position, hs.vision_radius())
        return visible

    def find_object_at(self, pos: CubeCoord, layer: int | None = None):
        """Find a living map object at the given position.

        If layer is given, only match objects on that layer.
        """
        for obj in self.map_objects:
            if obj.position == pos and obj.alive:
                if layer is not None and hasattr(obj, "layer") and obj.layer != layer:
                    continue
                return obj
        return None

    def remove_object(self, obj):
        """Mark an object as dead/collected."""
        obj.alive = False

    def check_victory(self):
        """Check if the game is over."""
        alive_players = [p for p in self.players if not p.defeated]
        if len(alive_players) <= 1:
            self.game_over = True
            if alive_players:
                self.winner_id = alive_players[0].player_id
