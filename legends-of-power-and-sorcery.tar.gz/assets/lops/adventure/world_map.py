"""World map: terrain types, tiles, and the hex world grid."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto

from lops.hex import (
    CubeCoord,
    OffsetCoord,
    cube_neighbors,
    cube_to_offset,
    offset_to_cube,
)


class Terrain(Enum):
    GRASS = auto()
    FOREST = auto()
    ROAD = auto()
    DIRT = auto()
    MOUNTAIN = auto()
    WATER = auto()
    CAVE_FLOOR = auto()
    CAVE_WALL = auto()
    LAVA = auto()
    SUBTERRANEAN_ROAD = auto()


@dataclass
class MapTile:
    terrain: Terrain
    object_id: str | None = None  # reference to a MapObject placed here


class WorldMap:
    """A hex-based world map using cube coordinates."""

    def __init__(self, cols: int, rows: int):
        self.cols = cols
        self.rows = rows
        self._tiles: dict[CubeCoord, MapTile] = {}

        # Initialize all tiles as grass
        for col in range(cols):
            for row in range(rows):
                c = offset_to_cube(OffsetCoord(col, row))
                self._tiles[c] = MapTile(terrain=Terrain.GRASS)

    def in_bounds(self, pos: CubeCoord) -> bool:
        o = cube_to_offset(pos)
        return 0 <= o.col < self.cols and 0 <= o.row < self.rows

    def get_tile(self, pos: CubeCoord) -> MapTile | None:
        return self._tiles.get(pos)

    def set_terrain(self, pos: CubeCoord, terrain: Terrain):
        tile = self._tiles.get(pos)
        if tile is not None:
            tile.terrain = terrain

    def is_passable(self, pos: CubeCoord) -> bool:
        tile = self.get_tile(pos)
        if tile is None:
            return False
        return tile.terrain not in (Terrain.MOUNTAIN, Terrain.WATER, Terrain.CAVE_WALL, Terrain.LAVA)

    def all_positions(self) -> list[CubeCoord]:
        return list(self._tiles.keys())

    def neighbors(self, pos: CubeCoord) -> list[CubeCoord]:
        return [n for n in cube_neighbors(pos) if self.in_bounds(n)]
