"""Selection state machine for combat input."""

from __future__ import annotations

from enum import Enum, auto

from lops.combat import CombatEngine
from lops.hex import CubeCoord
from lops.models import CreatureStack, Side
from lops.pathfinding import get_attack_positions


class SelectionState(Enum):
    IDLE = auto()
    STACK_ACTIVE = auto()  # stack selected, showing moves/attacks
    SPELL_TARGETING = auto()  # spell selected, picking target


class SelectionStateMachine:
    """Manages the selection flow: IDLE -> STACK_ACTIVE -> action executed."""

    def __init__(self, engine: CombatEngine, player_side: Side = Side.ATTACKER):
        self.engine = engine
        self.player_side = player_side
        self.state = SelectionState.IDLE
        self.valid_moves: dict[CubeCoord, int] = {}
        self.valid_attacks: list[CreatureStack] = []
        self.attack_hexes: set[CubeCoord] = set()

        # Spell targeting state
        self.pending_spell = None  # Spell being targeted
        self.spell_valid_targets: list[CreatureStack] = []
        self.spell_target_hexes: set[CubeCoord] = set()
        self.spell_area_preview: set[CubeCoord] = set()

    @property
    def is_player_turn(self) -> bool:
        stack = self.engine.current_stack
        return stack is not None and stack.side == self.player_side and stack.alive

    def activate_current_stack(self):
        """Activate the current stack and compute valid moves/attacks."""
        if not self.is_player_turn:
            return

        stack = self.engine.current_stack
        self.state = SelectionState.STACK_ACTIVE
        self.valid_moves = self.engine.get_valid_moves()
        self.valid_attacks = self.engine.get_valid_attacks()

        # Build set of hexes that contain attackable enemies
        self.attack_hexes = set()
        for target in self.valid_attacks:
            if target.position:
                self.attack_hexes.add(target.position)

    def deactivate(self):
        self.state = SelectionState.IDLE
        self.valid_moves = {}
        self.valid_attacks = []
        self.attack_hexes = set()
        self.pending_spell = None
        self.spell_valid_targets = []
        self.spell_target_hexes = set()
        self.spell_area_preview = set()

    def enter_spell_targeting(self, spell):
        """Enter spell targeting mode: compute valid targets for this spell."""
        from lops.spells import SpellTarget, is_mass_cast

        self.pending_spell = spell
        self.state = SelectionState.SPELL_TARGETING
        self.spell_valid_targets = []
        self.spell_target_hexes = set()
        self.spell_area_preview = set()

        stack = self.engine.current_stack
        if not stack:
            return

        bf = self.engine.battlefield
        # Determine valid targets based on spell target type
        if spell.target_type in (SpellTarget.SINGLE_FRIENDLY, SpellTarget.ALL_FRIENDLY):
            army = bf.get_army(stack.side)
            self.spell_valid_targets = [s for s in army.alive_stacks]
        elif spell.target_type in (SpellTarget.SINGLE_ENEMY, SpellTarget.ALL_ENEMY):
            army = bf.get_enemy_army(stack.side)
            self.spell_valid_targets = [s for s in army.alive_stacks]
        elif spell.target_type in (SpellTarget.AREA, SpellTarget.RING):
            # Any hex near a stack is a valid target (cast at position)
            self.spell_valid_targets = [s for s in bf.alive_stacks]

        # Mass cast: any single target is fine (it affects all)
        if is_mass_cast(spell, self.engine.get_hero(stack.side)):
            if spell.target_type == SpellTarget.SINGLE_FRIENDLY:
                army = bf.get_army(stack.side)
                self.spell_valid_targets = [s for s in army.alive_stacks]
            elif spell.target_type == SpellTarget.SINGLE_ENEMY:
                army = bf.get_enemy_army(stack.side)
                self.spell_valid_targets = [s for s in army.alive_stacks]

        self.spell_target_hexes = {
            s.position for s in self.spell_valid_targets if s.position
        }

    def cancel_spell_targeting(self):
        """Cancel spell targeting, return to STACK_ACTIVE."""
        self.pending_spell = None
        self.spell_valid_targets = []
        self.spell_target_hexes = set()
        self.spell_area_preview = set()
        self.state = SelectionState.STACK_ACTIVE
        self.activate_current_stack()

    def get_target_at(self, pos: CubeCoord) -> CreatureStack | None:
        """Get an attackable enemy at the given hex."""
        for target in self.valid_attacks:
            if target.position == pos:
                return target
        return None

    def get_best_attack_position(self, target: CreatureStack) -> CubeCoord | None:
        """Get the best hex to move to for attacking the given target."""
        stack = self.engine.current_stack
        if not stack:
            return None

        positions = get_attack_positions(stack, target, self.engine.battlefield)
        if not positions:
            return None

        # Prefer current position (already adjacent)
        if stack.position in positions:
            return stack.position

        # Otherwise pick closest to current position
        from lops.hex import cube_distance

        spos = stack.position
        assert spos is not None
        return min(positions, key=lambda p: cube_distance(p, spos))
