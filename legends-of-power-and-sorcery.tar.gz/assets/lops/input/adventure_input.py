"""Adventure mode input: click-to-move, scroll, object interaction."""

from __future__ import annotations

import pygame

from lops.adventure.game_director import GameDirector, GameMode
from lops.adventure.hero_movement import find_path
from lops.adventure.map_objects import (
    CreatureBank,
    PandorasBox,
    TownSite,
    TreasureChest,
    WanderingMonster,
)
from lops.adventure.movement_anim import AdventureAnimState, AnimSpeed
from lops.hex import CubeCoord
from lops.renderer.adventure_renderer import AdventureRenderer
from lops.renderer.adventure_ui import AdventureUI


class AdventureInputHandler:
    """Handles mouse and keyboard input for the adventure map."""

    def __init__(
        self,
        director: GameDirector,
        renderer: AdventureRenderer,
        ui: AdventureUI,
        anim_state: AdventureAnimState | None = None,
    ):
        self.director = director
        self.renderer = renderer
        self.ui = ui
        self.anim_state = anim_state

        # Cached movement range
        self._move_range: dict[CubeCoord, int] | None = None
        self._last_hover_hex: CubeCoord | None = None
        self.refresh_move_range()

    def _hero_layer(self) -> int:
        """Get the current human hero's layer."""
        player = self.director._state.current_player
        hs = player.active_hero_state
        return hs.layer if hs else 0

    def refresh_move_range(self):
        """Recompute movement range for current player."""
        if self.director.mode != GameMode.ADVENTURE:
            return
        player = self.director._state.current_player
        if player.is_ai or player.defeated or player.position is None:
            self._move_range = None
            self.renderer.move_range.clear()
            return
        self._move_range = self.director.get_player_movement_range()
        # Only show reachable hexes that are revealed (fog of war)
        hs = player.active_hero_state
        hero_layer = hs.layer if hs else 0
        revealed = player.revealed_for_layer(hero_layer)
        if revealed:
            self.renderer.move_range = set(self._move_range.keys()) & revealed
        else:
            self.renderer.move_range = set(self._move_range.keys())

    def handle_event(self, event: pygame.event.Event) -> str | None:
        """Process event. Returns action string or None.

        Actions: 'moved', 'combat', 'town', 'end_turn', 'resource', None
        """
        state = self.director._state
        if state.game_over:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return "quit"
            return None

        player = state.current_player
        if player.is_ai:
            return None

        animating = self.anim_state is not None and self.anim_state.is_animating

        # Dialog intercepts
        if self.ui.chest_dialog_active:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                choice = self.ui.handle_chest_click(event.pos)
                if choice is not None:
                    result = self.director.resolve_treasure_chest(player, choice)
                    if result:
                        from lops.experience import format_level_up

                        msgs = [format_level_up(r) for r in result]
                        self.ui.set_status(" | ".join(msgs), 4.0)
                    self.refresh_move_range()
                    return "treasure_resolved"
            return None

        if self.ui.arena_dialog_active:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                choice = self.ui.handle_arena_click(event.pos)
                if choice is not None:
                    self.director.resolve_arena(player, choice)
                    stat_name = "Attack" if choice == "attack" else "Defense"
                    self.ui.set_status(f"Arena: {stat_name} +2!")
                    self.refresh_move_range()
                    return "arena_resolved"
            return None

        if self.ui.dwelling_dialog_active:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                dwelling_result = self.ui.handle_dwelling_click(event.pos)
                if dwelling_result == "recruit":
                    if player.position is None:
                        return None
                    obj = self.director._state.find_object_at(player.position, layer=self._hero_layer())
                    if obj and hasattr(obj, "available"):
                        if self.director.recruit_from_dwelling(player, obj.available):
                            self.ui.set_status("Creatures recruited!")
                        else:
                            self.ui.set_status("Army is full!")
                    self.refresh_move_range()
                    return "dwelling_recruited"
                elif dwelling_result == "cancel":
                    self.refresh_move_range()
                    return "dwelling_cancelled"
            return None

        if self.ui.hill_fort_dialog_active:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                hf_result = self.ui.handle_hill_fort_click(event.pos)
                if hf_result is not None:
                    if isinstance(hf_result, int):
                        if self.director.upgrade_creature_at_hill_fort(player, hf_result):
                            self.ui.set_status("Creature upgraded!")
                        else:
                            self.ui.set_status("Cannot upgrade.")
                    elif hf_result == "close":
                        pass
                    self.refresh_move_range()
                    return "hill_fort_done"
            return None

        if event.type == pygame.KEYDOWN:
            self.renderer.handle_scroll_key(event.key, True)
            # V key: cycle speed (works during animation too)
            if event.key == pygame.K_v and self.anim_state is not None:
                self.anim_state.cycle_speed()
                if animating and self.anim_state.speed == AnimSpeed.INSTANT:
                    self.anim_state.finish_immediately()
                return None
            if animating:
                return None  # block other keys during animation
            if event.key == pygame.K_SPACE:
                return self._end_turn()
            # Hero selection: keys 1-5 select hero by index
            elif event.key in (
                pygame.K_1,
                pygame.K_2,
                pygame.K_3,
                pygame.K_4,
                pygame.K_5,
            ):
                hero_idx = event.key - pygame.K_1  # 0-based index
                self._select_hero(player, hero_idx)
            # Tab: cycle to next hero with remaining movement points
            elif event.key == pygame.K_TAB:
                self._cycle_next_hero(player)
            # H: open hero equipment modal
            elif event.key == pygame.K_h:
                self.director.open_hero_modal()
                return "hero_modal"
            # S: open adventure spellbook
            elif event.key == pygame.K_s:
                spells = self.director.get_adventure_spells(player)
                if spells:
                    return "adventure_spellbook"
        elif event.type == pygame.KEYUP:
            self.renderer.handle_scroll_key(event.key, False)

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if animating:
                return None  # block clicks during animation
            return self._handle_click(event.pos)

        return None

    def update(self):
        """Called each frame. Updates path preview and refreshes move range if needed."""
        if self.anim_state is not None and self.anim_state.is_animating:
            return  # no path preview during animation
        # Auto-refresh move range if it's missing (e.g. after turn change)
        if self._move_range is None:
            player = self.director._state.current_player
            if not player.is_ai and not player.defeated:
                self.refresh_move_range()
        hover = self.renderer.hover_hex
        if hover != self._last_hover_hex:
            self._last_hover_hex = hover
            self._update_path_preview()

    def _handle_click(self, pos: tuple[int, int]) -> str | None:
        """Handle left mouse click."""
        # Check HUD buttons first
        if self.ui.is_end_turn_clicked(pos):
            return self._end_turn()

        hex_pos = self.renderer.screen_to_hex(pos[0], pos[1])
        if hex_pos is None:
            return None

        player = self.director._state.current_player

        # Ignore clicks on unexplored hexes
        hs = player.active_hero_state
        hero_layer = hs.layer if hs else 0
        hero_revealed = player.revealed_for_layer(hero_layer)
        if hero_revealed and hex_pos not in hero_revealed:
            return None

        # Allow clicking current hex to interact with objects there (e.g. visit town)
        if hex_pos == player.position:
            return self._interact_current_hex(player)

        # Check if destination is reachable
        if self._move_range is None or hex_pos not in self._move_range:
            # Out of range: open own town remotely (like sidebar)
            obj = self.director._state.find_object_at(hex_pos, layer=self._hero_layer())
            if isinstance(obj, TownSite) and obj.owner == player.player_id:
                self.director.open_town_screen(obj)
                return "town"
            return None

        # Animated movement (NORMAL or FAST speed)
        if self.anim_state is not None and self.anim_state.speed != AnimSpeed.INSTANT:
            result = self.director.prepare_move(player, hex_pos)
            if result is None:
                return None
            hex_path, event = result
            pixel_path = [self.renderer.hex_world_center(h) for h in hex_path]
            hs = player.active_hero_state
            self.anim_state.start_move(hs, player, hex_path, pixel_path, event)
            self.renderer.clear_highlights()
            self._move_range = None
            return "animating"

        # Instant movement (existing path)
        event = self.director.move_hero(player, hex_pos)
        if player.position is not None:
            self.renderer.center_on_hex(player.position)

        if event == "treasure_chest":
            obj = self.director._state.find_object_at(hex_pos, layer=self._hero_layer())
            if isinstance(obj, TreasureChest):
                if obj.is_artifact:
                    art_name = ""
                    if obj.artifact_id is not None:
                        from lops.data.artifacts import ARTIFACT_REGISTRY

                        art_name = ARTIFACT_REGISTRY[obj.artifact_id].name
                    self.ui.show_chest_dialog(
                        obj.gold_amount,
                        obj.xp_amount,
                        is_artifact=True,
                        artifact_name=art_name,
                    )
                else:
                    self.ui.show_chest_dialog(obj.gold_amount, obj.xp_amount)
            return "treasure_chest"
        if event == "artifact":
            self.ui.set_status(self.director.last_event_description)
            self.refresh_move_range()
            return "artifact"
        elif event == "resource":
            self.ui.set_status(self.director.last_event_description)
            self.refresh_move_range()
            return "resource"
        elif event == "mine_captured":
            self.ui.set_status(self.director.last_event_description)
            self.refresh_move_range()
            return "mine_captured"
        elif event == "monster":
            # Find the monster and start combat
            obj = self.director._state.find_object_at(hex_pos, layer=self._hero_layer())
            if isinstance(obj, WanderingMonster):
                self.director.start_monster_combat(player, obj)
                return "combat"
        elif event == "own_town":
            obj = self.director._state.find_object_at(hex_pos, layer=self._hero_layer())
            if isinstance(obj, TownSite):
                self.director.open_town_screen(obj)
                return "town"
        elif event in ("enemy_town", "neutral_town"):
            obj = self.director._state.find_object_at(hex_pos, layer=self._hero_layer())
            if isinstance(obj, TownSite):
                town = obj.town
                has_fort = town and self.director._get_fort_level(town) is not None
                def_player, def_hs = self.director._find_defender_at_town(obj, player)
                has_defenders = town and (town.garrison or def_hs is not None)
                if has_fort and has_defenders:
                    self.director.start_siege_combat(player, obj)
                    return "combat"
                else:
                    self.director.capture_town(player, obj)
                    self.ui.set_status(f"Captured {obj.name}!")
                    self.refresh_move_range()
                    return "capture"
        elif event == "enemy_hero":
            for other in self.director._state.players:
                if other.player_id != player.player_id and not other.defeated:
                    if other.hero_at(hex_pos) is not None:
                        self.director.start_hero_combat(player, other, hex_pos)
                        return "combat"
        elif event == "campfire":
            self.ui.set_status(self.director.last_event_description)
            self.refresh_move_range()
            return "campfire"
        elif event == "stat_booster":
            self.ui.set_status(self.director.last_event_description)
            self.refresh_move_range()
            return "stat_booster"
        elif event == "arena":
            self.ui.show_arena_dialog()
            return "arena"
        elif event == "library_too_low":
            self.ui.set_status(self.director.last_event_description)
            self.refresh_move_range()
            return "library_too_low"
        elif event == "magic_well":
            self.ui.set_status(self.director.last_event_description)
            self.refresh_move_range()
            return "magic_well"
        elif event == "pandora_guarded":
            obj = self.director._state.find_object_at(hex_pos, layer=self._hero_layer())
            if isinstance(obj, PandorasBox):
                self.director.start_monster_combat(player, obj)
                return "combat"
        elif event == "pandora_unguarded":
            self.ui.set_status(self.director.last_event_description)
            self.refresh_move_range()
            return "pandora_unguarded"
        elif event == "creature_bank":
            obj = self.director._state.find_object_at(hex_pos, layer=self._hero_layer())
            if isinstance(obj, CreatureBank):
                self.director.start_monster_combat(player, obj)
                return "combat"
        elif event == "dwelling_visit":
            self.ui.show_dwelling_dialog()
            return "dwelling_visit"
        elif event == "hill_fort":
            self.ui.show_hill_fort_dialog()
            return "hill_fort"

        self.refresh_move_range()
        return "moved" if event is None else event

    def _interact_current_hex(self, player) -> str | None:
        """Interact with an object on the hex the hero is standing on."""
        if player.position is None:
            return None
        obj = self.director._state.find_object_at(player.position, layer=self._hero_layer())
        if isinstance(obj, TownSite) and obj.owner == player.player_id:
            self.director.open_town_screen(obj)
            return "town"
        return None

    def _end_turn(self) -> str:
        self.director.end_turn()
        self.renderer.clear_highlights()
        self.refresh_move_range()
        pos = self.director._state.current_player.position
        if pos is not None:
            self.renderer.center_on_hex(pos)
        return "end_turn"

    def _select_hero(self, player, hero_idx: int):
        """Select a hero by index within the alive heroes list."""
        alive = player.all_alive_heroes()
        if hero_idx < 0 or hero_idx >= len(alive):
            return
        player.selected_hero_idx = hero_idx
        self.refresh_move_range()
        # Center camera on the newly selected hero
        hs = player.active_hero_state
        if hs and hs.position is not None:
            self.renderer.center_on_hex(hs.position)

    def _cycle_next_hero(self, player):
        """Cycle to the next hero that still has movement points remaining."""
        alive = player.alive_heroes()
        if not alive:
            return
        start_idx = player.selected_hero_idx
        n = len(alive)
        for offset in range(1, n + 1):
            idx = (start_idx + offset) % n
            if alive[idx].movement_points > 0:
                player.selected_hero_idx = idx
                self.refresh_move_range()
                hs = player.active_hero_state
                if hs and hs.position is not None:
                    self.renderer.center_on_hex(hs.position)
                return
        # No hero with MP found — just cycle to next anyway
        next_idx = (start_idx + 1) % n
        player.selected_hero_idx = next_idx
        self.refresh_move_range()
        hs = player.active_hero_state
        if hs and hs.position is not None:
            self.renderer.center_on_hex(hs.position)

    def _update_path_preview(self):
        """Show path preview on hover."""
        if self._move_range is None:
            return
        hover = self.renderer.hover_hex
        if hover and hover in self._move_range:
            player = self.director._state.current_player
            if player.position is None:
                return
            blocked = self.director._get_blocked_hexes(player, allow=hover)
            from lops.skills import SkillId

            pf = player.hero.skill_value(SkillId.PATHFINDING)
            path = find_path(
                player.position,
                hover,
                self.director._hero_map(player),
                blocked,
                pathfinding_reduction=pf,
            )
            self.renderer.move_path = path or []
        else:
            self.renderer.move_path = []
