"""InputHandler: event dispatch for combat input."""

from __future__ import annotations

import pygame

from lops.actions import ActionType, CombatAction
from lops.combat import CombatEngine
from lops.hex import CubeCoord
from lops.input.selection import SelectionState, SelectionStateMachine
from lops.models import Side
from lops.renderer.core import GameRenderer
from lops.spells import MagicSchool

# Shared school-to-color mapping
SCHOOL_COLORS = {
    MagicSchool.AIR: (180, 200, 255),
    MagicSchool.FIRE: (255, 140, 60),
    MagicSchool.WATER: (80, 160, 255),
    MagicSchool.EARTH: (140, 200, 80),
}


class InputHandler:
    """Handles mouse and keyboard input for the human player."""

    def __init__(
        self,
        engine: CombatEngine,
        renderer: GameRenderer,
        player_side: Side = Side.ATTACKER,
    ):
        self.engine = engine
        self.renderer = renderer
        self.player_side = player_side
        self.auto_combat = False  # AI plays for the human player
        self.selection = SelectionStateMachine(engine, player_side=player_side)

        # Auto-activate on player turns
        self.engine.on_action.append(self._on_action_executed)
        self._try_activate()

    def handle_event(self, event: pygame.event.Event):
        """Process a pygame event."""
        if self.engine.is_over():
            return
        if self.renderer.is_animating:
            return

        # A key toggles auto-combat (works anytime, even during enemy turn)
        if event.type == pygame.KEYDOWN and event.key == pygame.K_a:
            self.auto_combat = not self.auto_combat
            return

        if self.auto_combat:
            return  # block all other input during auto-combat
        if not self.selection.is_player_turn:
            return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self._handle_click(event.pos)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 3:
            # Right-click cancels spell targeting
            if self.selection.state == SelectionState.SPELL_TARGETING:
                self.selection.cancel_spell_targeting()
                self.renderer.show_spellbook = False
                self._update_highlights()
        elif event.type == pygame.MOUSEWHEEL and self.renderer.show_spellbook:
            # Scroll spellbook
            self.renderer.ui_renderer.spellbook_scroll(-event.y)
        elif event.type == pygame.KEYDOWN:
            self._handle_key(event.key)

    def _handle_click(self, pos: tuple[int, int]):
        """Handle left mouse click."""
        # If spellbook is open, check spell click
        if self.renderer.show_spellbook:
            spell = self.renderer.ui_renderer.spellbook_click(pos)
            if spell is not None:
                self._start_spell_targeting(spell)
                return
            # Clicking outside spellbook closes it
            self.renderer.show_spellbook = False
            self._update_highlights()
            return

        hex_pos = self.renderer.pixel_to_hex(pos[0], pos[1])
        if hex_pos is None:
            return

        stack = self.engine.current_stack
        if not stack:
            return

        # Spell targeting mode
        if self.selection.state == SelectionState.SPELL_TARGETING:
            if hex_pos in self.selection.spell_target_hexes:
                target = self.engine.battlefield.stack_at(hex_pos)
                if target:
                    self._execute_spell(stack, target)
            return

        if self.selection.state == SelectionState.STACK_ACTIVE:
            # Check if clicking on an enemy to attack
            target = self.selection.get_target_at(hex_pos)
            if target:
                self._execute_attack(stack, target)
                return

            # Check if clicking a valid move destination
            if hex_pos in self.selection.valid_moves:
                self._execute_move(stack, hex_pos)
                return

        # Clicking own stack re-activates (or on first click)
        self._try_activate()

    def _handle_key(self, key: int):
        """Handle keyboard input."""
        stack = self.engine.current_stack
        if not stack:
            return

        if key == pygame.K_w:
            if self.selection.state == SelectionState.SPELL_TARGETING:
                return
            self._execute_wait(stack)
        elif key == pygame.K_d:
            if self.selection.state == SelectionState.SPELL_TARGETING:
                return
            self._execute_defend(stack)
        elif key == pygame.K_s:
            self._toggle_spellbook()
        elif key == pygame.K_ESCAPE:
            if self.selection.state == SelectionState.SPELL_TARGETING:
                self.selection.cancel_spell_targeting()
                self.renderer.show_spellbook = False
                self._update_highlights()
            elif self.renderer.show_spellbook:
                self.renderer.show_spellbook = False

    def _toggle_spellbook(self):
        """Toggle spell book overlay."""
        hero = self.engine.get_hero(self.selection.player_side)
        if not hero or not hero.spells:
            return
        if self.selection.state == SelectionState.SPELL_TARGETING:
            self.selection.cancel_spell_targeting()
            self.renderer.show_spellbook = False
            self._update_highlights()
            return
        self.renderer.show_spellbook = not self.renderer.show_spellbook

    def _start_spell_targeting(self, spell):
        """Enter targeting mode for a spell from the spell book."""
        hero = self.engine.get_hero(self.selection.player_side)
        if not hero:
            return

        from lops.spells import get_mana_cost

        mana_cost = get_mana_cost(hero, spell)
        if hero.mana < mana_cost or hero.has_cast_this_round:
            return

        self.renderer.show_spellbook = False
        self.selection.enter_spell_targeting(spell)
        self._update_highlights()

    def _execute_spell(self, stack, target):
        """Cast the pending spell on the target."""
        spell = self.selection.pending_spell
        if spell is None:
            return

        spell_color = SCHOOL_COLORS.get(spell.school, (180, 200, 255))

        action = CombatAction(
            action_type=ActionType.CAST_SPELL,
            actor=stack,
            target=target,
            spell=spell,
        )
        self.selection.deactivate()
        self.renderer.clear_highlights()

        # Execute action first to get result (needed for dispatch)
        caster_side = stack.side
        result = self.engine.execute_action(action)

        # Dispatch to appropriate animation
        targets = result.get("targets", [target])
        self.renderer.add_spell_animation(
            spell,
            caster_side,
            target,
            targets,
            result,
            color=spell_color,
        )

        # Show damage/buff animations
        if "damage" in result:
            for t in targets:
                if t.position:
                    self.renderer.add_damage_animation(t, result["damage"])
        if "healed" in result:
            for t in targets:
                if t.position:
                    self.renderer.add_float_text(
                        t, f"+{result['healed']} HP", (100, 255, 100)
                    )
        if "buff" in result:
            for t in targets:
                if t.position:
                    self.renderer.add_float_text(t, spell.name, (100, 200, 255))

    def _execute_move(self, stack, destination: CubeCoord):
        action = CombatAction(
            action_type=ActionType.MOVE,
            actor=stack,
            destination=destination,
        )
        self.selection.deactivate()
        self.renderer.clear_highlights()
        result = self.engine.execute_action(action)

    def _execute_attack(self, stack, target):
        # Determine if ranged or melee
        if stack.stats.is_ranged and stack.shots_left > 0:
            action = CombatAction(
                action_type=ActionType.RANGED_ATTACK,
                actor=stack,
                target=target,
            )
        else:
            dest = self.selection.get_best_attack_position(target)
            if dest is None:
                return
            action = CombatAction(
                action_type=ActionType.MELEE_ATTACK,
                actor=stack,
                target=target,
                destination=dest,
            )

        self.selection.deactivate()
        self.renderer.clear_highlights()
        result = self.engine.execute_action(action)

        # Show damage animations
        if "damage" in result:
            self.renderer.add_damage_animation(target, result["damage"])
        if "retaliation_damage" in result:
            self.renderer.add_damage_animation(stack, result["retaliation_damage"])
        if result.get("morale_bonus"):
            self.renderer.add_float_text(stack, "High Morale!", (255, 255, 100))

        # Fire Shield reflect burst on the attacker
        if "fire_shield_damage" in result:
            self.renderer.add_fire_shield_burst(stack)
            self.renderer.add_damage_animation(stack, result["fire_shield_damage"])

    def _execute_wait(self, stack):
        action = CombatAction(action_type=ActionType.WAIT, actor=stack)
        self.selection.deactivate()
        self.renderer.clear_highlights()
        self.engine.execute_action(action)

    def _execute_defend(self, stack):
        action = CombatAction(action_type=ActionType.DEFEND, actor=stack)
        self.selection.deactivate()
        self.renderer.clear_highlights()
        self.engine.execute_action(action)

    def _on_action_executed(self, action, result):
        """Callback after any action — show animations for AI spell casts."""
        if (
            action.action_type == ActionType.CAST_SPELL
            and action.actor.side != self.selection.player_side
            and result.get("spell")
        ):
            spell = result["spell"]
            spell_color = SCHOOL_COLORS.get(spell.school, (180, 200, 255))
            targets = result.get("targets", [action.target] if action.target else [])

            # Dispatch to appropriate animation
            self.renderer.add_spell_animation(
                spell,
                action.actor.side,
                action.target,
                targets,
                result,
                color=spell_color,
            )

            if "damage" in result:
                for t in targets:
                    if t and t.position:
                        self.renderer.add_damage_animation(t, result["damage"])
            if "buff" in result:
                for t in targets:
                    if t and t.position:
                        self.renderer.add_float_text(t, spell.name, (100, 200, 255))

        # Fire shield burst for AI melee attacks
        if (
            action.action_type == ActionType.MELEE_ATTACK
            and "fire_shield_damage" in result
            and action.actor.position
        ):
            self.renderer.add_fire_shield_burst(action.actor)

    def _try_activate(self):
        """Try to activate the current stack for selection."""
        if self.selection.is_player_turn:
            self.selection.activate_current_stack()
            self._update_highlights()

    def _update_highlights(self):
        """Update renderer highlights from selection state."""
        self.renderer.clear_highlights()
        if self.selection.state == SelectionState.STACK_ACTIVE:
            stack = self.engine.current_stack
            if stack and stack.position:
                self.renderer.selected_hex = stack.position
            self.renderer.move_highlights = set(self.selection.valid_moves.keys())
            self.renderer.attack_highlights = self.selection.attack_hexes
        elif self.selection.state == SelectionState.SPELL_TARGETING:
            self.renderer.spell_target_highlights = self.selection.spell_target_hexes
            self.renderer.spell_area_highlights = self.selection.spell_area_preview

    def update(self):
        """Called each frame to check if we need to re-activate."""
        if not self.engine.is_over() and not self.renderer.is_animating:
            if (
                self.selection.state == SelectionState.IDLE
                and self.selection.is_player_turn
            ):
                self._try_activate()

        # Update spell area preview on hover
        if (
            self.selection.state == SelectionState.SPELL_TARGETING
            and self.selection.pending_spell
        ):
            from lops.spells import SpellTarget

            spell = self.selection.pending_spell
            hover = self.renderer.hover_hex
            if hover and spell.target_type in (SpellTarget.AREA, SpellTarget.RING):
                from lops.hex import cube_distance, hexes_in_radius

                if spell.target_type == SpellTarget.AREA:
                    self.renderer.spell_area_highlights = hexes_in_radius(
                        hover, spell.area_radius
                    )
                elif spell.target_type == SpellTarget.RING:
                    all_in_range = hexes_in_radius(hover, spell.area_radius)
                    self.renderer.spell_area_highlights = {
                        h
                        for h in all_in_range
                        if cube_distance(h, hover) == spell.area_radius
                    }
            else:
                self.renderer.spell_area_highlights = set()
