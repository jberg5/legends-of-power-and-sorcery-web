"""HoMM3-style experience, leveling, and stat progression (no pygame)."""

from __future__ import annotations

import random

from lops.models import Hero
from lops.skills import MAX_HERO_SKILLS, HeroSkill, SkillId, SkillLevel

# HoMM3 XP thresholds: exact for levels 1-13, then ~20% growth
XP_THRESHOLDS = [
    0,  # level 1
    1000,  # level 2
    2000,  # level 3
    3200,  # level 4
    4600,  # level 5
    6200,  # level 6
    8000,  # level 7
    10000,  # level 8
    12200,  # level 9
    14700,  # level 10
    17500,  # level 11
    20600,  # level 12
    24320,  # level 13
]


def _ensure_thresholds(level: int) -> None:
    """Extend XP_THRESHOLDS if needed (20% growth per level beyond 13)."""
    while len(XP_THRESHOLDS) <= level:
        XP_THRESHOLDS.append(int(XP_THRESHOLDS[-1] * 1.2))


def xp_for_level(level: int) -> int:
    """XP required to reach a given level."""
    if level <= 1:
        return 0
    _ensure_thresholds(level - 1)
    return XP_THRESHOLDS[level - 1]


def level_for_xp(xp: int) -> int:
    """Compute level from total XP."""
    level = 1
    while True:
        next_threshold = xp_for_level(level + 1)
        if xp < next_threshold:
            return level
        level += 1


# Hero bonus XP for defeating a hero or winning siege
HERO_BONUS_XP = 500


def award_combat_xp(
    hero: Hero,
    original_enemy_stacks: list[tuple[str, int, int]],
    surviving_enemy_stacks: list[tuple[str, int]] | None = None,
    is_hero_or_siege: bool = False,
) -> int:
    """Compute XP earned from combat.

    original_enemy_stacks: [(name, count, max_hp)] before combat
    surviving_enemy_stacks: [(name, count)] after combat, or None if all killed
    is_hero_or_siege: True if fighting a hero or siege (500 bonus XP)

    Returns total XP (before Learning bonus).
    """
    killed_hp = 0
    survivors: dict[str, int] = {}
    if surviving_enemy_stacks:
        for name, count in surviving_enemy_stacks:
            survivors[name] = survivors.get(name, 0) + count

    for name, orig_count, max_hp in original_enemy_stacks:
        surviving_count = survivors.get(name, 0)
        killed_count = max(0, orig_count - surviving_count)
        killed_hp += killed_count * max_hp

    xp = killed_hp
    if is_hero_or_siege:
        xp += HERO_BONUS_XP
    return xp


def grant_xp(hero: Hero, xp: int, rng: random.Random | None = None) -> list[dict]:
    """Add XP to hero and process all level-ups.

    Returns a list of level-up result dicts:
    [{"level": N, "stat": "attack", "stat_amount": 1, "skill": "Offense", "skill_level": "Basic"}]
    """
    if rng is None:
        rng = random.Random()

    hero.experience += xp
    results = []
    while hero.experience >= xp_for_level(hero.level + 1):
        hero.level += 1
        result = _apply_level_up(hero, rng)
        results.append(result)
    return results


# Knight-class stat weights (HoMM3 Castle heroes)
_STAT_WEIGHTS = {
    "attack": 35,
    "defense": 45,
    "spell_power": 10,
    "knowledge": 10,
}

_STAT_CHOICES = list(_STAT_WEIGHTS.keys())
_STAT_CUM_WEIGHTS = []
_cum = 0
for _s in _STAT_CHOICES:
    _cum += _STAT_WEIGHTS[_s]
    _STAT_CUM_WEIGHTS.append(_cum)

# Skills eligible for auto-learn on level-up (excludes magic schools)
_LEVELUP_SKILLS = [
    SkillId.OFFENSE,
    SkillId.ARMORER,
    SkillId.ARCHERY,
    SkillId.LOGISTICS,
    SkillId.SCOUTING,
    SkillId.ESTATES,
    SkillId.LEADERSHIP,
    SkillId.LUCK,
    SkillId.PATHFINDING,
    SkillId.WISDOM,
    SkillId.TACTICS,
    SkillId.LEARNING,
    SkillId.MYSTICISM,
]


def _apply_level_up(hero: Hero, rng: random.Random) -> dict:
    """Apply a single level-up: +1 random primary stat + skill gain."""
    # Primary stat
    stat = rng.choices(_STAT_CHOICES, cum_weights=_STAT_CUM_WEIGHTS, k=1)[0]
    setattr(hero, stat, getattr(hero, stat) + 1)

    result = {
        "level": hero.level,
        "stat": stat,
        "stat_amount": 1,
        "skill": None,
        "skill_level": None,
    }

    # Secondary skill: try to upgrade existing, or learn new
    existing_upgradable = [
        s
        for s in hero.skills
        if s.level != SkillLevel.EXPERT and s.skill_id in _LEVELUP_SKILLS
    ]
    can_learn_new = len(hero.skills) < MAX_HERO_SKILLS

    if existing_upgradable and (not can_learn_new or rng.random() < 0.6):
        # Upgrade a random existing skill
        skill = rng.choice(existing_upgradable)
        if skill.level == SkillLevel.BASIC:
            skill.level = SkillLevel.ADVANCED
        elif skill.level == SkillLevel.ADVANCED:
            skill.level = SkillLevel.EXPERT
        result["skill"] = skill.definition.name
        result["skill_level"] = skill.level.name.capitalize()
    elif can_learn_new:
        # Learn a new skill
        known_ids = {s.skill_id for s in hero.skills}
        available = [sid for sid in _LEVELUP_SKILLS if sid not in known_ids]
        if available:
            new_id = rng.choice(available)
            new_skill = HeroSkill(skill_id=new_id, level=SkillLevel.BASIC)
            hero.skills.append(new_skill)
            result["skill"] = new_skill.definition.name
            result["skill_level"] = "Basic"

    return result


def format_level_up(result: dict) -> str:
    """Format a level-up result dict into a status message."""
    parts = [f"Level {result['level']}!"]
    stat_abbr = {
        "attack": "ATK",
        "defense": "DEF",
        "spell_power": "SPL",
        "knowledge": "KNW",
    }
    parts.append(
        f"{stat_abbr.get(result['stat'], result['stat'])} +{result['stat_amount']}"
    )
    if result["skill"]:
        parts.append(f"{result['skill_level']} {result['skill']}")
    return ", ".join(parts)
