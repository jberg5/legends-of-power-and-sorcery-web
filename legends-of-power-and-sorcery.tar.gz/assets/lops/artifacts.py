"""Artifact system: slots, classes, definitions, instances."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto


class ArtifactSlot(Enum):
    HELMET = auto()
    CAPE = auto()
    NECKLACE = auto()
    WEAPON = auto()
    SHIELD = auto()
    ARMOR = auto()
    RING = auto()
    BOOTS = auto()
    MISC = auto()


SLOT_CAPACITY = {
    ArtifactSlot.HELMET: 1,
    ArtifactSlot.CAPE: 1,
    ArtifactSlot.NECKLACE: 1,
    ArtifactSlot.WEAPON: 1,
    ArtifactSlot.SHIELD: 1,
    ArtifactSlot.ARMOR: 1,
    ArtifactSlot.RING: 2,
    ArtifactSlot.BOOTS: 1,
    ArtifactSlot.MISC: 5,
}

SLOT_NAMES = {
    ArtifactSlot.HELMET: "Helmet",
    ArtifactSlot.CAPE: "Cape",
    ArtifactSlot.NECKLACE: "Necklace",
    ArtifactSlot.WEAPON: "Weapon",
    ArtifactSlot.SHIELD: "Shield",
    ArtifactSlot.ARMOR: "Armor",
    ArtifactSlot.RING: "Ring",
    ArtifactSlot.BOOTS: "Boots",
    ArtifactSlot.MISC: "Misc",
}


class ArtifactClass(Enum):
    TREASURE = auto()
    MINOR = auto()
    MAJOR = auto()
    RELIC = auto()


class ArtifactId(Enum):
    # === WEAPONS ===
    CENTAURS_AXE = auto()
    BLACKSHARD_OF_THE_DEAD_KNIGHT = auto()
    GREATER_GNOLLS_FLAIL = auto()
    OGRES_CLUB_OF_HAVOC = auto()
    SWORD_OF_HELLFIRE = auto()
    TRIDENT_OF_DOMINION = auto()
    RED_DRAGON_FLAME_TONGUE = auto()
    TITANS_GLADIUS = auto()
    SWORD_OF_JUDGEMENT = auto()

    # === SHIELDS ===
    SHIELD_OF_THE_DWARVEN_LORDS = auto()
    SHIELD_OF_THE_YAWNING_DEAD = auto()
    BUCKLER_OF_THE_GNOLL_KING = auto()
    TARG_OF_THE_RAMPAGING_OGRE = auto()
    SHIELD_OF_THE_DAMNED = auto()
    SHIELD_OF_NAVAL_GLORY = auto()
    DRAGON_SCALE_SHIELD = auto()
    LIONS_SHIELD_OF_COURAGE = auto()
    SENTINELS_SHIELD = auto()

    # === ARMOR ===
    BREASTPLATE_OF_PETRIFIED_WOOD = auto()
    RIB_CAGE = auto()
    SCALES_OF_THE_GREATER_BASILISK = auto()
    TUNIC_OF_THE_CYCLOPS_KING = auto()
    BREASTPLATE_OF_BRIMSTONE = auto()
    ROYAL_ARMOR_OF_NIX = auto()
    ARMOR_OF_WONDER = auto()
    DRAGON_SCALE_ARMOR = auto()
    TITANS_CUIRASS = auto()

    # === HELMETS ===
    HELM_OF_THE_ALABASTER_UNICORN = auto()
    SKULL_HELMET = auto()
    HELM_OF_CHAOS = auto()
    CROWN_OF_THE_SUPREME_MAGI = auto()
    HELLSTORM_HELMET = auto()
    CROWN_OF_THE_FIVE_SEAS = auto()
    CROWN_OF_DRAGONTOOTH = auto()
    THUNDER_HELMET = auto()
    HELM_OF_HEAVENLY_ENLIGHTENMENT = auto()

    # === BOOTS ===
    DRAGONBONE_GREAVES = auto()
    SANDALS_OF_THE_SAINT = auto()
    BOOTS_OF_SPEED = auto()

    # === CAPES ===
    CAPE_OF_CONJURING = auto()
    DRAGON_WING_TABARD = auto()
    VAMPIRES_COWL = auto()
    CAPE_OF_VELOCITY = auto()
    EVERFLOWING_CRYSTAL_CLOAK = auto()
    ANGEL_WINGS = auto()

    # === NECKLACES ===
    COLLAR_OF_CONJURING = auto()
    PENDANT_OF_DISPASSION = auto()
    PENDANT_OF_FREE_WILL = auto()
    PENDANT_OF_HOLINESS = auto()
    AMULET_OF_THE_UNDERTAKER = auto()
    PENDANT_OF_LIFE = auto()
    PENDANT_OF_DEATH = auto()
    PENDANT_OF_TOTAL_RECALL = auto()
    NECKLACE_OF_SWIFTNESS = auto()
    NECKLACE_OF_DRAGONTEETH = auto()
    CELESTIAL_NECKLACE_OF_BLISS = auto()
    GARNITURE_OF_INTERFERENCE = auto()
    PENDANT_OF_COURAGE = auto()
    PENDANT_OF_NEGATIVITY = auto()

    # === RINGS ===
    STILL_EYE_OF_THE_DRAGON = auto()
    QUIET_EYE_OF_THE_DRAGON = auto()
    RING_OF_CONJURING = auto()
    EQUESTRIANS_GLOVES = auto()
    RING_OF_THE_WAYFARER = auto()
    RING_OF_VITALITY = auto()
    RING_OF_LIFE = auto()
    RING_OF_INFINITE_GEMS = auto()
    EVERSMOKING_RING_OF_SULFUR = auto()

    # === MISC ===
    CLOVER_OF_FORTUNE = auto()
    LADYBIRD_OF_LUCK = auto()
    CARDS_OF_PROPHECY = auto()
    GLYPH_OF_GALLANTRY = auto()
    CREST_OF_VALOR = auto()
    BADGE_OF_COURAGE = auto()
    SPIRIT_OF_OPPRESSION = auto()
    HOURGLASS_OF_THE_EVIL_HOUR = auto()
    SPYGLASS = auto()
    SPECULUM = auto()
    CHARM_OF_MANA = auto()
    TALISMAN_OF_MANA = auto()
    MYSTIC_ORB_OF_MANA = auto()
    ORB_OF_SILT = auto()
    ORB_OF_THE_FIRMAMENT = auto()
    ORB_OF_DRIVING_RAIN = auto()
    ORB_OF_TEMPESTUOUS_FIRE = auto()
    ORB_OF_INHIBITION = auto()
    GOLDEN_BOW = auto()
    BIRD_OF_PERCEPTION = auto()
    STOIC_WATCHMAN = auto()
    EMBLEM_OF_COGNIZANCE = auto()
    HIDEOUS_MASK = auto()
    RUNES_OF_IMMINENCY = auto()
    DEMONS_HORSESHOE = auto()
    SHAMANS_PUPPET = auto()
    RING_OF_SUPPRESSION = auto()


@dataclass(frozen=True)
class ArtifactDef:
    """Immutable definition of an artifact."""

    artifact_id: ArtifactId
    name: str
    slot: ArtifactSlot
    artifact_class: ArtifactClass
    description: str
    # Stat bonuses (additive)
    attack: int = 0
    defense: int = 0
    spell_power: int = 0
    knowledge: int = 0
    morale: int = 0
    luck: int = 0
    # Adventure bonuses
    movement_bonus: int = 0
    scouting_bonus: int = 0
    # Combat bonuses
    combat_speed_bonus: int = 0
    # AI value for prioritization
    ai_value: int = 0


@dataclass
class ArtifactInstance:
    """A specific artifact held by a hero."""

    artifact_id: ArtifactId

    @property
    def definition(self) -> ArtifactDef:
        from lops.data.artifacts import ARTIFACT_REGISTRY

        return ARTIFACT_REGISTRY[self.artifact_id]

    @property
    def slot(self) -> ArtifactSlot:
        return self.definition.slot

    @property
    def name(self) -> str:
        return self.definition.name
