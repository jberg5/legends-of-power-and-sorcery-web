"""AI opponent that chooses actions for the computer player."""

from __future__ import annotations

from lops.actions import ActionType, CombatAction
from lops.ai.evaluation import score_targets
from lops.hex import CubeCoord, cube_distance
from lops.models import CreatureStack, Side


class AIOpponent:
    """Heuristic-based AI that picks the highest-scoring valid action."""

    def __init__(self, engine, side: Side = Side.DEFENDER):
        self.engine = engine
        self.side = side

    def take_turn(self):
        """Execute the best action for the current stack."""
        engine = self.engine
        stack = engine.current_stack

        if not stack or not stack.alive or stack.side != self.side:
            return

        action = self._choose_action(stack)
        if action:
            engine.execute_action(action)

    def _choose_action(self, stack: CreatureStack) -> CombatAction | None:
        engine = self.engine

        # Consider casting a spell before physical action
        spell_action = self._consider_spell(stack)
        if spell_action is not None:
            return spell_action

        valid_attacks = engine.get_valid_attacks(stack)
        valid_moves = engine.get_valid_moves(stack)

        # Ranged attack: shoot the best target (unless Forgetfulness debuff)
        if (
            stack.stats.is_ranged
            and stack.shots_left > 0
            and not stack.is_ranged_disabled
            and valid_attacks
        ):
            target = self._pick_best_target(stack, valid_attacks)
            return CombatAction(
                action_type=ActionType.RANGED_ATTACK,
                actor=stack,
                target=target,
            )

        # Melee: find best target we can reach
        if valid_attacks:
            target = self._pick_best_target(stack, valid_attacks)
            # Find the best attack position
            positions = engine.get_melee_positions(target)
            if positions:
                # Prefer current position if adjacent, otherwise closest
                if stack.position in positions:
                    dest = stack.position
                else:
                    assert stack.position is not None
                    spos: CubeCoord = stack.position
                    dest = min(
                        positions, key=lambda p: cube_distance(p, spos)
                    )
                return CombatAction(
                    action_type=ActionType.MELEE_ATTACK,
                    actor=stack,
                    target=target,
                    destination=dest,
                )

        # No attacks available: move toward closest enemy
        if valid_moves:
            enemy_army = engine.battlefield.get_enemy_army(stack.side)
            enemies = enemy_army.alive_stacks
            if enemies:
                assert stack.position is not None
                cur_pos: CubeCoord = stack.position
                closest_enemy = min(
                    enemies, key=lambda e: cube_distance(cur_pos, e.position)
                )
                # Move as close as possible
                best_pos = min(
                    valid_moves.keys(),
                    key=lambda p: cube_distance(p, closest_enemy.position),
                )
                return CombatAction(
                    action_type=ActionType.MOVE,
                    actor=stack,
                    destination=best_pos,
                )

        # Can't do anything useful — defend
        return CombatAction(action_type=ActionType.DEFEND, actor=stack)

    def _consider_spell(self, stack: CreatureStack) -> CombatAction | None:
        """Consider casting a spell. Returns CombatAction or None."""
        hero = self.engine.get_hero(self.side)
        if not hero or not hero.spells or hero.has_cast_this_round:
            return None

        from lops.data.spells import SPELL_REGISTRY
        from lops.spells import (
            SpellEffect,
            SpellTarget,
            calculate_spell_damage,
            create_buff_from_template,
            get_mana_cost,
            get_spell_targets,
        )

        best_score = 5.0  # minimum threshold to avoid wasting mana
        best_action = None

        bf = self.engine.battlefield
        enemy_army = bf.get_enemy_army(self.side)
        friendly_army = bf.get_army(self.side)

        for spell_id in hero.spells:
            spell = SPELL_REGISTRY.get(spell_id)
            if spell is None:
                continue

            mana_cost = get_mana_cost(hero, spell)
            if hero.mana < mana_cost:
                continue

            # Skip adventure-only spells
            if spell.effect == SpellEffect.ADVENTURE:
                continue

            if spell.effect == SpellEffect.DAMAGE:
                # Score damage spells: expected kills * unit value
                damage = calculate_spell_damage(spell, hero)

                if spell.target_type in (SpellTarget.SINGLE_ENEMY,):
                    for target in enemy_army.alive_stacks:
                        kills = min(target.count, damage // max(1, target.stats.hp))
                        score = kills * target.stats.hp * 0.5
                        if score > best_score:
                            best_score = score
                            best_action = CombatAction(
                                action_type=ActionType.CAST_SPELL,
                                actor=stack,
                                target=target,
                                spell=spell,
                            )

                elif spell.target_type in (SpellTarget.ALL_ENEMY,):
                    # Target any enemy to indicate the side
                    if enemy_army.alive_stacks:
                        total_kills = 0
                        for t in enemy_army.alive_stacks:
                            total_kills += min(t.count, damage // max(1, t.stats.hp))
                        score = total_kills * 5.0
                        if score > best_score:
                            best_score = score
                            best_action = CombatAction(
                                action_type=ActionType.CAST_SPELL,
                                actor=stack,
                                target=enemy_army.alive_stacks[0],
                                spell=spell,
                            )

                elif spell.target_type == SpellTarget.ALL:
                    # Armageddon: damages everyone, only use if we're way ahead
                    if enemy_army.alive_stacks and friendly_army.alive_stacks:
                        enemy_hp = sum(t.total_hp for t in enemy_army.alive_stacks)
                        friendly_hp = sum(
                            t.total_hp for t in friendly_army.alive_stacks
                        )
                        if friendly_hp > enemy_hp * 2:
                            total_kills = 0
                            for t in enemy_army.alive_stacks:
                                total_kills += min(
                                    t.count, damage // max(1, t.stats.hp)
                                )
                            score = total_kills * 3.0
                            if score > best_score:
                                best_score = score
                                best_action = CombatAction(
                                    action_type=ActionType.CAST_SPELL,
                                    actor=stack,
                                    target=enemy_army.alive_stacks[0],
                                    spell=spell,
                                )

                elif spell.target_type in (SpellTarget.AREA, SpellTarget.RING):
                    # Find the target that hits the most enemies
                    for target in enemy_army.alive_stacks:
                        targets = get_spell_targets(spell, hero, target, bf)
                        total_kills = 0
                        for t in targets:
                            total_kills += min(t.count, damage // max(1, t.stats.hp))
                        score = total_kills * 5.0
                        # Penalize friendly fire
                        for t in targets:
                            if t.side == self.side:
                                score -= min(t.count, damage // max(1, t.stats.hp)) * 10
                        if score > best_score:
                            best_score = score
                            best_action = CombatAction(
                                action_type=ActionType.CAST_SPELL,
                                actor=stack,
                                target=target,
                                spell=spell,
                            )

            elif spell.effect == SpellEffect.CHAIN_DAMAGE:
                # Chain Lightning: value total damage across chain
                damage = calculate_spell_damage(spell, hero)
                if enemy_army.alive_stacks:
                    # Estimate: hit 4 targets with halving damage
                    total_score = 0
                    current_dmg = damage
                    for target in sorted(
                        enemy_army.alive_stacks, key=lambda t: -t.total_hp
                    )[:4]:
                        kills = min(
                            target.count, current_dmg // max(1, target.stats.hp)
                        )
                        total_score += kills * target.stats.hp * 0.4
                        current_dmg //= 2
                    if total_score > best_score:
                        best_score = total_score
                        best_action = CombatAction(
                            action_type=ActionType.CAST_SPELL,
                            actor=stack,
                            target=enemy_army.alive_stacks[0],
                            spell=spell,
                        )

            elif spell.effect == SpellEffect.RESURRECT:
                # Resurrection: value = HP revived
                hp_to_restore = calculate_spell_damage(spell, hero)
                for target in friendly_army.stacks:
                    if target.alive and target.count < 10:  # lost some creatures
                        creatures_back = hp_to_restore // max(1, target.stats.hp)
                        if creatures_back > 0:
                            value = creatures_back * target.stats.hp * 0.5
                            if value > best_score:
                                best_score = value
                                best_action = CombatAction(
                                    action_type=ActionType.CAST_SPELL,
                                    actor=stack,
                                    target=target,
                                    spell=spell,
                                )

            elif spell.effect == SpellEffect.BUFF:
                # Buff the strongest unbuffed ally
                for target in friendly_army.alive_stacks:
                    if any(b.spell_id == spell.spell_id for b in target.active_buffs):
                        continue
                    # Score: unit value * buff impact
                    value = target.count * target.stats.hp * 0.1
                    buff = create_buff_from_template(spell, hero)
                    value += abs(buff.speed_mod) * target.count * 0.5
                    value += abs(buff.attack_mod) * target.count * 0.3
                    value += abs(buff.defense_mod) * target.count * 0.3
                    if buff.deal_max_damage:
                        value += (
                            target.count
                            * (target.stats.max_damage - target.stats.min_damage)
                            * 0.5
                        )
                    if buff.fire_shield_reflect > 0:
                        value += target.count * target.stats.hp * 0.15
                    if buff.extra_retaliations > 0:
                        value += target.count * 3.0
                    if buff.morale_mod > 0:
                        value += target.count * buff.morale_mod * 0.5
                    if buff.luck_mod > 0:
                        value += target.count * buff.luck_mod * 0.5
                    if value > best_score:
                        best_score = value
                        best_action = CombatAction(
                            action_type=ActionType.CAST_SPELL,
                            actor=stack,
                            target=target,
                            spell=spell,
                        )

            elif spell.effect == SpellEffect.DEBUFF:
                # Debuff the strongest unbuffed enemy
                for target in enemy_army.alive_stacks:
                    if any(b.spell_id == spell.spell_id for b in target.active_buffs):
                        continue
                    value = target.count * target.stats.hp * 0.1
                    buff = create_buff_from_template(spell, hero)
                    value += abs(buff.speed_mod) * target.count * 0.5
                    value += abs(buff.attack_mod) * target.count * 0.3
                    if buff.is_blinded:
                        value += target.count * target.stats.hp * 0.3
                    if buff.disable_ranged and target.stats.is_ranged:
                        value += target.count * target.stats.hp * 0.4
                    if buff.morale_mod < 0:
                        value += target.count * abs(buff.morale_mod) * 0.5
                    if buff.luck_mod < 0:
                        value += target.count * abs(buff.luck_mod) * 0.5
                    if value > best_score:
                        best_score = value
                        best_action = CombatAction(
                            action_type=ActionType.CAST_SPELL,
                            actor=stack,
                            target=target,
                            spell=spell,
                        )

            elif spell.effect == SpellEffect.EARTHQUAKE:
                # Only useful in siege
                if bf.is_siege:
                    walls = bf.siege_info.destructible_walls()
                    if walls:
                        score = len(walls) * 10.0
                        if score > best_score:
                            best_score = score
                            # Target any enemy for action
                            target = (
                                enemy_army.alive_stacks[0]
                                if enemy_army.alive_stacks
                                else None
                            )
                            if target:
                                best_action = CombatAction(
                                    action_type=ActionType.CAST_SPELL,
                                    actor=stack,
                                    target=target,
                                    spell=spell,
                                )

        return best_action

    def _pick_best_target(
        self, attacker: CreatureStack, targets: list[CreatureStack]
    ) -> CreatureStack:
        scored = score_targets(attacker, targets, self.engine.battlefield)
        return scored[0][0] if scored else targets[0]
