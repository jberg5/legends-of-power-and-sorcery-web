"""Target priority scoring and damage estimation for AI."""

from __future__ import annotations

from lops.damage import calculate_damage_range
from lops.models import Battlefield, CreatureStack


def score_targets(
    attacker: CreatureStack,
    targets: list[CreatureStack],
    battlefield: Battlefield,
) -> list[tuple[CreatureStack, float]]:
    """Score and rank targets by priority.

    Scoring heuristics:
    - Prefer targets we can one-shot (kill all creatures)
    - Prefer high-threat targets (high damage output)
    - Weight by retaliation risk
    """
    scored = []
    for target in targets:
        score = _score_target(attacker, target, battlefield)
        scored.append((target, score))

    scored.sort(key=lambda x: -x[1])
    return scored


def _score_target(
    attacker: CreatureStack,
    target: CreatureStack,
    battlefield: Battlefield,
) -> float:
    """Score a single target."""
    min_dmg, max_dmg = calculate_damage_range(attacker, target)
    avg_dmg = (min_dmg + max_dmg) / 2

    # Can we kill the stack?
    can_kill = avg_dmg >= target.total_hp

    # Threat level: how much damage can this target do?
    threat = target.effective_max_damage * target.count

    # Retaliation risk: how much damage will we take if we melee?
    ret_min, ret_max = calculate_damage_range(target, attacker)
    retaliation_risk = (ret_min + ret_max) / 2

    score = 0.0

    # Big bonus for one-shotting
    if can_kill:
        score += 1000 + threat

    # Damage efficiency (damage dealt / target total HP)
    if target.total_hp > 0:
        score += (avg_dmg / target.total_hp) * 100

    # Threat-based priority
    score += threat * 0.5

    # Penalize high retaliation risk for melee
    if not attacker.stats.is_ranged:
        score -= retaliation_risk * 0.3

    return score
