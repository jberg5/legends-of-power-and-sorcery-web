"""Combat action definitions."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto

from lops.hex import CubeCoord
from lops.models import CreatureStack


class ActionType(Enum):
    MOVE = auto()
    MELEE_ATTACK = auto()
    RANGED_ATTACK = auto()
    WAIT = auto()
    DEFEND = auto()
    CAST_SPELL = auto()


@dataclass
class CombatAction:
    action_type: ActionType
    actor: CreatureStack
    destination: CubeCoord | None = None  # for MOVE and MELEE_ATTACK
    target: CreatureStack | None = None  # for attacks and spells
    path: list[CubeCoord] | None = None  # movement path for animation
    spell: object | None = None  # for CAST_SPELL
