"""Spell system: enums, dataclasses, and helper functions for HoMM3 magic."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto


class MagicSchool(Enum):
    AIR = auto()
    EARTH = auto()
    FIRE = auto()
    WATER = auto()


class SpellId(Enum):
    # Level 1
    MAGIC_ARROW = auto()
    HASTE = auto()
    SLOW = auto()
    BLESS = auto()
    CURSE = auto()
    BLOODLUST = auto()
    STONE_SKIN = auto()
    CURE = auto()
    SHIELD = auto()
    DISRUPTING_RAY = auto()
    PROTECTION_FROM_AIR = auto()
    PROTECTION_FROM_FIRE = auto()
    PROTECTION_FROM_WATER = auto()
    PROTECTION_FROM_EARTH = auto()
    VISIONS = auto()
    # Level 2
    LIGHTNING_BOLT = auto()
    PRECISION = auto()
    WEAKNESS = auto()
    FORTUNE = auto()
    DISPEL = auto()
    ICE_BOLT = auto()
    FIRE_WALL = auto()
    MISFORTUNE = auto()
    REMOVE_OBSTACLE = auto()
    # Level 3
    FIREBALL = auto()
    FROST_RING = auto()
    BLIND = auto()
    DEATH_RIPPLE = auto()
    DESTROY_UNDEAD = auto()
    AIR_SHIELD = auto()
    HYPNOTIZE = auto()
    FORGETFULNESS = auto()
    MIRTH = auto()
    SORROW = auto()
    ANIMATE_DEAD = auto()
    ANTI_MAGIC = auto()
    EARTHQUAKE = auto()
    TELEPORT = auto()
    # Level 4
    CHAIN_LIGHTNING = auto()
    COUNTERSTRIKE = auto()
    METEOR_SHOWER = auto()
    RESURRECTION = auto()
    ARMAGEDDON = auto()
    INFERNO = auto()
    BERSERK = auto()
    FIRE_SHIELD = auto()
    SLAYER = auto()
    PRAYER = auto()
    TOWN_PORTAL = auto()
    # Level 5
    IMPLOSION = auto()
    SUMMON_AIR_ELEMENTAL = auto()
    SUMMON_EARTH_ELEMENTAL = auto()
    SUMMON_FIRE_ELEMENTAL = auto()
    SUMMON_WATER_ELEMENTAL = auto()
    DIMENSION_DOOR = auto()
    FLY = auto()
    WATER_WALK = auto()


class SpellTarget(Enum):
    SINGLE_ENEMY = auto()
    SINGLE_FRIENDLY = auto()
    AREA = auto()
    ALL_ENEMY = auto()
    ALL_FRIENDLY = auto()
    RING = auto()  # ring around target hex (not center)
    ALL = auto()  # both sides (Armageddon)
    HEX = auto()  # target a hex, not a stack (Teleport, Land Mine)


class SpellEffect(Enum):
    DAMAGE = auto()
    BUFF = auto()
    DEBUFF = auto()
    HEAL = auto()
    DISPEL = auto()
    RESURRECT = auto()
    CHAIN_DAMAGE = auto()
    TELEPORT = auto()
    SUMMON = auto()
    ADVENTURE = auto()
    EARTHQUAKE = auto()


class Mastery(Enum):
    NONE = 0
    BASIC = 1
    ADVANCED = 2
    EXPERT = 3


@dataclass(frozen=True)
class BuffTemplate:
    """Per-mastery buff modifiers. Each tuple is (none, basic, adv, expert)."""

    attack_mod: tuple[int, int, int, int] = (0, 0, 0, 0)
    defense_mod: tuple[int, int, int, int] = (0, 0, 0, 0)
    speed_mod: tuple[int, int, int, int] = (0, 0, 0, 0)
    damage_mod: tuple[int, int, int, int] = (0, 0, 0, 0)
    deal_max_damage: bool = False  # Bless
    deal_min_damage: bool = False  # Curse
    melee_damage_reduction: tuple[float, float, float, float] = (
        0.0,
        0.0,
        0.0,
        0.0,
    )  # Shield
    is_blinded: bool = False  # Blind
    ranged_damage_reduction: tuple[float, float, float, float] = (
        0.0,
        0.0,
        0.0,
        0.0,
    )  # Air Shield
    fire_shield_reflect: tuple[float, float, float, float] = (
        0.0,
        0.0,
        0.0,
        0.0,
    )  # Fire Shield
    morale_mod: tuple[int, int, int, int] = (0, 0, 0, 0)  # Mirth / Sorrow
    luck_mod: tuple[int, int, int, int] = (0, 0, 0, 0)  # Fortune / Misfortune
    disable_ranged: bool = False  # Forgetfulness
    extra_retaliations: tuple[int, int, int, int] = (0, 0, 0, 0)  # Counterstrike
    spell_immunity_level: tuple[int, int, int, int] = (0, 0, 0, 0)  # Anti-Magic
    spell_damage_reduction: tuple[float, float, float, float] = (
        0.0,
        0.0,
        0.0,
        0.0,
    )  # Protection spells


@dataclass(frozen=True)
class Spell:
    """Full spell definition with per-mastery values."""

    spell_id: SpellId
    name: str
    level: int  # 1-5
    school: MagicSchool
    target_type: SpellTarget
    effect: SpellEffect
    base_values: tuple[int, int, int, int] = (0, 0, 0, 0)  # per-mastery damage/heal
    power_multiplier: int = 0  # spell_power * this added to base
    mana_costs: tuple[int, int] = (0, 0)  # (without school, with school)
    duration: int = 0  # 0=instant, -1=spell_power rounds, >0=fixed
    area_radius: int = 0
    buff_template: BuffTemplate | None = None
    description: str = ""


@dataclass
class Buff:
    """Active buff/debuff on a creature stack."""

    spell_id: SpellId
    name: str
    remaining_rounds: int
    mastery: Mastery = Mastery.NONE
    attack_mod: int = 0
    defense_mod: int = 0
    speed_mod: int = 0
    damage_mod: int = 0
    deal_max_damage: bool = False
    deal_min_damage: bool = False
    melee_damage_reduction: float = 0.0
    is_blinded: bool = False
    ranged_damage_reduction: float = 0.0
    fire_shield_reflect: float = 0.0
    morale_mod: int = 0
    luck_mod: int = 0
    disable_ranged: bool = False
    extra_retaliations: int = 0
    spell_immunity_level: int = 0
    spell_damage_reduction: float = 0.0


# --- Helper functions (pure logic, no pygame) ---


def _school_to_skill_id(school: MagicSchool):
    """Map MagicSchool to the corresponding SkillId."""
    from lops.skills import SkillId

    return {
        MagicSchool.AIR: SkillId.AIR_MAGIC,
        MagicSchool.EARTH: SkillId.EARTH_MAGIC,
        MagicSchool.FIRE: SkillId.FIRE_MAGIC,
        MagicSchool.WATER: SkillId.WATER_MAGIC,
    }[school]


def get_mastery(hero, spell: Spell) -> Mastery:
    """Get the hero's mastery level for the spell's magic school."""
    if hero is None:
        return Mastery.NONE
    skill_id = _school_to_skill_id(spell.school)
    level = hero.skill_level(skill_id)
    return Mastery(min(level, 3))


def get_mana_cost(hero, spell: Spell) -> int:
    """Get mana cost: reduced cost if hero has the spell's school skill."""
    mastery = get_mastery(hero, spell)
    if mastery.value >= 1:
        return spell.mana_costs[1]  # with school
    return spell.mana_costs[0]  # without school


def calculate_spell_damage(spell: Spell, hero) -> int:
    """Calculate spell damage: base_values[mastery] + spell_power * multiplier."""
    mastery = get_mastery(hero, spell)
    base = spell.base_values[mastery.value]
    sp = hero.effective_spell_power() if hero else 0
    return base + sp * spell.power_multiplier


def create_buff_from_template(spell: Spell, hero) -> Buff:
    """Create a Buff instance from a spell's BuffTemplate at the hero's mastery."""
    mastery = get_mastery(hero, spell)
    m = mastery.value
    bt = spell.buff_template

    if spell.duration == -1:
        sp = hero.effective_spell_power() if hero else 1
        duration = max(1, sp)
    elif spell.duration > 0:
        duration = spell.duration
    else:
        duration = 1

    if bt is None:
        return Buff(
            spell_id=spell.spell_id,
            name=spell.name,
            remaining_rounds=duration,
            mastery=mastery,
        )

    return Buff(
        spell_id=spell.spell_id,
        name=spell.name,
        remaining_rounds=duration,
        mastery=mastery,
        attack_mod=bt.attack_mod[m],
        defense_mod=bt.defense_mod[m],
        speed_mod=bt.speed_mod[m],
        damage_mod=bt.damage_mod[m],
        deal_max_damage=bt.deal_max_damage,
        deal_min_damage=bt.deal_min_damage,
        melee_damage_reduction=bt.melee_damage_reduction[m],
        is_blinded=bt.is_blinded,
        ranged_damage_reduction=bt.ranged_damage_reduction[m],
        fire_shield_reflect=bt.fire_shield_reflect[m],
        morale_mod=bt.morale_mod[m],
        luck_mod=bt.luck_mod[m],
        disable_ranged=bt.disable_ranged,
        extra_retaliations=bt.extra_retaliations[m],
        spell_immunity_level=bt.spell_immunity_level[m],
        spell_damage_reduction=bt.spell_damage_reduction[m],
    )


def is_mass_cast(spell: Spell, hero) -> bool:
    """At Expert mastery, single-target buffs/debuffs become mass casts."""
    if spell.target_type not in (SpellTarget.SINGLE_FRIENDLY, SpellTarget.SINGLE_ENEMY):
        return False
    if spell.effect not in (
        SpellEffect.BUFF,
        SpellEffect.DEBUFF,
        SpellEffect.HEAL,
        SpellEffect.DISPEL,
    ):
        return False
    mastery = get_mastery(hero, spell)
    return mastery == Mastery.EXPERT


def get_spell_targets(spell: Spell, hero, target_stack, battlefield) -> list:
    """Resolve the actual targets for a spell cast.

    Returns a list of CreatureStack targets.
    """
    from lops.hex import hexes_in_radius

    caster_side = None
    for stack in battlefield.alive_stacks:
        if stack is target_stack:
            caster_side = hero  # we need to know who is casting
            break

    # Mass cast at Expert
    if is_mass_cast(spell, hero):
        if spell.target_type == SpellTarget.SINGLE_FRIENDLY:
            army = battlefield.get_army(target_stack.side)
            return [s for s in army.alive_stacks]
        elif spell.target_type == SpellTarget.SINGLE_ENEMY:
            army = battlefield.get_army(target_stack.side)
            return [s for s in army.alive_stacks]

    # Area spells (Fireball): hit all stacks within radius of target position
    if spell.target_type == SpellTarget.AREA and target_stack.position:
        area = hexes_in_radius(target_stack.position, spell.area_radius)
        return [s for s in battlefield.alive_stacks if s.position in area]

    # Ring spells (Frost Ring): hit stacks at distance exactly == radius
    if spell.target_type == SpellTarget.RING and target_stack.position:
        from lops.hex import cube_distance

        return [
            s
            for s in battlefield.alive_stacks
            if s.position
            and cube_distance(s.position, target_stack.position) == spell.area_radius
        ]

    # ALL_ENEMY: target_stack is on the enemy side; return all stacks on that side
    if spell.target_type == SpellTarget.ALL_ENEMY:
        army = battlefield.get_army(target_stack.side)
        return [s for s in army.alive_stacks]

    # ALL_FRIENDLY: target_stack is on the caster's side
    if spell.target_type == SpellTarget.ALL_FRIENDLY:
        army = battlefield.get_army(target_stack.side)
        return [s for s in army.alive_stacks]

    # ALL: both sides (Armageddon)
    if spell.target_type == SpellTarget.ALL:
        return list(battlefield.alive_stacks)

    # Single target
    return [target_stack]


def spell_detail_lines(spell: Spell, hero) -> list[str]:
    """Generate contextual description lines for the spellbook tooltip.

    Shows the spell description plus computed values at the hero's mastery.
    """
    lines = []

    # Base description
    if spell.description:
        lines.append(spell.description)

    mastery = get_mastery(hero, spell)
    mastery_name = mastery.name.capitalize() if mastery != Mastery.NONE else "None"
    lines.append(f"School mastery: {mastery_name}")

    # Effect-specific details
    if spell.effect == SpellEffect.DAMAGE:
        dmg = calculate_spell_damage(spell, hero)
        lines.append(f"Damage: {dmg}")
        if spell.target_type == SpellTarget.AREA:
            lines.append(f"Area: radius {spell.area_radius} (hits allies too)")
        elif spell.target_type == SpellTarget.RING:
            lines.append(f"Ring: radius {spell.area_radius}")
        elif spell.target_type == SpellTarget.ALL_ENEMY:
            lines.append("Hits all enemy creatures")

    elif spell.effect == SpellEffect.HEAL:
        heal = calculate_spell_damage(spell, hero)
        lines.append(f"Heals: {heal} HP")
        lines.append("Also removes negative effects")

    elif spell.effect in (SpellEffect.BUFF, SpellEffect.DEBUFF):
        bt = spell.buff_template
        m = mastery.value
        if bt:
            parts = []
            if bt.attack_mod[m] != 0:
                parts.append(f"ATK {bt.attack_mod[m]:+d}")
            if bt.defense_mod[m] != 0:
                parts.append(f"DEF {bt.defense_mod[m]:+d}")
            if bt.speed_mod[m] != 0:
                parts.append(f"SPD {bt.speed_mod[m]:+d}")
            if bt.deal_max_damage:
                parts.append("Creatures deal max damage")
            if bt.deal_min_damage:
                parts.append("Creatures deal min damage")
            if bt.melee_damage_reduction[m] > 0:
                pct = int(bt.melee_damage_reduction[m] * 100)
                parts.append(f"-{pct}% melee damage taken")
            if bt.ranged_damage_reduction[m] > 0:
                pct = int(bt.ranged_damage_reduction[m] * 100)
                parts.append(f"-{pct}% ranged damage taken")
            if bt.fire_shield_reflect[m] > 0:
                pct = int(bt.fire_shield_reflect[m] * 100)
                parts.append(f"Reflects {pct}% melee damage")
            if bt.morale_mod[m] != 0:
                parts.append(f"Morale {bt.morale_mod[m]:+d}")
            if bt.luck_mod[m] != 0:
                parts.append(f"Luck {bt.luck_mod[m]:+d}")
            if bt.is_blinded:
                parts.append("Target skips next turn")
            if bt.disable_ranged:
                parts.append("Disables ranged attacks")
            if bt.extra_retaliations[m] > 0:
                parts.append(f"+{bt.extra_retaliations[m]} retaliations")
            if bt.spell_immunity_level[m] > 0:
                parts.append(
                    f"Immune to spells lv {bt.spell_immunity_level[m]} and below"
                )
            if bt.spell_damage_reduction[m] > 0:
                pct = int(bt.spell_damage_reduction[m] * 100)
                parts.append(f"-{pct}% spell damage")
            if parts:
                lines.append(", ".join(parts))

        # Duration
        if spell.duration == -1:
            sp = hero.effective_spell_power() if hero else 1
            lines.append(f"Duration: {max(1, sp)} rounds")
        elif spell.duration > 0:
            lines.append(f"Duration: {spell.duration} rounds")

    elif spell.effect == SpellEffect.DISPEL:
        lines.append("Removes all effects from target")

    # Mass cast note
    if is_mass_cast(spell, hero):
        lines.append("Expert: affects all targets!")

    return lines
