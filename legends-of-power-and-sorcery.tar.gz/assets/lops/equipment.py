"""Hero equipment: manages equipped artifacts and backpack."""

from __future__ import annotations

from dataclasses import dataclass, field

from lops.artifacts import SLOT_CAPACITY, ArtifactInstance, ArtifactSlot


@dataclass
class HeroEquipment:
    """Manages a hero's equipped artifacts and backpack."""

    equipped: dict[tuple[ArtifactSlot, int], ArtifactInstance] = field(
        default_factory=dict
    )
    backpack: list[ArtifactInstance] = field(default_factory=list)

    def equip(self, artifact: ArtifactInstance) -> ArtifactInstance | None:
        """Equip artifact to its slot. Returns displaced artifact or None.

        Finds the first empty matching slot. If all slots full, displaces
        the lowest ai_value artifact in that slot type.
        """
        slot = artifact.slot
        capacity = SLOT_CAPACITY[slot]

        # Find first empty index
        for idx in range(capacity):
            key = (slot, idx)
            if key not in self.equipped:
                self.equipped[key] = artifact
                return None

        # All slots full — displace lowest value
        worst_key = None
        worst_val = float("inf")
        for idx in range(capacity):
            key = (slot, idx)
            existing = self.equipped.get(key)
            if existing is not None and existing.definition.ai_value < worst_val:
                worst_val = existing.definition.ai_value
                worst_key = key

        if worst_key is not None:
            # Only displace if incoming is better
            if artifact.definition.ai_value > worst_val:
                displaced = self.equipped[worst_key]
                self.equipped[worst_key] = artifact
                self.backpack.append(displaced)
                return displaced
            else:
                # Incoming is worse — put in backpack
                self.backpack.append(artifact)
                return None

        return None

    def unequip(self, slot: ArtifactSlot, index: int = 0) -> ArtifactInstance | None:
        """Remove artifact from slot and move to backpack."""
        key = (slot, index)
        artifact = self.equipped.pop(key, None)
        if artifact is not None:
            self.backpack.append(artifact)
        return artifact

    def equip_from_backpack(self, backpack_index: int) -> bool:
        """Equip an artifact from the backpack. Returns True on success."""
        if backpack_index < 0 or backpack_index >= len(self.backpack):
            return False
        artifact = self.backpack.pop(backpack_index)
        self.equip(artifact)
        return True

    def all_equipped(self) -> list[ArtifactInstance]:
        """Return all currently equipped artifacts."""
        return list(self.equipped.values())

    def all_artifacts(self) -> list[ArtifactInstance]:
        """Return all artifacts (equipped + backpack)."""
        return self.all_equipped() + list(self.backpack)

    def equipped_in_slot(self, slot: ArtifactSlot) -> list[ArtifactInstance]:
        """Return artifacts equipped in a specific slot type."""
        result = []
        capacity = SLOT_CAPACITY[slot]
        for idx in range(capacity):
            art = self.equipped.get((slot, idx))
            if art is not None:
                result.append(art)
        return result

    def total_bonus(self, attr: str) -> int:
        """Sum a stat bonus across all equipped artifacts."""
        total = 0
        for art in self.equipped.values():
            total += getattr(art.definition, attr, 0)
        return total

    def has_artifact(self, artifact_id) -> bool:
        """Check if hero has a specific artifact (equipped or backpack)."""
        for art in self.all_artifacts():
            if art.artifact_id == artifact_id:
                return True
        return False
