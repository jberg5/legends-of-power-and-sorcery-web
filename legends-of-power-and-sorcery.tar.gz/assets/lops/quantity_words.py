"""HoMM3-style quantity descriptors for army preview."""

from __future__ import annotations


def quantity_word(count: int) -> str:
    """Return a HoMM3-style descriptive word for a creature count."""
    if count >= 1000:
        return "Legion"
    if count >= 500:
        return "Zounds"
    if count >= 250:
        return "Swarm"
    if count >= 100:
        return "Throng"
    if count >= 50:
        return "Horde"
    if count >= 20:
        return "Lots"
    if count >= 10:
        return "Pack"
    if count >= 5:
        return "Several"
    return "Few"
