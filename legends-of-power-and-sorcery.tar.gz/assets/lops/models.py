"""Core game models for tactical combat."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import TYPE_CHECKING

from lops.hex import BATTLEFIELD_ROWS, CubeCoord, OffsetCoord, offset_to_cube

if TYPE_CHECKING:
    from lops.equipment import HeroEquipment
    from lops.siege import SiegeInfo
    from lops.skills import HeroSkill, SkillId
    from lops.spells import Buff, SpellId


class Side(Enum):
    ATTACKER = auto()
    DEFENDER = auto()


@dataclass(frozen=True, slots=True)
class CreatureStats:
    """Immutable base stats for a creature type."""

    name: str
    attack: int
    defense: int
    min_damage: int
    max_damage: int
    hp: int
    speed: int
    is_ranged: bool = False
    is_flying: bool = False
    shots: int = 0  # 0 = melee unit
    # Special abilities are flags
    double_strike: bool = False
    jousting: bool = False
    unlimited_retaliation: bool = False


@dataclass
class CreatureStack:
    """A stack of creatures in combat — mutable combat state."""

    stats: CreatureStats
    count: int
    current_hp: int  # HP of the top creature
    position: CubeCoord | None = None
    side: Side = Side.ATTACKER
    slot_index: int = 0

    # Combat state
    has_moved: bool = False
    has_attacked: bool = False
    has_retaliated: bool = False
    is_waiting: bool = False
    is_defending: bool = False
    shots_left: int = 0
    active_buffs: list[Buff] = field(default_factory=list)

    # Morale/luck
    had_morale_bonus: bool = False

    # Siege state
    in_moat: bool = False

    # Retaliation tracking
    _retaliation_count: int = 0

    @property
    def alive(self) -> bool:
        return self.count > 0

    @property
    def total_hp(self) -> int:
        """Total remaining HP across all creatures in the stack."""
        if self.count <= 0:
            return 0
        return (self.count - 1) * self.stats.hp + self.current_hp

    @property
    def effective_attack(self) -> int:
        base = self.stats.attack
        for buff in self.active_buffs:
            base += buff.attack_mod
        return base

    @property
    def effective_defense(self) -> int:
        base = self.stats.defense
        if self.is_defending:
            base = int(base * 1.2)
        for buff in self.active_buffs:
            base += buff.defense_mod
        return base

    @property
    def effective_speed(self) -> int:
        base = self.stats.speed
        for buff in self.active_buffs:
            base += buff.speed_mod
        return max(1, base)

    @property
    def effective_min_damage(self) -> int:
        base = self.stats.min_damage
        for buff in self.active_buffs:
            base += buff.damage_mod
            if buff.deal_max_damage:
                base = self.stats.max_damage + buff.damage_mod
        return max(1, base)

    @property
    def effective_max_damage(self) -> int:
        base = self.stats.max_damage
        for buff in self.active_buffs:
            base += buff.damage_mod
            if buff.deal_min_damage:
                base = self.stats.min_damage + buff.damage_mod
        return max(1, base)

    @property
    def buff_morale_mod(self) -> int:
        return sum(b.morale_mod for b in self.active_buffs)

    @property
    def buff_luck_mod(self) -> int:
        return sum(b.luck_mod for b in self.active_buffs)

    @property
    def is_ranged_disabled(self) -> bool:
        return any(b.disable_ranged for b in self.active_buffs)

    @property
    def total_extra_retaliations(self) -> int:
        return sum(b.extra_retaliations for b in self.active_buffs)

    @property
    def spell_immunity_level(self) -> int:
        return max((b.spell_immunity_level for b in self.active_buffs), default=0)

    def take_damage(self, damage: int) -> int:
        """Apply damage to the stack. Returns number of creatures killed."""
        if damage <= 0 or not self.alive:
            return 0

        old_count = self.count

        if damage >= self.current_hp:
            damage -= self.current_hp
            self.count -= 1
            if self.count > 0:
                full_kills = damage // self.stats.hp
                remainder = damage % self.stats.hp
                self.count -= full_kills
                if self.count <= 0:
                    self.count = 0
                    self.current_hp = 0
                else:
                    self.current_hp = self.stats.hp - remainder
                    if self.current_hp <= 0:
                        self.count -= 1
                        self.current_hp = (
                            self.stats.hp + self.current_hp
                        )  # current_hp is negative
                        if self.count <= 0:
                            self.count = 0
                            self.current_hp = 0
            else:
                self.current_hp = 0

        else:
            self.current_hp -= damage

        return old_count - self.count

    def reset_turn(self):
        """Reset per-turn flags at start of a new turn."""
        self.has_moved = False
        self.has_attacked = False
        self.is_waiting = False
        self.is_defending = False
        self.had_morale_bonus = False
        self.in_moat = False

    def reset_round(self):
        """Reset per-round flags at start of a new round."""
        self.reset_turn()
        self.has_retaliated = False
        self._retaliation_count = 0


@dataclass
class Hero:
    """A hero leading an army."""

    name: str
    attack: int = 0
    defense: int = 0
    spell_power: int = 0
    knowledge: int = 0
    mana: int = 0
    level: int = 1
    experience: int = 0
    spells: list[SpellId] = field(default_factory=list)
    skills: list[HeroSkill] = field(default_factory=list)
    equipment: HeroEquipment | None = None

    def __post_init__(self):
        if self.mana == 0:
            self.mana = self.knowledge * 10
        self.has_cast_this_round = False
        if self.equipment is None:
            from lops.equipment import HeroEquipment

            self.equipment = HeroEquipment()

    # --- Effective stats (base + artifact bonuses) ---

    def effective_attack(self) -> int:
        return self.attack + (
            self.equipment.total_bonus("attack") if self.equipment else 0
        )

    def effective_defense(self) -> int:
        return self.defense + (
            self.equipment.total_bonus("defense") if self.equipment else 0
        )

    def effective_spell_power(self) -> int:
        return self.spell_power + (
            self.equipment.total_bonus("spell_power") if self.equipment else 0
        )

    def effective_knowledge(self) -> int:
        return self.knowledge + (
            self.equipment.total_bonus("knowledge") if self.equipment else 0
        )

    def artifact_morale_bonus(self) -> int:
        return self.equipment.total_bonus("morale") if self.equipment else 0

    def artifact_luck_bonus(self) -> int:
        return self.equipment.total_bonus("luck") if self.equipment else 0

    def artifact_movement_bonus(self) -> int:
        return self.equipment.total_bonus("movement_bonus") if self.equipment else 0

    def artifact_scouting_bonus(self) -> int:
        return self.equipment.total_bonus("scouting_bonus") if self.equipment else 0

    def artifact_combat_speed_bonus(self) -> int:
        return self.equipment.total_bonus("combat_speed_bonus") if self.equipment else 0

    def get_skill(self, skill_id: SkillId) -> HeroSkill | None:
        """Get hero's HeroSkill by SkillId, or None if not learned."""
        for s in self.skills:
            if s.skill_id == skill_id:
                return s
        return None

    def has_skill(self, skill_id: SkillId) -> bool:
        return self.get_skill(skill_id) is not None

    def skill_value(self, skill_id: SkillId) -> float:
        """Get the effect value of a skill, or 0.0 if not learned."""
        s = self.get_skill(skill_id)
        return s.value if s is not None else 0.0

    def skill_level(self, skill_id: SkillId) -> int:
        """Get skill level as int: 0=unlearned, 1=Basic, 2=Advanced, 3=Expert."""
        s = self.get_skill(skill_id)
        return s.level.value if s is not None else 0


@dataclass
class Army:
    """An army: a hero and up to 7 creature stacks."""

    hero: Hero
    stacks: list[CreatureStack] = field(default_factory=list)
    side: Side = Side.ATTACKER

    def __post_init__(self):
        for i, stack in enumerate(self.stacks):
            stack.side = self.side
            stack.slot_index = i
            stack.shots_left = stack.stats.shots

    @property
    def alive_stacks(self) -> list[CreatureStack]:
        return [s for s in self.stacks if s.alive]

    @property
    def defeated(self) -> bool:
        return len(self.alive_stacks) == 0


def default_placement(army: Army) -> None:
    """Place army stacks in their starting positions on the battlefield."""
    alive = army.alive_stacks
    if not alive:
        return

    if army.side == Side.ATTACKER:
        col = 0
    else:
        col = 14  # rightmost column

    # Spread stacks evenly along the column
    total = len(alive)
    spacing = BATTLEFIELD_ROWS / (total + 1)

    for i, stack in enumerate(alive):
        row = int(spacing * (i + 1))
        row = min(row, BATTLEFIELD_ROWS - 1)
        stack.position = offset_to_cube(OffsetCoord(col, row))


def siege_placement(army: Army, siege_info: SiegeInfo) -> None:
    """Place defender army behind the walls (cols 12-14) in siege combat.

    Spreads stacks evenly along column 13 first (centered vertically),
    overflowing to columns 12 and 14 if needed.
    """
    alive = army.alive_stacks
    if not alive:
        return

    # Collect valid positions on col 13, sorted by distance from center row
    tower_hexes = {t.position for t in siege_info.towers}
    wall_hexes = siege_info.wall_hexes_set()
    center_row = BATTLEFIELD_ROWS // 2  # row 5

    # Primary column: 13 (main area behind walls)
    col13_positions: list[CubeCoord] = []
    for row in range(BATTLEFIELD_ROWS):
        pos = offset_to_cube(OffsetCoord(13, row))
        if pos not in tower_hexes and pos not in wall_hexes:
            col13_positions.append(pos)

    # Spread evenly along col 13, centered
    total = len(alive)
    if total <= len(col13_positions):
        spacing = BATTLEFIELD_ROWS / (total + 1)
        for i, stack in enumerate(alive):
            row = int(spacing * (i + 1))
            row = min(row, BATTLEFIELD_ROWS - 1)
            pos = offset_to_cube(OffsetCoord(13, row))
            # If this exact pos is blocked (tower), find nearest valid
            if pos in tower_hexes:
                for offset in (1, -1, 2, -2):
                    alt_row = row + offset
                    if 0 <= alt_row < BATTLEFIELD_ROWS:
                        alt = offset_to_cube(OffsetCoord(13, alt_row))
                        if alt not in tower_hexes and alt not in wall_hexes:
                            pos = alt
                            break
            stack.position = pos
    else:
        # More stacks than col 13 slots — use overflow columns
        all_positions: list[CubeCoord] = []
        for col in (13, 12, 14):
            for row in range(BATTLEFIELD_ROWS):
                pos = offset_to_cube(OffsetCoord(col, row))
                if pos not in tower_hexes and pos not in wall_hexes:
                    all_positions.append(pos)
        spacing = max(1, len(all_positions) // (total + 1))
        for i, stack in enumerate(alive):
            idx = min(spacing * (i + 1), len(all_positions) - 1)
            stack.position = all_positions[idx]


@dataclass
class Battlefield:
    """The combat battlefield with two armies."""

    attacker: Army
    defender: Army
    obstacles: set[CubeCoord] = field(default_factory=set)
    siege_info: SiegeInfo | None = None

    def __post_init__(self):
        if self.siege_info is not None:
            # Siege: attacker at col 0, defender behind walls
            default_placement(self.attacker)
            siege_placement(self.defender, self.siege_info)
        else:
            default_placement(self.attacker)
            default_placement(self.defender)

    @property
    def is_siege(self) -> bool:
        return self.siege_info is not None

    @property
    def all_stacks(self) -> list[CreatureStack]:
        return self.attacker.stacks + self.defender.stacks

    @property
    def alive_stacks(self) -> list[CreatureStack]:
        return [s for s in self.all_stacks if s.alive]

    def stack_at(self, pos: CubeCoord) -> CreatureStack | None:
        for s in self.alive_stacks:
            if s.position == pos:
                return s
        return None

    def is_passable(self, pos: CubeCoord, side: Side | None = None) -> bool:
        """Check if a hex is passable (no obstacle, stack, or blocking wall).

        In siege, side is used to allow defenders through the drawbridge.
        """
        if pos in self.obstacles:
            return False
        if self.stack_at(pos) is not None:
            return False
        if self.siege_info is not None:
            if self.siege_info.is_wall_blocking(pos, side):
                return False
        return True

    def get_army(self, side: Side) -> Army:
        return self.attacker if side == Side.ATTACKER else self.defender

    def get_enemy_army(self, side: Side) -> Army:
        return self.defender if side == Side.ATTACKER else self.attacker
