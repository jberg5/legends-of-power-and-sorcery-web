"""Siege combat data model: walls, moat, arrow towers, catapult."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto

from lops.hex import CubeCoord, OffsetCoord, offset_to_cube


class FortLevel(Enum):
    FORT = auto()
    CITADEL = auto()
    CASTLE = auto()


class WallState(Enum):
    INTACT = auto()
    DAMAGED = auto()
    DESTROYED = auto()


class WallType(Enum):
    INDESTRUCTIBLE = auto()
    DESTRUCTIBLE = auto()
    DRAWBRIDGE = auto()


WALL_COL = 11


@dataclass
class WallSegment:
    """A single wall segment on the siege battlefield."""

    position: CubeCoord
    wall_type: WallType
    max_hp: int
    current_hp: int
    state: WallState = WallState.INTACT

    def take_damage(self, amount: int = 1):
        """Apply damage to this wall segment."""
        if self.wall_type == WallType.INDESTRUCTIBLE:
            return
        self.current_hp = max(0, self.current_hp - amount)
        if self.current_hp <= 0:
            self.state = WallState.DESTROYED
        elif self.current_hp < self.max_hp:
            self.state = WallState.DAMAGED

    @property
    def blocks_movement(self) -> bool:
        """Whether this wall blocks ground movement."""
        if self.state == WallState.DESTROYED:
            return False
        return True


@dataclass
class ArrowTower:
    """An arrow tower that fires at attackers each round."""

    position: CubeCoord
    is_central: bool = False
    destroyed: bool = False


@dataclass
class SiegeInfo:
    """Complete siege battlefield information."""

    fort_level: FortLevel
    walls: list[WallSegment] = field(default_factory=list)
    moat_hexes: set[CubeCoord] = field(default_factory=set)
    towers: list[ArrowTower] = field(default_factory=list)
    has_catapult: bool = True

    def wall_at(self, pos: CubeCoord) -> WallSegment | None:
        """Return the wall segment at a position, or None."""
        for w in self.walls:
            if w.position == pos:
                return w
        return None

    def is_wall_blocking(self, pos: CubeCoord, side=None) -> bool:
        """Check if a wall at this position blocks movement.

        Defenders can pass through the drawbridge (gate) while it's intact.
        Attackers are blocked by all intact walls.
        """
        wall = self.wall_at(pos)
        if wall is None:
            return False
        if wall.state == WallState.DESTROYED:
            return False
        # Defenders can pass through the drawbridge
        if side is not None:
            from lops.models import Side

            if side == Side.DEFENDER and wall.wall_type == WallType.DRAWBRIDGE:
                return False
        return True

    def destructible_walls(self) -> list[WallSegment]:
        """Return all destructible wall segments (including drawbridge)."""
        return [
            w
            for w in self.walls
            if w.wall_type in (WallType.DESTRUCTIBLE, WallType.DRAWBRIDGE)
            and w.state != WallState.DESTROYED
        ]

    def wall_hexes_set(self) -> set[CubeCoord]:
        """Return set of all wall hex positions."""
        return {w.position for w in self.walls}

    def active_towers(self) -> list[ArrowTower]:
        """Return towers that can still fire."""
        return [t for t in self.towers if not t.destroyed]


# Wall layout per row at WALL_COL
# (row, WallType)
_WALL_LAYOUT: list[tuple[int, WallType]] = [
    (0, WallType.INDESTRUCTIBLE),
    (1, WallType.INDESTRUCTIBLE),
    (2, WallType.DESTRUCTIBLE),
    (3, WallType.INDESTRUCTIBLE),
    (4, WallType.DRAWBRIDGE),
    (5, WallType.INDESTRUCTIBLE),
    (6, WallType.DESTRUCTIBLE),
    (7, WallType.INDESTRUCTIBLE),
    (8, WallType.DESTRUCTIBLE),
    (9, WallType.INDESTRUCTIBLE),
    (10, WallType.INDESTRUCTIBLE),
]


def create_siege_info(fort_level: FortLevel) -> SiegeInfo:
    """Factory: create a SiegeInfo for the given fort level."""
    # Wall HP depends on fort level
    if fort_level == FortLevel.CASTLE:
        wall_hp = 3
    else:
        wall_hp = 2

    walls: list[WallSegment] = []
    for row, wtype in _WALL_LAYOUT:
        pos = offset_to_cube(OffsetCoord(WALL_COL, row))
        if wtype == WallType.INDESTRUCTIBLE:
            hp = 999
        elif wtype == WallType.DRAWBRIDGE:
            hp = 2  # drawbridge always 2 HP
        else:
            hp = wall_hp
        walls.append(
            WallSegment(position=pos, wall_type=wtype, max_hp=hp, current_hp=hp)
        )

    # Moat: column 10, all rows (Citadel+ only)
    moat_hexes: set[CubeCoord] = set()
    if fort_level in (FortLevel.CITADEL, FortLevel.CASTLE):
        for row in range(11):
            moat_hexes.add(offset_to_cube(OffsetCoord(WALL_COL - 1, row)))

    # Towers
    towers: list[ArrowTower] = []
    # Central tower at (13, 5) — always present with Citadel+
    if fort_level in (FortLevel.CITADEL, FortLevel.CASTLE):
        towers.append(
            ArrowTower(
                position=offset_to_cube(OffsetCoord(13, 5)),
                is_central=True,
            )
        )
    # Flanking towers at (13, 2) and (13, 8) — Castle only
    if fort_level == FortLevel.CASTLE:
        towers.append(
            ArrowTower(
                position=offset_to_cube(OffsetCoord(13, 2)),
                is_central=False,
            )
        )
        towers.append(
            ArrowTower(
                position=offset_to_cube(OffsetCoord(13, 8)),
                is_central=False,
            )
        )

    return SiegeInfo(
        fort_level=fort_level,
        walls=walls,
        moat_hexes=moat_hexes,
        towers=towers,
        has_catapult=True,
    )
