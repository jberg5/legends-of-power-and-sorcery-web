"""Creature special abilities (Phase 6)."""

from __future__ import annotations


def has_double_strike(stats) -> bool:
    return getattr(stats, "double_strike", False)


def has_jousting(stats) -> bool:
    return getattr(stats, "jousting", False)


def has_unlimited_retaliation(stats) -> bool:
    return getattr(stats, "unlimited_retaliation", False)
