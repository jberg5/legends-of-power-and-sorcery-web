"""Creature bank definitions: guard armies and reward tables."""

from lops.adventure.resources import Resources
from lops.data.creatures import CreatureType

# Each bank: name, guards [(CreatureType, count)], gold reward,
# optional resource reward, optional artifact_class for random drop
# HoMM3-accurate guard compositions (using middle-tier difficulty)
# Guards have 50% chance to be upgraded variants
CREATURE_BANK_TYPES = [
    {
        "name": "Dwarven Treasury",
        "guards": [(CreatureType.DWARF, 50), (CreatureType.BATTLE_DWARF, 25)],
        "gold": 4000,
        "resources": Resources(crystal=3),
        "artifact_class": None,
    },
    {
        "name": "Griffin Conservatory",
        "guards": [(CreatureType.GRIFFIN, 50), (CreatureType.ROYAL_GRIFFIN, 50), (CreatureType.ANGEL, 2)],
        "gold": 0,
        "resources": None,
        "artifact_class": "MINOR",
    },
    {
        "name": "Medusa Stores",
        "guards": [(CreatureType.MEDUSA, 20), (CreatureType.MEDUSA_QUEEN, 10)],
        "gold": 3000,
        "resources": Resources(sulfur=6),
        "artifact_class": None,
    },
    {
        "name": "Naga Bank",
        "guards": [(CreatureType.NAGA, 10), (CreatureType.NAGA_QUEEN, 5)],
        "gold": 6000,
        "resources": Resources(sulfur=12),
        "artifact_class": None,
    },
    {
        "name": "Dragon Utopia",
        "guards": [
            (CreatureType.GREEN_DRAGON, 8),
            (CreatureType.RED_DRAGON, 5),
            (CreatureType.GOLD_DRAGON, 2),
            (CreatureType.BLACK_DRAGON, 1),
        ],
        "gold": 20000,
        "resources": None,
        "artifact_class": "RELIC",
    },
    {
        "name": "Cyclops Stockpile",
        "guards": [(CreatureType.CYCLOPS, 20), (CreatureType.CYCLOPS_KING, 10)],
        "gold": 0,
        "resources": Resources(wood=4, ore=4, mercury=4, sulfur=4, crystal=4, gems=4),
        "artifact_class": None,
    },
]
