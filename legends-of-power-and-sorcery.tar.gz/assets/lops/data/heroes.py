"""Castle faction hero definitions for the Tavern.

Source: https://heroes.thelazy.net/index.php/List_of_heroes
All Castle heroes are Knights: base ATK=2, DEF=2, SPL=1, KNW=1.
Each has Basic Leadership + one specialty skill.
"""

from __future__ import annotations

from dataclasses import dataclass

from lops.models import Hero
from lops.skills import HeroSkill, SkillId, SkillLevel


@dataclass(frozen=True)
class HeroDef:
    """Template for creating a hero instance."""

    name: str
    attack: int
    defense: int
    spell_power: int
    knowledge: int
    skills: tuple[tuple[SkillId, SkillLevel], ...]
    starting_spells: tuple = ()  # tuple of SpellId


CASTLE_HEROES: list[HeroDef] = [
    HeroDef(
        "Orrin",
        2,
        2,
        1,
        1,
        ((SkillId.LEADERSHIP, SkillLevel.BASIC), (SkillId.ARCHERY, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Valeska",
        2,
        2,
        1,
        1,
        ((SkillId.LEADERSHIP, SkillLevel.BASIC), (SkillId.ARCHERY, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Edric",
        2,
        2,
        1,
        1,
        ((SkillId.LEADERSHIP, SkillLevel.BASIC), (SkillId.ARMORER, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Sylvia",
        2,
        2,
        1,
        1,
        (
            (SkillId.LEADERSHIP, SkillLevel.BASIC),
            (SkillId.PATHFINDING, SkillLevel.BASIC),
        ),
    ),
    HeroDef(
        "Beatrice",
        2,
        2,
        1,
        1,
        ((SkillId.LEADERSHIP, SkillLevel.BASIC), (SkillId.SCOUTING, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Lord Haart",
        2,
        2,
        1,
        1,
        ((SkillId.LEADERSHIP, SkillLevel.BASIC), (SkillId.ESTATES, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Sorsha",
        2,
        2,
        1,
        1,
        ((SkillId.LEADERSHIP, SkillLevel.BASIC), (SkillId.OFFENSE, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Christian",
        2,
        2,
        1,
        1,
        ((SkillId.LEADERSHIP, SkillLevel.BASIC), (SkillId.ARTILLERY, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Tyris",
        2,
        2,
        1,
        1,
        ((SkillId.LEADERSHIP, SkillLevel.BASIC), (SkillId.TACTICS, SkillLevel.BASIC)),
    ),
    HeroDef("Sir Mullich", 2, 2, 1, 1, ((SkillId.LEADERSHIP, SkillLevel.ADVANCED),)),
]

NECROPOLIS_HEROES: list[HeroDef] = [
    # Death Knights (ATK1 DEF2 SPL2 KNW1)
    HeroDef(
        "Straker",
        1,
        2,
        2,
        1,
        ((SkillId.OFFENSE, SkillLevel.BASIC), (SkillId.ARMORER, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Vokial",
        1,
        2,
        2,
        1,
        ((SkillId.OFFENSE, SkillLevel.BASIC), (SkillId.ESTATES, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Moandor",
        1,
        2,
        2,
        1,
        ((SkillId.OFFENSE, SkillLevel.BASIC), (SkillId.LUCK, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Charna",
        1,
        2,
        2,
        1,
        ((SkillId.OFFENSE, SkillLevel.BASIC), (SkillId.TACTICS, SkillLevel.BASIC)),
    ),
    # Necromancers (ATK1 DEF0 SPL2 KNW2)
    HeroDef(
        "Sandro",
        1,
        0,
        2,
        2,
        ((SkillId.EARTH_MAGIC, SkillLevel.BASIC), (SkillId.WISDOM, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Septienna",
        1,
        0,
        2,
        2,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.ESTATES, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Aislinn",
        1,
        0,
        2,
        2,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.SCOUTING, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Nimbus",
        1,
        0,
        2,
        2,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.PATHFINDING, SkillLevel.BASIC)),
    ),
]

INFERNO_HEROES: list[HeroDef] = [
    # Demoniacs (ATK2 DEF2 SPL1 KNW1)
    HeroDef(
        "Fiona",
        2,
        2,
        1,
        1,
        ((SkillId.OFFENSE, SkillLevel.BASIC), (SkillId.SCOUTING, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Rashka",
        2,
        2,
        1,
        1,
        ((SkillId.OFFENSE, SkillLevel.BASIC), (SkillId.ESTATES, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Marius",
        2,
        2,
        1,
        1,
        ((SkillId.OFFENSE, SkillLevel.BASIC), (SkillId.ARMORER, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Ignatius",
        2,
        2,
        1,
        1,
        ((SkillId.OFFENSE, SkillLevel.BASIC), (SkillId.TACTICS, SkillLevel.BASIC)),
    ),
    # Heretics (ATK1 DEF1 SPL2 KNW2)
    HeroDef(
        "Ayden",
        1,
        1,
        2,
        2,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.FIRE_MAGIC, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Xyron",
        1,
        1,
        2,
        2,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.FIRE_MAGIC, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Axsis",
        1,
        1,
        2,
        2,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.MYSTICISM, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Olema",
        1,
        1,
        2,
        2,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.BALLISTICS, SkillLevel.BASIC)),
    ),
]

DUNGEON_HEROES: list[HeroDef] = [
    # Overlords (ATK2 DEF2 SPL1 KNW1)
    HeroDef(
        "Lorelei",
        2,
        2,
        1,
        1,
        ((SkillId.LEADERSHIP, SkillLevel.BASIC), (SkillId.SCOUTING, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Shakti",
        2,
        2,
        1,
        1,
        ((SkillId.LEADERSHIP, SkillLevel.BASIC), (SkillId.OFFENSE, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Dace",
        2,
        2,
        1,
        1,
        ((SkillId.LEADERSHIP, SkillLevel.BASIC), (SkillId.TACTICS, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Mutare",
        2,
        2,
        1,
        1,
        ((SkillId.LEADERSHIP, SkillLevel.BASIC), (SkillId.ESTATES, SkillLevel.BASIC)),
    ),
    # Warlocks (ATK0 DEF0 SPL3 KNW3)
    HeroDef(
        "Alamar",
        0,
        0,
        3,
        3,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.EARTH_MAGIC, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Malekith",
        0,
        0,
        3,
        3,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.SCOUTING, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Jeddite",
        0,
        0,
        3,
        3,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.ESTATES, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Geon",
        0,
        0,
        3,
        3,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.FIRE_MAGIC, SkillLevel.BASIC)),
    ),
]

RAMPART_HEROES: list[HeroDef] = [
    # Rangers (ATK2 DEF2 SPL1 KNW1)
    HeroDef(
        "Kyrre",
        2,
        2,
        1,
        1,
        ((SkillId.ARCHERY, SkillLevel.BASIC), (SkillId.LOGISTICS, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Mephala",
        2,
        2,
        1,
        1,
        ((SkillId.LEADERSHIP, SkillLevel.BASIC), (SkillId.ARMORER, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Ivor",
        2,
        2,
        1,
        1,
        ((SkillId.ARCHERY, SkillLevel.BASIC), (SkillId.OFFENSE, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Ryland",
        2,
        2,
        1,
        1,
        ((SkillId.LEADERSHIP, SkillLevel.BASIC), (SkillId.DIPLOMACY, SkillLevel.BASIC)),
    ),
    # Druids (ATK0 DEF2 SPL1 KNW2)
    HeroDef(
        "Coronius",
        0,
        2,
        1,
        2,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.SCHOLAR, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Uland",
        0,
        2,
        1,
        2,
        ((SkillId.WISDOM, SkillLevel.ADVANCED), (SkillId.BALLISTICS, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Gem",
        0,
        2,
        1,
        2,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.FIRST_AID, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Alagar",
        0,
        2,
        1,
        2,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.SORCERY, SkillLevel.BASIC)),
    ),
]

TOWER_HEROES: list[HeroDef] = [
    # Alchemists (ATK1 DEF1 SPL2 KNW2)
    HeroDef(
        "Fafner",
        1,
        1,
        2,
        2,
        ((SkillId.SCHOLAR, SkillLevel.BASIC), (SkillId.RESISTANCE, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Josephine",
        1,
        1,
        2,
        2,
        ((SkillId.MYSTICISM, SkillLevel.BASIC), (SkillId.SORCERY, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Neela",
        1,
        1,
        2,
        2,
        ((SkillId.SCHOLAR, SkillLevel.BASIC), (SkillId.ARMORER, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Torosar",
        1,
        1,
        2,
        2,
        ((SkillId.MYSTICISM, SkillLevel.BASIC), (SkillId.TACTICS, SkillLevel.BASIC)),
    ),
    # Wizards (ATK0 DEF0 SPL3 KNW3)
    HeroDef(
        "Solmyr",
        0,
        0,
        3,
        3,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.SORCERY, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Theodorus",
        0,
        0,
        3,
        3,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.BALLISTICS, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Cyra",
        0,
        0,
        3,
        3,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.DIPLOMACY, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Aine",
        0,
        0,
        3,
        3,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.SCHOLAR, SkillLevel.BASIC)),
    ),
]

STRONGHOLD_HEROES: list[HeroDef] = [
    # Barbarians (ATK4 DEF0 SPL1 KNW1)
    HeroDef(
        "Crag Hack",
        4,
        0,
        1,
        1,
        ((SkillId.OFFENSE, SkillLevel.ADVANCED),),
    ),
    HeroDef(
        "Yog",
        4,
        0,
        1,
        1,
        ((SkillId.BALLISTICS, SkillLevel.BASIC), (SkillId.OFFENSE, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Shiva",
        4,
        0,
        1,
        1,
        ((SkillId.OFFENSE, SkillLevel.BASIC), (SkillId.ARMORER, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Tyraxor",
        4,
        0,
        1,
        1,
        ((SkillId.OFFENSE, SkillLevel.BASIC), (SkillId.TACTICS, SkillLevel.BASIC)),
    ),
    # Battle Mages (ATK2 DEF1 SPL1 KNW1)
    HeroDef(
        "Dessa",
        2,
        1,
        1,
        1,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.LOGISTICS, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Gird",
        2,
        1,
        1,
        1,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.SORCERY, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Zubin",
        2,
        1,
        1,
        1,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.ARTILLERY, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Oris",
        2,
        1,
        1,
        1,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.EAGLE_EYE, SkillLevel.BASIC)),
    ),
]

FORTRESS_HEROES: list[HeroDef] = [
    # Beastmasters (ATK1 DEF3 SPL1 KNW1)
    HeroDef(
        "Tazar",
        1,
        3,
        1,
        1,
        ((SkillId.ARMORER, SkillLevel.ADVANCED),),
    ),
    HeroDef(
        "Bron",
        1,
        3,
        1,
        1,
        ((SkillId.ARMORER, SkillLevel.BASIC), (SkillId.RESISTANCE, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Drakon",
        1,
        3,
        1,
        1,
        ((SkillId.ARMORER, SkillLevel.BASIC), (SkillId.LEADERSHIP, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Alkin",
        1,
        3,
        1,
        1,
        ((SkillId.ARMORER, SkillLevel.BASIC), (SkillId.OFFENSE, SkillLevel.BASIC)),
    ),
    # Witches (ATK0 DEF1 SPL2 KNW2)
    HeroDef(
        "Mirlanda",
        0,
        1,
        2,
        2,
        ((SkillId.WISDOM, SkillLevel.ADVANCED),),
    ),
    HeroDef(
        "Rosic",
        0,
        1,
        2,
        2,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.MYSTICISM, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Andra",
        0,
        1,
        2,
        2,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.INTELLIGENCE, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Styg",
        0,
        1,
        2,
        2,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.SORCERY, SkillLevel.BASIC)),
    ),
]

CONFLUX_HEROES: list[HeroDef] = [
    # Planeswalkers (ATK2 DEF2 SPL1 KNW1)
    HeroDef(
        "Pasis",
        2,
        2,
        1,
        1,
        ((SkillId.OFFENSE, SkillLevel.BASIC), (SkillId.ARTILLERY, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Thunar",
        2,
        2,
        1,
        1,
        ((SkillId.TACTICS, SkillLevel.BASIC), (SkillId.ESTATES, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Erdamon",
        2,
        2,
        1,
        1,
        ((SkillId.TACTICS, SkillLevel.BASIC), (SkillId.ESTATES, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Fiur",
        2,
        2,
        1,
        1,
        ((SkillId.OFFENSE, SkillLevel.ADVANCED),),
    ),
    # Elementalists (ATK0 DEF0 SPL2 KNW3)
    HeroDef(
        "Luna",
        0,
        0,
        2,
        3,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.FIRE_MAGIC, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Brissa",
        0,
        0,
        2,
        3,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.AIR_MAGIC, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Ciele",
        0,
        0,
        2,
        3,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.WATER_MAGIC, SkillLevel.BASIC)),
    ),
    HeroDef(
        "Labetha",
        0,
        0,
        2,
        3,
        ((SkillId.WISDOM, SkillLevel.BASIC), (SkillId.EARTH_MAGIC, SkillLevel.BASIC)),
    ),
]

HERO_HIRE_COST = 2500


def get_faction_heroes(faction_id) -> list[HeroDef]:
    """Return hero list for a given FactionId."""
    name = faction_id.name if hasattr(faction_id, "name") else str(faction_id)
    return _FACTION_HEROES.get(name, CASTLE_HEROES)


# Populated by faction data modules; Castle is default
_FACTION_HEROES: dict[str, list[HeroDef]] = {
    "CASTLE": CASTLE_HEROES,
    "NECROPOLIS": NECROPOLIS_HEROES,
    "INFERNO": INFERNO_HEROES,
    "DUNGEON": DUNGEON_HEROES,
    "RAMPART": RAMPART_HEROES,
    "TOWER": TOWER_HEROES,
    "STRONGHOLD": STRONGHOLD_HEROES,
    "FORTRESS": FORTRESS_HEROES,
    "CONFLUX": CONFLUX_HEROES,
}


def register_faction_heroes(faction_name: str, heroes: list[HeroDef]):
    """Register a faction's hero list."""
    _FACTION_HEROES[faction_name] = heroes


def create_hero_from_def(hero_def: HeroDef) -> Hero:
    """Instantiate a Hero from a HeroDef template."""
    skills = [HeroSkill(sid, lvl) for sid, lvl in hero_def.skills]
    return Hero(
        name=hero_def.name,
        attack=hero_def.attack,
        defense=hero_def.defense,
        spell_power=hero_def.spell_power,
        knowledge=hero_def.knowledge,
        skills=skills,
        spells=list(hero_def.starting_spells),
    )
