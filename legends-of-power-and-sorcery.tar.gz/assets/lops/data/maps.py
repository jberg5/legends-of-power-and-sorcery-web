"""Procedural map generation for the adventure mode."""

from __future__ import annotations

import math
import random
from collections import deque

from lops.adventure.layered_map import GatePair, LayeredMap
from lops.adventure.world_map import Terrain, WorldMap
from lops.hex import (
    CubeCoord,
    OffsetCoord,
    cube_distance,
    cube_neighbors,
    cube_to_offset,
    offset_to_cube,
)


def generate_default_map(
    cols: int = 36,
    rows: int = 24,
    seed: int | None = None,
) -> WorldMap:
    """Generate a 36x24 world map with terrain variety.

    Layout: two towns on opposite sides, road connecting them,
    forests/mountains scattered via simple noise, water at edges.
    """
    rng = random.Random(seed)
    world = WorldMap(cols, rows)

    # Town positions (offset coords)
    town1_offset = OffsetCoord(3, rows // 2)
    town2_offset = OffsetCoord(cols - 4, rows // 2)
    town1_pos = offset_to_cube(town1_offset)
    town2_pos = offset_to_cube(town2_offset)

    # Place water border (top and bottom rows, plus some coast)
    for col in range(cols):
        for row in range(rows):
            c = offset_to_cube(OffsetCoord(col, row))
            # Water at map edges
            if row == 0 or row == rows - 1 or col == 0 or col == cols - 1:
                world.set_terrain(c, Terrain.WATER)

    # Scatter forests using simple probability
    for pos in world.all_positions():
        o = cube_to_offset(pos)
        if o.row == 0 or o.row == rows - 1 or o.col == 0 or o.col == cols - 1:
            continue  # skip water border

        # Distance from map center affects forest density
        cx, cy = cols / 2, rows / 2
        dist_norm = math.sqrt((o.col - cx) ** 2 + (o.row - cy) ** 2) / math.sqrt(
            cx**2 + cy**2
        )

        if rng.random() < 0.20:
            world.set_terrain(pos, Terrain.FOREST)
        elif rng.random() < 0.05:
            world.set_terrain(pos, Terrain.DIRT)

    # Place mountain clusters (avoid town areas) — scale with map size
    scale = (cols * rows) / (36 * 24)
    num_clusters = rng.randint(4, max(7, int(7 * scale)))
    for _ in range(num_clusters):
        center_col = rng.randint(4, cols - 5)
        center_row = rng.randint(3, rows - 4)
        center = offset_to_cube(OffsetCoord(center_col, center_row))

        # Don't place near towns
        if cube_distance(center, town1_pos) < 5 or cube_distance(center, town2_pos) < 5:
            continue

        # Small cluster of 2-5 mountain hexes
        cluster_size = rng.randint(2, 5)
        candidates = [center]
        placed = 0
        while candidates and placed < cluster_size:
            pos = candidates.pop(0)
            tile = world.get_tile(pos)
            if world.in_bounds(pos) and tile is not None and tile.terrain == Terrain.GRASS:
                world.set_terrain(pos, Terrain.MOUNTAIN)
                placed += 1
                from lops.hex import cube_neighbors

                for n in cube_neighbors(pos):
                    if world.in_bounds(n) and rng.random() < 0.5:
                        candidates.append(n)

    # Place small water features (ponds) — scale with map size
    num_ponds = rng.randint(2, max(4, int(4 * scale)))
    for _ in range(num_ponds):
        center_col = rng.randint(5, cols - 6)
        center_row = rng.randint(3, rows - 4)
        center = offset_to_cube(OffsetCoord(center_col, center_row))

        if cube_distance(center, town1_pos) < 4 or cube_distance(center, town2_pos) < 4:
            continue

        pond_size = rng.randint(2, 4)
        candidates = [center]
        placed = 0
        while candidates and placed < pond_size:
            pos = candidates.pop(0)
            tile = world.get_tile(pos)
            if tile and tile.terrain not in (Terrain.MOUNTAIN, Terrain.WATER):
                world.set_terrain(pos, Terrain.WATER)
                placed += 1
                from lops.hex import cube_neighbors

                for n in cube_neighbors(pos):
                    if world.in_bounds(n) and rng.random() < 0.4:
                        candidates.append(n)

    # Build road from town1 to town2 using hex A* for a connected path
    # First ensure the path is passable by clearing obstacles along the way
    from lops.adventure.hero_movement import find_path as _find_road_path

    # Clear any mountains/water directly between the towns to guarantee a path exists
    for col in range(town1_offset.col, town2_offset.col + 1):
        for dr in (-1, 0, 1):
            r = rows // 2 + dr
            r = max(1, min(rows - 2, r))
            c = offset_to_cube(OffsetCoord(col, r))
            tile = world.get_tile(c)
            if tile and tile.terrain in (Terrain.MOUNTAIN, Terrain.WATER):
                world.set_terrain(c, Terrain.GRASS)

    road_path = _find_road_path(town1_pos, town2_pos, world)
    if road_path:
        for c in road_path:
            world.set_terrain(c, Terrain.ROAD)
            # Clear adjacent mountains
            for n in world.neighbors(c):
                tile = world.get_tile(n)
                if tile and tile.terrain == Terrain.MOUNTAIN:
                    world.set_terrain(n, Terrain.GRASS)

    # Clear area around towns
    for town_pos in (town1_pos, town2_pos):
        world.set_terrain(town_pos, Terrain.GRASS)
        for n in world.neighbors(town_pos):
            n_tile = world.get_tile(n)
            if n_tile and n_tile.terrain in (
                Terrain.MOUNTAIN,
                Terrain.WATER,
            ):
                world.set_terrain(n, Terrain.GRASS)

    return world


def build_road(world: WorldMap, from_pos: CubeCoord, to_pos: CubeCoord):
    """Build a road between two positions on an existing map.

    Clears obstacles along a corridor, then pathfinds and lays road tiles.
    """
    from lops.adventure.hero_movement import find_path as _find_road_path

    # Clear a 3-hex-wide corridor between the positions to ensure passability
    from_oc = cube_to_offset(from_pos)
    to_oc = cube_to_offset(to_pos)
    min_col = min(from_oc.col, to_oc.col)
    max_col = max(from_oc.col, to_oc.col)
    min_row = min(from_oc.row, to_oc.row)
    max_row = max(from_oc.row, to_oc.row)

    # Step through columns and rows, clearing obstacles along the diagonal
    steps = max(max_col - min_col, max_row - min_row, 1)
    for i in range(steps + 1):
        t = i / steps
        mid_col = int(from_oc.col + (to_oc.col - from_oc.col) * t)
        mid_row = int(from_oc.row + (to_oc.row - from_oc.row) * t)
        for dr in (-1, 0, 1):
            r = max(1, min(world.rows - 2, mid_row + dr))
            c = max(1, min(world.cols - 2, mid_col))
            pos = offset_to_cube(OffsetCoord(c, r))
            tile = world.get_tile(pos)
            if tile and tile.terrain in (Terrain.MOUNTAIN, Terrain.WATER):
                world.set_terrain(pos, Terrain.GRASS)

    # Pathfind and lay road
    road_path = _find_road_path(from_pos, to_pos, world)
    if road_path:
        for road_hex in road_path:
            world.set_terrain(road_hex, Terrain.ROAD)
            for n in world.neighbors(road_hex):
                tile = world.get_tile(n)
                if tile and tile.terrain == Terrain.MOUNTAIN:
                    world.set_terrain(n, Terrain.GRASS)


def generate_underground_map(
    cols: int = 36,
    rows: int = 24,
    seed: int | None = None,
    gate_landing_zones: list[CubeCoord] | None = None,
) -> WorldMap:
    """Generate an underground cavern map using cellular automata.

    Steps:
    1. Start all CAVE_WALL
    2. Random fill ~45% as CAVE_FLOOR
    3. Cellular automata smoothing (4-5 iterations)
    4. BFS connectivity — carve tunnels between disconnected regions
    5. Clear 2-hex radius around gate landing zones
    6. Place SUBTERRANEAN_ROAD between gates and key locations
    """
    rng = random.Random(seed)
    world = WorldMap(cols, rows)

    # Initialize all tiles as CAVE_WALL
    for pos in world.all_positions():
        world.set_terrain(pos, Terrain.CAVE_WALL)

    # Random fill: ~55% become CAVE_FLOOR, edges stay CAVE_WALL
    grid: dict[CubeCoord, bool] = {}  # True = floor, False = wall
    for pos in world.all_positions():
        o = cube_to_offset(pos)
        if o.row <= 0 or o.row >= rows - 1 or o.col <= 0 or o.col >= cols - 1:
            grid[pos] = False
        else:
            grid[pos] = rng.random() < 0.55

    # Cellular automata smoothing (hex grid has 6 neighbors)
    for _ in range(4):
        new_grid: dict[CubeCoord, bool] = {}
        for pos in world.all_positions():
            o = cube_to_offset(pos)
            if o.row <= 0 or o.row >= rows - 1 or o.col <= 0 or o.col >= cols - 1:
                new_grid[pos] = False
                continue
            # Count floor neighbors (not including self)
            floor_count = 0
            for n in cube_neighbors(pos):
                if grid.get(n, False):
                    floor_count += 1
            # Birth: >= 4 floor neighbors; Survival: >= 3 floor neighbors
            if grid.get(pos, False):
                new_grid[pos] = floor_count >= 3
            else:
                new_grid[pos] = floor_count >= 4
        grid = new_grid

    # Apply grid to world
    for pos, is_floor in grid.items():
        if is_floor:
            world.set_terrain(pos, Terrain.CAVE_FLOOR)

    # Scatter some lava pools
    num_lava = max(1, int(cols * rows / 200))
    floor_positions = [p for p, f in grid.items() if f]
    for _ in range(num_lava):
        if not floor_positions:
            break
        center = rng.choice(floor_positions)
        o = cube_to_offset(center)
        if o.row <= 2 or o.row >= rows - 3 or o.col <= 2 or o.col >= cols - 3:
            continue
        world.set_terrain(center, Terrain.LAVA)
        for n in cube_neighbors(center):
            if grid.get(n, False) and rng.random() < 0.3:
                world.set_terrain(n, Terrain.LAVA)

    # BFS to find connected regions of CAVE_FLOOR
    visited: set[CubeCoord] = set()
    regions: list[set[CubeCoord]] = []
    for pos in world.all_positions():
        if pos in visited or not world.is_passable(pos):
            continue
        # BFS from pos
        region: set[CubeCoord] = set()
        queue: deque[CubeCoord] = deque([pos])
        while queue:
            cur = queue.popleft()
            if cur in visited:
                continue
            visited.add(cur)
            region.add(cur)
            for n in world.neighbors(cur):
                if n not in visited and world.is_passable(n):
                    queue.append(n)
        if region:
            regions.append(region)

    # Connect disconnected regions by carving tunnels to the largest region
    if len(regions) > 1:
        regions.sort(key=len, reverse=True)
        main_region = regions[0]
        for other_region in regions[1:]:
            if len(other_region) < 3:
                continue  # skip tiny regions
            # Find closest pair of hexes between main_region and other_region
            best_dist = float("inf")
            best_pair = None
            # Sample to avoid O(n^2) for large regions
            main_sample = list(main_region)[:200]
            other_sample = list(other_region)[:200]
            for a in main_sample:
                for b in other_sample:
                    d = cube_distance(a, b)
                    if d < best_dist:
                        best_dist = d
                        best_pair = (a, b)
            if best_pair is not None:
                _carve_tunnel(world, best_pair[0], best_pair[1])
                main_region |= other_region

    # Clear areas around gate landing zones
    if gate_landing_zones:
        from lops.hex import hexes_in_radius

        for gz in gate_landing_zones:
            for h in hexes_in_radius(gz, 2):
                if world.in_bounds(h):
                    world.set_terrain(h, Terrain.CAVE_FLOOR)

        # Place SUBTERRANEAN_ROAD between gate landing zones
        if len(gate_landing_zones) >= 2:
            for i in range(len(gate_landing_zones) - 1):
                _build_underground_road(
                    world, gate_landing_zones[i], gate_landing_zones[i + 1]
                )

    return world


def _carve_tunnel(world: WorldMap, from_pos: CubeCoord, to_pos: CubeCoord):
    """Carve a passable tunnel between two positions through cave walls."""
    from_oc = cube_to_offset(from_pos)
    to_oc = cube_to_offset(to_pos)
    steps = max(abs(to_oc.col - from_oc.col), abs(to_oc.row - from_oc.row), 1)
    for i in range(steps + 1):
        t = i / steps
        col = int(from_oc.col + (to_oc.col - from_oc.col) * t)
        row = int(from_oc.row + (to_oc.row - from_oc.row) * t)
        col = max(1, min(world.cols - 2, col))
        row = max(1, min(world.rows - 2, row))
        pos = offset_to_cube(OffsetCoord(col, row))
        if not world.is_passable(pos):
            world.set_terrain(pos, Terrain.CAVE_FLOOR)
        # Also carve one neighbor for wider tunnel
        for n in world.neighbors(pos):
            o = cube_to_offset(n)
            if 0 < o.col < world.cols - 1 and 0 < o.row < world.rows - 1:
                if not world.is_passable(n):
                    world.set_terrain(n, Terrain.CAVE_FLOOR)
                break


def _build_underground_road(world: WorldMap, from_pos: CubeCoord, to_pos: CubeCoord):
    """Build a subterranean road between two underground positions."""
    from lops.adventure.hero_movement import find_path as _find_road_path

    # First ensure the path is passable
    _carve_tunnel(world, from_pos, to_pos)

    road_path = _find_road_path(from_pos, to_pos, world)
    if road_path:
        for h in road_path:
            world.set_terrain(h, Terrain.SUBTERRANEAN_ROAD)


def _pick_gate_targets(
    cols: int, rows: int, num_gates: int
) -> list[OffsetCoord]:
    """Return target offset coordinates for gates, placed near map corners.

    Always includes the 4 corners first (inset from edges), then adds
    mid-edge positions for gates 5-6.
    """
    # Inset from map edges: ~20% in from each side, clamped to valid range
    margin_col = max(3, cols // 5)
    margin_row = max(3, rows // 5)

    # Corner targets (NW, NE, SE, SW)
    corners = [
        OffsetCoord(margin_col, margin_row),                     # NW
        OffsetCoord(cols - 1 - margin_col, margin_row),          # NE
        OffsetCoord(cols - 1 - margin_col, rows - 1 - margin_row),  # SE
        OffsetCoord(margin_col, rows - 1 - margin_row),          # SW
    ]

    # Mid-edge extras for gates 5-6
    extras = [
        OffsetCoord(cols // 2, margin_row),                      # N center
        OffsetCoord(cols // 2, rows - 1 - margin_row),           # S center
    ]

    targets = corners[:num_gates]
    if num_gates > 4:
        targets.extend(extras[: num_gates - 4])
    return targets


def _find_nearest_passable(
    surface: WorldMap, target: OffsetCoord, avoid: set[CubeCoord], min_town_dist: int,
    town1: CubeCoord, town2: CubeCoord,
) -> CubeCoord | None:
    """Find the nearest passable non-road hex to target that satisfies constraints."""
    target_cube = offset_to_cube(target)
    best: CubeCoord | None = None
    best_dist = float("inf")
    for pos in surface.all_positions():
        if not surface.is_passable(pos):
            continue
        if pos in avoid:
            continue
        # Don't place gates on existing roads
        tile = surface.get_tile(pos)
        if tile and tile.terrain == Terrain.ROAD:
            continue
        if cube_distance(pos, town1) < min_town_dist:
            continue
        if cube_distance(pos, town2) < min_town_dist:
            continue
        d = cube_distance(pos, target_cube)
        if d < best_dist:
            best_dist = d
            best = pos
    return best


def generate_layered_map(
    cols: int = 36,
    rows: int = 24,
    seed: int | None = None,
    num_gates: int | None = None,
) -> LayeredMap:
    """Generate a full two-layer map with surface and underground connected by gates.

    Gates are placed deliberately near map corners so players encounter them
    while exploring outward. Min 2, max 6 gate pairs.
    """
    rng = random.Random(seed)

    # Generate surface
    surface = generate_default_map(cols=cols, rows=rows, seed=seed)

    # Determine number of gates: 2–6, scaling with map area
    if num_gates is None:
        scale = (cols * rows) / (36 * 24)
        num_gates = max(2, min(6, int(2 + scale)))

    town1_pos = offset_to_cube(OffsetCoord(3, rows // 2))
    town2_pos = offset_to_cube(OffsetCoord(cols - 4, rows // 2))

    # Place gates near corners
    targets = _pick_gate_targets(cols, rows, num_gates)
    gate_surface_positions: list[CubeCoord] = []
    used: set[CubeCoord] = set()

    for target_oc in targets:
        pos = _find_nearest_passable(
            surface, target_oc, used, min_town_dist=5,
            town1=town1_pos, town2=town2_pos,
        )
        if pos is not None:
            gate_surface_positions.append(pos)
            # Reserve a radius around the gate so others don't cluster
            from lops.hex import hexes_in_radius

            used |= hexes_in_radius(pos, 5)

    # Underground landing zones mirror the surface positions
    gate_underground_positions = list(gate_surface_positions)

    # Generate underground with gate landing zones
    underground = generate_underground_map(
        cols=cols,
        rows=rows,
        seed=(seed + 1000) if seed is not None else None,
        gate_landing_zones=gate_underground_positions,
    )

    # Create gate pairs
    gates: list[GatePair] = []
    for i, (sp, up) in enumerate(
        zip(gate_surface_positions, gate_underground_positions)
    ):
        gates.append(GatePair(surface_pos=sp, underground_pos=up, pair_id=i))

    return LayeredMap(surface=surface, underground=underground, gates=gates)
