"""Terrain movement costs and display properties."""

from __future__ import annotations

from lops.adventure.world_map import Terrain

# Movement cost per terrain type (movement points spent to enter)
TERRAIN_COST: dict[Terrain, int] = {
    Terrain.GRASS: 100,
    Terrain.FOREST: 150,
    Terrain.ROAD: 65,
    Terrain.DIRT: 100,
    Terrain.MOUNTAIN: -1,  # impassable
    Terrain.WATER: -1,  # impassable
    Terrain.CAVE_FLOOR: 100,
    Terrain.CAVE_WALL: -1,  # impassable
    Terrain.LAVA: -1,  # impassable
    Terrain.SUBTERRANEAN_ROAD: 65,
}

# Hex fill colors for rendering (R, G, B)
TERRAIN_COLOR: dict[Terrain, tuple[int, int, int]] = {
    Terrain.GRASS: (75, 140, 55),
    Terrain.FOREST: (35, 90, 30),
    Terrain.ROAD: (160, 145, 110),
    Terrain.DIRT: (130, 110, 75),
    Terrain.MOUNTAIN: (120, 110, 100),
    Terrain.WATER: (45, 90, 160),
    Terrain.CAVE_FLOOR: (70, 60, 50),
    Terrain.CAVE_WALL: (40, 35, 30),
    Terrain.LAVA: (160, 40, 20),
    Terrain.SUBTERRANEAN_ROAD: (120, 110, 85),
}
