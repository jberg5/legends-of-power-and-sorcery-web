"""Skill definitions registry with HoMM3-accurate values per mastery level."""

from __future__ import annotations

from lops.skills import SkillDef, SkillId

# Source: https://heroes.thelazy.net/index.php/Secondary_skill
SKILL_REGISTRY: dict[SkillId, SkillDef] = {
    SkillId.OFFENSE: SkillDef(
        skill_id=SkillId.OFFENSE,
        name="Offense",
        description="Increases melee damage dealt by hero's creatures.",
        values=(0.10, 0.20, 0.30),
    ),
    SkillId.ARMORER: SkillDef(
        skill_id=SkillId.ARMORER,
        name="Armorer",
        description="Reduces physical damage taken by hero's creatures.",
        values=(0.05, 0.10, 0.15),
    ),
    SkillId.ARCHERY: SkillDef(
        skill_id=SkillId.ARCHERY,
        name="Archery",
        description="Increases ranged damage dealt by hero's creatures.",
        values=(0.10, 0.25, 0.50),
    ),
    SkillId.LOGISTICS: SkillDef(
        skill_id=SkillId.LOGISTICS,
        name="Logistics",
        description="Increases hero's movement points on the adventure map.",
        values=(0.10, 0.20, 0.30),
    ),
    SkillId.SCOUTING: SkillDef(
        skill_id=SkillId.SCOUTING,
        name="Scouting",
        description="Increases hero's vision radius on the adventure map.",
        values=(1, 2, 3),
    ),
    SkillId.ESTATES: SkillDef(
        skill_id=SkillId.ESTATES,
        name="Estates",
        description="Provides daily gold income.",
        values=(125, 250, 500),
    ),
    SkillId.LEADERSHIP: SkillDef(
        skill_id=SkillId.LEADERSHIP,
        name="Leadership",
        description="Increases the morale of hero's creatures.",
        values=(1, 2, 3),
    ),
    SkillId.LUCK: SkillDef(
        skill_id=SkillId.LUCK,
        name="Luck",
        description="Increases the luck of hero's creatures.",
        values=(1, 2, 3),
    ),
    SkillId.PATHFINDING: SkillDef(
        skill_id=SkillId.PATHFINDING,
        name="Pathfinding",
        description="Reduces terrain movement penalties.",
        values=(0.25, 0.50, 0.75),
    ),
    SkillId.WISDOM: SkillDef(
        skill_id=SkillId.WISDOM,
        name="Wisdom",
        description="Allows learning higher-level spells.",
        values=(3, 4, 5),
    ),
    SkillId.TACTICS: SkillDef(
        skill_id=SkillId.TACTICS,
        name="Tactics",
        description="Allows rearranging troops before combat.",
        values=(3, 5, 7),
    ),
    SkillId.BALLISTICS: SkillDef(
        skill_id=SkillId.BALLISTICS,
        name="Ballistics",
        description="Improves catapult effectiveness in siege.",
        values=(1, 2, 3),
    ),
    SkillId.ARTILLERY: SkillDef(
        skill_id=SkillId.ARTILLERY,
        name="Artillery",
        description="Improves ballista effectiveness.",
        values=(1, 2, 3),
    ),
    SkillId.AIR_MAGIC: SkillDef(
        skill_id=SkillId.AIR_MAGIC,
        name="Air Magic",
        description="Increases effectiveness of Air school spells.",
        values=(1, 2, 3),
    ),
    SkillId.EARTH_MAGIC: SkillDef(
        skill_id=SkillId.EARTH_MAGIC,
        name="Earth Magic",
        description="Increases effectiveness of Earth school spells.",
        values=(1, 2, 3),
    ),
    SkillId.FIRE_MAGIC: SkillDef(
        skill_id=SkillId.FIRE_MAGIC,
        name="Fire Magic",
        description="Increases effectiveness of Fire school spells.",
        values=(1, 2, 3),
    ),
    SkillId.WATER_MAGIC: SkillDef(
        skill_id=SkillId.WATER_MAGIC,
        name="Water Magic",
        description="Increases effectiveness of Water school spells.",
        values=(1, 2, 3),
    ),
    SkillId.LEARNING: SkillDef(
        skill_id=SkillId.LEARNING,
        name="Learning",
        description="Increases experience gained from combat.",
        values=(0.05, 0.10, 0.15),
    ),
    SkillId.MYSTICISM: SkillDef(
        skill_id=SkillId.MYSTICISM,
        name="Mysticism",
        description="Regenerates extra mana each day.",
        values=(2, 3, 4),
    ),
    SkillId.DIPLOMACY: SkillDef(
        skill_id=SkillId.DIPLOMACY,
        name="Diplomacy",
        description="Allows surrendering for less gold and joining wandering creatures.",
        values=(0.20, 0.40, 0.60),
    ),
    SkillId.SCHOLAR: SkillDef(
        skill_id=SkillId.SCHOLAR,
        name="Scholar",
        description="Teaches spells to allied heroes upon meeting.",
        values=(1, 2, 3),
    ),
    SkillId.FIRST_AID: SkillDef(
        skill_id=SkillId.FIRST_AID,
        name="First Aid",
        description="Improves first aid tent healing in combat.",
        values=(25, 50, 75),
    ),
    SkillId.SORCERY: SkillDef(
        skill_id=SkillId.SORCERY,
        name="Sorcery",
        description="Increases spell damage dealt by hero.",
        values=(0.05, 0.10, 0.15),
    ),
    SkillId.RESISTANCE: SkillDef(
        skill_id=SkillId.RESISTANCE,
        name="Resistance",
        description="Reduces spell damage taken by hero's creatures.",
        values=(0.05, 0.10, 0.20),
    ),
    SkillId.INTELLIGENCE: SkillDef(
        skill_id=SkillId.INTELLIGENCE,
        name="Intelligence",
        description="Increases hero's maximum mana.",
        values=(0.25, 0.50, 1.00),
    ),
    SkillId.EAGLE_EYE: SkillDef(
        skill_id=SkillId.EAGLE_EYE,
        name="Eagle Eye",
        description="Chance to learn enemy spells cast in combat.",
        values=(0.20, 0.30, 0.40),
    ),
}
