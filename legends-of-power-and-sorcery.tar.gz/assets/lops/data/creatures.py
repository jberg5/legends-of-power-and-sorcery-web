"""Creature registry with HoMM3-accurate stats for all nine factions."""

from __future__ import annotations

from enum import Enum, auto

from lops.models import CreatureStack, CreatureStats


class CreatureType(Enum):
    # Castle faction - tier 1 through 7, base and upgraded
    PIKEMAN = auto()
    HALBERDIER = auto()
    ARCHER = auto()
    MARKSMAN = auto()
    GRIFFIN = auto()
    ROYAL_GRIFFIN = auto()
    SWORDSMAN = auto()
    CRUSADER = auto()
    MONK = auto()
    ZEALOT = auto()
    CAVALIER = auto()
    CHAMPION = auto()
    ANGEL = auto()
    ARCHANGEL = auto()

    # Necropolis faction
    SKELETON = auto()
    SKELETON_WARRIOR = auto()
    WALKING_DEAD = auto()
    ZOMBIE = auto()
    WIGHT = auto()
    WRAITH = auto()
    VAMPIRE = auto()
    VAMPIRE_LORD = auto()
    LICH = auto()
    POWER_LICH = auto()
    BLACK_KNIGHT = auto()
    DREAD_KNIGHT = auto()
    BONE_DRAGON = auto()
    GHOST_DRAGON = auto()

    # Inferno faction
    IMP = auto()
    FAMILIAR = auto()
    GOG = auto()
    MAGOG = auto()
    HELL_HOUND = auto()
    CERBERUS = auto()
    DEMON = auto()
    HORNED_DEMON = auto()
    PIT_FIEND = auto()
    PIT_LORD = auto()
    EFREETI = auto()
    EFREET_SULTAN = auto()
    DEVIL = auto()
    ARCH_DEVIL = auto()

    # Dungeon faction
    TROGLODYTE = auto()
    INFERNAL_TROGLODYTE = auto()
    HARPY = auto()
    HARPY_HAG = auto()
    BEHOLDER = auto()
    EVIL_EYE = auto()
    MEDUSA = auto()
    MEDUSA_QUEEN = auto()
    MINOTAUR = auto()
    MINOTAUR_KING = auto()
    MANTICORE = auto()
    SCORPICORE = auto()
    RED_DRAGON = auto()
    BLACK_DRAGON = auto()

    # Rampart faction
    CENTAUR = auto()
    CENTAUR_CAPTAIN = auto()
    DWARF = auto()
    BATTLE_DWARF = auto()
    WOOD_ELF = auto()
    GRAND_ELF = auto()
    PEGASUS = auto()
    SILVER_PEGASUS = auto()
    DENDROID_GUARD = auto()
    DENDROID_SOLDIER = auto()
    UNICORN = auto()
    WAR_UNICORN = auto()
    GREEN_DRAGON = auto()
    GOLD_DRAGON = auto()

    # Tower faction
    GREMLIN = auto()
    MASTER_GREMLIN = auto()
    STONE_GARGOYLE = auto()
    OBSIDIAN_GARGOYLE = auto()
    STONE_GOLEM = auto()
    IRON_GOLEM = auto()
    MAGE = auto()
    ARCH_MAGE = auto()
    GENIE = auto()
    MASTER_GENIE = auto()
    NAGA = auto()
    NAGA_QUEEN = auto()
    GIANT = auto()
    TITAN = auto()

    # Stronghold faction
    GOBLIN = auto()
    HOBGOBLIN = auto()
    WOLF_RIDER = auto()
    WOLF_RAIDER = auto()
    ORC = auto()
    ORC_CHIEFTAIN = auto()
    OGRE = auto()
    OGRE_MAGE = auto()
    ROC = auto()
    THUNDERBIRD = auto()
    CYCLOPS = auto()
    CYCLOPS_KING = auto()
    BEHEMOTH = auto()
    ANCIENT_BEHEMOTH = auto()

    # Fortress faction
    GNOLL = auto()
    GNOLL_MARAUDER = auto()
    LIZARDMAN = auto()
    LIZARD_WARRIOR = auto()
    SERPENT_FLY = auto()
    DRAGON_FLY = auto()
    BASILISK = auto()
    GREATER_BASILISK = auto()
    GORGON = auto()
    MIGHTY_GORGON = auto()
    WYVERN = auto()
    WYVERN_MONARCH = auto()
    HYDRA = auto()
    CHAOS_HYDRA = auto()

    # Conflux faction (new entries only; elementals reused from Neutral below)
    PIXIE = auto()
    SPRITE = auto()
    STORM_ELEMENTAL = auto()
    ICE_ELEMENTAL = auto()
    ENERGY_ELEMENTAL = auto()
    MAGMA_ELEMENTAL = auto()
    PSYCHIC_ELEMENTAL = auto()
    MAGIC_ELEMENTAL = auto()
    FIREBIRD = auto()
    PHOENIX = auto()

    # Neutral / Summoned creatures
    AIR_ELEMENTAL = auto()
    EARTH_ELEMENTAL = auto()
    FIRE_ELEMENTAL = auto()
    WATER_ELEMENTAL = auto()


CREATURE_REGISTRY: dict[CreatureType, CreatureStats] = {
    CreatureType.PIKEMAN: CreatureStats(
        name="Pikeman",
        attack=4,
        defense=5,
        min_damage=1,
        max_damage=3,
        hp=10,
        speed=4,
    ),
    CreatureType.HALBERDIER: CreatureStats(
        name="Halberdier",
        attack=6,
        defense=5,
        min_damage=2,
        max_damage=3,
        hp=10,
        speed=5,
    ),
    CreatureType.ARCHER: CreatureStats(
        name="Archer",
        attack=6,
        defense=3,
        min_damage=2,
        max_damage=3,
        hp=10,
        speed=4,
        is_ranged=True,
        shots=12,
    ),
    CreatureType.MARKSMAN: CreatureStats(
        name="Marksman",
        attack=6,
        defense=3,
        min_damage=2,
        max_damage=3,
        hp=10,
        speed=6,
        is_ranged=True,
        shots=24,
        double_strike=True,
    ),
    CreatureType.GRIFFIN: CreatureStats(
        name="Griffin",
        attack=8,
        defense=8,
        min_damage=3,
        max_damage=6,
        hp=25,
        speed=6,
        is_flying=True,
        unlimited_retaliation=True,
    ),
    CreatureType.ROYAL_GRIFFIN: CreatureStats(
        name="Royal Griffin",
        attack=9,
        defense=9,
        min_damage=3,
        max_damage=6,
        hp=25,
        speed=9,
        is_flying=True,
        unlimited_retaliation=True,
    ),
    CreatureType.SWORDSMAN: CreatureStats(
        name="Swordsman",
        attack=10,
        defense=12,
        min_damage=6,
        max_damage=9,
        hp=35,
        speed=5,
    ),
    CreatureType.CRUSADER: CreatureStats(
        name="Crusader",
        attack=12,
        defense=12,
        min_damage=7,
        max_damage=10,
        hp=35,
        speed=6,
        double_strike=True,
    ),
    CreatureType.MONK: CreatureStats(
        name="Monk",
        attack=12,
        defense=7,
        min_damage=10,
        max_damage=12,
        hp=30,
        speed=5,
        is_ranged=True,
        shots=12,
    ),
    CreatureType.ZEALOT: CreatureStats(
        name="Zealot",
        attack=12,
        defense=10,
        min_damage=10,
        max_damage=12,
        hp=30,
        speed=7,
        is_ranged=True,
        shots=24,
    ),
    CreatureType.CAVALIER: CreatureStats(
        name="Cavalier",
        attack=15,
        defense=15,
        min_damage=15,
        max_damage=25,
        hp=100,
        speed=7,
        jousting=True,
    ),
    CreatureType.CHAMPION: CreatureStats(
        name="Champion",
        attack=16,
        defense=16,
        min_damage=20,
        max_damage=25,
        hp=100,
        speed=9,
        jousting=True,
    ),
    CreatureType.ANGEL: CreatureStats(
        name="Angel",
        attack=20,
        defense=20,
        min_damage=50,
        max_damage=50,
        hp=200,
        speed=12,
        is_flying=True,
    ),
    CreatureType.ARCHANGEL: CreatureStats(
        name="Archangel",
        attack=30,
        defense=30,
        min_damage=50,
        max_damage=50,
        hp=250,
        speed=18,
        is_flying=True,
    ),
    # ── Necropolis faction ──────────────────────────────────────────────
    CreatureType.SKELETON: CreatureStats(
        name="Skeleton",
        attack=5,
        defense=4,
        min_damage=1,
        max_damage=3,
        hp=6,
        speed=4,
    ),
    CreatureType.SKELETON_WARRIOR: CreatureStats(
        name="Skeleton Warrior",
        attack=6,
        defense=6,
        min_damage=1,
        max_damage=3,
        hp=6,
        speed=5,
    ),
    CreatureType.WALKING_DEAD: CreatureStats(
        name="Walking Dead",
        attack=5,
        defense=5,
        min_damage=2,
        max_damage=3,
        hp=15,
        speed=3,
    ),
    CreatureType.ZOMBIE: CreatureStats(
        name="Zombie",
        attack=5,
        defense=5,
        min_damage=2,
        max_damage=3,
        hp=20,
        speed=4,
    ),
    CreatureType.WIGHT: CreatureStats(
        name="Wight",
        attack=7,
        defense=7,
        min_damage=3,
        max_damage=5,
        hp=18,
        speed=5,
        is_flying=True,
    ),
    CreatureType.WRAITH: CreatureStats(
        name="Wraith",
        attack=7,
        defense=7,
        min_damage=3,
        max_damage=5,
        hp=18,
        speed=7,
        is_flying=True,
    ),
    CreatureType.VAMPIRE: CreatureStats(
        name="Vampire",
        attack=10,
        defense=9,
        min_damage=5,
        max_damage=8,
        hp=30,
        speed=6,
        is_flying=True,
    ),
    CreatureType.VAMPIRE_LORD: CreatureStats(
        name="Vampire Lord",
        attack=10,
        defense=9,
        min_damage=5,
        max_damage=8,
        hp=40,
        speed=9,
        is_flying=True,
    ),
    CreatureType.LICH: CreatureStats(
        name="Lich",
        attack=13,
        defense=10,
        min_damage=11,
        max_damage=13,
        hp=30,
        speed=6,
        is_ranged=True,
        shots=12,
    ),
    CreatureType.POWER_LICH: CreatureStats(
        name="Power Lich",
        attack=13,
        defense=10,
        min_damage=11,
        max_damage=15,
        hp=40,
        speed=7,
        is_ranged=True,
        shots=24,
    ),
    CreatureType.BLACK_KNIGHT: CreatureStats(
        name="Black Knight",
        attack=16,
        defense=16,
        min_damage=15,
        max_damage=30,
        hp=120,
        speed=7,
    ),
    CreatureType.DREAD_KNIGHT: CreatureStats(
        name="Dread Knight",
        attack=18,
        defense=18,
        min_damage=15,
        max_damage=30,
        hp=120,
        speed=9,
    ),
    CreatureType.BONE_DRAGON: CreatureStats(
        name="Bone Dragon",
        attack=17,
        defense=15,
        min_damage=25,
        max_damage=50,
        hp=150,
        speed=9,
        is_flying=True,
    ),
    CreatureType.GHOST_DRAGON: CreatureStats(
        name="Ghost Dragon",
        attack=19,
        defense=17,
        min_damage=25,
        max_damage=50,
        hp=200,
        speed=14,
        is_flying=True,
    ),
    # ── Inferno faction ─────────────────────────────────────────────────
    CreatureType.IMP: CreatureStats(
        name="Imp",
        attack=2,
        defense=3,
        min_damage=1,
        max_damage=2,
        hp=4,
        speed=5,
        is_flying=True,
    ),
    CreatureType.FAMILIAR: CreatureStats(
        name="Familiar",
        attack=4,
        defense=4,
        min_damage=1,
        max_damage=2,
        hp=4,
        speed=7,
        is_flying=True,
    ),
    CreatureType.GOG: CreatureStats(
        name="Gog",
        attack=6,
        defense=4,
        min_damage=2,
        max_damage=4,
        hp=13,
        speed=4,
        is_ranged=True,
        shots=12,
    ),
    CreatureType.MAGOG: CreatureStats(
        name="Magog",
        attack=7,
        defense=4,
        min_damage=2,
        max_damage=4,
        hp=13,
        speed=6,
        is_ranged=True,
        shots=24,
    ),
    CreatureType.HELL_HOUND: CreatureStats(
        name="Hell Hound",
        attack=10,
        defense=6,
        min_damage=2,
        max_damage=7,
        hp=25,
        speed=7,
    ),
    CreatureType.CERBERUS: CreatureStats(
        name="Cerberus",
        attack=10,
        defense=8,
        min_damage=2,
        max_damage=7,
        hp=25,
        speed=8,
    ),
    CreatureType.DEMON: CreatureStats(
        name="Demon",
        attack=10,
        defense=10,
        min_damage=7,
        max_damage=9,
        hp=35,
        speed=5,
    ),
    CreatureType.HORNED_DEMON: CreatureStats(
        name="Horned Demon",
        attack=10,
        defense=10,
        min_damage=7,
        max_damage=9,
        hp=40,
        speed=6,
    ),
    CreatureType.PIT_FIEND: CreatureStats(
        name="Pit Fiend",
        attack=13,
        defense=13,
        min_damage=13,
        max_damage=17,
        hp=45,
        speed=6,
    ),
    CreatureType.PIT_LORD: CreatureStats(
        name="Pit Lord",
        attack=13,
        defense=13,
        min_damage=13,
        max_damage=17,
        hp=45,
        speed=7,
    ),
    CreatureType.EFREETI: CreatureStats(
        name="Efreeti",
        attack=16,
        defense=12,
        min_damage=16,
        max_damage=24,
        hp=90,
        speed=9,
        is_flying=True,
    ),
    CreatureType.EFREET_SULTAN: CreatureStats(
        name="Efreet Sultan",
        attack=16,
        defense=14,
        min_damage=16,
        max_damage=24,
        hp=90,
        speed=13,
        is_flying=True,
    ),
    CreatureType.DEVIL: CreatureStats(
        name="Devil",
        attack=19,
        defense=21,
        min_damage=30,
        max_damage=40,
        hp=160,
        speed=11,
        is_flying=True,
    ),
    CreatureType.ARCH_DEVIL: CreatureStats(
        name="Arch Devil",
        attack=26,
        defense=28,
        min_damage=30,
        max_damage=40,
        hp=200,
        speed=17,
        is_flying=True,
    ),
    # ── Dungeon faction ─────────────────────────────────────────────────
    CreatureType.TROGLODYTE: CreatureStats(
        name="Troglodyte",
        attack=4,
        defense=3,
        min_damage=1,
        max_damage=3,
        hp=5,
        speed=4,
    ),
    CreatureType.INFERNAL_TROGLODYTE: CreatureStats(
        name="Infernal Troglodyte",
        attack=5,
        defense=4,
        min_damage=1,
        max_damage=3,
        hp=6,
        speed=5,
    ),
    CreatureType.HARPY: CreatureStats(
        name="Harpy",
        attack=6,
        defense=5,
        min_damage=1,
        max_damage=4,
        hp=14,
        speed=6,
        is_flying=True,
    ),
    CreatureType.HARPY_HAG: CreatureStats(
        name="Harpy Hag",
        attack=6,
        defense=6,
        min_damage=1,
        max_damage=4,
        hp=14,
        speed=9,
        is_flying=True,
    ),
    CreatureType.BEHOLDER: CreatureStats(
        name="Beholder",
        attack=9,
        defense=7,
        min_damage=3,
        max_damage=5,
        hp=22,
        speed=5,
        is_ranged=True,
        shots=12,
    ),
    CreatureType.EVIL_EYE: CreatureStats(
        name="Evil Eye",
        attack=10,
        defense=8,
        min_damage=3,
        max_damage=5,
        hp=22,
        speed=7,
        is_ranged=True,
        shots=24,
    ),
    CreatureType.MEDUSA: CreatureStats(
        name="Medusa",
        attack=9,
        defense=9,
        min_damage=6,
        max_damage=8,
        hp=25,
        speed=5,
        is_ranged=True,
        shots=4,
    ),
    CreatureType.MEDUSA_QUEEN: CreatureStats(
        name="Medusa Queen",
        attack=10,
        defense=10,
        min_damage=6,
        max_damage=8,
        hp=30,
        speed=6,
        is_ranged=True,
        shots=8,
    ),
    CreatureType.MINOTAUR: CreatureStats(
        name="Minotaur",
        attack=14,
        defense=12,
        min_damage=12,
        max_damage=20,
        hp=50,
        speed=6,
    ),
    CreatureType.MINOTAUR_KING: CreatureStats(
        name="Minotaur King",
        attack=15,
        defense=15,
        min_damage=12,
        max_damage=20,
        hp=50,
        speed=8,
    ),
    CreatureType.MANTICORE: CreatureStats(
        name="Manticore",
        attack=15,
        defense=13,
        min_damage=14,
        max_damage=20,
        hp=80,
        speed=7,
        is_flying=True,
    ),
    CreatureType.SCORPICORE: CreatureStats(
        name="Scorpicore",
        attack=16,
        defense=14,
        min_damage=14,
        max_damage=20,
        hp=80,
        speed=11,
        is_flying=True,
    ),
    CreatureType.RED_DRAGON: CreatureStats(
        name="Red Dragon",
        attack=19,
        defense=19,
        min_damage=40,
        max_damage=50,
        hp=180,
        speed=11,
        is_flying=True,
    ),
    CreatureType.BLACK_DRAGON: CreatureStats(
        name="Black Dragon",
        attack=25,
        defense=25,
        min_damage=40,
        max_damage=50,
        hp=300,
        speed=15,
        is_flying=True,
    ),
    # ── Rampart faction ──────────────────────────────────────────────
    CreatureType.CENTAUR: CreatureStats(
        name="Centaur",
        attack=5,
        defense=3,
        min_damage=2,
        max_damage=3,
        hp=8,
        speed=6,
    ),
    CreatureType.CENTAUR_CAPTAIN: CreatureStats(
        name="Centaur Captain",
        attack=6,
        defense=3,
        min_damage=2,
        max_damage=3,
        hp=10,
        speed=8,
    ),
    CreatureType.DWARF: CreatureStats(
        name="Dwarf",
        attack=6,
        defense=7,
        min_damage=2,
        max_damage=4,
        hp=20,
        speed=3,
    ),
    CreatureType.BATTLE_DWARF: CreatureStats(
        name="Battle Dwarf",
        attack=7,
        defense=7,
        min_damage=2,
        max_damage=4,
        hp=20,
        speed=5,
    ),
    CreatureType.WOOD_ELF: CreatureStats(
        name="Wood Elf",
        attack=9,
        defense=5,
        min_damage=3,
        max_damage=5,
        hp=15,
        speed=6,
        is_ranged=True,
        shots=24,
    ),
    CreatureType.GRAND_ELF: CreatureStats(
        name="Grand Elf",
        attack=9,
        defense=5,
        min_damage=3,
        max_damage=5,
        hp=15,
        speed=7,
        is_ranged=True,
        shots=24,
    ),
    CreatureType.PEGASUS: CreatureStats(
        name="Pegasus",
        attack=9,
        defense=8,
        min_damage=5,
        max_damage=9,
        hp=30,
        speed=8,
        is_flying=True,
    ),
    CreatureType.SILVER_PEGASUS: CreatureStats(
        name="Silver Pegasus",
        attack=9,
        defense=10,
        min_damage=5,
        max_damage=9,
        hp=30,
        speed=12,
        is_flying=True,
    ),
    CreatureType.DENDROID_GUARD: CreatureStats(
        name="Dendroid Guard",
        attack=9,
        defense=12,
        min_damage=10,
        max_damage=14,
        hp=55,
        speed=3,
    ),
    CreatureType.DENDROID_SOLDIER: CreatureStats(
        name="Dendroid Soldier",
        attack=9,
        defense=12,
        min_damage=10,
        max_damage=14,
        hp=65,
        speed=4,
    ),
    CreatureType.UNICORN: CreatureStats(
        name="Unicorn",
        attack=15,
        defense=14,
        min_damage=18,
        max_damage=22,
        hp=90,
        speed=7,
    ),
    CreatureType.WAR_UNICORN: CreatureStats(
        name="War Unicorn",
        attack=15,
        defense=14,
        min_damage=18,
        max_damage=22,
        hp=110,
        speed=9,
    ),
    CreatureType.GREEN_DRAGON: CreatureStats(
        name="Green Dragon",
        attack=18,
        defense=18,
        min_damage=40,
        max_damage=50,
        hp=180,
        speed=10,
        is_flying=True,
    ),
    CreatureType.GOLD_DRAGON: CreatureStats(
        name="Gold Dragon",
        attack=27,
        defense=27,
        min_damage=40,
        max_damage=50,
        hp=250,
        speed=16,
        is_flying=True,
    ),
    # ── Tower faction ──────────────────────────────────────────────────
    CreatureType.GREMLIN: CreatureStats(
        name="Gremlin",
        attack=3,
        defense=3,
        min_damage=1,
        max_damage=2,
        hp=4,
        speed=4,
    ),
    CreatureType.MASTER_GREMLIN: CreatureStats(
        name="Master Gremlin",
        attack=4,
        defense=4,
        min_damage=1,
        max_damage=2,
        hp=4,
        speed=5,
        is_ranged=True,
        shots=8,
    ),
    CreatureType.STONE_GARGOYLE: CreatureStats(
        name="Stone Gargoyle",
        attack=6,
        defense=6,
        min_damage=2,
        max_damage=3,
        hp=16,
        speed=6,
        is_flying=True,
    ),
    CreatureType.OBSIDIAN_GARGOYLE: CreatureStats(
        name="Obsidian Gargoyle",
        attack=7,
        defense=7,
        min_damage=2,
        max_damage=3,
        hp=16,
        speed=9,
        is_flying=True,
    ),
    CreatureType.STONE_GOLEM: CreatureStats(
        name="Stone Golem",
        attack=7,
        defense=10,
        min_damage=4,
        max_damage=5,
        hp=30,
        speed=3,
    ),
    CreatureType.IRON_GOLEM: CreatureStats(
        name="Iron Golem",
        attack=9,
        defense=10,
        min_damage=4,
        max_damage=5,
        hp=35,
        speed=5,
    ),
    CreatureType.MAGE: CreatureStats(
        name="Mage",
        attack=11,
        defense=8,
        min_damage=7,
        max_damage=9,
        hp=25,
        speed=5,
        is_ranged=True,
        shots=24,
    ),
    CreatureType.ARCH_MAGE: CreatureStats(
        name="Arch Mage",
        attack=12,
        defense=9,
        min_damage=7,
        max_damage=9,
        hp=30,
        speed=7,
        is_ranged=True,
        shots=24,
    ),
    CreatureType.GENIE: CreatureStats(
        name="Genie",
        attack=12,
        defense=12,
        min_damage=13,
        max_damage=16,
        hp=40,
        speed=7,
        is_flying=True,
    ),
    CreatureType.MASTER_GENIE: CreatureStats(
        name="Master Genie",
        attack=12,
        defense=12,
        min_damage=13,
        max_damage=16,
        hp=40,
        speed=11,
        is_flying=True,
    ),
    CreatureType.NAGA: CreatureStats(
        name="Naga",
        attack=16,
        defense=13,
        min_damage=20,
        max_damage=20,
        hp=110,
        speed=5,
    ),
    CreatureType.NAGA_QUEEN: CreatureStats(
        name="Naga Queen",
        attack=16,
        defense=13,
        min_damage=30,
        max_damage=30,
        hp=110,
        speed=7,
    ),
    CreatureType.GIANT: CreatureStats(
        name="Giant",
        attack=19,
        defense=16,
        min_damage=40,
        max_damage=60,
        hp=150,
        speed=7,
    ),
    CreatureType.TITAN: CreatureStats(
        name="Titan",
        attack=24,
        defense=24,
        min_damage=40,
        max_damage=60,
        hp=300,
        speed=11,
        is_ranged=True,
        shots=24,
    ),
    # ── Stronghold faction ─────────────────────────────────────────────
    CreatureType.GOBLIN: CreatureStats(
        name="Goblin",
        attack=4,
        defense=2,
        min_damage=1,
        max_damage=2,
        hp=5,
        speed=5,
    ),
    CreatureType.HOBGOBLIN: CreatureStats(
        name="Hobgoblin",
        attack=5,
        defense=3,
        min_damage=1,
        max_damage=2,
        hp=5,
        speed=7,
    ),
    CreatureType.WOLF_RIDER: CreatureStats(
        name="Wolf Rider",
        attack=7,
        defense=5,
        min_damage=2,
        max_damage=4,
        hp=10,
        speed=6,
    ),
    CreatureType.WOLF_RAIDER: CreatureStats(
        name="Wolf Raider",
        attack=8,
        defense=5,
        min_damage=3,
        max_damage=4,
        hp=10,
        speed=8,
    ),
    CreatureType.ORC: CreatureStats(
        name="Orc",
        attack=8,
        defense=4,
        min_damage=2,
        max_damage=5,
        hp=15,
        speed=4,
        is_ranged=True,
        shots=12,
    ),
    CreatureType.ORC_CHIEFTAIN: CreatureStats(
        name="Orc Chieftain",
        attack=8,
        defense=4,
        min_damage=2,
        max_damage=5,
        hp=20,
        speed=5,
        is_ranged=True,
        shots=24,
    ),
    CreatureType.OGRE: CreatureStats(
        name="Ogre",
        attack=13,
        defense=7,
        min_damage=6,
        max_damage=12,
        hp=40,
        speed=4,
    ),
    CreatureType.OGRE_MAGE: CreatureStats(
        name="Ogre Mage",
        attack=13,
        defense=7,
        min_damage=6,
        max_damage=12,
        hp=60,
        speed=5,
    ),
    CreatureType.ROC: CreatureStats(
        name="Roc",
        attack=13,
        defense=11,
        min_damage=11,
        max_damage=15,
        hp=60,
        speed=7,
        is_flying=True,
    ),
    CreatureType.THUNDERBIRD: CreatureStats(
        name="Thunderbird",
        attack=13,
        defense=11,
        min_damage=11,
        max_damage=15,
        hp=60,
        speed=11,
        is_flying=True,
    ),
    CreatureType.CYCLOPS: CreatureStats(
        name="Cyclops",
        attack=15,
        defense=12,
        min_damage=16,
        max_damage=20,
        hp=70,
        speed=6,
        is_ranged=True,
        shots=16,
    ),
    CreatureType.CYCLOPS_KING: CreatureStats(
        name="Cyclops King",
        attack=17,
        defense=13,
        min_damage=16,
        max_damage=20,
        hp=70,
        speed=8,
        is_ranged=True,
        shots=24,
    ),
    CreatureType.BEHEMOTH: CreatureStats(
        name="Behemoth",
        attack=17,
        defense=17,
        min_damage=30,
        max_damage=50,
        hp=160,
        speed=6,
    ),
    CreatureType.ANCIENT_BEHEMOTH: CreatureStats(
        name="Ancient Behemoth",
        attack=19,
        defense=19,
        min_damage=30,
        max_damage=50,
        hp=300,
        speed=9,
    ),
    # ── Fortress faction ───────────────────────────────────────────────
    CreatureType.GNOLL: CreatureStats(
        name="Gnoll",
        attack=3,
        defense=5,
        min_damage=2,
        max_damage=3,
        hp=6,
        speed=4,
    ),
    CreatureType.GNOLL_MARAUDER: CreatureStats(
        name="Gnoll Marauder",
        attack=4,
        defense=6,
        min_damage=2,
        max_damage=3,
        hp=6,
        speed=5,
    ),
    CreatureType.LIZARDMAN: CreatureStats(
        name="Lizardman",
        attack=5,
        defense=6,
        min_damage=2,
        max_damage=3,
        hp=14,
        speed=4,
        is_ranged=True,
        shots=12,
    ),
    CreatureType.LIZARD_WARRIOR: CreatureStats(
        name="Lizard Warrior",
        attack=6,
        defense=8,
        min_damage=2,
        max_damage=5,
        hp=15,
        speed=5,
        is_ranged=True,
        shots=24,
    ),
    CreatureType.SERPENT_FLY: CreatureStats(
        name="Serpent Fly",
        attack=7,
        defense=9,
        min_damage=2,
        max_damage=5,
        hp=20,
        speed=9,
        is_flying=True,
    ),
    CreatureType.DRAGON_FLY: CreatureStats(
        name="Dragon Fly",
        attack=8,
        defense=10,
        min_damage=2,
        max_damage=5,
        hp=20,
        speed=13,
        is_flying=True,
    ),
    CreatureType.BASILISK: CreatureStats(
        name="Basilisk",
        attack=11,
        defense=11,
        min_damage=6,
        max_damage=10,
        hp=35,
        speed=5,
    ),
    CreatureType.GREATER_BASILISK: CreatureStats(
        name="Greater Basilisk",
        attack=12,
        defense=12,
        min_damage=6,
        max_damage=10,
        hp=40,
        speed=7,
    ),
    CreatureType.GORGON: CreatureStats(
        name="Gorgon",
        attack=10,
        defense=14,
        min_damage=12,
        max_damage=16,
        hp=70,
        speed=5,
    ),
    CreatureType.MIGHTY_GORGON: CreatureStats(
        name="Mighty Gorgon",
        attack=11,
        defense=16,
        min_damage=12,
        max_damage=16,
        hp=70,
        speed=6,
    ),
    CreatureType.WYVERN: CreatureStats(
        name="Wyvern",
        attack=14,
        defense=14,
        min_damage=14,
        max_damage=18,
        hp=70,
        speed=7,
        is_flying=True,
    ),
    CreatureType.WYVERN_MONARCH: CreatureStats(
        name="Wyvern Monarch",
        attack=14,
        defense=14,
        min_damage=18,
        max_damage=22,
        hp=70,
        speed=11,
        is_flying=True,
    ),
    CreatureType.HYDRA: CreatureStats(
        name="Hydra",
        attack=16,
        defense=18,
        min_damage=25,
        max_damage=45,
        hp=175,
        speed=5,
    ),
    CreatureType.CHAOS_HYDRA: CreatureStats(
        name="Chaos Hydra",
        attack=18,
        defense=20,
        min_damage=25,
        max_damage=45,
        hp=250,
        speed=7,
    ),
    # ── Conflux faction ────────────────────────────────────────────────
    CreatureType.PIXIE: CreatureStats(
        name="Pixie",
        attack=2,
        defense=2,
        min_damage=1,
        max_damage=2,
        hp=3,
        speed=7,
        is_flying=True,
    ),
    CreatureType.SPRITE: CreatureStats(
        name="Sprite",
        attack=2,
        defense=2,
        min_damage=1,
        max_damage=3,
        hp=3,
        speed=9,
        is_flying=True,
    ),
    CreatureType.STORM_ELEMENTAL: CreatureStats(
        name="Storm Elemental",
        attack=9,
        defense=9,
        min_damage=2,
        max_damage=8,
        hp=25,
        speed=8,
        is_ranged=True,
        shots=24,
    ),
    CreatureType.ICE_ELEMENTAL: CreatureStats(
        name="Ice Elemental",
        attack=8,
        defense=10,
        min_damage=3,
        max_damage=7,
        hp=30,
        speed=6,
        is_ranged=True,
        shots=24,
    ),
    CreatureType.ENERGY_ELEMENTAL: CreatureStats(
        name="Energy Elemental",
        attack=12,
        defense=8,
        min_damage=4,
        max_damage=6,
        hp=35,
        speed=8,
        is_flying=True,
    ),
    CreatureType.MAGMA_ELEMENTAL: CreatureStats(
        name="Magma Elemental",
        attack=11,
        defense=11,
        min_damage=6,
        max_damage=10,
        hp=40,
        speed=6,
    ),
    CreatureType.PSYCHIC_ELEMENTAL: CreatureStats(
        name="Psychic Elemental",
        attack=15,
        defense=13,
        min_damage=10,
        max_damage=20,
        hp=75,
        speed=7,
    ),
    CreatureType.MAGIC_ELEMENTAL: CreatureStats(
        name="Magic Elemental",
        attack=15,
        defense=13,
        min_damage=15,
        max_damage=25,
        hp=80,
        speed=9,
    ),
    CreatureType.FIREBIRD: CreatureStats(
        name="Firebird",
        attack=18,
        defense=18,
        min_damage=30,
        max_damage=40,
        hp=150,
        speed=15,
        is_flying=True,
    ),
    CreatureType.PHOENIX: CreatureStats(
        name="Phoenix",
        attack=21,
        defense=18,
        min_damage=30,
        max_damage=40,
        hp=200,
        speed=21,
        is_flying=True,
    ),
    # Neutral / Summoned creatures
    CreatureType.AIR_ELEMENTAL: CreatureStats(
        name="Air Elemental",
        attack=9,
        defense=9,
        min_damage=2,
        max_damage=8,
        hp=25,
        speed=7,
        is_flying=True,
    ),
    CreatureType.EARTH_ELEMENTAL: CreatureStats(
        name="Earth Elemental",
        attack=10,
        defense=10,
        min_damage=4,
        max_damage=8,
        hp=40,
        speed=4,
    ),
    CreatureType.FIRE_ELEMENTAL: CreatureStats(
        name="Fire Elemental",
        attack=10,
        defense=8,
        min_damage=4,
        max_damage=6,
        hp=35,
        speed=6,
    ),
    CreatureType.WATER_ELEMENTAL: CreatureStats(
        name="Water Elemental",
        attack=8,
        defense=10,
        min_damage=3,
        max_damage=7,
        hp=30,
        speed=5,
    ),
}


def make_stack(creature_type: CreatureType, count: int) -> CreatureStack:
    """Create a new CreatureStack of the given type and count."""
    stats = CREATURE_REGISTRY[creature_type]
    return CreatureStack(
        stats=stats,
        count=count,
        current_hp=stats.hp,
    )
