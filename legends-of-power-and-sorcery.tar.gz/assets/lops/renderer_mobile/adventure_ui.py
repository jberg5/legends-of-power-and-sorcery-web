"""Mobile adventure UI: bottom action bar, settings dialog, New Game button.

Subclasses the desktop AdventureUI to reuse dialog rendering and resource
bar logic, overriding the victory screen and adding mobile-specific overlays.
"""

from __future__ import annotations

import pygame

from lops.adventure.adventure_state import AdventureState
from lops.renderer.adventure_ui import AdventureUI

COLOR_ACTION_BAR = (30, 28, 24)
COLOR_ACTION_BTN = (55, 65, 90)
COLOR_ACTION_BTN_HOVER = (75, 90, 125)
COLOR_ACTION_TEXT = (220, 220, 220)
COLOR_SETTINGS_BG = (40, 36, 32)
COLOR_SETTINGS_BORDER = (180, 150, 80)


class MobileAdventureUI(AdventureUI):
    """Mobile HUD: thin top bar, bottom action bar, settings dialog."""

    ACTION_BAR_HEIGHT = 52

    def __init__(self, surface: pygame.Surface, viewport_w: int | None = None):
        super().__init__(surface, viewport_w=viewport_w)
        self.btn_font = pygame.font.Font(None, 22)

        # Settings dialog state
        self.settings_open = False

        # Action bar button rects (computed in draw)
        self._action_rects: dict[str, pygame.Rect] = {}

        # New Game button rect (computed in _draw_victory_screen)
        self._new_game_rect = pygame.Rect(0, 0, 0, 0)

    def draw(self, adventure_state: AdventureState, anim_state=None):
        # Draw standard HUD bar and bottom resource bar
        self._draw_hud_bar(adventure_state, anim_state=anim_state)
        self._draw_bottom_bar(adventure_state)
        self._draw_status_message()

        # Dialogs
        self._draw_chest_dialog()
        self._draw_arena_dialog()
        self._draw_dwelling_dialog(adventure_state)
        self._draw_hill_fort_dialog(adventure_state)

        # Mobile action bar (above resource bar)
        self._draw_action_bar(adventure_state, anim_state)

        # Settings overlay
        if self.settings_open:
            self._draw_settings_dialog(anim_state)

        # Victory/game-over with "New Game?" button
        if adventure_state.game_over:
            self._draw_victory_screen(adventure_state)

    def _draw_action_bar(self, state: AdventureState, anim_state):
        """Bottom action bar with touch-friendly buttons."""
        sh = self.surface.get_height()
        bar_y = sh - self.BOTTOM_BAR_HEIGHT - self.ACTION_BAR_HEIGHT
        vw = self.viewport_w

        # Bar background
        pygame.draw.rect(
            self.surface, COLOR_ACTION_BAR,
            (0, bar_y, vw, self.ACTION_BAR_HEIGHT),
        )
        pygame.draw.line(
            self.surface, (60, 55, 45),
            (0, bar_y), (vw, bar_y), 1,
        )

        # Button definitions
        from lops.adventure.movement_anim import SPEED_LABELS
        speed_label = "1x"
        if anim_state is not None:
            speed_label = SPEED_LABELS.get(anim_state.speed, "1x")

        buttons = [
            ("end_turn", "End Turn"),
            ("settings", f"Settings"),
            ("hero_modal", "Hero"),
            ("next_hero", "Next"),
        ]

        btn_h = 38
        btn_gap = 10
        total_btns = len(buttons)
        btn_w = min(130, (vw - btn_gap * (total_btns + 1)) // total_btns)
        total_w = total_btns * btn_w + (total_btns - 1) * btn_gap
        start_x = (vw - total_w) // 2
        btn_y = bar_y + (self.ACTION_BAR_HEIGHT - btn_h) // 2

        mx, my = pygame.mouse.get_pos()
        self._action_rects.clear()

        for i, (action_id, label) in enumerate(buttons):
            x = start_x + i * (btn_w + btn_gap)
            rect = pygame.Rect(x, btn_y, btn_w, btn_h)
            self._action_rects[action_id] = rect

            hover = rect.collidepoint(mx, my)
            bg = COLOR_ACTION_BTN_HOVER if hover else COLOR_ACTION_BTN
            pygame.draw.rect(self.surface, bg, rect, border_radius=6)
            pygame.draw.rect(
                self.surface, (100, 100, 110), rect, 1, border_radius=6
            )

            txt = self.btn_font.render(label, True, COLOR_ACTION_TEXT)
            self.surface.blit(txt, txt.get_rect(center=rect.center))

    def _draw_settings_dialog(self, anim_state):
        """Settings overlay: movement speed toggle."""
        sw, sh = self.viewport_w, self.surface.get_height()

        # Dim background
        overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 160))
        self.surface.blit(overlay, (0, 0))

        # Dialog box
        dw, dh = min(360, sw - 40), 200
        dx = (sw - dw) // 2
        dy = (sh - dh) // 2
        pygame.draw.rect(
            self.surface, COLOR_SETTINGS_BG, (dx, dy, dw, dh), border_radius=8
        )
        pygame.draw.rect(
            self.surface, COLOR_SETTINGS_BORDER, (dx, dy, dw, dh), 2, border_radius=8
        )

        # Title
        title = self.font.render("Settings", True, (240, 200, 50))
        self.surface.blit(title, title.get_rect(centerx=dx + dw // 2, y=dy + 14))

        # Speed option
        from lops.adventure.movement_anim import SPEED_LABELS, AnimSpeed
        current_speed = anim_state.speed if anim_state else AnimSpeed.NORMAL
        speed_label = SPEED_LABELS.get(current_speed, "1x")

        speed_text = self.font.render(
            f"Movement Speed: {speed_label}", True, (200, 200, 210)
        )
        self.surface.blit(
            speed_text, speed_text.get_rect(centerx=dx + dw // 2, y=dy + 55)
        )

        # Speed buttons
        btn_w, btn_h = 80, 36
        btn_y = dy + 90
        speeds = [
            (AnimSpeed.NORMAL, "1x"),
            (AnimSpeed.FAST, "2x"),
            (AnimSpeed.INSTANT, ">>"),
        ]
        total_w = len(speeds) * btn_w + (len(speeds) - 1) * 12
        sx = dx + (dw - total_w) // 2
        mx, my = pygame.mouse.get_pos()

        self._speed_rects: dict[str, tuple[pygame.Rect, object]] = {}
        for i, (spd, label) in enumerate(speeds):
            rect = pygame.Rect(sx + i * (btn_w + 12), btn_y, btn_w, btn_h)
            is_active = current_speed == spd
            hover = rect.collidepoint(mx, my)

            if is_active:
                bg = (80, 120, 80)
            elif hover:
                bg = (70, 80, 100)
            else:
                bg = (50, 55, 65)

            pygame.draw.rect(self.surface, bg, rect, border_radius=5)
            pygame.draw.rect(self.surface, (140, 140, 150), rect, 1, border_radius=5)
            txt = self.font.render(label, True, (255, 255, 255))
            self.surface.blit(txt, txt.get_rect(center=rect.center))
            self._speed_rects[f"speed_{i}"] = (rect, spd)

        # Close button
        close_rect = pygame.Rect(dx + dw // 2 - 50, dy + dh - 48, 100, 34)
        self._settings_close_rect = close_rect
        hover = close_rect.collidepoint(mx, my)
        bg = (100, 65, 65) if hover else (80, 50, 50)
        pygame.draw.rect(self.surface, bg, close_rect, border_radius=5)
        pygame.draw.rect(
            self.surface, (180, 180, 180), close_rect, 1, border_radius=5
        )
        txt = self.font.render("Close", True, (255, 255, 255))
        self.surface.blit(txt, txt.get_rect(center=close_rect.center))

    def _draw_victory_screen(self, state: AdventureState):
        """Victory/defeat screen with 'New Game?' button instead of 'Press ESC'."""
        sw, sh = self.surface.get_size()
        overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        self.surface.blit(overlay, (0, 0))

        if state.winner_id is not None:
            winner = state.players[state.winner_id]
            text = f"{winner.hero.name} is victorious!"
        else:
            text = "Game Over!"

        title = self.large_font.render(text, True, (255, 215, 0))
        title_rect = title.get_rect(center=(sw // 2, sh // 2 - 30))
        self.surface.blit(title, title_rect)

        # "New Game?" button
        btn_w, btn_h = 180, 48
        self._new_game_rect = pygame.Rect(
            sw // 2 - btn_w // 2, sh // 2 + 20, btn_w, btn_h
        )
        mx, my = pygame.mouse.get_pos()
        hover = self._new_game_rect.collidepoint(mx, my)
        bg = (80, 110, 80) if hover else (60, 90, 60)
        pygame.draw.rect(self.surface, bg, self._new_game_rect, border_radius=8)
        pygame.draw.rect(
            self.surface, (180, 200, 150), self._new_game_rect, 2, border_radius=8
        )
        txt = self.font.render("New Game?", True, (255, 255, 255))
        self.surface.blit(txt, txt.get_rect(center=self._new_game_rect.center))

    def is_new_game_clicked(self, pos: tuple[int, int]) -> bool:
        return self._new_game_rect.collidepoint(pos)

    def handle_tap(self, pos: tuple[int, int]) -> str | None:
        """Check if a tap hit an action bar button or settings control.

        Returns action string or None if tap wasn't on any button.
        """
        # Settings dialog is modal
        if self.settings_open:
            return self._handle_settings_tap(pos)

        # Action bar buttons
        for action_id, rect in self._action_rects.items():
            if rect.collidepoint(pos):
                if action_id == "settings":
                    self.settings_open = True
                    return "settings_opened"
                return action_id
        return None

    def _handle_settings_tap(self, pos: tuple[int, int]) -> str | None:
        """Handle taps inside the settings dialog."""
        # Speed buttons
        for key, (rect, spd) in getattr(self, "_speed_rects", {}).items():
            if rect.collidepoint(pos):
                # Return the speed to set (handled by the input handler)
                self._pending_speed = spd
                return "set_speed"

        # Close button
        if hasattr(self, "_settings_close_rect"):
            if self._settings_close_rect.collidepoint(pos):
                self.settings_open = False
                return "settings_closed"

        return "settings_consumed"  # block tap-through
