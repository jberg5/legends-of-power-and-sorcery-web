"""HoMM3 damage formula and combat math."""

from __future__ import annotations

import random

from lops.models import CreatureStack, Hero


def calculate_damage(
    attacker: CreatureStack,
    defender: CreatureStack,
    attacker_hero: Hero | None = None,
    defender_hero: Hero | None = None,
    is_ranged: bool = False,
    distance: int = 0,
    wall_penalty: bool = False,
) -> int:
    """Calculate damage using the HoMM3 formula.

    base_damage * stack_size * atk_def_modifier

    Atk > Def: multiplier = 1 + 0.05 * diff, capped at 4.0
    Def > Atk: multiplier = 1 / (1 + 0.025 * diff), floor 0.3
    """
    # Roll base damage per creature
    min_dmg = attacker.effective_min_damage
    max_dmg = attacker.effective_max_damage
    base_damage = random.randint(min_dmg, max_dmg)

    # Total raw damage
    raw_damage = base_damage * attacker.count

    # Calculate effective attack and defense with hero bonuses
    atk = attacker.effective_attack
    dfn = defender.effective_defense
    if attacker_hero:
        atk += attacker_hero.effective_attack()
    if defender_hero:
        dfn += defender_hero.effective_defense()

    # Attack/defense modifier
    diff = atk - dfn
    if diff > 0:
        modifier = 1.0 + 0.05 * diff
        modifier = min(modifier, 4.0)
    elif diff < 0:
        modifier = 1.0 / (1.0 + 0.025 * abs(diff))
        modifier = max(modifier, 0.3)
    else:
        modifier = 1.0

    total_damage = int(raw_damage * modifier)

    # Secondary skill modifiers
    from lops.skills import SkillId

    if not is_ranged and attacker_hero:
        offense = attacker_hero.skill_value(SkillId.OFFENSE)
        if offense > 0:
            total_damage = int(total_damage * (1.0 + offense))
    if is_ranged and attacker_hero:
        archery = attacker_hero.skill_value(SkillId.ARCHERY)
        if archery > 0:
            total_damage = int(total_damage * (1.0 + archery))
    if defender_hero:
        armorer = defender_hero.skill_value(SkillId.ARMORER)
        if armorer > 0:
            total_damage = int(total_damage * (1.0 - armorer))

    # Shield buff: reduce melee damage
    if not is_ranged:
        for buff in defender.active_buffs:
            if (
                hasattr(buff, "melee_damage_reduction")
                and buff.melee_damage_reduction > 0
            ):
                total_damage = int(total_damage * (1.0 - buff.melee_damage_reduction))

    # Air Shield buff: reduce ranged damage
    if is_ranged:
        for buff in defender.active_buffs:
            if (
                hasattr(buff, "ranged_damage_reduction")
                and buff.ranged_damage_reduction > 0
            ):
                total_damage = int(total_damage * (1.0 - buff.ranged_damage_reduction))

    # Wall penalty: halve damage when shooting across walls
    if wall_penalty:
        total_damage = total_damage // 2

    return max(1, total_damage)  # always at least 1 damage


def calculate_damage_range(
    attacker: CreatureStack,
    defender: CreatureStack,
    attacker_hero: Hero | None = None,
    defender_hero: Hero | None = None,
    is_ranged: bool = False,
) -> tuple[int, int]:
    """Calculate min and max possible damage (no randomness)."""
    min_dmg = attacker.effective_min_damage * attacker.count
    max_dmg = attacker.effective_max_damage * attacker.count

    atk = attacker.effective_attack
    dfn = defender.effective_defense
    if attacker_hero:
        atk += attacker_hero.effective_attack()
    if defender_hero:
        dfn += defender_hero.effective_defense()

    diff = atk - dfn
    if diff > 0:
        modifier = min(1.0 + 0.05 * diff, 4.0)
    elif diff < 0:
        modifier = max(1.0 / (1.0 + 0.025 * abs(diff)), 0.3)
    else:
        modifier = 1.0

    lo = int(min_dmg * modifier)
    hi = int(max_dmg * modifier)

    # Secondary skill modifiers
    from lops.skills import SkillId

    if not is_ranged and attacker_hero:
        offense = attacker_hero.skill_value(SkillId.OFFENSE)
        if offense > 0:
            lo = int(lo * (1.0 + offense))
            hi = int(hi * (1.0 + offense))
    if is_ranged and attacker_hero:
        archery = attacker_hero.skill_value(SkillId.ARCHERY)
        if archery > 0:
            lo = int(lo * (1.0 + archery))
            hi = int(hi * (1.0 + archery))
    if defender_hero:
        armorer = defender_hero.skill_value(SkillId.ARMORER)
        if armorer > 0:
            lo = int(lo * (1.0 - armorer))
            hi = int(hi * (1.0 - armorer))

    return (max(1, lo), max(1, hi))


def roll_morale(stack: CreatureStack, hero: Hero | None = None) -> bool:
    """Roll for positive morale (extra turn). Leadership skill + artifacts + buffs increase chance."""
    from lops.skills import SkillId

    chance = 0.08
    if hero:
        leadership = hero.skill_value(SkillId.LEADERSHIP)
        chance += leadership * 0.04
        chance += hero.artifact_morale_bonus() * 0.04
    chance += stack.buff_morale_mod * 0.04
    return random.random() < chance


def roll_luck(stack: CreatureStack, hero: Hero | None = None) -> bool:
    """Roll for luck (double damage). Luck skill + artifacts + buffs increase chance."""
    from lops.skills import SkillId

    chance = 0.04
    if hero:
        luck = hero.skill_value(SkillId.LUCK)
        chance += luck * 0.04
        chance += hero.artifact_luck_bonus() * 0.04
    chance += stack.buff_luck_mod * 0.04
    return random.random() < chance


def calculate_tower_damage(defender_creature_count: int, is_central: bool) -> int:
    """Calculate arrow tower damage.

    Scales with total garrison size. Central tower does full damage,
    flanking towers do half.
    """
    base = max(1, defender_creature_count // 10 + 5)
    if not is_central:
        base = max(1, base // 2)
    # Add some variance
    variance = random.randint(-1, 1)
    return max(1, base + variance)
