import asyncio
import sys

import pygame


def _detect_layout() -> tuple[int, int, int, bool]:
    """Detect screen dimensions and whether we're on mobile.

    Returns (viewport_w, sidebar_w, screen_h, is_mobile).
    """
    is_mobile = False
    if sys.platform == "emscripten":
        import platform as _plat

        w = int(_plat.window.innerWidth)
        h = int(_plat.window.innerHeight)
        # Use device pixel ratio for sharper rendering on high-DPI screens
        dpr = float(getattr(_plat.window, "devicePixelRatio", 1))
        is_mobile = w < 900
        if is_mobile:
            # Mobile: no sidebar, full screen, landscape preferred
            canvas_w = int(w * min(dpr, 2))
            canvas_h = int(h * min(dpr, 2))
            # Cap at reasonable resolution to avoid performance issues
            canvas_w = min(canvas_w, 1920)
            canvas_h = min(canvas_h, 1080)
            return (canvas_w, 0, canvas_h, True)
        else:
            # Desktop browser: 1280x720 standard
            return (1024, 256, 720, False)
    # Native desktop
    return (1024, 256, 720, False)


async def main():
    pygame.init()
    viewport_w, sidebar_w, screen_h, is_mobile = _detect_layout()
    screen = pygame.display.set_mode((viewport_w + sidebar_w, screen_h))
    pygame.display.set_caption("Legends of Power and Sorcery")

    # Future: if is_mobile, use MobileFrontend with dedicated renderers.
    # For now, desktop frontend works on all screen sizes.
    from lops.frontend.desktop import DesktopFrontend

    frontend = DesktopFrontend(screen)

    from lops.frontend.game_loop import GameLoop

    loop = GameLoop(screen, frontend)
    await loop.run()


if __name__ == "__main__":
    asyncio.run(main())
