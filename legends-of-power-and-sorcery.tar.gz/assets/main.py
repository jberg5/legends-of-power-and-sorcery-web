import asyncio
import sys

import pygame


def _detect_layout() -> tuple[int, int, int, bool]:
    """Detect screen dimensions and whether we're on mobile.

    Returns (viewport_w, sidebar_w, screen_h, is_mobile).
    """
    is_mobile = False
    if sys.platform == "emscripten":
        import platform as _plat

        w = int(_plat.window.innerWidth)
        h = int(_plat.window.innerHeight)
        # Use device pixel ratio for sharper rendering on high-DPI screens
        dpr = float(getattr(_plat.window, "devicePixelRatio", 1))
        is_mobile = w < 900
        if is_mobile:
            # Mobile: no sidebar, full screen, landscape preferred
            canvas_w = int(w * min(dpr, 2))
            canvas_h = int(h * min(dpr, 2))
            # Cap at reasonable resolution to avoid performance issues
            canvas_w = min(canvas_w, 1920)
            canvas_h = min(canvas_h, 1080)
            return (canvas_w, 0, canvas_h, True)
        else:
            # Desktop browser: 1280x720 standard
            return (1024, 256, 720, False)
    # Native desktop
    return (1024, 256, 720, False)


async def main():
    pygame.init()
    VIEWPORT_W, SIDEBAR_W, SCREEN_H, IS_MOBILE = _detect_layout()
    screen = pygame.display.set_mode((VIEWPORT_W + SIDEBAR_W, SCREEN_H))
    pygame.display.set_caption("Legends of Power and Sorcery")

    from lops.adventure.game_director import GameDirector, GameMode
    from lops.adventure.map_objects import (
        TownSite,
        TreasureChest,
        WanderingMonster,
    )
    from lops.adventure.movement_anim import AdventureAnimState, AnimSpeed
    from lops.ai.opponent import AIOpponent

    # Start with welcome screen
    from lops.game_log import GameLog
    from lops.input.adventure_input import AdventureInputHandler
    from lops.input.handler import InputHandler
    from lops.models import Side
    from lops.renderer.adventure_renderer import AdventureRenderer, set_adv_hex_size

    # Zoom in on mobile for easier touch targets and larger text
    if IS_MOBILE:
        set_adv_hex_size(40)
        from lops.renderer.font_scale import set_font_scale
        set_font_scale(1.5)
    from lops.renderer.adventure_ui import AdventureUI
    from lops.renderer.core import GameRenderer
    from lops.renderer.sidebar import SidebarPanel
    from lops.renderer.town_screen import TownScreen
    from lops.renderer.welcome_screen import WelcomeScreen

    game_log = GameLog()
    director = GameDirector()
    director.game_log = game_log
    director.mode = GameMode.WELCOME
    welcome_screen = WelcomeScreen(screen, is_mobile=IS_MOBILE)

    # These are initialized after faction selection
    adv_renderer = None
    adv_ui = None
    town_screen = None
    sidebar = None
    anim_state = None
    adv_input = None
    hero_modal = None

    # Combat renderer/input (created on demand)
    combat_renderer = None
    combat_input = None
    combat_ai = None
    combat_end_timer = 0.0  # delay before returning to adventure after combat

    def _init_adventure():
        """Initialize adventure UI after faction selection and game setup."""
        nonlocal \
            adv_renderer, \
            adv_ui, \
            town_screen, \
            sidebar, \
            anim_state, \
            adv_input, \
            hero_modal
        adv_renderer = AdventureRenderer(
            screen, director.world_map, viewport_w=VIEWPORT_W,
            layered_map=director.layered_map,
        )
        adv_ui = AdventureUI(screen, viewport_w=VIEWPORT_W, is_mobile=IS_MOBILE)
        town_screen = TownScreen(screen)
        if SIDEBAR_W > 0:
            sidebar = SidebarPanel(
                screen, x=VIEWPORT_W, width=SIDEBAR_W, world_map=director.world_map,
                layered_map=director.layered_map,
            )
        else:
            sidebar = None  # mobile: no sidebar
        anim_state = AdventureAnimState()
        adv_input = AdventureInputHandler(
            director, adv_renderer, adv_ui, anim_state=anim_state,
            is_mobile=IS_MOBILE,
        )
        from lops.renderer.hero_modal import HeroModal

        hero_modal = HeroModal(screen)
        player = director.adventure_state.players[0]
        adv_renderer.center_on_hex(player.position)

    clock = pygame.time.Clock()
    running = True

    while running:
        dt = clock.tick(60) / 1000.0

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                break
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                if director.mode == GameMode.WELCOME:
                    running = False
                    break
                elif director.mode == GameMode.COMBAT:
                    pass  # no escape from combat
                elif director.mode == GameMode.TOWN_SCREEN:
                    director.close_town_screen()
                    adv_input.refresh_move_range()
                elif director.mode == GameMode.HERO_MODAL:
                    director.close_hero_modal()
                    adv_input.refresh_move_range()
                else:
                    running = False
                    break

            if director.mode == GameMode.WELCOME:
                if event.type == pygame.MOUSEWHEEL:
                    welcome_screen.handle_scroll(event.y)
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    result = welcome_screen.handle_click(event.pos)
                    if result is not None and hasattr(result, "faction"):
                        director.setup_new_game(
                            seed=42,
                            player_faction=result.faction,
                            map_cols=result.map_size.cols,
                            map_rows=result.map_size.rows,
                            difficulty=result.difficulty,
                        )
                        _init_adventure()
                continue

            if director.mode == GameMode.HERO_MODAL:
                if event.type == pygame.MOUSEWHEEL:
                    hero_modal.handle_scroll(event.y)
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    human = director.adventure_state.players[0]
                    hs = human.active_hero_state
                    if hs:
                        result = hero_modal.handle_click(event.pos, hs.hero)
                        if result == "-1":
                            director.close_hero_modal()
                            adv_input.refresh_move_range()

            elif director.mode == GameMode.ADVENTURE:
                # Sidebar scroll
                if (
                    sidebar is not None
                    and event.type == pygame.MOUSEWHEEL
                    and pygame.mouse.get_pos()[0] >= VIEWPORT_W
                ):
                    sidebar.handle_scroll(event.y)
                # Route clicks: sidebar vs map
                elif (
                    sidebar is not None
                    and event.type == pygame.MOUSEBUTTONDOWN
                    and event.button == 1
                    and event.pos[0] >= VIEWPORT_W
                ):
                    if not anim_state.is_animating:
                        sidebar_result = sidebar.handle_click(
                            event.pos, director.adventure_state
                        )
                        if sidebar_result == "layer_toggle":
                            pass  # toggle already handled in sidebar
                        elif sidebar_result == "minimap_click":
                            hex_pos = sidebar.minimap_to_world_hex(event.pos)
                            if hex_pos is not None:
                                adv_renderer.center_on_hex(hex_pos)
                        elif sidebar_result and sidebar_result.startswith(
                            "hero_select:"
                        ):
                            hero_idx = int(sidebar_result.split(":")[1])
                            human = director.adventure_state.players[0]
                            adv_input._select_hero(human, hero_idx)
                        elif sidebar_result and sidebar_result.startswith(
                            "town_click:"
                        ):
                            tid = int(sidebar_result.split(":")[1])
                            for obj in director.adventure_state.map_objects:
                                if isinstance(obj, TownSite) and id(obj) == tid:
                                    adv_renderer.center_on_hex(obj.position)
                                    director.open_town_screen(obj)
                                    break
                else:
                    result = adv_input.handle_event(event)
                    if result == "combat":
                        # Transition to combat
                        combat_renderer = GameRenderer(screen, director.combat_engine)
                        combat_input = InputHandler(
                            director.combat_engine, combat_renderer
                        )
                        combat_ai = AIOpponent(director.combat_engine)
                    elif result == "quit":
                        running = False
                        break

            elif director.mode == GameMode.COMBAT:
                if combat_input:
                    combat_input.handle_event(event)

            elif director.mode == GameMode.TOWN_SCREEN:
                if event.type == pygame.MOUSEWHEEL:
                    town_screen.handle_scroll(event.y)
                elif event.type == pygame.MOUSEMOTION and IS_MOBILE and pygame.mouse.get_pressed()[0]:
                    # Touch drag scrolling for town screen on mobile
                    if hasattr(town_screen, '_touch_last_y'):
                        dy = event.pos[1] - town_screen._touch_last_y
                        if abs(dy) > 3:
                            town_screen.handle_scroll(1 if dy < 0 else -1)
                    town_screen._touch_last_y = event.pos[1]
                elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                    town_screen.handle_mouse_up()
                    town_screen.handle_marketplace_mouse_up()
                    if hasattr(town_screen, '_touch_last_y'):
                        del town_screen._touch_last_y
                elif event.type == pygame.MOUSEMOTION:
                    town_screen.handle_mouse_motion(event.pos)
                    if director.active_town and director.active_town.town:
                        _mp = director.adventure_state.current_player
                        town_screen.handle_marketplace_mouse_motion(event.pos, _mp)
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    # Check scrollbar drag first
                    if town_screen.handle_mouse_down(event.pos):
                        pass  # scrollbar consumed the click
                    elif (
                        director.active_town
                        and director.active_town.town
                        and town_screen.handle_marketplace_mouse_down(
                            event.pos,
                            director.adventure_state.current_player,
                        )
                    ):
                        pass  # marketplace slider consumed the click
                    elif director.active_town and director.active_town.town:
                        town = director.active_town.town
                        player = director.adventure_state.current_player
                        # Set hero_at_town flag + army reference for garrison tab
                        from lops.adventure.buildings import BuildingId

                        _hat = director._hero_at_town(director.active_town)
                        town_screen.hero_at_town = _hat is not None
                        town_screen.hero_at_town_army = _hat.army if _hat else None
                        town_screen.has_tavern = BuildingId.TAVERN in town.buildings
                        town_screen.has_merchant = (
                            BuildingId.ARTIFACT_MERCHANT in town.buildings
                        )
                        town_screen.has_marketplace = (
                            BuildingId.MARKETPLACE in town.buildings
                        )
                        town_screen.marketplace_count = (
                            director.get_marketplace_count(player)
                        )
                        result = town_screen.handle_click(event.pos, town, player)
                        if result == -1:
                            director.close_town_screen()
                            adv_input.refresh_move_range()
                        elif isinstance(result, str) and result.startswith("upgrade:"):
                            army_slot = int(result.split(":")[1])
                            director.upgrade_creature_at_town(army_slot)
                        elif isinstance(result, str) and result.startswith(
                            "buy_artifact:"
                        ):
                            art_idx = int(result.split(":")[1])
                            director.buy_artifact(art_idx)
                        elif isinstance(result, str) and result.startswith(
                            "hire_hero:"
                        ):
                            hero_idx = int(result.split(":")[1])
                            director.hire_hero(director.active_town, hero_idx)
                            adv_input.refresh_move_range()
                        elif isinstance(result, str) and result.startswith(
                            "garrison_to:"
                        ):
                            parts = result.split(":")
                            slot = int(parts[1])
                            count = int(parts[2]) if len(parts) > 2 else None
                            director.transfer_to_garrison(slot, count)
                        elif isinstance(result, str) and result.startswith(
                            "garrison_from:"
                        ):
                            parts = result.split(":")
                            slot = int(parts[1])
                            count = int(parts[2]) if len(parts) > 2 else None
                            director.transfer_from_garrison(slot, count)
                        elif isinstance(result, str) and result.startswith(
                            "trade:"
                        ):
                            parts = result.split(":")
                            director.execute_trade(
                                player, parts[1], parts[2], int(parts[3])
                            )
                        elif isinstance(result, int) and result >= 0:
                            # Recruit tab: dwelling index
                            dwelling = town.dwellings[result]
                            unit_cost = dwelling.active_cost_per_unit
                            max_afford = player.gold // unit_cost
                            count = min(dwelling.available, max_afford)
                            director.recruit_from_town(result, count)
                        elif result is not None:
                            # Build tab: BuildingId
                            director.build_in_town(result)

        if not running:
            break

        # --- Update ---
        if director.mode == GameMode.ADVENTURE:
            adv_renderer.update(dt)
            adv_ui.update(dt)
            adv_input.update()

            # --- Animation update ---
            if anim_state.is_animating:
                entered_hex = anim_state.update(dt)
                anim = anim_state.active

                # Incremental fog reveal
                if entered_hex is not None and anim is not None:
                    anim.player.reveal_around(entered_hex)

                # Camera follows animated hero
                # For AI heroes, only follow when visible to human player
                if anim is not None:
                    should_follow = True
                    if anim.player.is_ai:
                        human = director.adventure_state.players[0]
                        cur_hex = anim.hex_path[anim.current_step]
                        should_follow = cur_hex in human.revealed
                    if should_follow:
                        wx, wy = anim.current_world_pos
                        adv_renderer.camera.center_on_world(wx, wy)

                # Animation finished — apply move and resolve event
                if anim is not None and anim.finished:
                    dest = anim.destination
                    pending = anim.pending_event
                    anim_player = anim.player
                    _anim_hs = anim_player.active_hero_state
                    _anim_layer = _anim_hs.layer if _anim_hs else 0
                    anim_state.clear()

                    resolved = director.apply_move(anim_player, dest, pending)

                    if resolved == "treasure_chest":
                        obj = director.adventure_state.find_object_at(dest, layer=_anim_layer)
                        if isinstance(obj, TreasureChest) and not anim_player.is_ai:
                            if obj.is_artifact:
                                art_name = ""
                                if obj.artifact_id is not None:
                                    from lops.data.artifacts import ARTIFACT_REGISTRY

                                    art_name = ARTIFACT_REGISTRY[obj.artifact_id].name
                                adv_ui.show_chest_dialog(
                                    obj.gold_amount,
                                    obj.xp_amount,
                                    is_artifact=True,
                                    artifact_name=art_name,
                                )
                            else:
                                adv_ui.show_chest_dialog(obj.gold_amount, obj.xp_amount)
                        elif isinstance(obj, TreasureChest) and anim_player.is_ai:
                            director.resolve_treasure_chest(anim_player, "gold")
                            director.end_turn()
                            adv_input.refresh_move_range()
                            if not director.adventure_state.game_over:
                                adv_renderer.center_on_hex(
                                    director.adventure_state.current_player.position
                                )
                    elif resolved == "artifact":
                        adv_ui.set_status(director.last_event_description)
                        adv_input.refresh_move_range()
                    elif resolved == "resource":
                        adv_ui.set_status(director.last_event_description)
                        adv_input.refresh_move_range()
                    elif resolved == "mine_captured":
                        adv_ui.set_status(director.last_event_description)
                        adv_input.refresh_move_range()
                    elif resolved == "monster":
                        obj = director.adventure_state.find_object_at(dest, layer=_anim_layer)
                        if isinstance(obj, WanderingMonster):
                            if anim_player.is_ai:
                                director._run_ai_combat(anim_player, obj)
                                director.end_turn()
                                adv_input.refresh_move_range()
                                if not director.adventure_state.game_over:
                                    adv_renderer.center_on_hex(
                                        director.adventure_state.current_player.position
                                    )
                            else:
                                director.start_monster_combat(anim_player, obj)
                                combat_renderer = GameRenderer(
                                    screen, director.combat_engine
                                )
                                combat_input = InputHandler(
                                    director.combat_engine, combat_renderer
                                )
                                combat_ai = AIOpponent(director.combat_engine)
                    elif resolved == "own_town":
                        if not anim_player.is_ai:
                            obj = director.adventure_state.find_object_at(dest, layer=_anim_layer)
                            if isinstance(obj, TownSite):
                                director.open_town_screen(obj)
                        else:
                            # AI recruits and picks up garrison when visiting town
                            ai_ctrl = director._ai_controllers.get(
                                anim_player.player_id
                            )
                            if ai_ctrl:
                                ai_ctrl.auto_recruit()
                                ai_ctrl.auto_pickup_garrison()
                            director.end_turn()
                            adv_input.refresh_move_range()
                            if not director.adventure_state.game_over:
                                adv_renderer.center_on_hex(
                                    director.adventure_state.current_player.position
                                )
                    elif resolved in ("enemy_town", "neutral_town"):
                        obj = director.adventure_state.find_object_at(dest, layer=_anim_layer)
                        if isinstance(obj, TownSite):
                            if anim_player.is_ai:
                                town = obj.town
                                has_fort = (
                                    town and director._get_fort_level(town) is not None
                                )
                                _dp, _dh = director._find_defender_at_town(
                                    obj, anim_player
                                )
                                has_defenders = town and (
                                    town.garrison or _dh is not None
                                )
                                if has_fort and has_defenders:
                                    defending_human = director._town_has_human_defender(
                                        obj, anim_player
                                    )
                                    director.start_siege_combat(anim_player, obj)
                                    if director.combat_engine and defending_human:
                                        combat_renderer = GameRenderer(
                                            screen,
                                            director.combat_engine,
                                            player_side=Side.DEFENDER,
                                        )
                                        combat_input = InputHandler(
                                            director.combat_engine,
                                            combat_renderer,
                                            player_side=Side.DEFENDER,
                                        )
                                        combat_ai = AIOpponent(
                                            director.combat_engine, side=Side.ATTACKER
                                        )
                                    elif director.combat_engine:
                                        director.combat_engine.run_headless()
                                        director.on_combat_finished()
                                        director.end_turn()
                                        adv_input.refresh_move_range()
                                        if not director.adventure_state.game_over:
                                            adv_renderer.center_on_hex(
                                                director.adventure_state.current_player.position
                                            )
                                else:
                                    director.capture_town(anim_player, obj)
                                    director.end_turn()
                                    adv_input.refresh_move_range()
                                    if not director.adventure_state.game_over:
                                        adv_renderer.center_on_hex(
                                            director.adventure_state.current_player.position
                                        )
                            else:
                                town = obj.town
                                has_fort = (
                                    town and director._get_fort_level(town) is not None
                                )
                                def_player, def_hs = director._find_defender_at_town(
                                    obj, anim_player
                                )
                                has_defenders = town and (
                                    town.garrison or def_hs is not None
                                )
                                if has_fort and has_defenders:
                                    director.start_siege_combat(anim_player, obj)
                                    combat_renderer = GameRenderer(
                                        screen, director.combat_engine
                                    )
                                    combat_input = InputHandler(
                                        director.combat_engine, combat_renderer
                                    )
                                    combat_ai = AIOpponent(director.combat_engine)
                                else:
                                    director.capture_town(anim_player, obj)
                                    adv_ui.set_status(f"Captured {obj.name}!")
                                    adv_input.refresh_move_range()
                    elif resolved == "enemy_hero":
                        if anim_player.is_ai:
                            for other in director.adventure_state.players:
                                if (
                                    other.player_id != anim_player.player_id
                                    and not other.defeated
                                ):
                                    if other.hero_at(dest) is not None:
                                        if not other.is_ai:
                                            director.start_hero_combat(
                                                anim_player, other, dest
                                            )
                                            combat_renderer = GameRenderer(
                                                screen,
                                                director.combat_engine,
                                                player_side=Side.DEFENDER,
                                            )
                                            combat_input = InputHandler(
                                                director.combat_engine,
                                                combat_renderer,
                                                player_side=Side.DEFENDER,
                                            )
                                            combat_ai = AIOpponent(
                                                director.combat_engine,
                                                side=Side.ATTACKER,
                                            )
                                        else:
                                            director._run_ai_hero_combat(
                                                anim_player, other, dest
                                            )
                                            director.end_turn()
                                            adv_input.refresh_move_range()
                                            if not director.adventure_state.game_over:
                                                adv_renderer.center_on_hex(
                                                    director.adventure_state.current_player.position
                                                )
                                        break
                        else:
                            for other in director.adventure_state.players:
                                if (
                                    other.player_id != anim_player.player_id
                                    and not other.defeated
                                ):
                                    if other.hero_at(dest) is not None:
                                        director.start_hero_combat(
                                            anim_player, other, dest
                                        )
                                        combat_renderer = GameRenderer(
                                            screen, director.combat_engine
                                        )
                                        combat_input = InputHandler(
                                            director.combat_engine, combat_renderer
                                        )
                                        combat_ai = AIOpponent(director.combat_engine)
                                        break
                    elif resolved == "campfire":
                        adv_ui.set_status(director.last_event_description)
                        adv_input.refresh_move_range()
                        if anim_player.is_ai:
                            director.end_turn()
                            if not director.adventure_state.game_over:
                                adv_renderer.center_on_hex(
                                    director.adventure_state.current_player.position
                                )
                    elif resolved == "stat_booster":
                        obj = director.adventure_state.find_object_at(dest, layer=_anim_layer)
                        if obj and hasattr(obj, "name"):
                            adv_ui.set_status(director.last_event_description)
                        adv_input.refresh_move_range()
                        if anim_player.is_ai:
                            director.end_turn()
                            if not director.adventure_state.game_over:
                                adv_renderer.center_on_hex(
                                    director.adventure_state.current_player.position
                                )
                    elif resolved == "arena":
                        if anim_player.is_ai:
                            # AI picks whichever stat is lower
                            h = anim_player.hero
                            choice = "attack" if h.attack <= h.defense else "defense"
                            director.resolve_arena(anim_player, choice)
                            director.end_turn()
                            adv_input.refresh_move_range()
                            if not director.adventure_state.game_over:
                                adv_renderer.center_on_hex(
                                    director.adventure_state.current_player.position
                                )
                        else:
                            adv_ui.show_arena_dialog()
                    elif resolved == "magic_well":
                        adv_ui.set_status(director.last_event_description)
                        adv_input.refresh_move_range()
                        if anim_player.is_ai:
                            director.end_turn()
                            if not director.adventure_state.game_over:
                                adv_renderer.center_on_hex(
                                    director.adventure_state.current_player.position
                                )
                    elif resolved in ("pandora_guarded", "creature_bank"):
                        from lops.adventure.map_objects import CreatureBank, PandorasBox

                        obj = director.adventure_state.find_object_at(dest, layer=_anim_layer)
                        if obj and (
                            isinstance(obj, PandorasBox)
                            or isinstance(obj, CreatureBank)
                        ):
                            if anim_player.is_ai:
                                director._run_ai_combat(anim_player, obj)
                                director.end_turn()
                                adv_input.refresh_move_range()
                                if not director.adventure_state.game_over:
                                    adv_renderer.center_on_hex(
                                        director.adventure_state.current_player.position
                                    )
                            else:
                                director.start_monster_combat(anim_player, obj)
                                combat_renderer = GameRenderer(
                                    screen, director.combat_engine
                                )
                                combat_input = InputHandler(
                                    director.combat_engine, combat_renderer
                                )
                                combat_ai = AIOpponent(director.combat_engine)
                    elif resolved == "pandora_unguarded":
                        adv_ui.set_status(director.last_event_description)
                        adv_input.refresh_move_range()
                        if anim_player.is_ai:
                            director.end_turn()
                            if not director.adventure_state.game_over:
                                adv_renderer.center_on_hex(
                                    director.adventure_state.current_player.position
                                )
                    elif resolved == "dwelling_visit":
                        if anim_player.is_ai:
                            from lops.adventure.map_objects import CreatureDwelling

                            obj = director.adventure_state.find_object_at(dest, layer=_anim_layer)
                            if isinstance(obj, CreatureDwelling) and obj.available > 0:
                                director.recruit_from_dwelling(
                                    anim_player, obj.available
                                )
                            director.end_turn()
                            adv_input.refresh_move_range()
                            if not director.adventure_state.game_over:
                                adv_renderer.center_on_hex(
                                    director.adventure_state.current_player.position
                                )
                        else:
                            adv_ui.show_dwelling_dialog()
                    elif resolved == "hill_fort":
                        if anim_player.is_ai:
                            # AI auto-upgrades all possible stacks
                            for i in range(7):
                                director.upgrade_creature_at_hill_fort(anim_player, i)
                            director.end_turn()
                            adv_input.refresh_move_range()
                            if not director.adventure_state.game_over:
                                adv_renderer.center_on_hex(
                                    director.adventure_state.current_player.position
                                )
                        else:
                            adv_ui.show_hill_fort_dialog()
                    elif resolved == "gate":
                        adv_ui.set_status(director.last_event_description)
                        adv_input.refresh_move_range()
                        # Re-center camera and sync minimap to new layer
                        hs_gate = (anim_player.active_hero_state
                                   if not anim_player.is_ai else None)
                        if hs_gate and hs_gate.position:
                            if sidebar is not None:
                                sidebar.minimap_layer = hs_gate.layer
                            adv_renderer.center_on_hex(hs_gate.position)
                        if anim_player.is_ai:
                            director.end_turn()
                            if not director.adventure_state.game_over:
                                adv_renderer.center_on_hex(
                                    director.adventure_state.current_player.position
                                )
                    elif resolved == "library_too_low":
                        adv_ui.set_status(director.last_event_description)
                        adv_input.refresh_move_range()
                    else:
                        # No special event — just finished moving
                        if anim_player.is_ai:
                            director.end_turn()
                            adv_input.refresh_move_range()
                            if not director.adventure_state.game_over:
                                adv_renderer.center_on_hex(
                                    director.adventure_state.current_player.position
                                )
                        else:
                            adv_input.refresh_move_range()

            # AI turn (not animating)
            elif not anim_state.is_animating:
                current = director.adventure_state.current_player
                if (
                    current.is_ai
                    and not current.defeated
                    and not director.adventure_state.game_over
                ):
                    if anim_state.speed == AnimSpeed.INSTANT:
                        # Existing instant AI turn
                        ai_event = director.run_ai_turn()
                        if ai_event == "combat":
                            combat_renderer = GameRenderer(
                                screen,
                                director.combat_engine,
                                player_side=Side.DEFENDER,
                            )
                            combat_input = InputHandler(
                                director.combat_engine,
                                combat_renderer,
                                player_side=Side.DEFENDER,
                            )
                            combat_ai = AIOpponent(
                                director.combat_engine, side=Side.ATTACKER
                            )
                        else:
                            director.end_turn()
                            adv_input.refresh_move_range()
                            if not director.adventure_state.game_over:
                                adv_renderer.center_on_hex(
                                    director.adventure_state.current_player.position
                                )
                    else:
                        # Animated AI turn
                        result = director.prepare_ai_turn()
                        if result is not None:
                            hex_path, event = result
                            pixel_path = [
                                adv_renderer.hex_world_center(h) for h in hex_path
                            ]
                            ai_player = director.adventure_state.current_player
                            hs = ai_player.active_hero_state
                            anim_state.start_move(
                                hs, ai_player, hex_path, pixel_path, event
                            )
                        else:
                            director.end_turn()
                            adv_input.refresh_move_range()
                            if not director.adventure_state.game_over:
                                adv_renderer.center_on_hex(
                                    director.adventure_state.current_player.position
                                )

        elif director.mode == GameMode.COMBAT:
            if combat_renderer:
                combat_renderer.update(dt)
                combat_input.update()

                # Sync auto-combat flag to renderer for UI display
                combat_renderer.auto_combat = combat_input.auto_combat

                # AI takes actions (enemy AI + player auto-battle)
                engine = director.combat_engine
                if engine and not engine.is_over() and not combat_renderer.is_animating:
                    current_side = engine.current_side()
                    if combat_ai and current_side == combat_ai.side:
                        combat_ai.take_turn()
                    elif (
                        combat_input.auto_combat
                        and current_side == combat_input.player_side
                    ):
                        # Auto-battle: AI plays for the human
                        auto_ai = AIOpponent(engine, side=combat_input.player_side)
                        auto_ai.take_turn()

                # Check if combat is over
                if engine and engine.is_over() and not combat_renderer.is_animating:
                    if combat_end_timer <= 0:
                        combat_end_timer = 2.0  # 2 second pause to show result
                    else:
                        combat_end_timer -= dt
                        if combat_end_timer <= 0:
                            # Check if AI was the attacker (needs turn ended after combat)
                            ai_was_attacker = (
                                combat_ai is not None
                                and combat_ai.side == Side.ATTACKER
                            )
                            director.on_combat_finished()
                            # Show reward + level-up messages
                            status_parts = []
                            if director.last_event_description:
                                status_parts.append(director.last_event_description)
                            if director._pending_level_ups:
                                from lops.experience import format_level_up

                                msgs = [
                                    format_level_up(r)
                                    for r in director._pending_level_ups
                                ]
                                status_parts.extend(msgs)
                                director._pending_level_ups = None
                            if status_parts:
                                adv_ui.set_status(" | ".join(status_parts), 4.0)
                            combat_renderer = None
                            combat_input = None
                            combat_ai = None
                            combat_end_timer = 0.0
                            # If AI was attacking, end its turn now
                            if ai_was_attacker:
                                current = director.adventure_state.current_player
                                if current.is_ai and not current.defeated:
                                    director.end_turn()
                            adv_input.refresh_move_range()
                            if not director.adventure_state.game_over:
                                adv_renderer.center_on_hex(
                                    director.adventure_state.current_player.position
                                )

        # --- Draw ---
        if director.mode == GameMode.WELCOME:
            welcome_screen.draw()

        elif director.mode == GameMode.ADVENTURE:
            # Compute fog of war for hero's current layer
            human = director.adventure_state.players[0]
            hero_hs = human.active_hero_state
            hero_layer = hero_hs.layer if hero_hs else 0
            revealed = human.revealed_for_layer(hero_layer)
            visible = director.adventure_state.visible_hexes(human.player_id, layer=hero_layer)
            adv_renderer.draw(
                director.adventure_state,
                revealed=revealed,
                visible=visible,
                anim_state=anim_state,
                current_layer=hero_layer,
            )
            adv_ui.draw(director.adventure_state, anim_state=anim_state)
            if sidebar is not None:
                minimap_revealed = human.revealed_for_layer(sidebar.minimap_layer)
                sidebar.draw(
                    director.adventure_state,
                    revealed=revealed,
                    visible=visible,
                    camera=adv_renderer.camera,
                    minimap_revealed=minimap_revealed,
                )

        elif director.mode == GameMode.COMBAT:
            if combat_renderer:
                combat_renderer.draw()

        elif director.mode == GameMode.TOWN_SCREEN:
            # Draw adventure map behind town screen
            human = director.adventure_state.players[0]
            hero_hs_t = human.active_hero_state
            hero_layer_t = hero_hs_t.layer if hero_hs_t else 0
            revealed = human.revealed_for_layer(hero_layer_t)
            visible = director.adventure_state.visible_hexes(human.player_id, layer=hero_layer_t)
            adv_renderer.draw(
                director.adventure_state,
                revealed=revealed,
                visible=visible,
                anim_state=anim_state,
                current_layer=hero_layer_t,
            )
            adv_ui.draw(director.adventure_state, anim_state=anim_state)
            if sidebar is not None:
                sidebar.draw(
                    director.adventure_state,
                    revealed=revealed,
                    visible=visible,
                    camera=adv_renderer.camera,
                    minimap_revealed=human.revealed_for_layer(sidebar.minimap_layer),
                )
            if director.active_town and director.active_town.town:
                player = director.adventure_state.current_player
                _hat2 = director._hero_at_town(director.active_town)
                town_screen.hero_at_town = _hat2 is not None
                town_screen.hero_at_town_army = _hat2.army if _hat2 else None
                from lops.adventure.buildings import BuildingId as _BID

                town_screen.has_tavern = (
                    _BID.TAVERN in director.active_town.town.buildings
                )
                town_screen.has_merchant = (
                    _BID.ARTIFACT_MERCHANT in director.active_town.town.buildings
                )
                town_screen.has_marketplace = (
                    _BID.MARKETPLACE in director.active_town.town.buildings
                )
                town_screen.marketplace_count = (
                    director.get_marketplace_count(player)
                )
                town_screen.draw(director.active_town.town, player)

        elif director.mode == GameMode.HERO_MODAL:
            # Draw adventure map behind modal
            human = director.adventure_state.players[0]
            hero_hs_h = human.active_hero_state
            hero_layer_h = hero_hs_h.layer if hero_hs_h else 0
            revealed = human.revealed_for_layer(hero_layer_h)
            visible = director.adventure_state.visible_hexes(human.player_id, layer=hero_layer_h)
            adv_renderer.draw(
                director.adventure_state,
                revealed=revealed,
                visible=visible,
                anim_state=anim_state,
                current_layer=hero_layer_h,
            )
            adv_ui.draw(director.adventure_state, anim_state=anim_state)
            if sidebar is not None:
                sidebar.draw(
                    director.adventure_state,
                    revealed=revealed,
                    visible=visible,
                    camera=adv_renderer.camera,
                    minimap_revealed=human.revealed_for_layer(sidebar.minimap_layer),
                )
            hs = human.active_hero_state
            if hs:
                hero_modal.draw(hs.hero)

        pygame.display.flip()
        await asyncio.sleep(0)

    game_log.close()
    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
